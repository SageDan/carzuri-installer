/**
 * Carzuri Customer Dashboard v1.0.0 Frontend Script
 * Aggregates buyer activity across Carzuri suite REST endpoints.
 * Handles diverse endpoint response shapes and fault-tolerant isolation.
 */
(function() {
    'use strict';

    /* Global settings injected by wp_localize_script or window fallback */
    const settings = window.carzuriDashboardSettings || {
        rest_url: '/wp-json/carzuri/v1/',
        nonce: '',
        is_logged_in: true,
        endpoints: {
            favorites: 'carzuri/v1/favorites',
            searches: 'carzuri/v1/saved-searches',
            inquiries: 'carzuri/v1/my-inquiries',
            finance: 'carzuri/v1/my-finance-applications',
            valuations: 'carzuri/v1/my-valuations'
        },
        links: {
            favorites: '/my-favorites/',
            searches: '/my-saved-searches/',
            inquiries: '/my-inquiries/',
            finance: '/my-finance-applications/',
            listings: '/buy-cars/'
        },
        i18n: {
            error_loading: 'Unable to load this section.',
            retry: 'Retry',
            view_all: 'View All',
            empty_favorites: 'No saved favorite vehicles yet.',
            empty_searches: 'No saved search criteria found.',
            empty_inquiries: 'No vehicle inquiries submitted yet.',
            empty_finance: 'No finance applications on record.',
            empty_valuations: 'No AI trade-in valuations recorded.'
        }
    };

    /* Store dashboard data state */
    const state = {
        favorites: { status: 'idle', data: [], total: 0, error: null },
        searches: { status: 'idle', data: [], total: 0, error: null },
        inquiries: { status: 'idle', data: [], total: 0, error: null },
        finance: { status: 'idle', data: [], total: 0, error: null },
        valuations: { status: 'idle', data: [], total: 0, error: null },
        activeTab: 'overview'
    };

    /* Helper: Escape HTML strings to prevent XSS */
    function escapeHtml(str) {
        if (!str && str !== 0) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    /* Helper: Format currency */
    function formatMoney(amount) {
        if (amount === undefined || amount === null || isNaN(amount)) return 'KSh 0';
        return 'KSh ' + Number(amount).toLocaleString('en-US');
    }

    /* Helper: Format date */
    function formatDate(dateString) {
        if (!dateString) return '';
        try {
            const d = new Date(dateString);
            return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        } catch (e) {
            return dateString;
        }
    }

    /* --- Unwrapping Handlers for Endpoint-Specific Response Shapes --- */

    function unwrapFavoritesResponse(res) {
        if (Array.isArray(res)) {
            return { items: res, total: res.length };
        }
        if (res && Array.isArray(res.items)) {
            return { items: res.items, total: res.total || res.items.length };
        }
        if (res && Array.isArray(res.data)) {
            return { items: res.data, total: res.total || res.data.length };
        }
        return { items: [], total: 0 };
    }

    function unwrapSearchesResponse(res) {
        if (Array.isArray(res)) {
            return { items: res, total: res.length };
        }
        if (res && Array.isArray(res.searches)) {
            return { items: res.searches, total: res.searches.length };
        }
        if (res && Array.isArray(res.data)) {
            return { items: res.data, total: res.data.length };
        }
        return { items: [], total: 0 };
    }

    /* Target Endpoint Shape: { inquiries: [...], total_results } */
    function unwrapInquiriesResponse(res) {
        if (res && Array.isArray(res.inquiries)) {
            const total = typeof res.total_results === 'number' ? res.total_results : res.inquiries.length;
            return { items: res.inquiries, total: total };
        }
        if (Array.isArray(res)) {
            return { items: res, total: res.length };
        }
        if (res && Array.isArray(res.data)) {
            return { items: res.data, total: res.total || res.data.length };
        }
        return { items: [], total: 0 };
    }

    /* Target Endpoint Shape: { success: true, data: [...] } */
    function unwrapFinanceResponse(res) {
        if (res && res.success && Array.isArray(res.data)) {
            return { items: res.data, total: res.data.length };
        }
        if (Array.isArray(res)) {
            return { items: res, total: res.length };
        }
        if (res && Array.isArray(res.data)) {
            return { items: res.data, total: res.data.length };
        }
        return { items: [], total: 0 };
    }

    /* Target Endpoint Shape: { success: true, data: [...] } */
    function unwrapValuationsResponse(res) {
        if (res && res.success && Array.isArray(res.data)) {
            return { items: res.data, total: res.data.length };
        }
        if (Array.isArray(res)) {
            return { items: res, total: res.length };
        }
        if (res && Array.isArray(res.data)) {
            return { items: res.data, total: res.data.length };
        }
        return { items: [], total: 0 };
    }

    /* --- Fetch Single Endpoint with Fault Tolerance --- */
    function fetchModule(key, endpointPath, unwrapper) {
        state[key].status = 'loading';
        state[key].error = null;
        renderSectionSkeleton(key);

        /* Construct full REST URL */
        let url = endpointPath;
        if (!url.startsWith('http') && !url.startsWith('/')) {
            const baseUrl = settings.rest_url.endsWith('/') ? settings.rest_url : settings.rest_url + '/';
            url = baseUrl + endpointPath.replace(/^carzuri\/v1\//, '');
        }

        const headers = {
            'Content-Type': 'application/json'
        };
        if (settings.nonce) {
            headers['X-WP-Nonce'] = settings.nonce;
        }

        return fetch(url, { method: 'GET', headers: headers })
            .then(function(response) {
                if (!response.ok) {
                    throw new Error('Server returned status ' + response.status);
                }
                return response.json();
            })
            .then(function(json) {
                const unwrapped = unwrapper(json);
                state[key].status = 'success';
                state[key].data = unwrapped.items;
                state[key].total = unwrapped.total;
                renderSection(key);
                updateBadge(key, unwrapped.total);
            })
            .catch(function(err) {
                console.warn('[Carzuri Customer Dashboard] Module load failed for ' + key + ':', err);
                state[key].status = 'error';
                state[key].error = err.message || settings.i18n.error_loading;
                renderSectionError(key);
                updateBadge(key, '!');
            });
    }

    /* --- UI Renderers --- */

    function renderSectionSkeleton(key) {
        const bodyEl = document.getElementById('carzuri-body-' + key);
        if (!bodyEl) return;
        bodyEl.innerHTML = '<div class="carzuri-dash-skeleton-grid">' +
            '<div class="carzuri-dash-skeleton-item"></div>' +
            '<div class="carzuri-dash-skeleton-item"></div>' +
            '</div>';
    }

    function renderSectionError(key) {
        const bodyEl = document.getElementById('carzuri-body-' + key);
        if (!bodyEl) return;
        bodyEl.innerHTML = '<div class="carzuri-dash-error">' +
            '<div>' +
            '<strong>' + escapeHtml(settings.i18n.error_loading) + '</strong>' +
            '<p style="margin: 0.25rem 0 0 0; font-size: 0.8rem; opacity: 0.85;">' + escapeHtml(state[key].error) + '</p>' +
            '</div>' +
            '<button type="button" class="carzuri-dash-btn carzuri-dash-btn-sm carzuri-dash-btn-outline carzuri-retry-btn" data-key="' + key + '">' +
            escapeHtml(settings.i18n.retry) +
            '</button>' +
            '</div>';

        const retryBtn = bodyEl.querySelector('.carzuri-retry-btn');
        if (retryBtn) {
            retryBtn.addEventListener('click', function() {
                reloadModule(key);
            });
        }
    }

    function updateBadge(key, count) {
        const badgeEl = document.getElementById('carzuri-badge-' + key);
        const countEl = document.getElementById('carzuri-count-' + key);
        if (badgeEl) badgeEl.textContent = count;
        if (countEl) countEl.textContent = '(' + count + ')';
    }

    function renderSection(key) {
        const bodyEl = document.getElementById('carzuri-body-' + key);
        if (!bodyEl) return;

        const items = state[key].data || [];
        const limit = parseInt(document.getElementById('carzuri-customer-dashboard')?.dataset?.itemsLimit || '3', 10);
        const recentItems = items.slice(0, limit);

        if (items.length === 0) {
            bodyEl.innerHTML = renderEmptyState(key);
            return;
        }

        let html = '';
        if (key === 'favorites') {
            html = '<div class="carzuri-dash-grid">' + recentItems.map(renderFavoriteCard).join('') + '</div>';
        } else if (key === 'searches') {
            html = '<div class="carzuri-dash-list">' + recentItems.map(renderSearchCard).join('') + '</div>';
        } else if (key === 'inquiries') {
            html = '<div class="carzuri-dash-list">' + recentItems.map(renderInquiryCard).join('') + '</div>';
        } else if (key === 'finance') {
            html = '<div class="carzuri-dash-grid">' + recentItems.map(renderFinanceCard).join('') + '</div>';
        } else if (key === 'valuations') {
            html = '<div class="carzuri-dash-grid">' + recentItems.map(renderValuationCard).join('') + '</div>';
        }

        bodyEl.innerHTML = html;
    }

    function renderEmptyState(key) {
        let msg = settings.i18n['empty_' + key] || 'No records found.';
        let actionUrl = settings.links[key] || '#';
        let btnText = 'Browse Items';

        if (key === 'favorites' || key === 'searches' || key === 'inquiries') {
            actionUrl = settings.links.listings || '/buy-cars/';
            btnText = 'Browse Vehicle Inventory';
        } else if (key === 'finance') {
            btnText = 'Apply For Financing';
        } else if (key === 'valuations') {
            btnText = 'Get Instant AI Trade-In Estimate';
        }

        return '<div class="carzuri-dash-empty">' +
            '<p>' + escapeHtml(msg) + '</p>' +
            '<a href="' + escapeHtml(actionUrl) + '" class="carzuri-dash-btn carzuri-dash-btn-sm carzuri-dash-btn-outline">' +
            escapeHtml(btnText) +
            '</a>' +
            '</div>';
    }

    /* Card Item Builders */

    function renderFavoriteCard(item) {
        const title = item.title || item.vehicle_name || (item.year ? (item.year + ' ' + (item.make || '') + ' ' + (item.model || '')) : 'Saved Vehicle');
        const price = item.price ? formatMoney(item.price) : 'Contact Dealer';
        const img = item.image || item.thumbnail || 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=400&q=80';
        const url = item.url || (settings.links.favorites + '#' + (item.id || ''));

        return '<div class="carzuri-dash-card carzuri-card-vehicle">' +
            '<img src="' + escapeHtml(img) + '" alt="' + escapeHtml(title) + '" class="carzuri-vehicle-img" />' +
            '<div class="carzuri-vehicle-meta">' +
            '<h4 class="carzuri-vehicle-title"><a href="' + escapeHtml(url) + '" style="color:inherit;text-decoration:none;">' + escapeHtml(title) + '</a></h4>' +
            '<div class="carzuri-vehicle-price">' + escapeHtml(price) + '</div>' +
            '<span style="font-size:0.75rem; color:var(--carzuri-text-muted);">' + escapeHtml(formatDate(item.added_at || item.created_at)) + '</span>' +
            '</div>' +
            '</div>';
    }

    function renderSearchCard(item) {
        const name = item.name || item.search_title || 'Saved Vehicle Search';
        const matches = item.matches_count !== undefined ? (item.matches_count + ' matching vehicles') : 'Active Alert';
        const created = formatDate(item.created_at);

        return '<div class="carzuri-dash-card" style="flex-direction:row; align-items:center; justify-content:space-between;">' +
            '<div>' +
            '<h4 style="margin:0 0 0.25rem 0; font-size:0.95rem; font-weight:700;">' + escapeHtml(name) + '</h4>' +
            '<span class="carzuri-badge carzuri-badge-approved">' + escapeHtml(matches) + '</span>' +
            '</div>' +
            '<span style="font-size:0.8rem; color:var(--carzuri-text-muted);">' + escapeHtml(created) + '</span>' +
            '</div>';
    }

    function renderInquiryCard(item) {
        const title = item.vehicle_title || item.subject || ('Inquiry #' + (item.id || ''));
        const status = item.status || 'Pending';
        const message = item.message || item.notes || '';
        const date = formatDate(item.created_at || item.submitted_at);

        let badgeClass = 'carzuri-badge-pending';
        if (status.toLowerCase().includes('answer') || status.toLowerCase().includes('close') || status.toLowerCase().includes('contact')) {
            badgeClass = 'carzuri-badge-answered';
        }

        return '<div class="carzuri-dash-card">' +
            '<div style="display:flex; justify-content:space-between; align-items:flex-start; gap:0.5rem;">' +
            '<div>' +
            '<h4 style="margin:0 0 0.25rem 0; font-size:0.95rem; font-weight:700;">' + escapeHtml(title) + '</h4>' +
            '<p style="margin:0; font-size:0.85rem; color:var(--carzuri-text-muted); display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical; overflow:hidden;">' + escapeHtml(message) + '</p>' +
            '</div>' +
            '<span class="carzuri-badge ' + badgeClass + '">' + escapeHtml(status) + '</span>' +
            '</div>' +
            '<div style="font-size:0.75rem; color:var(--carzuri-text-muted); margin-top:0.25rem;">Submitted ' + escapeHtml(date) + '</div>' +
            '</div>';
    }

    function renderFinanceCard(item) {
        const appNo = 'APP-' + (item.id || '0');
        const vehicle = (item.vehicle_title && item.vehicle_title !== 'N/A') ? item.vehicle_title : 'General Application';
        const amount = item.vehicle_price ? formatMoney(item.vehicle_price) : 'Pending Calculation';
        const status = item.status || 'submitted';

        let statusClass = 'carzuri-status-pending';
        if (status.toLowerCase().includes('approve')) statusClass = 'carzuri-status-approved';
        else if (status.toLowerCase().includes('reject') || status.toLowerCase().includes('declin')) statusClass = 'carzuri-status-rejected';

        return '<div class="carzuri-dash-card">' +
            '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.375rem;">' +
            '<span style="font-weight:700; font-size:0.8rem; color:var(--carzuri-primary);">' + escapeHtml(appNo) + '</span>' +
            '<span class="carzuri-status-badge ' + statusClass + '">' + escapeHtml(status.replace('_', ' ')) + '</span>' +
            '</div>' +
            '<h4 style="margin:0; font-size:0.875rem; font-weight:700;">' + escapeHtml(vehicle) + '</h4>' +
            '<div style="margin-top:0.375rem; font-size:0.8rem; font-weight:600; color:var(--carzuri-text-muted);">' +
            'Amount: ' + escapeHtml(amount) +
            '</div>' +
            '</div>';
    }

    function renderValuationCard(item) {
        const vehicle = (item.year || '') + ' ' + (item.make || '') + ' ' + (item.model || '');
        const estValue = item.estimated_market_value ? formatMoney(item.estimated_market_value) : 'N/A';
        const condition = item.condition || 'Good';
        const date = formatDate(item.created_at);

        return '<div class="carzuri-dash-card">' +
            '<div style="display:flex; justify-content:space-between; align-items:center;">' +
            '<span style="font-size:0.75rem; text-transform:uppercase; font-weight:700; color:var(--carzuri-accent);">' + escapeHtml(condition) + ' Condition</span>' +
            '<span style="font-size:0.75rem; color:var(--carzuri-text-muted);">' + escapeHtml(date) + '</span>' +
            '</div>' +
            '<h4 style="margin:0.25rem 0; font-size:0.95rem; font-weight:700;">' + escapeHtml(vehicle.trim()) + '</h4>' +
            '<div style="font-size:1.1rem; font-weight:800; color:var(--carzuri-accent); margin-top:0.25rem;">Est. Value: ' + escapeHtml(estValue) + '</div>' +
            '</div>';
    }

    /* --- Tab Switching Handler --- */
    function switchTab(tabKey) {
        state.activeTab = tabKey;

        /* Update buttons active state */
        const tabs = document.querySelectorAll('.carzuri-dash-tab');
        tabs.forEach(function(tab) {
            if (tab.dataset.tab === tabKey) {
                tab.classList.add('active');
            } else {
                tab.classList.remove('active');
            }
        });

        /* Update visibility of sections */
        const sections = document.querySelectorAll('.carzuri-dash-section');
        sections.forEach(function(sec) {
            if (tabKey === 'overview' || sec.dataset.section === tabKey) {
                sec.style.display = 'block';
            } else {
                sec.style.display = 'none';
            }
        });
    }

    /* --- Reload Controllers --- */
    function reloadModule(key) {
        if (key === 'favorites') fetchModule('favorites', settings.endpoints.favorites, unwrapFavoritesResponse);
        if (key === 'searches') fetchModule('searches', settings.endpoints.searches, unwrapSearchesResponse);
        if (key === 'inquiries') fetchModule('inquiries', settings.endpoints.inquiries, unwrapInquiriesResponse);
        if (key === 'finance') fetchModule('finance', settings.endpoints.finance, unwrapFinanceResponse);
        if (key === 'valuations') fetchModule('valuations', settings.endpoints.valuations, unwrapValuationsResponse);
    }

    function reloadAll() {
        fetchModule('favorites', settings.endpoints.favorites, unwrapFavoritesResponse);
        fetchModule('searches', settings.endpoints.searches, unwrapSearchesResponse);
        fetchModule('inquiries', settings.endpoints.inquiries, unwrapInquiriesResponse);
        fetchModule('finance', settings.endpoints.finance, unwrapFinanceResponse);
        fetchModule('valuations', settings.endpoints.valuations, unwrapValuationsResponse);
    }

    /* --- Initialization --- */
    function initDashboard() {
        const container = document.getElementById('carzuri-customer-dashboard');
        if (!container) return;

        /* Event: Refresh Button */
        const refreshBtn = document.getElementById('carzuri-dash-refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', function() {
                reloadAll();
            });
        }

        /* Event: Tab Clicks */
        const tabs = document.querySelectorAll('.carzuri-dash-tab');
        tabs.forEach(function(tab) {
            tab.addEventListener('click', function() {
                switchTab(this.dataset.tab);
            });
        });

        /* Default tab setup */
        const defaultTab = container.dataset.activeTab || 'overview';
        switchTab(defaultTab);

        /* Initial load of all 5 independent REST endpoints */
        reloadAll();
    }

    /* Expose window API */
    window.CarzuriCustomerDashboard = {
        init: initDashboard,
        reloadAll: reloadAll,
        reloadModule: reloadModule,
        switchTab: switchTab,
        getState: function() { return state; }
    };

    /* Auto-initialize when DOM is ready */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initDashboard);
    } else {
        initDashboard();
    }
})();