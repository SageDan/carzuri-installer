<?php
/**
 * Plugin Name: Carzuri Customer Dashboard
 * Plugin URI:  https://carzuri.com/plugins/customer-dashboard
 * Description: Single, unified buyer dashboard aggregating activity across Carzuri modules (Favorites, Saved Searches, Inquiries, Finance Applications, AI Valuations).
 * Version:     1.0.3
 * Author:      Carzuri
 * Author URI:  https://carzuri.com
 * License:     GPL-2.0+
 * Text Domain: carzuri-customer-dashboard
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('CARZURI_CUSTOMER_DASHBOARD_VERSION', '1.0.3');
define('CARZURI_CUSTOMER_DASHBOARD_DIR', plugin_dir_path(__FILE__));
define('CARZURI_CUSTOMER_DASHBOARD_URL', plugin_dir_url(__FILE__));

/**
 * Main Plugin Class
 */
class Carzuri_Customer_Dashboard {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('carzuri_customer_dashboard', array($this, 'render_shortcode'));
    }

    /**
     * Enqueue CSS and JS assets
     */
    public function enqueue_scripts() {
        // Enqueue Core Design System if available, otherwise fallback handles it in plugin CSS
        if (wp_script_is('carzuri-design-system', 'registered') || wp_style_is('carzuri-design-system', 'registered')) {
            wp_enqueue_style('carzuri-design-system');
        }

        // Plugin Stylesheet
        wp_enqueue_style(
            'carzuri-customer-dashboard-style',
            CARZURI_CUSTOMER_DASHBOARD_URL . 'assets/css/customer-dashboard.css',
            array(),
            CARZURI_CUSTOMER_DASHBOARD_VERSION
        );

        // Plugin Script
        wp_enqueue_script(
            'carzuri-customer-dashboard-script',
            CARZURI_CUSTOMER_DASHBOARD_URL . 'assets/js/customer-dashboard.js',
            array(),
            CARZURI_CUSTOMER_DASHBOARD_VERSION,
            true
        );

        // Pass settings and REST endpoints to script
        $settings = array(
            'rest_url'     => esc_url_raw(rest_url('carzuri/v1/')),
            'nonce'        => wp_create_nonce('wp_rest'),
            'is_logged_in' => is_user_logged_in(),
            'login_url'    => wp_login_url(get_permalink()),
            'endpoints'    => array(
                'favorites'  => 'carzuri/v1/favorites',
                'searches'   => 'carzuri/v1/saved-searches',
                'inquiries'  => 'carzuri/v1/my-inquiries',
                'finance'    => 'carzuri/v1/my-finance-applications',
                'valuations' => 'carzuri/v1/my-valuations',
            ),
            'links'        => array(
                'favorites'  => apply_filters('carzuri_link_favorites', site_url('/my-favorites/')),
                'searches'   => apply_filters('carzuri_link_saved_searches', site_url('/my-saved-searches/')),
                'inquiries'  => apply_filters('carzuri_link_inquiries', site_url('/my-inquiries/')),
                'finance'    => apply_filters('carzuri_link_finance', site_url('/my-finance-applications/')),
                'valuations' => apply_filters('carzuri_link_valuations', site_url('/my-valuations/')),
                'listings'   => apply_filters('carzuri_link_listings', site_url('/buy-cars/')),
            ),
            'i18n'         => array(
                'login_required'   => __('Please log in to access your customer dashboard.', 'carzuri-customer-dashboard'),
                'error_loading'    => __('Unable to load this section right now.', 'carzuri-customer-dashboard'),
                'retry'            => __('Retry', 'carzuri-customer-dashboard'),
                'view_all'         => __('View All', 'carzuri-customer-dashboard'),
                'empty_favorites'  => __('No saved favorite vehicles yet.', 'carzuri-customer-dashboard'),
                'empty_searches'   => __('No saved search criteria found.', 'carzuri-customer-dashboard'),
                'empty_inquiries'  => __('You have not submitted any vehicle inquiries yet.', 'carzuri-customer-dashboard'),
                'empty_finance'    => __('No finance applications on record.', 'carzuri-customer-dashboard'),
                'empty_valuations' => __('No AI trade-in valuations recorded.', 'carzuri-customer-dashboard'),
            ),
        );

        wp_localize_script('carzuri-customer-dashboard-script', 'carzuriDashboardSettings', $settings);
    }

    /**
     * Render Shortcode [carzuri_customer_dashboard]
     */
    public function render_shortcode($atts = array()) {
        $atts = shortcode_atts(array(
            'active_tab'         => 'overview',
            'items_per_section'  => 3,
            'class'              => '',
        ), $atts, 'carzuri_customer_dashboard');

        // Check if logged in
        if (!is_user_logged_in()) {
            $login_url = wp_login_url(get_permalink());
            ob_start();
            ?>
            <div class="carzuri-dashboard-guest-card">
                <div class="carzuri-dash-lock-icon-wrap">
                    <svg class="carzuri-dash-icon carzuri-dash-icon-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="32" height="32">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                    </svg>
                </div>
                <h3><?php esc_html_e('Customer Account Required', 'carzuri-customer-dashboard'); ?></h3>
                <p><?php esc_html_e('Log in to access your saved favorite vehicles, saved searches, active vehicle inquiries, finance applications, and AI trade-in valuations.', 'carzuri-customer-dashboard'); ?></p>
                <div class="carzuri-dash-guest-actions">
                    <a href="<?php echo esc_url($login_url); ?>" class="carzuri-dash-btn carzuri-dash-btn-primary">
                        <?php esc_html_e('Log In to Dashboard', 'carzuri-customer-dashboard'); ?>
                    </a>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }

        // Email verification gate. Only blocks accounts explicitly marked
        // unverified ('0'). Accounts with no carzuri_email_verified meta at
        // all (i.e. every buyer created before this feature existed) are
        // left completely untouched — they are NOT retroactively locked out.
        $current_user_id_check = get_current_user_id();
        $verified_meta = get_user_meta($current_user_id_check, 'carzuri_email_verified', true);
        $needs_verification = ($verified_meta === '0');

        if ($needs_verification) {
            ob_start();
            ?>
            <div class="carzuri-dashboard-guest-card">
                <div class="carzuri-dash-lock-icon-wrap">
                    <svg class="carzuri-dash-icon carzuri-dash-icon-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="32" height="32">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                        <polyline points="22,6 12,13 2,6"></polyline>
                    </svg>
                </div>
                <h3><?php esc_html_e('Please Verify Your Email Address', 'carzuri-customer-dashboard'); ?></h3>
                <p><?php esc_html_e('We sent a confirmation link to your email address when you registered. Click that link to activate your dashboard, saved favorites, inquiries, finance applications, and AI valuations.', 'carzuri-customer-dashboard'); ?></p>

                <?php if (isset($_GET['carzuri_verify_error'])) : ?>
                    <p style="color:#b91c1c; font-weight:600;">
                        <?php
                        if ($_GET['carzuri_verify_error'] === 'expired') {
                            esc_html_e('That verification link has expired. Request a new one below.', 'carzuri-customer-dashboard');
                        } else {
                            esc_html_e('That verification link is invalid. Request a new one below.', 'carzuri-customer-dashboard');
                        }
                        ?>
                    </p>
                <?php endif; ?>

                <div id="carzuri-resend-feedback" style="margin: 10px 0; font-weight: 600;"></div>

                <div class="carzuri-dash-guest-actions">
                    <button type="button" id="carzuri-resend-verification-btn" class="carzuri-dash-btn carzuri-dash-btn-primary">
                        <?php esc_html_e('Resend Verification Email', 'carzuri-customer-dashboard'); ?>
                    </button>
                </div>
            </div>
            <script>
            (function() {
                var btn = document.getElementById('carzuri-resend-verification-btn');
                if (!btn) { return; }
                btn.addEventListener('click', function() {
                    btn.disabled = true;
                    var feedback = document.getElementById('carzuri-resend-feedback');
                    feedback.textContent = '<?php echo esc_js(__('Sending...', 'carzuri-customer-dashboard')); ?>';
                    feedback.style.color = '#334155';

                    var formData = new FormData();
                    formData.append('action', 'carzuri_resend_verification');
                    formData.append('nonce', '<?php echo esc_js(wp_create_nonce('carzuri_buyer_nonce')); ?>');

                    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        credentials: 'same-origin',
                        body: formData
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        btn.disabled = false;
                        if (data.success) {
                            feedback.style.color = '#15803d';
                            feedback.textContent = data.data.message;
                        } else {
                            feedback.style.color = '#b91c1c';
                            feedback.textContent = data.data.message || '<?php echo esc_js(__('Something went wrong. Please try again.', 'carzuri-customer-dashboard')); ?>';
                        }
                    })
                    .catch(function() {
                        btn.disabled = false;
                        feedback.style.color = '#b91c1c';
                        feedback.textContent = '<?php echo esc_js(__('Something went wrong. Please try again.', 'carzuri-customer-dashboard')); ?>';
                    });
                });
            })();
            </script>
            <?php
            return ob_get_clean();
        }

        // Render Logged-In Customer Dashboard
        $current_user = wp_get_current_user();
        $user_display_name = $current_user->display_name ? $current_user->display_name : $current_user->user_login;

        ob_start();
        ?>
        <?php if (isset($_GET['carzuri_verified']) && $_GET['carzuri_verified'] === '1') : ?>
            <div class="carzuri-buyer-alert carzuri-alert-info" style="margin-bottom: 16px;">
                <svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                <div><strong><?php esc_html_e('Email verified! Welcome to your dashboard.', 'carzuri-customer-dashboard'); ?></strong></div>
            </div>
        <?php endif; ?>
        <div id="carzuri-customer-dashboard" 
             class="carzuri-dashboard-container <?php echo esc_attr($atts['class']); ?>"
             data-active-tab="<?php echo esc_attr($atts['active_tab']); ?>"
             data-items-limit="<?php echo esc_attr($atts['items_per_section']); ?>">

            <!-- Header Welcome Card -->
            <div class="carzuri-dash-header">
                <div class="carzuri-dash-user-info">
                    <div class="carzuri-dash-avatar">
                        <?php echo esc_html(strtoupper(substr($user_display_name, 0, 1))); ?>
                    </div>
                    <div>
                        <h2 class="carzuri-dash-title">
                            <?php printf(esc_html__('Welcome back, %s', 'carzuri-customer-dashboard'), esc_html($user_display_name)); ?>
                        </h2>
                        <p class="carzuri-dash-subtitle">
                            <?php esc_html_e('Carzuri Automotive Buyer Activity Center', 'carzuri-customer-dashboard'); ?>
                        </p>
                    </div>
                </div>
                <div class="carzuri-dash-header-actions">
                    <button type="button" id="carzuri-dash-refresh-btn" class="carzuri-dash-btn carzuri-dash-btn-outline" title="<?php esc_attr_e('Refresh Data', 'carzuri-customer-dashboard'); ?>">
                        <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
                            <polyline points="23 4 23 10 17 10"></polyline>
                            <polyline points="1 20 1 14 7 14"></polyline>
                            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                        </svg>
                        <span><?php esc_html_e('Refresh', 'carzuri-customer-dashboard'); ?></span>
                    </button>
                    <a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>" class="carzuri-dash-btn carzuri-dash-btn-outline">
                        <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
                            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                            <polyline points="16 17 21 12 16 7"></polyline>
                            <line x1="21" y1="12" x2="9" y2="12"></line>
                        </svg>
                        <span><?php esc_html_e('Log Out', 'carzuri-customer-dashboard'); ?></span>
                    </a>
                </div>
            </div>

            <!-- Scrollable Responsive Navigation Tabs -->
            <div class="carzuri-dash-tabs-wrapper">
                <nav class="carzuri-dash-tabs" aria-label="Dashboard Tabs">
                    <button type="button" class="carzuri-dash-tab active" data-tab="overview">
                        <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
                            <rect x="3" y="3" width="7" height="7"></rect>
                            <rect x="14" y="3" width="7" height="7"></rect>
                            <rect x="14" y="14" width="7" height="7"></rect>
                            <rect x="3" y="14" width="7" height="7"></rect>
                        </svg>
                        <span><?php esc_html_e('Overview', 'carzuri-customer-dashboard'); ?></span>
                    </button>
                    <button type="button" class="carzuri-dash-tab" data-tab="favorites">
                        <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                        </svg>
                        <span><?php esc_html_e('Favorites', 'carzuri-customer-dashboard'); ?></span>
                        <span class="carzuri-dash-count-badge" id="carzuri-badge-favorites">-</span>
                    </button>
                    <button type="button" class="carzuri-dash-tab" data-tab="searches">
                        <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
                            <circle cx="11" cy="11" r="8"></circle>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                        </svg>
                        <span><?php esc_html_e('Saved Searches', 'carzuri-customer-dashboard'); ?></span>
                        <span class="carzuri-dash-count-badge" id="carzuri-badge-searches">-</span>
                    </button>
                    <button type="button" class="carzuri-dash-tab" data-tab="inquiries">
                        <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
                            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                        </svg>
                        <span><?php esc_html_e('Inquiries', 'carzuri-customer-dashboard'); ?></span>
                        <span class="carzuri-dash-count-badge" id="carzuri-badge-inquiries">-</span>
                    </button>
                    <button type="button" class="carzuri-dash-tab" data-tab="finance">
                        <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
                            <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
                            <line x1="1" y1="10" x2="23" y2="10"></line>
                        </svg>
                        <span><?php esc_html_e('Finance', 'carzuri-customer-dashboard'); ?></span>
                        <span class="carzuri-dash-count-badge" id="carzuri-badge-finance">-</span>
                    </button>
                    <button type="button" class="carzuri-dash-tab" data-tab="valuations">
                        <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
                            <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                        </svg>
                        <span><?php esc_html_e('AI Valuations', 'carzuri-customer-dashboard'); ?></span>
                        <span class="carzuri-dash-count-badge" id="carzuri-badge-valuations">-</span>
                    </button>
                </nav>
            </div>

            <!-- Tab Content View Areas -->
            <div class="carzuri-dash-content">
                <!-- Section: Favorites -->
                <section id="carzuri-sec-favorites" class="carzuri-dash-section" data-section="favorites">
                    <div class="carzuri-dash-section-header">
                        <div class="carzuri-dash-sec-title">
                            <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                            </svg>
                            <h3><?php esc_html_e('Saved Favorite Vehicles', 'carzuri-customer-dashboard'); ?></h3>
                            <span class="carzuri-dash-sec-count" id="carzuri-count-favorites"></span>
                        </div>
                        <a href="<?php echo esc_url(apply_filters('carzuri_link_favorites', site_url('/my-favorites/'))); ?>" class="carzuri-dash-view-all">
                            <span><?php esc_html_e('View All Favorites', 'carzuri-customer-dashboard'); ?></span>
                            <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg>
                        </a>
                    </div>
                    <div class="carzuri-dash-sec-body" id="carzuri-body-favorites">
                        <!-- Rendered by JS -->
                    </div>
                </section>

                <!-- Section: Saved Searches -->
                <section id="carzuri-sec-searches" class="carzuri-dash-section" data-section="searches">
                    <div class="carzuri-dash-section-header">
                        <div class="carzuri-dash-sec-title">
                            <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
                                <circle cx="11" cy="11" r="8"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                            </svg>
                            <h3><?php esc_html_e('Saved Search Alerts', 'carzuri-customer-dashboard'); ?></h3>
                            <span class="carzuri-dash-sec-count" id="carzuri-count-searches"></span>
                        </div>
                        <a href="<?php echo esc_url(apply_filters('carzuri_link_saved_searches', site_url('/my-saved-searches/'))); ?>" class="carzuri-dash-view-all">
                            <span><?php esc_html_e('View All Searches', 'carzuri-customer-dashboard'); ?></span>
                            <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg>
                        </a>
                    </div>
                    <div class="carzuri-dash-sec-body" id="carzuri-body-searches">
                        <!-- Rendered by JS -->
                    </div>
                </section>

                <!-- Section: My Inquiries -->
                <section id="carzuri-sec-inquiries" class="carzuri-dash-section" data-section="inquiries">
                    <div class="carzuri-dash-section-header">
                        <div class="carzuri-dash-sec-title">
                            <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
                                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                            </svg>
                            <h3><?php esc_html_e('Vehicle Inquiries & Leads', 'carzuri-customer-dashboard'); ?></h3>
                            <span class="carzuri-dash-sec-count" id="carzuri-count-inquiries"></span>
                        </div>
                        <a href="<?php echo esc_url(apply_filters('carzuri_link_inquiries', site_url('/my-inquiries/'))); ?>" class="carzuri-dash-view-all">
                            <span><?php esc_html_e('View All Inquiries', 'carzuri-customer-dashboard'); ?></span>
                            <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg>
                        </a>
                    </div>
                    <div class="carzuri-dash-sec-body" id="carzuri-body-inquiries">
                        <!-- Rendered by JS -->
                    </div>
                </section>

                <!-- Section: Finance Applications -->
                <section id="carzuri-sec-finance" class="carzuri-dash-section" data-section="finance">
                    <div class="carzuri-dash-section-header">
                        <div class="carzuri-dash-sec-title">
                            <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
                                <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
                                <line x1="1" y1="10" x2="23" y2="10"></line>
                            </svg>
                            <h3><?php esc_html_e('Finance Applications', 'carzuri-customer-dashboard'); ?></h3>
                            <span class="carzuri-dash-sec-count" id="carzuri-count-finance"></span>
                        </div>
                        <a href="<?php echo esc_url(apply_filters('carzuri_link_finance', site_url('/my-finance-applications/'))); ?>" class="carzuri-dash-view-all">
                            <span><?php esc_html_e('View All Applications', 'carzuri-customer-dashboard'); ?></span>
                            <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg>
                        </a>
                    </div>
                    <div class="carzuri-dash-sec-body" id="carzuri-body-finance">
                        <!-- Rendered by JS -->
                    </div>
                </section>

                <!-- Section: AI Smart Valuations -->
                <section id="carzuri-sec-valuations" class="carzuri-dash-section" data-section="valuations">
                    <div class="carzuri-dash-section-header">
                        <div class="carzuri-dash-sec-title">
                            <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
                                <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                            </svg>
                            <h3><?php esc_html_e('AI Trade-In Valuations', 'carzuri-customer-dashboard'); ?></h3>
                            <span class="carzuri-dash-sec-count" id="carzuri-count-valuations"></span>
                        </div>
                        <a href="<?php echo esc_url(apply_filters('carzuri_link_valuations', site_url('/my-valuations/'))); ?>" class="carzuri-dash-view-all">
                            <span><?php esc_html_e('View All Valuations', 'carzuri-customer-dashboard'); ?></span>
                            <svg class="carzuri-dash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg>
                        </a>
                    </div>
                    <div class="carzuri-dash-sec-body" id="carzuri-body-valuations">
                        <!-- Rendered by JS -->
                    </div>
                </section>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

// Initialize Plugin
add_action('plugins_loaded', array('Carzuri_Customer_Dashboard', 'get_instance'));
