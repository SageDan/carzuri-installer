=== Carzuri Customer Dashboard ===
Contributors: Carzuri
Tags: carzuri, customer-dashboard, automotive, buyer-dashboard, vehicle-inquiries, finance-applications, ai-valuations
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A single, unified, logged-in buyer dashboard aggregating activity across Carzuri modules (Favorites, Saved Searches, Inquiries, Finance Applications, and AI Valuations).

== Description ==

Carzuri Customer Dashboard version 1.0.0 is a display and aggregation layer plugin designed for the Carzuri automotive suite.

= Key Features =
* Shortcode `[carzuri_customer_dashboard]` for easy page embedding.
* Logged-in-only security gating with graceful login callout for guests.
* Responsive horizontal tabbed overview for Favorites, Saved Searches, Inquiries, Finance Applications, and AI Valuations.
* Summary cards with recent items preview and direct "View All" links to full module pages.
* Fault-tolerant architecture: individual REST endpoint failures fail gracefully without breaking the rest of the dashboard.
* Uses Carzuri Core Design System CSS handle (`carzuri-design-system`) with full fallback compatibility.
* Explicit SVG icon dimension rules preventing visual layout bugs.

== Shortcode Usage ==

`[carzuri_customer_dashboard]`

Optional attributes:
* `active_tab` - Starting active tab (e.g., `overview`, `favorites`, `inquiries`, `finance`, `valuations`). Default: `overview`.
* `items_per_section` - Number of summary items per module card. Default: `3`.
* `class` - Additional CSS wrapper class.

== Changelog ==

= 1.0.0 =
* Initial release of Carzuri Customer Dashboard module.
