<?php
/**
 * Footer Template for Carzuri Site Header & Footer
 *
 * @package Carzuri_Site_Header_Footer
 */

if (!defined('ABSPATH')) {
    exit;
}

$home_url = esc_url(home_url('/'));
$current_year = date('Y');

// Determine the correct "My Dashboard" destination based on the logged-in user's role.
// Defaults to the buyer dashboard; dealers and the site's carzuri_admin role each have
// their own real dashboard elsewhere on the site.
$is_logged_in = is_user_logged_in();
$is_dealer = false;
$is_carzuri_admin = false;

$dashboard_url = home_url('/customer-dashboard/');
if ($is_logged_in) {
    $current_user_roles = (array) wp_get_current_user()->roles;
    $is_dealer = in_array('carzuri_dealer', $current_user_roles, true);
    $is_carzuri_admin = in_array('carzuri_admin', $current_user_roles, true);

    if ($is_dealer) {
        $dashboard_url = home_url('/dealer-dashboard/');
    } elseif ($is_carzuri_admin) {
        $dashboard_url = home_url('/carzuri-admin-portal/');
    }
}
$dashboard_url = esc_url($dashboard_url);
?>
<footer id="carzuri-custom-footer" class="carzuri-site-footer" role="contentinfo">
    <div class="carzuri-footer-main">
        <div class="carzuri-footer-container">
            <div class="carzuri-footer-grid">
                <!-- Column 1: Brand & Mission -->
                <div class="carzuri-footer-col carzuri-footer-col-brand">
                    <div class="carzuri-footer-logo-wrapper">
                        <?php
                        if (function_exists('the_custom_logo') && has_custom_logo()) {
                            the_custom_logo();
                        } else {
                            ?>
                            <a href="<?php echo $home_url; ?>" class="carzuri-fallback-logo" rel="home">
                                <span class="carzuri-logo-brand">CAR<span class="carzuri-logo-accent">ZURI</span></span>
                                <span class="carzuri-logo-tagline">Automotive Marketplace</span>
                            </a>
                            <?php
                        }
                        ?>
                    </div>
                    <p class="carzuri-footer-tagline"><strong>Driven by Trust. Powered by Value.</strong></p>
                    <p class="carzuri-footer-blurb">
                        Making vehicle ownership easier across Kenya through smart technology, trusted dealer partnerships, and transparent, accessible financing solutions.
                    </p>
                    <div class="carzuri-footer-socials">
                        <a href="https://www.instagram.com/carzuri.ke/" class="carzuri-social-icon" aria-label="Instagram" target="_blank" rel="noopener noreferrer">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                            </svg>
                        </a>
                        <a href="https://www.tiktok.com/@carzuri.limited" class="carzuri-social-icon" aria-label="TikTok" target="_blank" rel="noopener noreferrer">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                <path d="M16.6 5.82c-.9-.87-1.44-2.06-1.44-3.38h-3.06v14.02c0 1.5-1.22 2.72-2.72 2.72s-2.72-1.22-2.72-2.72 1.22-2.72 2.72-2.72c.28 0 .55.04.8.12v-3.11a5.79 5.79 0 0 0-.8-.06 5.79 5.79 0 0 0-5.79 5.79 5.79 5.79 0 0 0 5.79 5.79 5.79 5.79 0 0 0 5.79-5.79V9.14a8.6 8.6 0 0 0 5.03 1.61V7.7a5.36 5.36 0 0 1-3.6-1.88z"/>
                            </svg>
                        </a>
                    </div>
                </div>

                <!-- Column 2: Quick Links -->
                <div class="carzuri-footer-col">
                    <h4 class="carzuri-footer-heading"><?php esc_html_e('Quick Links', 'carzuri-site-header-footer'); ?></h4>
                    <ul class="carzuri-footer-links">
                        <li><a href="<?php echo $home_url; ?>"><?php esc_html_e('Home', 'carzuri-site-header-footer'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/buy-cars/')); ?>"><?php esc_html_e('Buy Cars', 'carzuri-site-header-footer'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/ai-valuation/')); ?>"><?php esc_html_e('Sell / Trade-In (AI Valuation)', 'carzuri-site-header-footer'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/finance-calculator/')); ?>"><?php esc_html_e('Finance Calculator', 'carzuri-site-header-footer'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/blog/')); ?>"><?php esc_html_e('Blog', 'carzuri-site-header-footer'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/dealer-registration/')); ?>"><?php esc_html_e('Dealers Registration', 'carzuri-site-header-footer'); ?></a></li>
                    </ul>
                </div>

                <!-- Column 3: My Account -->
                <div class="carzuri-footer-col">
                    <h4 class="carzuri-footer-heading"><?php esc_html_e('My Account', 'carzuri-site-header-footer'); ?></h4>
                    <ul class="carzuri-footer-links">
                        <li><a href="<?php echo $dashboard_url; ?>"><?php esc_html_e('My Dashboard', 'carzuri-site-header-footer'); ?></a></li>
                        <?php if (!$is_dealer && !$is_carzuri_admin) : ?>
                            <li><a href="<?php echo esc_url(home_url('/my-favorites/')); ?>"><?php esc_html_e('My Favorites', 'carzuri-site-header-footer'); ?></a></li>
                            <li><a href="<?php echo esc_url(home_url('/my-inquiries/')); ?>"><?php esc_html_e('My Inquiries', 'carzuri-site-header-footer'); ?></a></li>
                            <?php if (!$is_logged_in) : ?>
                                <li><a href="<?php echo esc_url(home_url('/buyer-login/')); ?>"><?php esc_html_e('Buyer Login', 'carzuri-site-header-footer'); ?></a></li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Column 4: Company & Contact -->
                <div class="carzuri-footer-col">
                    <h4 class="carzuri-footer-heading"><?php esc_html_e('Company & Support', 'carzuri-site-header-footer'); ?></h4>
                    <ul class="carzuri-footer-links carzuri-footer-company-links">
                        <li><a href="<?php echo esc_url(home_url('/about-us/')); ?>"><?php esc_html_e('About Us', 'carzuri-site-header-footer'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/contact-us/')); ?>"><?php esc_html_e('Contact Us', 'carzuri-site-header-footer'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/faq/')); ?>"><?php esc_html_e('FAQ', 'carzuri-site-header-footer'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>"><?php esc_html_e('Privacy Policy', 'carzuri-site-header-footer'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>"><?php esc_html_e('Terms of Service', 'carzuri-site-header-footer'); ?></a></li>
                    </ul>
                    <div class="carzuri-footer-contact-details">
                        <div class="carzuri-contact-item">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                                <polyline points="22,6 12,13 2,6"></polyline>
                            </svg>
                            <a href="mailto:info@carzuri.co.ke">info@carzuri.co.ke</a>
                        </div>
                        <div class="carzuri-contact-item">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                            </svg>
                            <a href="tel:0710549093">0710 549 093</a>
                        </div>
                        <div class="carzuri-contact-item">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                            <span>Ngong Road, Nairobi, Kenya</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bottom Copyright Bar -->
    <div class="carzuri-footer-bottom">
        <div class="carzuri-footer-container">
            <p class="carzuri-copyright-text">
                &copy; <?php echo esc_html($current_year); ?> Carzuri Limited. All rights reserved.
            </p>
        </div>
    </div>
</footer>
