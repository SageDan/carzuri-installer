<?php
/**
 * Header Template for Carzuri Site Header & Footer
 *
 * @package Carzuri_Site_Header_Footer
 */

if (!defined('ABSPATH')) {
    exit;
}

$home_url = esc_url(home_url('/'));

// Determine the logged-in user's role, once, for all conditional nav logic below.
$is_logged_in = is_user_logged_in();
$current_user_roles = $is_logged_in ? (array) wp_get_current_user()->roles : array();
$is_dealer = in_array('carzuri_dealer', $current_user_roles, true);
$is_carzuri_admin = in_array('carzuri_admin', $current_user_roles, true);

// "Dealers" nav item (List Your Vehicles / Dealer Login) is only useful to a guest
// who hasn't registered yet — hidden for anyone already logged in, in any role.
$show_dealers_nav = !$is_logged_in;

// Determine the correct "My Dashboard" destination based on the logged-in user's role.
// Defaults to the buyer dashboard; dealers and the site's carzuri_admin role each have
// their own real dashboard elsewhere on the site.
$dashboard_url = home_url('/customer-dashboard/');
if ($is_dealer) {
    $dashboard_url = home_url('/dealer-dashboard/');
} elseif ($is_carzuri_admin) {
    $dashboard_url = home_url('/carzuri-admin-portal/');
}
$dashboard_url = esc_url($dashboard_url);
?>
<header id="carzuri-custom-header" class="carzuri-site-header" role="banner">
    <div class="carzuri-header-container">
        <!-- Site Logo (Custom Logo with fallback) -->
        <div class="carzuri-header-logo-wrapper">
            <?php
            if (function_exists('the_custom_logo') && has_custom_logo()) {
                the_custom_logo();
            } else {
                ?>
                <a href="<?php echo $home_url; ?>" class="carzuri-fallback-logo" rel="home">
                    <span class="carzuri-logo-brand">CAR<span class="carzuri-logo-accent">ZURI</span></span>
                    <span class="carzuri-logo-tagline">Automotive Marketplace</span>
                </a>
                <?php
            }
            ?>
        </div>

        <!-- Desktop Navigation -->
        <nav id="carzuri-primary-nav" class="carzuri-primary-navigation" role="navigation" aria-label="<?php esc_attr_e('Primary Navigation', 'carzuri-site-header-footer'); ?>">
            <ul class="carzuri-nav-list">
                <!-- Home -->
                <li class="carzuri-nav-item">
                    <a href="<?php echo $home_url; ?>" class="carzuri-nav-link"><?php esc_html_e('Home', 'carzuri-site-header-footer'); ?></a>
                </li>

                <!-- Buy Cars (Direct link, no dropdown) -->
                <li class="carzuri-nav-item">
                    <a href="<?php echo esc_url(home_url('/buy-cars/')); ?>" class="carzuri-nav-link carzuri-nav-link-highlight"><?php esc_html_e('Buy Cars', 'carzuri-site-header-footer'); ?></a>
                </li>

                <!-- Sell / Trade-In (Dropdown) - visible to everyone regardless of role -->
                <li class="carzuri-nav-item carzuri-has-dropdown" aria-haspopup="true">
                    <button type="button" class="carzuri-dropdown-toggle" aria-expanded="false">
                        <span><?php esc_html_e('Sell / Trade-In', 'carzuri-site-header-footer'); ?></span>
                        <svg class="carzuri-dropdown-chevron" width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                            <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                    <ul class="carzuri-dropdown-menu" role="menu">
                        <li role="none">
                            <a href="<?php echo esc_url(home_url('/ai-valuation/')); ?>" class="carzuri-dropdown-link" role="menuitem">
                                <span class="carzuri-dropdown-title"><?php esc_html_e('Get AI Valuation', 'carzuri-site-header-footer'); ?></span>
                                <span class="carzuri-dropdown-desc"><?php esc_html_e('Instant algorithmic vehicle valuation', 'carzuri-site-header-footer'); ?></span>
                            </a>
                        </li>
                        <li role="none">
                            <a href="<?php echo esc_url(home_url('/finance-application-form/')); ?>" class="carzuri-dropdown-link" role="menuitem">
                                <span class="carzuri-dropdown-title"><?php esc_html_e('Apply for Trade-In Financing', 'carzuri-site-header-footer'); ?></span>
                                <span class="carzuri-dropdown-desc"><?php esc_html_e('Upgrade your vehicle with financing', 'carzuri-site-header-footer'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Financing (Dropdown) - visible to everyone regardless of role -->
                <li class="carzuri-nav-item carzuri-has-dropdown" aria-haspopup="true">
                    <button type="button" class="carzuri-dropdown-toggle" aria-expanded="false">
                        <span><?php esc_html_e('Financing', 'carzuri-site-header-footer'); ?></span>
                        <svg class="carzuri-dropdown-chevron" width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                            <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                    <ul class="carzuri-dropdown-menu" role="menu">
                        <li role="none">
                            <a href="<?php echo esc_url(home_url('/finance-calculator/')); ?>" class="carzuri-dropdown-link" role="menuitem">
                                <span class="carzuri-dropdown-title"><?php esc_html_e('Finance Calculator', 'carzuri-site-header-footer'); ?></span>
                                <span class="carzuri-dropdown-desc"><?php esc_html_e('Estimate monthly loan repayments', 'carzuri-site-header-footer'); ?></span>
                            </a>
                        </li>
                        <li role="none">
                            <a href="<?php echo esc_url(home_url('/finance-application-form/')); ?>" class="carzuri-dropdown-link" role="menuitem">
                                <span class="carzuri-dropdown-title"><?php esc_html_e('Apply for Financing', 'carzuri-site-header-footer'); ?></span>
                                <span class="carzuri-dropdown-desc"><?php esc_html_e('Fast pre-approval with partner banks', 'carzuri-site-header-footer'); ?></span>
                            </a>
                        </li>
                        <li role="none">
                            <a href="<?php echo esc_url(home_url('/my-finance-applications/')); ?>" class="carzuri-dropdown-link" role="menuitem">
                                <span class="carzuri-dropdown-title"><?php esc_html_e('My Applications', 'carzuri-site-header-footer'); ?></span>
                                <span class="carzuri-dropdown-desc"><?php esc_html_e('Track your active loan applications', 'carzuri-site-header-footer'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Blog (Direct link, no dropdown) -->
                <li class="carzuri-nav-item">
                    <a href="<?php echo esc_url(home_url('/blog/')); ?>" class="carzuri-nav-link"><?php esc_html_e('Blog', 'carzuri-site-header-footer'); ?></a>
                </li>

                <?php if ($show_dealers_nav) : ?>
                <!-- Dealers (Dropdown) - only shown to guests; hidden for anyone already logged in -->
                <li class="carzuri-nav-item carzuri-has-dropdown" aria-haspopup="true">
                    <button type="button" class="carzuri-dropdown-toggle" aria-expanded="false">
                        <span><?php esc_html_e('Dealers', 'carzuri-site-header-footer'); ?></span>
                        <svg class="carzuri-dropdown-chevron" width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                            <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                    <ul class="carzuri-dropdown-menu" role="menu">
                        <li role="none">
                            <a href="<?php echo esc_url(home_url('/dealer-registration/')); ?>" class="carzuri-dropdown-link" role="menuitem">
                                <span class="carzuri-dropdown-title"><?php esc_html_e('List Your Vehicles', 'carzuri-site-header-footer'); ?></span>
                                <span class="carzuri-dropdown-desc"><?php esc_html_e('Register as an authorized dealership', 'carzuri-site-header-footer'); ?></span>
                            </a>
                        </li>
                        <li role="none">
                            <a href="<?php echo esc_url(home_url('/dealer-login/')); ?>" class="carzuri-dropdown-link" role="menuitem">
                                <span class="carzuri-dropdown-title"><?php esc_html_e('Dealer Login', 'carzuri-site-header-footer'); ?></span>
                                <span class="carzuri-dropdown-desc"><?php esc_html_e('Access your inventory manager & leads', 'carzuri-site-header-footer'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <!-- My Account - Note: NO Admin Login anywhere -->
                <?php if ($is_dealer) : ?>
                    <!-- Logged-in dealer: single direct link to their real dashboard, no dropdown -->
                    <li class="carzuri-nav-item">
                        <a href="<?php echo $dashboard_url; ?>" class="carzuri-nav-link carzuri-account-btn">
                            <svg class="carzuri-account-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                            <span><?php esc_html_e('Dealer Dashboard', 'carzuri-site-header-footer'); ?></span>
                        </a>
                    </li>
                <?php elseif ($is_carzuri_admin) : ?>
                    <!-- Logged-in carzuri_admin: single direct link to the Admin Portal, no dropdown -->
                    <li class="carzuri-nav-item">
                        <a href="<?php echo $dashboard_url; ?>" class="carzuri-nav-link carzuri-account-btn">
                            <svg class="carzuri-account-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                            <span><?php esc_html_e('Admin Portal', 'carzuri-site-header-footer'); ?></span>
                        </a>
                    </li>
                <?php else : ?>
                    <!-- Guest or logged-in buyer: full "My Account" dropdown -->
                    <li class="carzuri-nav-item carzuri-has-dropdown carzuri-account-dropdown" aria-haspopup="true">
                        <button type="button" class="carzuri-dropdown-toggle carzuri-account-btn" aria-expanded="false">
                            <svg class="carzuri-account-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                            <span><?php esc_html_e('My Account', 'carzuri-site-header-footer'); ?></span>
                            <svg class="carzuri-dropdown-chevron" width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                                <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <ul class="carzuri-dropdown-menu carzuri-dropdown-menu-right" role="menu">
                            <li role="none">
                                <a href="<?php echo $dashboard_url; ?>" class="carzuri-dropdown-link" role="menuitem">
                                    <span class="carzuri-dropdown-title"><?php esc_html_e('My Dashboard', 'carzuri-site-header-footer'); ?></span>
                                </a>
                            </li>
                            <li role="none">
                                <a href="<?php echo esc_url(home_url('/my-favorites/')); ?>" class="carzuri-dropdown-link" role="menuitem">
                                    <span class="carzuri-dropdown-title"><?php esc_html_e('My Favorites', 'carzuri-site-header-footer'); ?></span>
                                </a>
                            </li>
                            <li role="none">
                                <a href="<?php echo esc_url(home_url('/my-inquiries/')); ?>" class="carzuri-dropdown-link" role="menuitem">
                                    <span class="carzuri-dropdown-title"><?php esc_html_e('My Inquiries', 'carzuri-site-header-footer'); ?></span>
                                </a>
                            </li>
                            <li role="none">
                                <a href="<?php echo esc_url(home_url('/my-saved-searches/')); ?>" class="carzuri-dropdown-link" role="menuitem">
                                    <span class="carzuri-dropdown-title"><?php esc_html_e('My Saved Searches', 'carzuri-site-header-footer'); ?></span>
                                </a>
                            </li>
                            <?php if (!$is_logged_in) : ?>
                            <li role="none" class="carzuri-dropdown-divider"></li>
                            <li role="none">
                                <a href="<?php echo esc_url(home_url('/buyer-registration/')); ?>" class="carzuri-dropdown-link carzuri-link-register" role="menuitem">
                                    <span class="carzuri-dropdown-title"><?php esc_html_e('Register', 'carzuri-site-header-footer'); ?></span>
                                </a>
                            </li>
                            <li role="none">
                                <a href="<?php echo esc_url(home_url('/buyer-login/')); ?>" class="carzuri-dropdown-link carzuri-link-login" role="menuitem">
                                    <span class="carzuri-dropdown-title"><?php esc_html_e('Buyer Login', 'carzuri-site-header-footer'); ?></span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>

        <!-- Right Utilities: Notification Bell Slot + Mobile Hamburger Button -->
        <div class="carzuri-header-actions">
            <!-- Dedicated Slot for Relocated Notification Bell (from Carzuri Notifications plugin) -->
            <div id="carzuri-header-notification-slot" class="carzuri-header-notification-slot" aria-label="<?php esc_attr_e('Notifications', 'carzuri-site-header-footer'); ?>">
                <!-- Notification bell widget is moved here via carzuri-header-footer.js -->
            </div>

            <!-- Mobile Hamburger Toggle Button (Active below 992px) -->
            <button id="carzuri-mobile-menu-toggle" class="carzuri-mobile-toggle-btn" type="button" aria-expanded="false" aria-controls="carzuri-mobile-drawer" aria-label="<?php esc_attr_e('Toggle navigation menu', 'carzuri-site-header-footer'); ?>">
                <span class="carzuri-hamburger-box">
                    <span class="carzuri-hamburger-line"></span>
                    <span class="carzuri-hamburger-line"></span>
                    <span class="carzuri-hamburger-line"></span>
                </span>
            </button>
        </div>
    </div>

    <!-- Mobile Slide-Out Drawer Navigation -->
    <div id="carzuri-mobile-drawer" class="carzuri-mobile-drawer" aria-hidden="true">
        <div class="carzuri-mobile-drawer-backdrop"></div>
        <div class="carzuri-mobile-drawer-inner">
            <div class="carzuri-mobile-drawer-header">
                <span class="carzuri-mobile-drawer-title"><?php esc_html_e('Menu', 'carzuri-site-header-footer'); ?></span>
                <button type="button" id="carzuri-mobile-drawer-close" class="carzuri-mobile-close-btn" aria-label="<?php esc_attr_e('Close menu', 'carzuri-site-header-footer'); ?>">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                </button>
            </div>

            <nav class="carzuri-mobile-navigation" role="navigation">
                <ul class="carzuri-mobile-nav-list">
                    <li class="carzuri-mobile-nav-item">
                        <a href="<?php echo $home_url; ?>" class="carzuri-mobile-nav-link"><?php esc_html_e('Home', 'carzuri-site-header-footer'); ?></a>
                    </li>
                    <li class="carzuri-mobile-nav-item">
                        <a href="<?php echo esc_url(home_url('/buy-cars/')); ?>" class="carzuri-mobile-nav-link carzuri-mobile-highlight"><?php esc_html_e('Buy Cars', 'carzuri-site-header-footer'); ?></a>
                    </li>

                    <!-- Accordion: Sell / Trade-In - visible to everyone -->
                    <li class="carzuri-mobile-nav-item carzuri-mobile-accordion">
                        <button type="button" class="carzuri-mobile-accordion-toggle" aria-expanded="false">
                            <span><?php esc_html_e('Sell / Trade-In', 'carzuri-site-header-footer'); ?></span>
                            <svg class="carzuri-mobile-accordion-chevron" width="14" height="14" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                                <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <ul class="carzuri-mobile-submenu">
                            <li><a href="<?php echo esc_url(home_url('/ai-valuation/')); ?>"><?php esc_html_e('Get AI Valuation', 'carzuri-site-header-footer'); ?></a></li>
                            <li><a href="<?php echo esc_url(home_url('/finance-application-form/')); ?>"><?php esc_html_e('Apply for Trade-In Financing', 'carzuri-site-header-footer'); ?></a></li>
                        </ul>
                    </li>

                    <!-- Accordion: Financing - visible to everyone -->
                    <li class="carzuri-mobile-nav-item carzuri-mobile-accordion">
                        <button type="button" class="carzuri-mobile-accordion-toggle" aria-expanded="false">
                            <span><?php esc_html_e('Financing', 'carzuri-site-header-footer'); ?></span>
                            <svg class="carzuri-mobile-accordion-chevron" width="14" height="14" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                                <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <ul class="carzuri-mobile-submenu">
                            <li><a href="<?php echo esc_url(home_url('/finance-calculator/')); ?>"><?php esc_html_e('Finance Calculator', 'carzuri-site-header-footer'); ?></a></li>
                            <li><a href="<?php echo esc_url(home_url('/finance-application-form/')); ?>"><?php esc_html_e('Apply for Financing', 'carzuri-site-header-footer'); ?></a></li>
                            <li><a href="<?php echo esc_url(home_url('/my-finance-applications/')); ?>"><?php esc_html_e('My Applications', 'carzuri-site-header-footer'); ?></a></li>
                        </ul>
                    </li>

                    <!-- Blog (Direct link) -->
                    <li class="carzuri-mobile-nav-item">
                        <a href="<?php echo esc_url(home_url('/blog/')); ?>" class="carzuri-mobile-nav-link"><?php esc_html_e('Blog', 'carzuri-site-header-footer'); ?></a>
                    </li>

                    <?php if ($show_dealers_nav) : ?>
                    <!-- Accordion: Dealers - only shown to guests -->
                    <li class="carzuri-mobile-nav-item carzuri-mobile-accordion">
                        <button type="button" class="carzuri-mobile-accordion-toggle" aria-expanded="false">
                            <span><?php esc_html_e('Dealers', 'carzuri-site-header-footer'); ?></span>
                            <svg class="carzuri-mobile-accordion-chevron" width="14" height="14" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                                <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <ul class="carzuri-mobile-submenu">
                            <li><a href="<?php echo esc_url(home_url('/dealer-registration/')); ?>"><?php esc_html_e('List Your Vehicles', 'carzuri-site-header-footer'); ?></a></li>
                            <li><a href="<?php echo esc_url(home_url('/dealer-login/')); ?>"><?php esc_html_e('Dealer Login', 'carzuri-site-header-footer'); ?></a></li>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <!-- My Account -->
                    <?php if ($is_dealer) : ?>
                        <!-- Logged-in dealer: single direct link -->
                        <li class="carzuri-mobile-nav-item">
                            <a href="<?php echo $dashboard_url; ?>" class="carzuri-mobile-nav-link"><?php esc_html_e('Dealer Dashboard', 'carzuri-site-header-footer'); ?></a>
                        </li>
                    <?php elseif ($is_carzuri_admin) : ?>
                        <!-- Logged-in carzuri_admin: single direct link -->
                        <li class="carzuri-mobile-nav-item">
                            <a href="<?php echo $dashboard_url; ?>" class="carzuri-mobile-nav-link"><?php esc_html_e('Admin Portal', 'carzuri-site-header-footer'); ?></a>
                        </li>
                    <?php else : ?>
                        <!-- Guest or logged-in buyer: full accordion -->
                        <li class="carzuri-mobile-nav-item carzuri-mobile-accordion">
                            <button type="button" class="carzuri-mobile-accordion-toggle" aria-expanded="false">
                                <span><?php esc_html_e('My Account', 'carzuri-site-header-footer'); ?></span>
                                <svg class="carzuri-mobile-accordion-chevron" width="14" height="14" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                                    <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                            <ul class="carzuri-mobile-submenu">
                                <li><a href="<?php echo $dashboard_url; ?>"><?php esc_html_e('My Dashboard', 'carzuri-site-header-footer'); ?></a></li>
                                <li><a href="<?php echo esc_url(home_url('/my-favorites/')); ?>"><?php esc_html_e('My Favorites', 'carzuri-site-header-footer'); ?></a></li>
                                <li><a href="<?php echo esc_url(home_url('/my-inquiries/')); ?>"><?php esc_html_e('My Inquiries', 'carzuri-site-header-footer'); ?></a></li>
                                <li><a href="<?php echo esc_url(home_url('/my-saved-searches/')); ?>"><?php esc_html_e('My Saved Searches', 'carzuri-site-header-footer'); ?></a></li>
                                <?php if (!$is_logged_in) : ?>
                                <li><a href="<?php echo esc_url(home_url('/buyer-registration/')); ?>"><?php esc_html_e('Register', 'carzuri-site-header-footer'); ?></a></li>
                                <li><a href="<?php echo esc_url(home_url('/buyer-login/')); ?>"><?php esc_html_e('Buyer Login', 'carzuri-site-header-footer'); ?></a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</header>
