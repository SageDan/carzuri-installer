/**
 * Carzuri Site Header & Footer Interactive Script
 * 
 * Features:
 * 1. Relocation of .carzuri-notifications-container into #carzuri-header-notification-slot
 * 2. Mobile slide-out navigation drawer toggle and backdrop dismiss
 * 3. Mobile accordion submenu toggling
 * 4. Desktop dropdown accessibility (Keyboard navigation, Tab/Shift-Tab, Escape dismissal)
 */

(function () {
    'use strict';

    /**
     * 1. Notification Bell DOM Relocation
     * 
     * Relocates the existing .carzuri-notifications-container element from wherever
     * it currently resides (e.g. wp_footer) into the designated #carzuri-header-notification-slot.
     * Physically moves the real DOM node so all existing event listeners remain active.
     */
    function initNotificationRelocator() {
        var targetSlot = document.getElementById('carzuri-header-notification-slot');
        if (!targetSlot) {
            return;
        }

        var maxAttempts = 50; // Try for up to 5 seconds
        var attempts = 0;

        function tryMoveNotificationBell() {
            var bellContainer = document.querySelector('.carzuri-notifications-container');

            if (bellContainer && targetSlot) {
                // If it is not already inside our slot, move the DOM node directly
                if (targetSlot !== bellContainer.parentElement) {
                    targetSlot.appendChild(bellContainer);
                }
                return true;
            }

            attempts++;
            if (attempts < maxAttempts) {
                setTimeout(tryMoveNotificationBell, 100);
            }
            return false;
        }

        // Run immediately
        if (!tryMoveNotificationBell()) {
            // Also listen to window load and DOM ready
            window.addEventListener('load', tryMoveNotificationBell);
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', tryMoveNotificationBell);
            }

            // MutationObserver fallback to capture async injections
            if (window.MutationObserver) {
                var observer = new MutationObserver(function (mutations, obs) {
                    var container = document.querySelector('.carzuri-notifications-container');
                    if (container && targetSlot && targetSlot !== container.parentElement) {
                        targetSlot.appendChild(container);
                        obs.disconnect();
                    }
                });
                observer.observe(document.body || document.documentElement, {
                    childList: true,
                    subtree: true
                });
            }
        }
    }

    /**
     * 2. Mobile Navigation Drawer & Accordions
     */
    function initMobileNavigation() {
        var toggleBtn = document.getElementById('carzuri-mobile-menu-toggle');
        var drawer = document.getElementById('carzuri-mobile-drawer');
        var closeBtn = document.getElementById('carzuri-mobile-drawer-close');
        var backdrop = drawer ? drawer.querySelector('.carzuri-mobile-drawer-backdrop') : null;

        if (!toggleBtn || !drawer) {
            return;
        }

        function openDrawer() {
            drawer.classList.add('carzuri-drawer-active');
            drawer.setAttribute('aria-hidden', 'false');
            toggleBtn.setAttribute('aria-expanded', 'true');
            document.body.style.overflow = 'hidden';
            if (closeBtn) {
                closeBtn.focus();
            }
        }

        function closeDrawer() {
            drawer.classList.remove('carzuri-drawer-active');
            drawer.setAttribute('aria-hidden', 'true');
            toggleBtn.setAttribute('aria-expanded', 'false');
            document.body.style.overflow = '';
            toggleBtn.focus();
        }

        toggleBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            if (drawer.classList.contains('carzuri-drawer-active')) {
                closeDrawer();
            } else {
                openDrawer();
            }
        });

        if (closeBtn) {
            closeBtn.addEventListener('click', closeDrawer);
        }

        if (backdrop) {
            backdrop.addEventListener('click', closeDrawer);
        }

        // Mobile Accordion Submenus
        var accordionToggles = drawer.querySelectorAll('.carzuri-mobile-accordion-toggle');
        accordionToggles.forEach(function (accordionBtn) {
            accordionBtn.addEventListener('click', function () {
                var parentItem = accordionBtn.closest('.carzuri-mobile-accordion');
                var isExpanded = accordionBtn.getAttribute('aria-expanded') === 'true';

                // Toggle state
                if (parentItem) {
                    parentItem.classList.toggle('carzuri-accordion-open');
                }
                accordionBtn.setAttribute('aria-expanded', isExpanded ? 'false' : 'true');
            });
        });
    }

    /**
     * 3. Desktop Dropdown Accessibility & Keyboard Navigation
     */
    function initDesktopDropdowns() {
        var dropdownItems = document.querySelectorAll('.carzuri-nav-item.carzuri-has-dropdown');

        dropdownItems.forEach(function (item) {
            var toggleBtn = item.querySelector('.carzuri-dropdown-toggle');
            var menu = item.querySelector('.carzuri-dropdown-menu');

            if (!toggleBtn || !menu) {
                return;
            }

            // Click/Tap toggle
            toggleBtn.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();

                var isOpen = item.classList.contains('carzuri-dropdown-open');

                // Close other open dropdowns
                dropdownItems.forEach(function (other) {
                    if (other !== item) {
                        other.classList.remove('carzuri-dropdown-open');
                        var otherBtn = other.querySelector('.carzuri-dropdown-toggle');
                        if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
                    }
                });

                if (isOpen) {
                    item.classList.remove('carzuri-dropdown-open');
                    toggleBtn.setAttribute('aria-expanded', 'false');
                } else {
                    item.classList.add('carzuri-dropdown-open');
                    toggleBtn.setAttribute('aria-expanded', 'true');
                }
            });
        });

        // Global click to close desktop dropdowns
        document.addEventListener('click', function (e) {
            dropdownItems.forEach(function (item) {
                if (!item.contains(e.target)) {
                    item.classList.remove('carzuri-dropdown-open');
                    var toggleBtn = item.querySelector('.carzuri-dropdown-toggle');
                    if (toggleBtn) toggleBtn.setAttribute('aria-expanded', 'false');
                }
            });
        });

        // Global Escape key to dismiss menus
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' || e.keyCode === 27) {
                // Dismiss desktop dropdowns
                dropdownItems.forEach(function (item) {
                    if (item.classList.contains('carzuri-dropdown-open')) {
                        item.classList.remove('carzuri-dropdown-open');
                        var toggleBtn = item.querySelector('.carzuri-dropdown-toggle');
                        if (toggleBtn) {
                            toggleBtn.setAttribute('aria-expanded', 'false');
                            toggleBtn.focus();
                        }
                    }
                });

                // Dismiss mobile drawer
                var drawer = document.getElementById('carzuri-mobile-drawer');
                if (drawer && drawer.classList.contains('carzuri-drawer-active')) {
                    drawer.classList.remove('carzuri-drawer-active');
                    drawer.setAttribute('aria-hidden', 'true');
                    document.body.style.overflow = '';
                    var toggleBtn = document.getElementById('carzuri-mobile-menu-toggle');
                    if (toggleBtn) {
                        toggleBtn.setAttribute('aria-expanded', 'false');
                        toggleBtn.focus();
                    }
                }
            }
        });
    }

    // Initialize all components on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            initNotificationRelocator();
            initMobileNavigation();
            initDesktopDropdowns();
        });
    } else {
        initNotificationRelocator();
        initMobileNavigation();
        initDesktopDropdowns();
    }
})();
