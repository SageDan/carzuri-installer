<?php
/**
 * Plugin Name: Carzuri Site Header & Footer
 * Plugin URI: https://carzuri.co.ke
 * Description: Custom header and footer for the Carzuri automotive marketplace. Seamlessly replaces Astra theme headers and footers with brand-accurate navigation, custom logo integration, and notification bell slot relocation.
 * Version: 1.0.0
 * Author: Carzuri Development Team
 * Author URI: https://carzuri.co.ke
 * Text Domain: carzuri-site-header-footer
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('CARZURI_HF_VERSION', '1.0.0');
define('CARZURI_HF_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CARZURI_HF_PLUGIN_URL', plugin_dir_url(__FILE__));

class Carzuri_Site_Header_Footer {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Enqueue styles and scripts
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'), 999);

        // Inject custom header into template
        add_action('wp_body_open', array($this, 'render_header'), 1);
        // Fallback for older themes or Astra hooks
        add_action('astra_header_before', array($this, 'render_header'), 1);

        // Inject custom footer into template
        add_action('wp_footer', array($this, 'render_footer'), 5);
        add_action('astra_footer_before', array($this, 'render_footer'), 5);

        // Register custom navigation theme support if needed
        add_action('after_setup_theme', array($this, 'theme_support_setup'));
    }

    public function theme_support_setup() {
        // Ensure custom logo support is active
        add_theme_support('custom-logo', array(
            'height'      => 80,
            'width'       => 240,
            'flex-height' => true,
            'flex-width'  => true,
            'header-text' => array('site-title', 'site-description'),
        ));
    }

    public function enqueue_assets() {
        // Enqueue Header & Footer CSS with design system dependency fallback
        $dependencies = array();
        if (wp_style_is('carzuri-design-system', 'registered') || wp_style_is('carzuri-design-system', 'enqueued')) {
            $dependencies[] = 'carzuri-design-system';
        }

        wp_enqueue_style(
            'carzuri-header-footer-style',
            CARZURI_HF_PLUGIN_URL . 'assets/css/carzuri-header-footer.css',
            $dependencies,
            CARZURI_HF_VERSION
        );

        // Enqueue Header & Footer JS
        wp_enqueue_script(
            'carzuri-header-footer-script',
            CARZURI_HF_PLUGIN_URL . 'assets/js/carzuri-header-footer.js',
            array('jquery'),
            CARZURI_HF_VERSION,
            true // Load in footer
        );

        // Pass localized data if needed
        wp_localize_script('carzuri-header-footer-script', 'CarzuriHFData', array(
            'homeUrl' => esc_url(home_url('/')),
            'siteTitle' => get_bloginfo('name'),
        ));
    }

    public function render_header() {
        // Prevent duplicate rendering
        static $header_rendered = false;
        if ($header_rendered) {
            return;
        }
        $header_rendered = true;

        $template_path = CARZURI_HF_PLUGIN_DIR . 'templates/header-template.php';
        if (file_exists($template_path)) {
            include $template_path;
        }
    }

    public function render_footer() {
        // Prevent duplicate rendering
        static $footer_rendered = false;
        if ($footer_rendered) {
            return;
        }
        $footer_rendered = true;

        $template_path = CARZURI_HF_PLUGIN_DIR . 'templates/footer-template.php';
        if (file_exists($template_path)) {
            include $template_path;
        }
    }
}

// Initialize the plugin
add_action('plugins_loaded', array('Carzuri_Site_Header_Footer', 'get_instance'));
