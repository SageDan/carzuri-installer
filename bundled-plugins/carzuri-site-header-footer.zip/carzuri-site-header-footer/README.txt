=== Carzuri Site Header & Footer ===
Contributors: carzuri
Tags: carzuri, header, footer, astra, automotive, marketplace, notifications
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Custom Header & Footer plugin for Carzuri automotive marketplace. Cleanly replaces Astra theme defaults with brand-accurate navigation, custom logo integration, and notification bell slot relocation.

== Description ==

Carzuri Site Header & Footer provides a bespoke, fully responsive navigation and footer experience specifically crafted for the Carzuri automotive marketplace.

= Key Highlights =
* **Astra Theme Override**: Cleanly hides Astra's '#masthead' and '#colophon' via CSS without requiring theme modifications.
* **Carzuri Design System Integration**: Reuses '--carzuri-navy-dark', '--carzuri-gold', and CSS custom properties with resilient fallback values.
* **WordPress Custom Logo**: Leverages WordPress native 'get_custom_logo()' for seamless domain and branding transitions.
* **Carzuri Notifications Relocation**: Provides an empty '#carzuri-header-notification-slot' and relocates the existing '.carzuri-notifications-container' node from 'wp_footer' directly into the header without destroying bound event listeners.
* **Mobile Responsive Fidelity**: Collapses below 992px to a hamburger navigation drawer with touch-friendly accordion dropdowns while keeping the notification bell accessible.
* **Defensive Styling**: Explicit '!important' dimension rules on all SVG icons to prevent 0x0 collapse conflicts with theme styles.
* **Deliberate Exclusion**: No 'Admin Login' in the header and no newsletter form in the footer as requested.

== Real Slugs Mapped in Plugin ==
* Home: '/'
* Buy Cars: '/buy-cars/'
* AI Valuation: '/ai-valuation/'
* Trade-In Financing: '/finance-application-form/'
* Finance Calculator: '/finance-calculator/'
* My Finance Applications: '/my-finance-applications/'
* Dealer Registration: '/dealer-registration/'
* Dealer Login: '/dealer-login/'
* Customer Dashboard: '/customer-dashboard/'
* My Favorites: '/my-favorites/'
* My Inquiries: '/my-inquiries/'
* My Saved Searches: '/my-saved-searches/'
* Buyer Registration: '/buyer-registration/'
* Buyer Login: '/buyer-login/'
* About Us: '/about-us/'
* Contact Us: '/contact-us/'
* FAQ: '/faq/'
* Privacy Policy: '/privacy-policy/'
* Terms of Service: '/terms-of-service/'

== Installation ==

1. Download 'carzuri-site-header-footer.zip'.
2. In your WordPress admin dashboard, navigate to **Plugins > Add New > Upload Plugin**.
3. Select 'carzuri-site-header-footer.zip' and click **Install Now**.
4. Activate the plugin through the **Plugins** menu.
5. Ensure your site logo is configured under **Appearance > Customize > Site Identity**.
