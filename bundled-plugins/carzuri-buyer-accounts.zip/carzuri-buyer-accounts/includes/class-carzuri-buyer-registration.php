<?php
/**
 * Buyer Registration Form & Shortcode
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Buyer_Registration {

	public function __construct() {
		add_shortcode( 'carzuri_buyer_registration', array( $this, 'render_shortcode' ) );
		add_action( 'wp_ajax_nopriv_carzuri_buyer_register', array( $this, 'handle_ajax_registration' ) );
		add_action( 'wp_ajax_carzuri_buyer_register', array( $this, 'handle_ajax_registration' ) );

		// Handles clicks on the verification link sent by email. Runs on
		// every page load (no dedicated page/route needed) but only acts
		// when the two expected query args are present.
		add_action( 'init', array( $this, 'maybe_handle_email_verification_link' ) );

		// Lets an already-logged-in-but-unverified buyer request a fresh
		// verification email from the dashboard's "blocked" screen.
		add_action( 'wp_ajax_carzuri_resend_verification', array( $this, 'handle_resend_verification' ) );
	}

	public function render_shortcode( $atts ) {
		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
			$dashboard_url = home_url( '/customer-dashboard/' );
			return '<div class="carzuri-buyer-alert carzuri-alert-info">
				<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
				<div>
					<strong>Already Registered & Logged In!</strong><br>
					You are logged in as <strong>' . esc_html( $user->display_name ) . '</strong> (' . esc_html( $user->user_email ) . ').
					<div class="carzuri-mt-2">
						<a href="' . esc_url( $dashboard_url ) . '" class="carzuri-btn carzuri-btn-sm carzuri-btn-primary">Go to Customer Dashboard &rarr;</a>
					</div>
				</div>
			</div>';
		}

		ob_start();
		?>
		<div class="carzuri-buyer-card carzuri-buyer-registration-wrap">
			<div class="carzuri-buyer-card-header">
				<h3 class="carzuri-buyer-title">Create Your Buyer Account</h3>
				<p class="carzuri-buyer-subtitle">Save vehicles, request finance, and track valuations. We'll ask you to confirm your email before your account is fully active.</p>
			</div>

			<form id="carzuri-buyer-reg-form" class="carzuri-buyer-form" method="post">
				<?php wp_nonce_field( 'carzuri_buyer_nonce', 'carzuri_reg_nonce' ); ?>
				
				<div id="carzuri-reg-feedback" class="carzuri-buyer-feedback"></div>

				<div class="carzuri-form-group">
					<label for="carzuri_full_name">Full Name <span class="carzuri-required">*</span></label>
					<div class="carzuri-input-icon-wrap">
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
						<input type="text" id="carzuri_full_name" name="full_name" class="carzuri-input" placeholder="e.g. Sarah Jenkins" required>
					</div>
				</div>

				<div class="carzuri-form-group">
					<label for="carzuri_email">Email Address <span class="carzuri-required">*</span></label>
					<div class="carzuri-input-icon-wrap">
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
						<input type="email" id="carzuri_email" name="email" class="carzuri-input" placeholder="sarah@example.com" required>
					</div>
				</div>

				<div class="carzuri-form-group">
					<label for="carzuri_phone">Phone Number <span class="carzuri-optional">(Optional)</span></label>
					<div class="carzuri-input-icon-wrap">
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
						<input type="tel" id="carzuri_phone" name="phone" class="carzuri-input" placeholder="+44 7700 900123">
					</div>
				</div>

				<div class="carzuri-form-group">
					<label for="carzuri_reg_password">Password <span class="carzuri-required">*</span></label>
					<div class="carzuri-input-icon-wrap">
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
						<input type="password" id="carzuri_reg_password" name="password" class="carzuri-input" placeholder="At least 8 characters" required>
						<button type="button" class="carzuri-toggle-pw" aria-label="Toggle password visibility">
							<svg class="carzuri-icon-svg carzuri-pw-show" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
						</button>
					</div>
					<div id="carzuri-pw-strength" class="carzuri-pw-meter">
						<div class="carzuri-pw-bar"></div>
						<span class="carzuri-pw-label">Password Strength</span>
					</div>
				</div>

				<div class="carzuri-form-footer">
					<button type="submit" class="carzuri-btn carzuri-btn-primary carzuri-btn-block" id="carzuri-reg-btn">
						<span>Create Account</span>
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
					</button>
				</div>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	public function handle_ajax_registration() {
		check_ajax_referer( 'carzuri_buyer_nonce', 'nonce' );

		$full_name = isset( $_POST['full_name'] ) ? sanitize_text_field( wp_unslash( $_POST['full_name'] ) ) : '';
		$email     = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$password  = isset( $_POST['password'] ) ? $_POST['password'] : '';
		$phone     = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';

		if ( empty( $full_name ) || empty( $email ) || empty( $password ) ) {
			wp_send_json_error( array( 'message' => 'Please fill in all required fields.' ) );
		}

		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => 'Please provide a valid email address.' ) );
		}

		if ( email_exists( $email ) ) {
			wp_send_json_error( array( 'message' => 'An account with this email address already exists. Please log in.' ) );
		}

		if ( strlen( $password ) < 8 ) {
			wp_send_json_error( array( 'message' => 'Password must be at least 8 characters long.' ) );
		}

		/* Split Full Name into First and Last Name */
		$name_parts = explode( ' ', trim( $full_name ), 2 );
		$first_name = $name_parts[0];
		$last_name  = isset( $name_parts[1] ) ? $name_parts[1] : '';

		/* Create user with carzuri_buyer role - account exists immediately,
		 * but is treated as unverified until the email link is clicked
		 * (see carzuri_email_verified meta set below). */
		$user_id = wp_insert_user(
			array( 'user_login'    => $email,
				'user_email'    => $email,
				'user_pass'     => $password,
				'first_name'    => $first_name,
				'last_name'     => $last_name,
				'display_name'  => $full_name,
				'role'          => 'carzuri_buyer',
			)
		);

		if ( is_wp_error( $user_id ) ) {
			wp_send_json_error( array( 'message' => $user_id->get_error_message() ) );
		}

		if ( ! empty( $phone ) ) {
			update_user_meta( $user_id, 'carzuri_buyer_phone', $phone );
		}

		/* Generate and store the email verification token. Explicit string
		 * '0' (not boolean/empty) so the dashboard gate can distinguish
		 * "genuinely unverified" from "pre-existing account, never had this
		 * field at all" — the latter must NOT be blocked retroactively. */
		update_user_meta( $user_id, 'carzuri_email_verified', '0' );
		$token = wp_generate_password( 32, false, false );
		update_user_meta( $user_id, 'carzuri_email_verification_token', $token );
		update_user_meta( $user_id, 'carzuri_email_verification_expires', (string) ( time() + DAY_IN_SECONDS ) );

		/* Immediately Log In the Buyer — they land on the dashboard, which
		 * will show the "please verify your email" screen instead of their
		 * normal dashboard content until they click the emailed link. */
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, true );
		do_action( 'wp_login', $email, get_userdata( $user_id ) );

		/* Send verification email (replaces the old plain welcome email —
		 * the account isn't usable yet, so leading with "welcome" alone
		 * would be misleading). */
		Carzuri_Buyer_Notifications::send_verification_email( $user_id, $token );

		$redirect_url = home_url( '/customer-dashboard/' );

		wp_send_json_success(
			array( 'message'      => 'Account created! Please check your email to verify your address before you can access your dashboard.',
				'redirect_url' => $redirect_url,
				'user'         => array(
					'id'           => $user_id,
					'display_name' => $full_name,
					'email'        => $email,
				),
			)
		);
	}

	/**
	 * Handles GET requests carrying ?carzuri_verify_token=...&carzuri_verify_uid=...
	 * (the link sent in the verification email). Runs on 'init' so it works
	 * regardless of which page the link points at — no dedicated route needed.
	 */
	public function maybe_handle_email_verification_link() {
		if ( empty( $_GET['carzuri_verify_token'] ) || empty( $_GET['carzuri_verify_uid'] ) ) {
			return;
		}

		$user_id = absint( $_GET['carzuri_verify_uid'] );
		$token   = sanitize_text_field( wp_unslash( $_GET['carzuri_verify_token'] ) );

		if ( ! $user_id ) {
			return;
		}

		$stored_token   = get_user_meta( $user_id, 'carzuri_email_verification_token', true );
		$expires        = (int) get_user_meta( $user_id, 'carzuri_email_verification_expires', true );
		$already_verified = ( get_user_meta( $user_id, 'carzuri_email_verified', true ) === '1' );

		$dashboard_url = home_url( '/customer-dashboard/' );

		if ( $already_verified ) {
			wp_safe_redirect( add_query_arg( 'carzuri_verified', '1', $dashboard_url ) );
			exit;
		}

		if ( empty( $stored_token ) || ! hash_equals( $stored_token, $token ) ) {
			wp_safe_redirect( add_query_arg( 'carzuri_verify_error', 'invalid', $dashboard_url ) );
			exit;
		}

		if ( $expires && time() > $expires ) {
			wp_safe_redirect( add_query_arg( 'carzuri_verify_error', 'expired', $dashboard_url ) );
			exit;
		}

		update_user_meta( $user_id, 'carzuri_email_verified', '1' );
		delete_user_meta( $user_id, 'carzuri_email_verification_token' );
		delete_user_meta( $user_id, 'carzuri_email_verification_expires' );

		wp_safe_redirect( add_query_arg( 'carzuri_verified', '1', $dashboard_url ) );
		exit;
	}

	/**
	 * AJAX: logged-in-but-unverified buyer requests a fresh verification email
	 * from the dashboard's blocked screen (their original link may have expired).
	 */
	public function handle_resend_verification() {
		check_ajax_referer( 'carzuri_buyer_nonce', 'nonce' );

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'Please log in first.' ) );
		}

		$user_id = get_current_user_id();

		if ( get_user_meta( $user_id, 'carzuri_email_verified', true ) === '1' ) {
			wp_send_json_success( array( 'message' => 'Your email is already verified.' ) );
		}

		$token = wp_generate_password( 32, false, false );
		update_user_meta( $user_id, 'carzuri_email_verification_token', $token );
		update_user_meta( $user_id, 'carzuri_email_verification_expires', (string) ( time() + DAY_IN_SECONDS ) );

		Carzuri_Buyer_Notifications::send_verification_email( $user_id, $token );

		wp_send_json_success( array( 'message' => 'Verification email sent! Please check your inbox.' ) );
	}
}
