<?php
/**
 * Buyer Email Notifications Handler via WP Mail SMTP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Buyer_Notifications {

	/**
	 * Sends welcome email directly to the newly registered buyer using wp_mail()
	 * Does NOT use site notification email since this goes to the buyer himself/herself
	 * Kept for potential future use (e.g. after verification succeeds) — registration
	 * currently calls send_verification_email() instead, since the account isn't
	 * usable yet at the point this would have fired.
	 */
	public static function send_welcome_email( $user_id ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		$to          = $user->user_email;
		$site_name   = get_bloginfo( 'name' );
		$first_name  = ! empty( $user->first_name ) ? $user->first_name : $user->display_name;
		$dashboard_url = home_url( '/customer-dashboard/' );

		$subject = sprintf( 'Welcome to %s, %s!', $site_name, $first_name );

		$message = '
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<title>' . esc_html( $subject ) . '</title>
			<style>
				body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #1e293b; margin: 0; padding: 20px; }
				.email-card { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
				.email-header { background: #0f172a; padding: 28px 32px; text-align: center; color: #ffffff; }
				.email-header h1 { margin: 0; font-size: 22px; font-weight: 700; tracking-spacing: -0.5px; }
				.email-body { padding: 32px; }
				.email-body h2 { font-size: 18px; color: #0f172a; margin-top: 0; }
				.email-body p { line-height: 1.6; color: #475569; font-size: 15px; }
				.btn-primary { display: inline-block; background-color: #2563eb; color: #ffffff !important; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; margin-top: 16px; text-align: center; }
				.email-footer { background-color: #f1f5f9; padding: 20px 32px; text-align: center; font-size: 13px; color: #64748b; border-top: 1px solid #e2e8f0; }
				.feature-list { background: #f8fafc; border-radius: 8px; padding: 16px 20px; margin: 20px 0; border: 1px solid #e2e8f0; }
				.feature-list ul { margin: 0; padding-left: 20px; }
				.feature-list li { margin-bottom: 8px; color: #334155; font-size: 14px; }
			</style>
		</head>
		<body>
			<div class="email-card">
				<div class="email-header">
					<h1>' . esc_html( $site_name ) . '</h1>
				</div>
				<div class="email-body">
					<h2>Welcome aboard, ' . esc_html( $first_name ) . '!</h2>
					<p>Your buyer account has been created and is active immediately. You now have full access to our complete car buyer experience.</p>
					
					<div class="feature-list">
						<strong>What you can do right now:</strong>
						<ul>
							<li>Save favorite vehicles to your personal wishlist</li>
							<li>Track active dealer inquiries & lead status</li>
							<li>Submit instant vehicle finance applications</li>
							<li>Request instant AI smart vehicle valuations</li>
						</ul>
					</div>

					<p>Click below to open your personal Customer Dashboard:</p>
					<a href="' . esc_url( $dashboard_url ) . '" class="btn-primary">Go to My Dashboard &rarr;</a>
				</div>
				<div class="email-footer">
					&copy; ' . date( 'Y' ) . ' ' . esc_html( $site_name ) . '. Sent via WP Mail SMTP. All rights reserved.
				</div>
			</div>
		</body>
		</html>';

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
		);

		return wp_mail( $to, $subject, $message, $headers );
	}

	/**
	 * Sends the email address verification link to a newly registered (or
	 * resend-requesting) buyer. The link points at the customer dashboard
	 * page with two query args; Carzuri_Buyer_Registration::maybe_handle_email_verification_link()
	 * (hooked on 'init') validates them on the next page load and flips
	 * carzuri_email_verified to '1' before redirecting back with a success flag.
	 */
	public static function send_verification_email( $user_id, $token ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		$to         = $user->user_email;
		$site_name  = get_bloginfo( 'name' );
		$first_name = ! empty( $user->first_name ) ? $user->first_name : $user->display_name;

		$verify_url = add_query_arg(
			array(
				'carzuri_verify_token' => rawurlencode( $token ),
				'carzuri_verify_uid'   => $user_id,
			),
			home_url( '/customer-dashboard/' )
		);

		$subject = sprintf( 'Please confirm your email for %s', $site_name );

		$message = '
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<title>' . esc_html( $subject ) . '</title>
			<style>
				body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #1e293b; margin: 0; padding: 20px; }
				.email-card { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
				.email-header { background: #0f172a; padding: 28px 32px; text-align: center; color: #ffffff; }
				.email-header h1 { margin: 0; font-size: 22px; font-weight: 700; }
				.email-body { padding: 32px; }
				.email-body h2 { font-size: 18px; color: #0f172a; margin-top: 0; }
				.email-body p { line-height: 1.6; color: #475569; font-size: 15px; }
				.btn-primary { display: inline-block; background-color: #d4af37 !important; color: #0b192c !important; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 700; margin-top: 16px; text-align: center; }
				.email-footer { background-color: #f1f5f9; padding: 20px 32px; text-align: center; font-size: 13px; color: #64748b; border-top: 1px solid #e2e8f0; }
				.fallback-link { word-break: break-all; font-size: 12px; color: #94a3b8; margin-top: 16px; }
			</style>
		</head>
		<body>
			<div class="email-card">
				<div class="email-header">
					<h1>' . esc_html( $site_name ) . '</h1>
				</div>
				<div class="email-body">
					<h2>One more step, ' . esc_html( $first_name ) . '</h2>
					<p>Thanks for creating a buyer account. Please confirm this is really your email address by clicking the button below — this keeps your account (and everyone else\'s) secure.</p>
					<p>This link will expire in 24 hours.</p>
					<a href="' . esc_url( $verify_url ) . '" class="btn-primary">Verify My Email Address &rarr;</a>
					<p class="fallback-link">If the button doesn\'t work, copy and paste this link into your browser:<br>' . esc_html( $verify_url ) . '</p>
					<p>If you didn\'t create this account, you can safely ignore this email.</p>
				</div>
				<div class="email-footer">
					&copy; ' . date( 'Y' ) . ' ' . esc_html( $site_name ) . '. Sent via WP Mail SMTP. All rights reserved.
				</div>
			</div>
		</body>
		</html>';

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
		);

		return wp_mail( $to, $subject, $message, $headers );
	}
}
