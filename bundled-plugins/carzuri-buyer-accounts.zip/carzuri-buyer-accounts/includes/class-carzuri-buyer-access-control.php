<?php
/**
 * Buyer Access Control & Admin Protection
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Buyer_Access_Control {

	public function __construct() {
		/* Hide admin bar for buyer role */
		add_action( 'after_setup_theme', array( $this, 'hide_admin_bar' ) );

		/* Redirect wp-admin access for non-admin buyers */
		add_action( 'admin_init', array( $this, 'restrict_admin_access' ) );
	}

	/**
	 * Completely hides the WordPress Admin Bar for buyers
	 */
	public function hide_admin_bar() {
		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
			if ( in_array( 'carzuri_buyer', (array) $user->roles, true ) || ! current_user_can( 'edit_posts' ) ) {
				show_admin_bar( false );
			}
		}
	}

	/**
	 * Restricts /wp-admin/ access for buyers, redirecting them to front-end page
	 * Crucial: Bypasses AJAX and REST API requests!
	 */
	public function restrict_admin_access() {
		/* Bypass guard 1: AJAX requests */
		if ( wp_doing_ajax() ) {
			return;
		}

		/* Bypass guard 2: REST API requests */
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}

		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
			if ( in_array( 'carzuri_buyer', (array) $user->roles, true ) || ! current_user_can( 'edit_posts' ) ) {
				$redirect_url = home_url( '/customer-dashboard/' );
				wp_redirect( $redirect_url );
				exit;
			}
		}
	}
}
