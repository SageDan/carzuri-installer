<?php
/**
 * Buyer Login Form & Shortcode
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Buyer_Login {

	public function __construct() {
		add_shortcode( 'carzuri_buyer_login', array( $this, 'render_shortcode' ) );
		add_action( 'wp_ajax_nopriv_carzuri_buyer_login', array( $this, 'handle_ajax_login' ) );
		add_action( 'wp_ajax_carzuri_buyer_login', array( $this, 'handle_ajax_login' ) );
	}

	public function render_shortcode( $atts ) {
		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
			$logout_url = wp_logout_url( get_permalink() );
			$dashboard_url = home_url( '/customer-dashboard/' );

			ob_start();
			?>
			<div class="carzuri-buyer-card carzuri-buyer-logged-in-box">
				<div class="carzuri-buyer-user-profile">
					<div class="carzuri-buyer-avatar">
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
					</div>
					<div class="carzuri-buyer-details">
						<span class="carzuri-badge carzuri-badge-buyer">Verified Buyer</span>
						<h4 class="carzuri-buyer-name"><?php echo esc_html( $user->display_name ); ?></h4>
						<p class="carzuri-buyer-email"><?php echo esc_html( $user->user_email ); ?></p>
					</div>
				</div>

				<div class="carzuri-buyer-actions">
					<a href="<?php echo esc_url( $dashboard_url ); ?>" class="carzuri-btn carzuri-btn-primary">
						<span>Customer Dashboard</span>
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
					</a>
					<a href="<?php echo esc_url( $logout_url ); ?>" class="carzuri-btn carzuri-btn-outline carzuri-btn-logout">
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
						<span>Log Out</span>
					</a>
				</div>
			</div>
			<?php
			return ob_get_clean();
		}

		$lost_password_url = wp_lostpassword_url( home_url( '/buyer-login/' ) );

		ob_start();
		?>
		<div class="carzuri-buyer-card carzuri-buyer-login-wrap">
			<div class="carzuri-buyer-card-header">
				<h3 class="carzuri-buyer-title">Sign In to Your Account</h3>
				<p class="carzuri-buyer-subtitle">Access your saved vehicles, inquiries, and finance applications.</p>
			</div>

			<form id="carzuri-buyer-login-form" class="carzuri-buyer-form" method="post">
				<?php wp_nonce_field( 'carzuri_buyer_nonce', 'carzuri_login_nonce' ); ?>
				
				<div id="carzuri-login-feedback" class="carzuri-buyer-feedback"></div>

				<div class="carzuri-form-group">
					<label for="carzuri_login_email">Email Address <span class="carzuri-required">*</span></label>
					<div class="carzuri-input-icon-wrap">
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
						<input type="email" id="carzuri_login_email" name="log" class="carzuri-input" placeholder="sarah@example.com" required>
					</div>
				</div>

				<div class="carzuri-form-group">
					<div style="display: flex; justify-content: space-between; align-items: center;">
						<label for="carzuri_login_password" style="margin: 0;">Password <span class="carzuri-required">*</span></label>
						<a href="<?php echo esc_url( $lost_password_url ); ?>" style="font-size: 12px; color: var(--carzuri-gold, #D4AF37); text-decoration: none; font-weight: 600;">Forgot your password?</a>
					</div>
					<div class="carzuri-input-icon-wrap">
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
						<input type="password" id="carzuri_login_password" name="pwd" class="carzuri-input" placeholder="Your account password" required>
						<button type="button" class="carzuri-toggle-pw" aria-label="Toggle password visibility">
							<svg class="carzuri-icon-svg carzuri-pw-show" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
						</button>
					</div>
				</div>

				<div class="carzuri-form-group">
					<label for="carzuri_login_remember" style="display: flex; align-items: center; gap: 8px; font-weight: 500; cursor: pointer; margin: 0;">
						<input type="checkbox" id="carzuri_login_remember" name="remember" value="1" checked style="margin: 0; width: 16px; height: 16px; cursor: pointer;">
						<span>Keep me signed in</span>
					</label>
				</div>

				<div class="carzuri-form-footer">
					<button type="submit" class="carzuri-btn carzuri-btn-primary carzuri-btn-block" id="carzuri-login-btn">
						<span>Sign In</span>
						<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
					</button>
				</div>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	public function handle_ajax_login() {
		check_ajax_referer( 'carzuri_buyer_nonce', 'nonce' );

		$username = isset( $_POST['log'] ) ? sanitize_text_field( wp_unslash( $_POST['log'] ) ) : '';
		$password = isset( $_POST['pwd'] ) ? $_POST['pwd'] : '';

		// Defaults to true (checked) if the field is somehow missing from
		// the request at all, matching this form's previous always-on
		// behavior for anyone using an old cached copy of the page's JS.
		// If the checkbox itself is present but simply unchecked, the
		// browser omits it from the submitted data entirely (standard
		// HTML checkbox behavior) — the JS explicitly sends '0' in that
		// case instead, which is what actually turns this off.
		$remember = ! isset( $_POST['remember'] ) || '0' !== $_POST['remember'];

		if ( empty( $username ) || empty( $password ) ) {
			wp_send_json_error( array( 'message' => 'Please enter both your email address and password.' ) );
		}

		$creds = array(
			'user_login'    => $username,
			'user_password' => $password,
			'remember'      => $remember,
		);

		$user = wp_signon( $creds, is_ssl() );

		if ( is_wp_error( $user ) ) {
			wp_send_json_error( array( 'message' => 'Invalid email address or password. Please try again.' ) );
		}

		// CRITICAL: verify this account is genuinely a buyer before granting
		// access to the buyer dashboard. wp_signon() only checks that the
		// password is correct for SOME WordPress account — it has no idea
		// which login form was used to submit it. Without this check, a
		// dealer entering their own valid credentials into this Buyer Login
		// form would be silently logged in and redirected to a buyer
		// dashboard that was never built for them (this was the real root
		// cause of a "Favorites returns 403" report investigated this
		// session — the account genuinely wasn't a buyer, so it correctly
		// lacked the carzuri_save_favorites capability; the actual bug was
		// this form letting that mismatched login happen in the first place).
		$roles            = (array) $user->roles;
		$is_buyer_account = in_array( 'carzuri_buyer', $roles, true )
			|| in_array( 'administrator', $roles, true )
			|| in_array( 'carzuri_admin', $roles, true );

		if ( ! $is_buyer_account ) {
			// wp_signon() already set real auth cookies for this account —
			// log back out immediately so they aren't left signed in under
			// the wrong role while this form shows them an error.
			wp_logout();

			if ( in_array( 'carzuri_dealer', $roles, true ) ) {
				wp_send_json_error( array( 'message' => 'This looks like a dealer account. Please use the Dealer Login page instead.' ) );
			}

			wp_send_json_error( array( 'message' => 'This account is not registered as a buyer. Please check you are using the correct login page.' ) );
		}

		$redirect_url = home_url( '/customer-dashboard/' );

		// New Device Verification — shared mechanism from Carzuri Core
		// (carzuri_is_known_device() / carzuri_send_device_verification_code()),
		// applied identically across Buyer, Dealer, and Admin logins so a
		// device verified once for an account is remembered everywhere.
		// Placed after the buyer-role check above so a mismatched-role
		// login (e.g. a dealer using this form) is still rejected outright
		// rather than triggering an unnecessary verification email.
		if ( ! carzuri_is_known_device( $user->ID ) ) {
			wp_logout();
			carzuri_send_device_verification_code( $user->ID );

			wp_send_json_success(
				array(
					'requires_device_verification' => true,
					'user_id'                      => $user->ID,
					'remember'                     => $remember,
					'redirect_url'                 => $redirect_url,
					'message'                      => 'For your security, we emailed you a verification code. Please enter it below to finish signing in.',
				)
			);
		}

		wp_send_json_success(
			array( 'message'      => 'Login successful! Redirecting...',
				'redirect_url' => $redirect_url,
				'user'         => array(
					'id'           => $user->ID,
					'display_name' => $user->display_name,
					'email'        => $user->user_email,
				),
			)
		);
	}
}
