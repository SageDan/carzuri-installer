<?php
/**
 * Main Orchestrator Class for Carzuri Buyer Accounts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Buyer_Accounts {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->init_hooks();
		$this->init_components();
	}

	private function init_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		
		/* REST API Routes must be registered via rest_api_init, never earlier */
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
	}

	private function init_components() {
		new Carzuri_Buyer_Registration();
		new Carzuri_Buyer_Login();
		new Carzuri_Buyer_Access_Control();
		new Carzuri_Buyer_Notifications();
	}

	public function enqueue_assets() {
		/* Enqueue Core Design System handle if registered by Core */
		if ( wp_style_is( 'carzuri-design-system', 'registered' ) ) {
			wp_enqueue_style( 'carzuri-design-system' );
		}

		wp_enqueue_style(
			'carzuri-buyer-accounts-css',
			CARZURI_BUYER_ACCOUNTS_URL . 'assets/css/buyer-accounts.css',
			array(),
			CARZURI_BUYER_ACCOUNTS_VERSION
		);

		wp_enqueue_script(
			'carzuri-buyer-accounts-js',
			CARZURI_BUYER_ACCOUNTS_URL . 'assets/js/buyer-accounts.js',
			array( 'jquery' ),
			CARZURI_BUYER_ACCOUNTS_VERSION,
			true
		);

		/* Determine sensible dashboard URL */
		$dashboard_url = home_url( '/customer-dashboard/' );

		wp_localize_script(
			'carzuri-buyer-accounts-js',
			'carzuriBuyerAccounts',
			array( 'ajax_url'      => admin_url( 'admin-ajax.php' ),
				'nonce'         => wp_create_nonce( 'carzuri_buyer_nonce' ),
				'dashboard_url' => $dashboard_url,
				'site_name'     => get_bloginfo( 'name' ),
				// New Device Verification: the base REST URL (including the
				// carzuri/v1 namespace) so buyer-accounts.js can call Core's
				// shared /verify-device and /verify-device/resend endpoints
				// directly, without needing its own duplicate REST routes.
				'rest_root'     => esc_url_raw( rest_url( 'carzuri/v1/' ) ),
				'rest_nonce'    => wp_create_nonce( 'wp_rest' ),
			)
		);
	}

	public function register_rest_routes() {
		register_rest_route(
			'carzuri/v1',
			'/buyer/me',
			array( 'methods'             => 'GET',
				'callback'            => array( $this, 'rest_get_current_buyer' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public function rest_get_current_buyer() {
		if ( ! is_user_logged_in() ) {
			return new WP_REST_Response( array( 'logged_in' => false ), 200 );
		}

		$user = wp_get_current_user();
		if ( ! in_array( 'carzuri_buyer', (array) $user->roles, true ) ) {
			return new WP_REST_Response(
				array( 'logged_in' => true,
					'is_buyer'  => false,
					'role'      => reset( $user->roles ),
				),
				200
			);
		}

		return new WP_REST_Response(
			array( 'logged_in'    => true,
				'is_buyer'     => true,
				'id'           => $user->ID,
				'display_name' => $user->display_name,
				'email'        => $user->user_email,
				'phone'        => get_user_meta( $user->ID, 'carzuri_buyer_phone', true ),
			),
			200
		);
	}
}
