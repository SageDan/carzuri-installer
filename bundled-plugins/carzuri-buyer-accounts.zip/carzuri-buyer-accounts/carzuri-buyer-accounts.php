<?php
/**
 * Plugin Name: Carzuri Buyer Accounts
 * Plugin URI:  https://carzuri.com/plugins/buyer-accounts
 * Description: Lightweight, instant-access public buyer registration and login flow for the Carzuri suite.
 * Version:     1.0.1
 * Author:      Carzuri Engineering
 * Author URI:  https://carzuri.com
 * Text Domain: carzuri-buyer-accounts
 * Domain Path: /languages
 * License:     GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'CARZURI_BUYER_ACCOUNTS_VERSION', '1.0.1' );
define( 'CARZURI_BUYER_ACCOUNTS_PATH', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_BUYER_ACCOUNTS_URL', plugin_dir_url( __FILE__ ) );

/* Load Core Classes */
require_once CARZURI_BUYER_ACCOUNTS_PATH . 'includes/class-carzuri-buyer-accounts.php';
require_once CARZURI_BUYER_ACCOUNTS_PATH . 'includes/class-carzuri-buyer-registration.php';
require_once CARZURI_BUYER_ACCOUNTS_PATH . 'includes/class-carzuri-buyer-login.php';
require_once CARZURI_BUYER_ACCOUNTS_PATH . 'includes/class-carzuri-buyer-access-control.php';
require_once CARZURI_BUYER_ACCOUNTS_PATH . 'includes/class-carzuri-buyer-notifications.php';

/**
 * Initialize the plugin instance
 */
function carzuri_buyer_accounts_init() {
	return Carzuri_Buyer_Accounts::get_instance();
}
add_action( 'plugins_loaded', 'carzuri_buyer_accounts_init' );
