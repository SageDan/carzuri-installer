/* Carzuri Buyer Accounts Front-end Script */
/* Note: External enqueued JS only. No inline single-line slash comments inside shortcodes. */

(function($) {
  'use strict';

  $(document).ready(function() {
    /* Password Visibility Toggle */
    $(document).on('click', '.carzuri-toggle-pw', function(e) {
      e.preventDefault();
      var $input = $(this).closest('.carzuri-input-icon-wrap').find('input');
      var type = $input.attr('type') === 'password' ? 'text' : 'password';
      $input.attr('type', type);
      $(this).toggleClass('pw-visible');
    });

    /* Live Password Strength Meter */
    $(document).on('input', '#carzuri_reg_password', function() {
      var val = $(this).val();
      var $meter = $('#carzuri-pw-strength');
      var $label = $meter.find('.carzuri-pw-label');

      if (!val) {
        $meter.removeAttr('data-strength');
        $label.text('Password Strength');
        return;
      }

      if (val.length < 6) {
        $meter.attr('data-strength', 'weak');
        $label.text('Weak (Min 8 chars required)');
      } else if (val.length >= 8 && /[A-Z]/.test(val) && /[0-9]/.test(val)) {
        $meter.attr('data-strength', 'strong');
        $label.text('Strong Password');
      } else {
        $meter.attr('data-strength', 'medium');
        $label.text('Medium Strength');
      }
    });

    /* Registration AJAX Submission */
    $('#carzuri-buyer-reg-form').on('submit', function(e) {
      e.preventDefault();
      var $form = $(this);
      var $btn = $form.find('#carzuri-reg-btn');
      var $feedback = $('#carzuri-reg-feedback');

      $feedback.empty().removeClass('carzuri-buyer-alert carzuri-alert-error carzuri-alert-success');
      $btn.prop('disabled', true).addClass('carzuri-loading');

      var formData = {
        action: 'carzuri_buyer_register',
        nonce: typeof carzuriBuyerAccounts !== 'undefined' ? carzuriBuyerAccounts.nonce : '',
        full_name: $form.find('#carzuri_full_name').val(),
        email: $form.find('#carzuri_email').val(),
        phone: $form.find('#carzuri_phone').val(),
        password: $form.find('#carzuri_reg_password').val()
      };

      $.post(typeof carzuriBuyerAccounts !== 'undefined' ? carzuriBuyerAccounts.ajax_url : '/wp-admin/admin-ajax.php', formData)
        .done(function(response) {
          $btn.prop('disabled', false).removeClass('carzuri-loading');
          if (response.success) {
            $feedback.addClass('carzuri-buyer-alert carzuri-alert-success').text(response.data.message);
            setTimeout(function() {
              window.location.href = response.data.redirect_url;
            }, 1200);
          } else {
            $feedback.addClass('carzuri-buyer-alert carzuri-alert-error').text(response.data.message);
          }
        })
        .fail(function() {
          $btn.prop('disabled', false).removeClass('carzuri-loading');
          $feedback.addClass('carzuri-buyer-alert carzuri-alert-error').text('A network error occurred. Please try again.');
        });
    });

    /**
     * New Device Verification: builds and shows a one-time-code entry step
     * in place of the login form, calling Carzuri Core's shared
     * /carzuri/v1/verify-device endpoint (base URL localized as
     * carzuriBuyerAccounts.rest_root). Built dynamically here rather than
     * as a template addition, since the markup only ever needs to appear
     * for this one flow.
     */
    function showDeviceVerificationStep($form, userId, remember, redirectUrl) {
      $form.hide();

      var restRoot = (typeof carzuriBuyerAccounts !== 'undefined' && carzuriBuyerAccounts.rest_root) ? carzuriBuyerAccounts.rest_root : '/wp-json/carzuri/v1/';
      var restNonce = (typeof carzuriBuyerAccounts !== 'undefined' && carzuriBuyerAccounts.rest_nonce) ? carzuriBuyerAccounts.rest_nonce : '';
      var fallbackRedirect = (typeof carzuriBuyerAccounts !== 'undefined' && carzuriBuyerAccounts.dashboard_url) ? carzuriBuyerAccounts.dashboard_url : '/customer-dashboard/';

      var $verifyBlock = $(
        '<div id="carzuri-device-verify-block" class="carzuri-buyer-card">' +
          '<div class="carzuri-buyer-card-header">' +
            '<h3 class="carzuri-buyer-title">Verify This Device</h3>' +
            '<p class="carzuri-buyer-subtitle">Enter the 6-digit code we just emailed you to finish signing in.</p>' +
          '</div>' +
          '<div id="carzuri-verify-feedback" class="carzuri-buyer-feedback"></div>' +
          '<div class="carzuri-form-group">' +
            '<label for="carzuri_device_code">Verification Code</label>' +
            '<div class="carzuri-input-icon-wrap">' +
              '<svg class="carzuri-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>' +
              '<input type="text" id="carzuri_device_code" class="carzuri-input" inputmode="numeric" maxlength="6" placeholder="123456" style="letter-spacing: 2px;">' +
            '</div>' +
          '</div>' +
          '<div class="carzuri-form-footer">' +
            '<button type="button" id="carzuri-verify-code-btn" class="carzuri-btn carzuri-btn-primary carzuri-btn-block">' +
              '<span>Verify & Continue</span>' +
            '</button>' +
          '</div>' +
          '<div style="text-align:center; margin-top: 16px;">' +
            '<span style="font-size: 13px; color: var(--carzuri-muted, #64748B);">Didn\'t get a code?</span> ' +
            '<button type="button" id="carzuri-resend-code-btn" style="background:none; border:none; padding:0; font-size: 13px; font-weight: 600; color: var(--carzuri-primary, #D97706); cursor: pointer;">Resend it</button>' +
          '</div>' +
        '</div>'
      );

      $form.closest('.carzuri-buyer-card').after($verifyBlock);

      var $verifyFeedback = $('#carzuri-verify-feedback');

      function showFeedback(message, type) {
        $verifyFeedback.empty().removeClass('carzuri-buyer-alert carzuri-alert-error carzuri-alert-success carzuri-alert-info')
          .addClass('carzuri-buyer-alert ' + (type === 'error' ? 'carzuri-alert-error' : (type === 'success' ? 'carzuri-alert-success' : 'carzuri-alert-info')))
          .text(message);
      }

      $('#carzuri-verify-code-btn').on('click', function() {
        var code = $('#carzuri_device_code').val().trim();
        if (!code) {
          showFeedback('Please enter the code we emailed you.', 'error');
          return;
        }

        var $btn = $(this);
        $btn.prop('disabled', true).addClass('carzuri-loading');

        $.ajax({
          url: restRoot + 'verify-device',
          method: 'POST',
          contentType: 'application/json',
          beforeSend: function(xhr) {
            if (restNonce) {
              xhr.setRequestHeader('X-WP-Nonce', restNonce);
            }
          },
          data: JSON.stringify({ user_id: userId, code: code, remember: remember })
        })
          .done(function(response) {
            if (response.success) {
              showFeedback(response.message || 'Verified! Redirecting...', 'success');
              setTimeout(function() {
                window.location.href = redirectUrl || fallbackRedirect;
              }, 800);
            } else {
              $btn.prop('disabled', false).removeClass('carzuri-loading');
              showFeedback(response.message || 'Incorrect code. Please try again.', 'error');
            }
          })
          .fail(function(xhr) {
            $btn.prop('disabled', false).removeClass('carzuri-loading');
            var msg = 'Could not verify the code. Please try again.';
            if (xhr.responseJSON && xhr.responseJSON.message) {
              msg = xhr.responseJSON.message;
            }
            showFeedback(msg, 'error');
          });
      });

      $('#carzuri-resend-code-btn').on('click', function() {
        var $btn = $(this);
        $btn.prop('disabled', true).text('Sending...');

        $.ajax({
          url: restRoot + 'verify-device/resend',
          method: 'POST',
          contentType: 'application/json',
          beforeSend: function(xhr) {
            if (restNonce) {
              xhr.setRequestHeader('X-WP-Nonce', restNonce);
            }
          },
          data: JSON.stringify({ user_id: userId })
        })
          .done(function(response) {
            $btn.prop('disabled', false).text('Resend it');
            showFeedback(response.message || 'A new code has been sent.', response.success ? 'success' : 'error');
          })
          .fail(function() {
            $btn.prop('disabled', false).text('Resend it');
            showFeedback('Could not resend the code. Please try again.', 'error');
          });
      });
    }

    /* Login AJAX Submission */
    $('#carzuri-buyer-login-form').on('submit', function(e) {
      e.preventDefault();
      var $form = $(this);
      var $btn = $form.find('#carzuri-login-btn');
      var $feedback = $('#carzuri-login-feedback');

      $feedback.empty().removeClass('carzuri-buyer-alert carzuri-alert-error carzuri-alert-success');
      $btn.prop('disabled', true).addClass('carzuri-loading');

      var rememberChecked = $form.find('#carzuri_login_remember').is(':checked');

      var formData = {
        action: 'carzuri_buyer_login',
        nonce: typeof carzuriBuyerAccounts !== 'undefined' ? carzuriBuyerAccounts.nonce : '',
        log: $form.find('#carzuri_login_email').val(),
        pwd: $form.find('#carzuri_login_password').val(),
        remember: rememberChecked ? '1' : '0'
      };

      $.post(typeof carzuriBuyerAccounts !== 'undefined' ? carzuriBuyerAccounts.ajax_url : '/wp-admin/admin-ajax.php', formData)
        .done(function(response) {
          $btn.prop('disabled', false).removeClass('carzuri-loading');

          if (response.success && response.data && response.data.requires_device_verification) {
            $feedback.addClass('carzuri-buyer-alert carzuri-alert-info').text(response.data.message || 'Please verify your device to continue.');
            showDeviceVerificationStep($form, response.data.user_id, response.data.remember, response.data.redirect_url);
            return;
          }

          if (response.success) {
            $feedback.addClass('carzuri-buyer-alert carzuri-alert-success').text(response.data.message);
            setTimeout(function() {
              window.location.href = response.data.redirect_url;
            }, 1000);
          } else {
            $feedback.addClass('carzuri-buyer-alert carzuri-alert-error').text(response.data.message);
          }
        })
        .fail(function() {
          $btn.prop('disabled', false).removeClass('carzuri-loading');
          $feedback.addClass('carzuri-buyer-alert carzuri-alert-error').text('Authentication failed. Please verify network connectivity.');
        });
    });
  });
})(jQuery);
