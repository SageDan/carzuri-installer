=== Carzuri Buyer Accounts ===
Contributors: carzuri
Tags: buyer registration, buyer login, carzuri, user accounts, access control
Requires at least: 6.0
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later

Lightweight, public buyer registration and login flow for the Carzuri suite.

== Description ==
Carzuri Buyer Accounts version 1.0.0 provides a lightweight, public buyer registration and login flow, granting visitors instant access as a logged-in `carzuri_buyer` account.

Key Features:
- Shortcode [carzuri_buyer_registration] for front-end registration.
- Shortcode [carzuri_buyer_login] with show/hide password toggle & logout link.
- Instant buyer account activation with NO admin approval delay.
- Welcome email dispatched automatically to the buyer via WP Mail SMTP.
- Admin Bar hiding and /wp-admin/ access protection with REST and AJAX bypass guards.
- Full mobile-responsive layout built on the Carzuri Core design system.

== Shortcodes ==
* [carzuri_buyer_registration] - Renders the public buyer registration form.
* [carzuri_buyer_login] - Renders the buyer login form or profile card if logged in.
