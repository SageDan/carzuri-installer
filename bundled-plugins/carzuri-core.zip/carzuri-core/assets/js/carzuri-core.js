/**
 * Carzuri Core Client-Side Engine
 * 
 * Manages front-end REST API communication, nonce verification,
 * and standard trigger bindings (such as favorite toggles).
 */

(function($) {
  'use strict';

  // Global Namespace
  window.Carzuri = window.Carzuri || {};

  // Core configuration properties
  const config = {
    apiRoot: typeof carzuriSettings !== 'undefined' ? carzuriSettings.root : '',
    nonce: typeof carzuriSettings !== 'undefined' ? carzuriSettings.nonce : ''
  };

  /**
   * Send a secure request to the Carzuri REST API.
   */
  Carzuri.request = function(endpoint, method = 'GET', data = {}) {
    return $.ajax({
      url: config.apiRoot + 'carzuri/v1/' + endpoint,
      method: method,
      data: method === 'GET' ? data : JSON.stringify(data),
      contentType: method === 'GET' ? 'application/x-www-form-urlencoded' : 'application/json',
      beforeSend: function(xhr) {
        if (config.nonce) {
          xhr.setRequestHeader('X-WP-Nonce', config.nonce);
        }
      }
    });
  };

  /**
   * Models Service
   */
  Carzuri.Models = {
    // In-memory cache for models by make identifier
    _cache: {},

    /**
     * Fetch vehicle models (optionally filtered by make slug or ID).
     * Uses in-memory caching to eliminate redundant AJAX roundtrips.
     */
    list: function(make) {
      const cacheKey = make ? String(make).toLowerCase() : '__all__';
      if (Carzuri.Models._cache[cacheKey]) {
        return $.Deferred().resolve(Carzuri.Models._cache[cacheKey]).promise();
      }

      const data = {};
      if (make) {
        data.make = make;
      }

      return Carzuri.request('models', 'GET', data).done(function(res) {
        Carzuri.Models._cache[cacheKey] = res;
      });
    },

    /**
     * Clear cached models.
     */
    clearCache: function() {
      Carzuri.Models._cache = {};
    },

    /**
     * Populate a dependent model <select> element dynamically based on selected make.
     * 
     * @param {string|Element|jQuery} selectElement - The model <select> element or jQuery selector.
     * @param {string} makeSlug - The selected vehicle make slug or ID.
     * @param {Object} [options] - Optional display & selection configurations.
     * @param {string} [options.placeholder='Select Model'] - Default option label when make is selected.
     * @param {string} [options.allText='All Models'] - Default option label when no make is selected.
     * @param {string} [options.emptyText='No models available'] - Label when no models exist for make.
     * @param {string} [options.selected=''] - Pre-selected model slug or ID.
     * @returns {jQuery.Promise}
     */
    populateDropdown: function(selectElement, makeSlug, options) {
      const opts = options || {};
      const $select = $(selectElement);
      const placeholder = opts.placeholder || 'Select Model';
      const allText = opts.allText || 'All Models';
      const emptyText = opts.emptyText || 'No models available';
      const selectedValue = opts.selected || '';

      if (!makeSlug) {
        $select.prop('disabled', true).html('<option value="">' + allText + '</option>');
        return $.Deferred().resolve([]).promise();
      }

      $select.prop('disabled', true).html('<option value="">Loading models...</option>');

      return Carzuri.Models.list(makeSlug)
        .done(function(models) {
          $select.empty();
          if (!models || models.length === 0) {
            $select.append('<option value="">' + emptyText + '</option>');
            $select.prop('disabled', true);
          } else {
            $select.append('<option value="">' + placeholder + '</option>');
            models.forEach(function(m) {
              const isSelected = (selectedValue && (selectedValue === m.slug || selectedValue == m.id)) ? ' selected' : '';
              $select.append('<option value="' + m.slug + '" data-id="' + m.id + '"' + isSelected + '>' + m.name + '</option>');
            });
            $select.prop('disabled', false);
          }
          $select.trigger('carzuri:models_populated', [models]);
        })
        .fail(function(err) {
          console.error('Carzuri: Failed to fetch models', err);
          $select.html('<option value="">' + emptyText + '</option>').prop('disabled', true);
        });
    }
  };

  /**
   * Favorites Service
   */
  Carzuri.Favorites = {
    /**
     * Toggle a vehicle's favorite status.
     */
    toggle: function(vehicleId) {
      return Carzuri.request('favorites', 'POST', { vehicle_id: vehicleId });
    },

    /**
     * Fetch user's current favorite vehicles.
     */
    list: function() {
      return Carzuri.request('favorites', 'GET');
    }
  };

  /**
   * Notifications Service
   */
  Carzuri.Notifications = {
    /**
     * Fetch user notifications list.
     */
    list: function() {
      return Carzuri.request('notifications', 'GET');
    },

    /**
     * Mark a single notification or all as read.
     */
    markRead: function(notificationId = null, all = false) {
      const data = {};
      if (all) {
        data.all = true;
      } else if (notificationId) {
        data.notification_id = notificationId;
      }
      return Carzuri.request('notifications/mark-read', 'POST', data);
    }
  };

  // Bind core event triggers on DOM ready
  $(document).ready(function() {
    
    // Bind favorite buttons (convention: [data-carzuri-favorite-btn="ID"])
    $(document).on('click', '[data-carzuri-favorite-btn]', function(e) {
      e.preventDefault();
      const $btn = $(this);
      const vehicleId = $btn.data('carzuri-favorite-btn');
      
      if (!vehicleId) return;

      $btn.addClass('carzuri-loading').prop('disabled', true);

      Carzuri.Favorites.toggle(vehicleId)
        .done(function(res) {
          $btn.toggleClass('is-favorited', res.is_favorite);
          $btn.trigger('carzuri:favorite_toggled', [res]);
        })
        .fail(function(err) {
          console.error('Carzuri: Favorite toggle failed', err);
          $btn.trigger('carzuri:favorite_error', [err]);
        })
        .always(function() {
          $btn.removeClass('carzuri-loading').prop('disabled', false);
        });
    });

    // Dependent Make -> Model dropdown binding for frontend filters and dealer forms
    // Matches: [data-carzuri-make-select], select[name="vehicle_make"], select[name="make"], #carzuri_filter_make
    $(document).on('change', '[data-carzuri-make-select], select[name="vehicle_make"], select[name="make"], #carzuri_filter_make', function() {
      const $makeSelect = $(this);
      const makeSlug = $makeSelect.val();
      
      // Determine target model select
      let targetSelector = $makeSelect.data('target-model') || $makeSelect.data('model-target');
      let $modelSelect;
      
      if (targetSelector) {
        $modelSelect = $(targetSelector);
      } else {
        // Look within same form or nearby container first
        const $form = $makeSelect.closest('form, .carzuri-filter-container, .carzuri-modal-body, .carzuri-card');
        if ($form.length) {
          $modelSelect = $form.find('[data-carzuri-model-select], select[name="vehicle_model"], select[name="model"], #carzuri_filter_model');
        }
        if (!$modelSelect || !$modelSelect.length) {
          $modelSelect = $('[data-carzuri-model-select], select[name="vehicle_model"], select[name="model"], #carzuri_filter_model');
        }
      }

      if ($modelSelect && $modelSelect.length) {
        Carzuri.Models.populateDropdown($modelSelect, makeSlug, {
          placeholder: 'Select Model',
          allText: 'All Models',
          emptyText: 'No models available'
        });
      }
    });

  });

})(jQuery);
