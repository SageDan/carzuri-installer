<?php
/**
 * Global helper functions for the Carzuri platform.
 *
 * @package           Carzuri_Core
 * @subpackage        Carzuri_Core/includes
 */

if ( ! function_exists( 'carzuri_get_vehicle_data' ) ) {
	/**
	 * Retrieve a flattened, clean array of all meta and taxonomy data for a single vehicle post.
	 *
	 * @param int $vehicle_id The ID of the vehicle.
	 * @return array|false Array of vehicle data, or false on failure.
	 */
	function carzuri_get_vehicle_data( $vehicle_id ) {
		$post = get_post( $vehicle_id );
		if ( ! $post || $post->post_type !== 'vehicle' ) {
			return false;
		}

		$meta_keys = array(
			'carzuri_price',
			'carzuri_year',
			'carzuri_mileage',
			'carzuri_condition',
			'carzuri_transmission',
			'carzuri_fuel_type',
			'carzuri_engine_size',
			'carzuri_vin',
			'carzuri_registration_number',
			'carzuri_dealer_id',
			'carzuri_status',
			'carzuri_featured',
			'carzuri_gallery_ids',
			'carzuri_accident_history',
			'carzuri_service_history',
			'carzuri_views_count',
		);

		$data = array(
			'id'          => $post->ID,
			'title'       => $post->post_title,
			'description' => $post->post_content,
			'slug'        => $post->post_name,
			'created_at'  => $post->post_date,
			'updated_at'  => $post->post_modified,
		);

		foreach ( $meta_keys as $key ) {
			$clean_key = str_replace( 'carzuri_', '', $key );
			$value     = get_post_meta( $post->ID, $key, true );

			if ( $key === 'carzuri_featured' ) {
				$value = filter_var( $value, FILTER_VALIDATE_BOOLEAN );
			} elseif ( in_array( $key, array( 'carzuri_price', 'carzuri_year', 'carzuri_mileage', 'carzuri_dealer_id', 'carzuri_views_count' ), true ) ) {
				$value = (int) $value;
			} elseif ( $key === 'carzuri_gallery_ids' ) {
				$value = is_array( $value ) ? $value : ( empty( $value ) ? array() : array_map( 'absint', explode( ',', $value ) ) );
			}

			$data[ $clean_key ] = $value;
		}

		$tax_makes = wp_get_post_terms( $post->ID, 'vehicle_make', array( 'fields' => 'names' ) );
		$data['make'] = ! empty( $tax_makes ) && ! is_wp_error( $tax_makes ) ? $tax_makes[0] : '';
		$tax_make_slugs = wp_get_post_terms( $post->ID, 'vehicle_make', array( 'fields' => 'slugs' ) );
		$data['make_slug'] = ! empty( $tax_make_slugs ) && ! is_wp_error( $tax_make_slugs ) ? $tax_make_slugs[0] : '';

		$tax_models = wp_get_post_terms( $post->ID, 'vehicle_model', array( 'fields' => 'names' ) );
		$data['model'] = ! empty( $tax_models ) && ! is_wp_error( $tax_models ) ? $tax_models[0] : '';
		$tax_model_slugs = wp_get_post_terms( $post->ID, 'vehicle_model', array( 'fields' => 'slugs' ) );
		$data['model_slug'] = ! empty( $tax_model_slugs ) && ! is_wp_error( $tax_model_slugs ) ? $tax_model_slugs[0] : '';

		$tax_bodies = wp_get_post_terms( $post->ID, 'vehicle_body_type', array( 'fields' => 'names' ) );
		$data['body_type'] = ! empty( $tax_bodies ) && ! is_wp_error( $tax_bodies ) ? $tax_bodies[0] : '';

		$tax_locations = wp_get_post_terms( $post->ID, 'vehicle_location', array( 'fields' => 'names' ) );
		$data['location_name'] = ! empty( $tax_locations ) && ! is_wp_error( $tax_locations ) ? $tax_locations[0] : '';

		$featured_image_id = get_post_thumbnail_id( $post->ID );
		$data['featured_image_url'] = $featured_image_id ? wp_get_attachment_url( $featured_image_id ) : '';

		$dealer_id = (int) $data['dealer_id'];
		if ( $dealer_id > 0 ) {
			$dealer_user = get_userdata( $dealer_id );
			$data['dealer_name'] = $dealer_user ? $dealer_user->display_name : __( 'Independent Dealer', 'carzuri-core' );
		} else {
			$data['dealer_name'] = __( 'Carzuri Certified', 'carzuri-core' );
		}

		return $data;
	}
}

if ( ! function_exists( 'carzuri_format_price' ) ) {
	/**
	 * Format numeric amount into KSh currency representation.
	 *
	 * @param int $amount Amount to format.
	 * @return string Formatted price.
	 */
	function carzuri_format_price( $amount ) {
		$currency = get_option( 'carzuri_currency_symbol', 'KSh' );
		return $currency . ' ' . number_format( (int) $amount, 0, '.', ',' );
	}
}

if ( ! function_exists( 'carzuri_create_notification' ) ) {
	/**
	 * Insert a new notification record into the notifications table, and —
	 * as of the Android app's push notification feature — also attempt to
	 * deliver it as a real push notification to every device the recipient
	 * has registered. This is the ONE shared function every plugin across
	 * the whole platform already calls whenever anything notification-worthy
	 * happens, so hooking push delivery in here means every existing
	 * notification type automatically gains push delivery with no changes
	 * needed anywhere else. Push sending is deliberately best-effort: the
	 * in-app notifications table (already inserted into below) remains the
	 * reliable source of truth regardless of whether push delivery
	 * succeeds, is skipped (Firebase not configured), or partially fails.
	 *
	 * @param int    $user_id The recipient user ID.
	 * @param string $type    Notification type (e.g. 'new_inquiry', 'finance_update').
	 * @param string $title   The notification title.
	 * @param string $message The body content.
	 * @param string $link    Target link URL.
	 * @return int|false The ID of the inserted record, or false.
	 */
	function carzuri_create_notification( $user_id, $type, $title, $message, $link = '' ) {
		global $wpdb;

		$table_name = $wpdb->prefix . 'carzuri_notifications';

		$inserted = $wpdb->insert(
			$table_name,
			array(
				'user_id'    => absint( $user_id ),
				'type'       => sanitize_text_field( $type ),
				'title'      => sanitize_text_field( $title ),
				'message'    => wp_kses_post( $message ),
				'link_url'   => esc_url_raw( $link ),
				'is_read'    => 0,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%s', '%d', '%s' )
		);

		if ( $inserted && function_exists( 'carzuri_send_push_notification' ) ) {
			carzuri_send_push_notification( absint( $user_id ), $title, $message, $link );
		}

		return $inserted ? $wpdb->insert_id : false;
	}
}

if ( ! function_exists( 'carzuri_is_dealer' ) ) {
	/**
	 * Determine if a specific user (or current user if null) is a Carzuri Dealer.
	 *
	 * @param int|null $user_id Optional user ID.
	 * @return bool
	 */
	function carzuri_is_dealer( $user_id = null ) {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}
		if ( ! $user_id ) {
			return false;
		}
		return user_can( $user_id, 'carzuri_dealer' );
	}
}

if ( ! function_exists( 'carzuri_is_admin' ) ) {
	/**
	 * Determine if a specific user is a Carzuri Admin (or WP Administrator).
	 *
	 * @param int|null $user_id Optional user ID.
	 * @return bool
	 */
	function carzuri_is_admin( $user_id = null ) {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}
		if ( ! $user_id ) {
			return false;
		}
		return user_can( $user_id, 'carzuri_manage_all_vehicles' ) || user_can( $user_id, 'administrator' );
	}
}

if ( ! function_exists( 'carzuri_user_can' ) ) {
	/**
	 * Wrapper helper for user capability check with default current user check.
	 *
	 * @param string   $capability Capability slug.
	 * @param int|null $user_id    Optional user ID.
	 * @return bool
	 */
	function carzuri_user_can( $capability, $user_id = null ) {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}
		if ( ! $user_id ) {
			return false;
		}
		return user_can( $user_id, $capability );
	}
}

/**
 * ============================================================
 * New Device Email Verification — shared helpers
 * ============================================================
 */

if ( ! function_exists( 'carzuri_known_device_cookie_name' ) ) {
	function carzuri_known_device_cookie_name() {
		return 'carzuri_device_id';
	}
}

if ( ! function_exists( 'carzuri_is_known_device' ) ) {
	function carzuri_is_known_device( $user_id ) {
		$cookie_name = carzuri_known_device_cookie_name();

		if ( empty( $_COOKIE[ $cookie_name ] ) ) {
			return false;
		}

		global $wpdb;
		$token = sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) );
		$hash  = hash( 'sha256', $token );
		$table = $wpdb->prefix . 'carzuri_known_devices';

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM $table WHERE user_id = %d AND device_token_hash = %s",
				absint( $user_id ),
				$hash
			)
		);

		if ( ! $row ) {
			return false;
		}

		$wpdb->update(
			$table,
			array( 'last_seen_at' => current_time( 'mysql' ) ),
			array( 'id' => $row->id ),
			array( '%s' ),
			array( '%d' )
		);

		return true;
	}
}

if ( ! function_exists( 'carzuri_set_known_device_cookie' ) ) {
	function carzuri_set_known_device_cookie( $user_id ) {
		global $wpdb;

		$token = bin2hex( random_bytes( 32 ) );
		$hash  = hash( 'sha256', $token );
		$table = $wpdb->prefix . 'carzuri_known_devices';

		$wpdb->insert(
			$table,
			array(
				'user_id'           => absint( $user_id ),
				'device_token_hash' => $hash,
				'created_at'        => current_time( 'mysql' ),
				'last_seen_at'      => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s' )
		);

		setcookie(
			carzuri_known_device_cookie_name(),
			$token,
			array(
				'expires'  => time() + ( 180 * DAY_IN_SECONDS ),
				'path'     => defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/',
				'domain'   => defined( 'COOKIE_DOMAIN' ) && COOKIE_DOMAIN ? COOKIE_DOMAIN : '',
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
	}
}

if ( ! function_exists( 'carzuri_send_device_verification_code' ) ) {
	function carzuri_send_device_verification_code( $user_id ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		$code = (string) random_int( 100000, 999999 );
		set_transient( 'carzuri_device_code_' . $user_id, $code, 10 * MINUTE_IN_SECONDS );

		$site_name  = get_bloginfo( 'name' );
		$first_name = $user->first_name ? $user->first_name : $user->display_name;

		$subject = sprintf( __( 'Your %s sign-in verification code', 'carzuri-core' ), $site_name );
		$message = sprintf(
			__( "Hello %1\$s,\n\nWe noticed a sign-in to your %2\$s account from a device or browser we don't recognize.\n\nYour verification code is: %3\$s\n\nThis code expires in 10 minutes. If this wasn't you, you can safely ignore this email — your password has not been changed.", 'carzuri-core' ),
			$first_name,
			$site_name,
			$code
		);

		return wp_mail( $user->user_email, $subject, $message );
	}
}

if ( ! function_exists( 'carzuri_verify_device_code' ) ) {
	function carzuri_verify_device_code( $user_id, $code ) {
		$stored = get_transient( 'carzuri_device_code_' . $user_id );

		if ( false === $stored || ! hash_equals( (string) $stored, (string) $code ) ) {
			return false;
		}

		delete_transient( 'carzuri_device_code_' . $user_id );
		carzuri_set_known_device_cookie( $user_id );

		return true;
	}
}

/**
 * ============================================================
 * Push Notifications (Android app) — shared helpers
 * ============================================================
 *
 * Sends real push notifications via Firebase Cloud Messaging's HTTP v1
 * API. Authenticates using a Firebase "service account" JSON credential
 * (set in Carzuri → Settings → API Keys & Secrets) via a self-signed JWT
 * exchanged for a short-lived OAuth access token — implemented directly
 * with PHP's built-in openssl functions so no Composer/external library
 * is required on shared hosting. The access token is cached via a
 * transient (same pattern as Payments' M-Pesa OAuth token caching) so
 * this exchange only happens roughly once per hour, not on every push.
 */

if ( ! function_exists( 'carzuri_base64url_encode' ) ) {
	/**
	 * Base64url encoding (RFC 4648 §5) — the URL-safe variant JWTs require,
	 * which PHP's base64_encode() does not produce directly.
	 *
	 * @param string $data
	 * @return string
	 */
	function carzuri_base64url_encode( $data ) {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
	}
}

if ( ! function_exists( 'carzuri_get_firebase_access_token' ) ) {
	/**
	 * Obtain (and cache) an OAuth access token for calling the Firebase
	 * Cloud Messaging API, using the service account JSON stored in
	 * Settings. Returns false if Firebase isn't configured yet, or if the
	 * token exchange fails for any reason — callers treat this as a signal
	 * to silently skip push delivery, never as a fatal error.
	 *
	 * @return string|false
	 */
	function carzuri_get_firebase_access_token() {
		$cached = get_transient( 'carzuri_fcm_access_token' );
		if ( $cached ) {
			return $cached;
		}

		$service_account_json = get_option( 'carzuri_firebase_service_account_json', '' );
		if ( empty( $service_account_json ) ) {
			return false;
		}

		$account = json_decode( $service_account_json, true );
		if ( empty( $account['client_email'] ) || empty( $account['private_key'] ) ) {
			return false;
		}

		$now = time();

		$header = array(
			'alg' => 'RS256',
			'typ' => 'JWT',
		);
		$claims = array(
			'iss'   => $account['client_email'],
			'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
			'aud'   => 'https://oauth2.googleapis.com/token',
			'iat'   => $now,
			'exp'   => $now + HOUR_IN_SECONDS,
		);

		$signing_input = carzuri_base64url_encode( wp_json_encode( $header ) ) . '.' . carzuri_base64url_encode( wp_json_encode( $claims ) );

		$private_key = openssl_pkey_get_private( $account['private_key'] );
		if ( ! $private_key ) {
			return false;
		}

		$signature = '';
		openssl_sign( $signing_input, $signature, $private_key, 'sha256WithRSAEncryption' );

		$jwt = $signing_input . '.' . carzuri_base64url_encode( $signature );

		$response = wp_remote_post(
			'https://oauth2.googleapis.com/token',
			array(
				'body'    => array(
					'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
					'assertion'  => $jwt,
				),
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $body['access_token'] ) ) {
			return false;
		}

		// Cache for slightly under its real ~1-hour lifetime.
		set_transient( 'carzuri_fcm_access_token', $body['access_token'], 55 * MINUTE_IN_SECONDS );

		return $body['access_token'];
	}
}

if ( ! function_exists( 'carzuri_send_push_notification' ) ) {
	/**
	 * Push a notification to every device token on file for a user. Called
	 * automatically from carzuri_create_notification() — not usually
	 * something other code needs to call directly. Fully best-effort: any
	 * missing configuration, failed token exchange, or individual device
	 * send failure is silently skipped rather than surfaced as an error,
	 * since the in-app notifications table (already written by the caller)
	 * remains the authoritative record regardless.
	 *
	 * @param int    $user_id
	 * @param string $title
	 * @param string $body
	 * @param string $link
	 * @return void
	 */
	function carzuri_send_push_notification( $user_id, $title, $body, $link = '' ) {
		global $wpdb;

		$project_id = get_option( 'carzuri_firebase_project_id', '' );
		if ( empty( $project_id ) ) {
			return;
		}

		$access_token = carzuri_get_firebase_access_token();
		if ( ! $access_token ) {
			return;
		}

		$table  = $wpdb->prefix . 'carzuri_device_tokens';
		$tokens = $wpdb->get_col( $wpdb->prepare( "SELECT token FROM $table WHERE user_id = %d", absint( $user_id ) ) );

		if ( empty( $tokens ) ) {
			return;
		}

		$endpoint = 'https://fcm.googleapis.com/v1/projects/' . rawurlencode( $project_id ) . '/messages:send';

		foreach ( $tokens as $token ) {
			$payload = array(
				'message' => array(
					'token'        => $token,
					'notification' => array(
						'title' => wp_strip_all_tags( $title ),
						'body'  => wp_strip_all_tags( $body ),
					),
					'data'         => array(
						'link' => esc_url_raw( $link ),
					),
				),
			);

			// Individual send results are intentionally not inspected — a
			// stale/uninstalled-app token on one device should never block
			// delivery to a user's other devices, and this whole feature is
			// best-effort on top of the reliable in-app notification.
			wp_remote_post(
				$endpoint,
				array(
					'headers' => array(
						'Authorization' => 'Bearer ' . $access_token,
						'Content-Type'  => 'application/json',
					),
					'body'    => wp_json_encode( $payload ),
					'timeout' => 15,
				)
			);
		}
	}
}
