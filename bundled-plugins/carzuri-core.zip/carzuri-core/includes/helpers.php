<?php
/**
 * Global helper functions for the Carzuri platform.
 *
 * @package           Carzuri_Core
 * @subpackage        Carzuri_Core/includes
 */

if ( ! function_exists( 'carzuri_get_vehicle_data' ) ) {
	/**
	 * Retrieve a flattened, clean array of all meta and taxonomy data for a single vehicle post.
	 *
	 * @param int $vehicle_id The ID of the vehicle.
	 * @return array|false Array of vehicle data, or false on failure.
	 */
	function carzuri_get_vehicle_data( $vehicle_id ) {
		$post = get_post( $vehicle_id );
		if ( ! $post || $post->post_type !== 'vehicle' ) {
			return false;
		}

		// Core meta keys.
		// NOTE: 'carzuri_location' was removed from this list as part of the
		// Location field consolidation — the free-text meta field it read
		// was never displayed anywhere and could silently disagree with the
		// real `vehicle_location` taxonomy term. `location_name` below
		// (sourced from that taxonomy) is now the single source of truth
		// for a vehicle's location everywhere in the codebase.
		$meta_keys = array(
			'carzuri_price',
			'carzuri_year',
			'carzuri_mileage',
			'carzuri_condition',
			'carzuri_transmission',
			'carzuri_fuel_type',
			'carzuri_engine_size',
			'carzuri_vin',
			'carzuri_registration_number',
			'carzuri_dealer_id',
			'carzuri_status',
			'carzuri_featured',
			'carzuri_gallery_ids',
			'carzuri_accident_history',
			'carzuri_service_history',
			'carzuri_views_count',
		);

		$data = array(
			'id'          => $post->ID,
			'title'       => $post->post_title,
			'description' => $post->post_content,
			'slug'        => $post->post_name,
			'created_at'  => $post->post_date,
			'updated_at'  => $post->post_modified,
		);

		// Get all meta fields
		foreach ( $meta_keys as $key ) {
			$clean_key = str_replace( 'carzuri_', '', $key );
			$value     = get_post_meta( $post->ID, $key, true );
			
			// Format defaults
			if ( $key === 'carzuri_featured' ) {
				$value = filter_var( $value, FILTER_VALIDATE_BOOLEAN );
			} elseif ( in_array( $key, array( 'carzuri_price', 'carzuri_year', 'carzuri_mileage', 'carzuri_dealer_id', 'carzuri_views_count' ), true ) ) {
				$value = (int) $value;
			} elseif ( $key === 'carzuri_gallery_ids' ) {
				$value = is_array( $value ) ? $value : ( empty( $value ) ? array() : array_map( 'absint', explode( ',', $value ) ) );
			}

			$data[ $clean_key ] = $value;
		}

		// Retrieve taxonomies
		$tax_makes = wp_get_post_terms( $post->ID, 'vehicle_make', array( 'fields' => 'names' ) );
		$data['make'] = ! empty( $tax_makes ) && ! is_wp_error( $tax_makes ) ? $tax_makes[0] : '';
		$tax_make_slugs = wp_get_post_terms( $post->ID, 'vehicle_make', array( 'fields' => 'slugs' ) );
		$data['make_slug'] = ! empty( $tax_make_slugs ) && ! is_wp_error( $tax_make_slugs ) ? $tax_make_slugs[0] : '';

		$tax_models = wp_get_post_terms( $post->ID, 'vehicle_model', array( 'fields' => 'names' ) );
		$data['model'] = ! empty( $tax_models ) && ! is_wp_error( $tax_models ) ? $tax_models[0] : '';
		$tax_model_slugs = wp_get_post_terms( $post->ID, 'vehicle_model', array( 'fields' => 'slugs' ) );
		$data['model_slug'] = ! empty( $tax_model_slugs ) && ! is_wp_error( $tax_model_slugs ) ? $tax_model_slugs[0] : '';

		$tax_bodies = wp_get_post_terms( $post->ID, 'vehicle_body_type', array( 'fields' => 'names' ) );
		$data['body_type'] = ! empty( $tax_bodies ) && ! is_wp_error( $tax_bodies ) ? $tax_bodies[0] : '';

		// Vehicle location — sourced solely from the vehicle_location
		// taxonomy. This is the single source of truth for a vehicle's
		// location; there is no longer a parallel free-text meta field.
		$tax_locations = wp_get_post_terms( $post->ID, 'vehicle_location', array( 'fields' => 'names' ) );
		$data['location_name'] = ! empty( $tax_locations ) && ! is_wp_error( $tax_locations ) ? $tax_locations[0] : '';

		// Featured Image URL
		$featured_image_id = get_post_thumbnail_id( $post->ID );
		$data['featured_image_url'] = $featured_image_id ? wp_get_attachment_url( $featured_image_id ) : '';

		// Dealer details
		$dealer_id = (int) $data['dealer_id'];
		if ( $dealer_id > 0 ) {
			$dealer_user = get_userdata( $dealer_id );
			$data['dealer_name'] = $dealer_user ? $dealer_user->display_name : __( 'Independent Dealer', 'carzuri-core' );
		} else {
			$data['dealer_name'] = __( 'Carzuri Certified', 'carzuri-core' );
		}

		return $data;
	}
}

if ( ! function_exists( 'carzuri_format_price' ) ) {
	/**
	 * Format numeric amount into KSh currency representation.
	 *
	 * @param int $amount Amount to format.
	 * @return string Formatted price.
	 */
	function carzuri_format_price( $amount ) {
		$currency = get_option( 'carzuri_currency_symbol', 'KSh' );
		return $currency . ' ' . number_format( (int) $amount, 0, '.', ',' );
	}
}

if ( ! function_exists( 'carzuri_create_notification' ) ) {
	/**
	 * Insert a new notification record into the notifications table.
	 *
	 * @param int    $user_id The recipient user ID.
	 * @param string $type    Notification type (e.g. 'new_inquiry', 'finance_update').
	 * @param string $title   The notification title.
	 * @param string $message The body content.
	 * @param string $link    Target link URL.
	 * @return int|false The ID of the inserted record, or false.
	 */
	function carzuri_create_notification( $user_id, $type, $title, $message, $link = '' ) {
		global $wpdb;

		$table_name = $wpdb->prefix . 'carzuri_notifications';

		$inserted = $wpdb->insert(
			$table_name,
			array(
				'user_id'    => absint( $user_id ),
				'type'       => sanitize_text_field( $type ),
				'title'      => sanitize_text_field( $title ),
				'message'    => wp_kses_post( $message ),
				'link_url'   => esc_url_raw( $link ),
				'is_read'    => 0,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%s', '%d', '%s' )
		);

		return $inserted ? $wpdb->insert_id : false;
	}
}

if ( ! function_exists( 'carzuri_is_dealer' ) ) {
	/**
	 * Determine if a specific user (or current user if null) is a Carzuri Dealer.
	 *
	 * @param int|null $user_id Optional user ID.
	 * @return bool
	 */
	function carzuri_is_dealer( $user_id = null ) {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}
		if ( ! $user_id ) {
			return false;
		}
		return user_can( $user_id, 'carzuri_dealer' );
	}
}

if ( ! function_exists( 'carzuri_is_admin' ) ) {
	/**
	 * Determine if a specific user is a Carzuri Admin (or WP Administrator).
	 *
	 * @param int|null $user_id Optional user ID.
	 * @return bool
	 */
	function carzuri_is_admin( $user_id = null ) {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}
		if ( ! $user_id ) {
			return false;
		}
		return user_can( $user_id, 'carzuri_manage_all_vehicles' ) || user_can( $user_id, 'administrator' );
	}
}

if ( ! function_exists( 'carzuri_user_can' ) ) {
	/**
	 * Wrapper helper for user capability check with default current user check.
	 *
	 * @param string   $capability Capability slug.
	 * @param int|null $user_id    Optional user ID.
	 * @return bool
	 */
	function carzuri_user_can( $capability, $user_id = null ) {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}
		if ( ! $user_id ) {
			return false;
		}
		return user_can( $user_id, $capability );
	}
}

/**
 * ============================================================
 * New Device Email Verification — shared helpers
 * ============================================================
 *
 * Used identically by Carzuri Buyer Accounts, Carzuri Dealer Marketplace,
 * and Carzuri Admin Portal logins. A device is "remembered" via a random
 * token stored in an httpOnly cookie; only its SHA-256 hash is ever stored
 * server-side (in wp_carzuri_known_devices), so a database leak alone can
 * never be replayed as a working device cookie. Verifying a device once
 * for a given account is remembered across all three login types, since
 * the check is keyed on user_id alone, not which plugin performed it.
 */

if ( ! function_exists( 'carzuri_known_device_cookie_name' ) ) {
	/**
	 * Central definition of the device cookie's name, so every call site
	 * (read or write) always agrees on it.
	 *
	 * @return string
	 */
	function carzuri_known_device_cookie_name() {
		return 'carzuri_device_id';
	}
}

if ( ! function_exists( 'carzuri_is_known_device' ) ) {
	/**
	 * Check whether the current browser/device already holds a verified
	 * device cookie for the given user. Touches last_seen_at on a match so
	 * the table also doubles as a lightweight "last used" record per device.
	 *
	 * @param int $user_id
	 * @return bool
	 */
	function carzuri_is_known_device( $user_id ) {
		$cookie_name = carzuri_known_device_cookie_name();

		if ( empty( $_COOKIE[ $cookie_name ] ) ) {
			return false;
		}

		global $wpdb;
		$token = sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) );
		$hash  = hash( 'sha256', $token );
		$table = $wpdb->prefix . 'carzuri_known_devices';

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM $table WHERE user_id = %d AND device_token_hash = %s",
				absint( $user_id ),
				$hash
			)
		);

		if ( ! $row ) {
			return false;
		}

		$wpdb->update(
			$table,
			array( 'last_seen_at' => current_time( 'mysql' ) ),
			array( 'id' => $row->id ),
			array( '%s' ),
			array( '%d' )
		);

		return true;
	}
}

if ( ! function_exists( 'carzuri_set_known_device_cookie' ) ) {
	/**
	 * Mark the current browser/device as verified for the given user: store
	 * a hash of a freshly generated random token in the known-devices
	 * table, then set the raw token as a long-lived, httpOnly cookie on the
	 * response. Must be called before any output has been sent.
	 *
	 * @param int $user_id
	 * @return void
	 */
	function carzuri_set_known_device_cookie( $user_id ) {
		global $wpdb;

		$token = bin2hex( random_bytes( 32 ) );
		$hash  = hash( 'sha256', $token );
		$table = $wpdb->prefix . 'carzuri_known_devices';

		$wpdb->insert(
			$table,
			array(
				'user_id'           => absint( $user_id ),
				'device_token_hash' => $hash,
				'created_at'        => current_time( 'mysql' ),
				'last_seen_at'      => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s' )
		);

		setcookie(
			carzuri_known_device_cookie_name(),
			$token,
			array(
				'expires'  => time() + ( 180 * DAY_IN_SECONDS ),
				'path'     => defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/',
				'domain'   => defined( 'COOKIE_DOMAIN' ) && COOKIE_DOMAIN ? COOKIE_DOMAIN : '',
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
	}
}

if ( ! function_exists( 'carzuri_send_device_verification_code' ) ) {
	/**
	 * Generate a 6-digit code, store it server-side (10-minute expiry via a
	 * transient — no table needed, since it auto-cleans itself), and email
	 * it to the account's registered address.
	 *
	 * @param int $user_id
	 * @return bool True if the email was accepted for sending.
	 */
	function carzuri_send_device_verification_code( $user_id ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		$code = (string) random_int( 100000, 999999 );
		set_transient( 'carzuri_device_code_' . $user_id, $code, 10 * MINUTE_IN_SECONDS );

		$site_name  = get_bloginfo( 'name' );
		$first_name = $user->first_name ? $user->first_name : $user->display_name;

		$subject = sprintf( __( 'Your %s sign-in verification code', 'carzuri-core' ), $site_name );
		$message = sprintf(
			__( "Hello %1\$s,\n\nWe noticed a sign-in to your %2\$s account from a device or browser we don't recognize.\n\nYour verification code is: %3\$s\n\nThis code expires in 10 minutes. If this wasn't you, you can safely ignore this email — your password has not been changed.", 'carzuri-core' ),
			$first_name,
			$site_name,
			$code
		);

		return wp_mail( $user->user_email, $subject, $message );
	}
}

if ( ! function_exists( 'carzuri_verify_device_code' ) ) {
	/**
	 * Check a submitted code against the stored transient for that user.
	 * On success, deletes the transient (one-time use) and marks the
	 * device as known for next time.
	 *
	 * @param int    $user_id
	 * @param string $code
	 * @return bool
	 */
	function carzuri_verify_device_code( $user_id, $code ) {
		$stored = get_transient( 'carzuri_device_code_' . $user_id );

		if ( false === $stored || ! hash_equals( (string) $stored, (string) $code ) ) {
			return false;
		}

		delete_transient( 'carzuri_device_code_' . $user_id );
		carzuri_set_known_device_cookie( $user_id );

		return true;
	}
}
