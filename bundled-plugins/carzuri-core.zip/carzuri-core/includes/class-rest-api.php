<?php
namespace Carzuri\Core;

use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Query;

/**
 * Handles custom REST API routes and endpoints under carzuri/v1/.
 *
 * @package           Carzuri_Core
 * @subpackage        Carzuri_Core/includes
 */
class RestAPI {

	/**
	 * Namespace for all routes.
	 *
	 * @var string
	 */
	protected $namespace = 'carzuri/v1';

	/**
	 * Initialize REST API hooks.
	 */
	public function init() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register routes.
	 */
	public function register_routes() {

		// 1. Vehicles list & filters
		register_rest_route( $this->namespace, '/vehicles', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_vehicles' ),
				'permission_callback' => '__return_true',
			),
		) );

		// 2. Models list & make filter
		register_rest_route( $this->namespace, '/models', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_models' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'make' => array(
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			),
		) );

		// 3. Single vehicle details
		register_rest_route( $this->namespace, '/vehicles/(?P<id>\d+)', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_vehicle' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'id' => array(
						'validate_callback' => function( $param, $request, $key ) {
							return is_numeric( $param );
						}
					),
				),
			),
		) );

		// 4. Favorites endpoint (Toggle post)
		register_rest_route( $this->namespace, '/favorites', array(
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'toggle_favorite' ),
				'permission_callback' => array( $this, 'check_favorites_permission' ),
				'args'                => array(
					'vehicle_id' => array(
						'required'          => true,
						'validate_callback' => function( $param ) {
							return is_numeric( $param ) && (int) $param > 0;
						}
					),
				),
			),
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_favorites' ),
				'permission_callback' => array( $this, 'check_favorites_permission' ),
			),
		) );

		// 5. Notifications mark read
		register_rest_route( $this->namespace, '/notifications/mark-read', array(
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'mark_notifications_read' ),
				'permission_callback' => array( $this, 'check_notifications_permission' ),
			),
		) );

		// 6. Notifications list
		register_rest_route( $this->namespace, '/notifications', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_notifications' ),
				'permission_callback' => array( $this, 'check_notifications_permission' ),
			),
		) );

		// 7. Public contact form submission (Contact Us static page).
		register_rest_route( $this->namespace, '/contact', array(
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_contact_form' ),
				'permission_callback' => '__return_true',
			),
		) );

		// 8. Latest blog posts (public, read-only)
		register_rest_route( $this->namespace, '/blog/latest-posts', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_latest_blog_posts' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'count' => array(
						'required'          => false,
						'sanitize_callback' => 'absint',
					),
				),
			),
		) );

		// 9. New Device Email Verification — shared by Buyer, Dealer, and
		// Admin logins.
		register_rest_route( $this->namespace, '/verify-device', array(
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'verify_device' ),
				'permission_callback' => '__return_true',
			),
		) );

		// 10. Resend a device verification code.
		register_rest_route( $this->namespace, '/verify-device/resend', array(
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'resend_device_code' ),
				'permission_callback' => '__return_true',
			),
		) );

		// 11. Register a device token for push notifications (Android app).
		// Logged-in only — a token is only useful once tied to a specific
		// user, and the JS bridge on the site only ever calls this after
		// confirming the visitor is logged in.
		register_rest_route( $this->namespace, '/register-device-token', array(
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'register_device_token' ),
				'permission_callback' => function() {
					return is_user_logged_in();
				},
			),
		) );
	}

	/**
	 * GET /models: Retrieve vehicle models (optionally filtered by make slug or ID).
	 */
	public function get_models( WP_REST_Request $request ) {
		$make_param = $request->get_param( 'make' );

		$args = array(
			'taxonomy'   => 'vehicle_model',
			'hide_empty' => false,
			'orderby'    => 'name',
			'order'      => 'ASC',
		);

		if ( ! empty( $make_param ) ) {
			$make_term = null;
			if ( is_numeric( $make_param ) ) {
				$make_term = get_term( absint( $make_param ), 'vehicle_make' );
			}
			if ( ! $make_term || is_wp_error( $make_term ) ) {
				$make_term = get_term_by( 'slug', sanitize_text_field( $make_param ), 'vehicle_make' );
			}
			if ( ! $make_term || is_wp_error( $make_term ) ) {
				$make_term = get_term_by( 'name', sanitize_text_field( $make_param ), 'vehicle_make' );
			}

			if ( ! $make_term || is_wp_error( $make_term ) ) {
				return new WP_REST_Response( array(), 200 );
			}

			$args['meta_query'] = array(
				array(
					'key'     => 'related_make_term_id',
					'value'   => $make_term->term_id,
					'compare' => '=',
				),
			);
		}

		$terms = get_terms( $args );

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return new WP_REST_Response( array(), 200 );
		}

		$response = array();
		foreach ( $terms as $term ) {
			$related_make_id = (int) get_term_meta( $term->term_id, 'related_make_term_id', true );
			$response[] = array(
				'id'                   => (int) $term->term_id,
				'slug'                 => $term->slug,
				'name'                 => $term->name,
				'related_make_term_id' => $related_make_id,
			);
		}

		return new WP_REST_Response( $response, 200 );
	}

	/**
	 * GET /vehicles: Retrieve and filter listings.
	 */
	public function get_vehicles( WP_REST_Request $request ) {
		$page      = $request->get_param( 'page' ) ? absint( $request->get_param( 'page' ) ) : 1;
		$per_page  = $request->get_param( 'per_page' ) ? absint( $request->get_param( 'per_page' ) ) : get_option( 'carzuri_items_per_page', 10 );

		$args = array(
			'post_type'      => 'vehicle',
			'post_status'    => 'publish',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'meta_query'     => array(),
			'tax_query'      => array(),
		);

		$make      = $request->get_param( 'vehicle_make' ) ?: $request->get_param( 'make' );
		$model     = $request->get_param( 'vehicle_model' ) ?: $request->get_param( 'model' );
		$body_type = $request->get_param( 'vehicle_body_type' ) ?: $request->get_param( 'body_type' );
		$location  = $request->get_param( 'vehicle_location' ) ?: $request->get_param( 'location' );

		if ( ! empty( $make ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'vehicle_make',
				'field'    => 'slug',
				'terms'    => sanitize_text_field( $make ),
			);
		}

		if ( ! empty( $model ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'vehicle_model',
				'field'    => 'slug',
				'terms'    => sanitize_text_field( $model ),
			);
		}

		if ( ! empty( $body_type ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'vehicle_body_type',
				'field'    => 'slug',
				'terms'    => sanitize_text_field( $body_type ),
			);
		}

		if ( ! empty( $location ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'vehicle_location',
				'field'    => 'slug',
				'terms'    => sanitize_text_field( $location ),
			);
		}

		if ( count( $args['tax_query'] ) > 1 ) {
			$args['tax_query']['relation'] = 'AND';
		}

		$price_min   = $request->get_param( 'price_min' );
		$price_max   = $request->get_param( 'price_max' );
		$year_min    = $request->get_param( 'year_min' );
		$year_max    = $request->get_param( 'year_max' );
		$mileage_max = $request->get_param( 'mileage_max' );

		if ( ! empty( $price_min ) ) {
			$args['meta_query'][] = array(
				'key'     => 'carzuri_price',
				'value'   => absint( $price_min ),
				'type'    => 'NUMERIC',
				'compare' => '>=',
			);
		}
		if ( ! empty( $price_max ) ) {
			$args['meta_query'][] = array(
				'key'     => 'carzuri_price',
				'value'   => absint( $price_max ),
				'type'    => 'NUMERIC',
				'compare' => '<=',
			);
		}

		if ( ! empty( $year_min ) ) {
			$args['meta_query'][] = array(
				'key'     => 'carzuri_year',
				'value'   => absint( $year_min ),
				'type'    => 'NUMERIC',
				'compare' => '>=',
			);
		}
		if ( ! empty( $year_max ) ) {
			$args['meta_query'][] = array(
				'key'     => 'carzuri_year',
				'value'   => absint( $year_max ),
				'type'    => 'NUMERIC',
				'compare' => '<=',
			);
		}

		if ( ! empty( $mileage_max ) ) {
			$args['meta_query'][] = array(
				'key'     => 'carzuri_mileage',
				'value'   => absint( $mileage_max ),
				'type'    => 'NUMERIC',
				'compare' => '<=',
			);
		}

		$fuel_type    = $request->get_param( 'fuel_type' );
		$transmission = $request->get_param( 'transmission' );
		$featured     = $request->get_param( 'featured' );

		if ( ! empty( $fuel_type ) ) {
			$args['meta_query'][] = array(
				'key'     => 'carzuri_fuel_type',
				'value'   => sanitize_text_field( $fuel_type ),
				'compare' => '=',
			);
		}

		if ( ! empty( $transmission ) ) {
			$args['meta_query'][] = array(
				'key'     => 'carzuri_transmission',
				'value'   => sanitize_text_field( $transmission ),
				'compare' => '=',
			);
		}

		$condition = $request->get_param( 'condition' );
		if ( ! empty( $condition ) ) {
			$args['meta_query'][] = array(
				'key'     => 'carzuri_condition',
				'value'   => sanitize_text_field( $condition ),
				'compare' => '=',
			);
		}

		if ( $featured !== null ) {
			$args['meta_query'][] = array(
				'key'     => 'carzuri_featured',
				'value'   => filter_var( $featured, FILTER_VALIDATE_BOOLEAN ) ? '1' : '0',
				'compare' => '=',
			);
		}

		if ( count( $args['meta_query'] ) > 1 ) {
			$args['meta_query']['relation'] = 'AND';
		}

		$query = new WP_Query( $args );
		$vehicles = array();

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$vehicle_data = carzuri_get_vehicle_data( get_the_ID() );
				if ( $vehicle_data ) {
					$vehicles[] = $vehicle_data;
				}
			}
			wp_reset_postdata();
		}

		$response = array(
			'vehicles'      => $vehicles,
			'total_results' => (int) $query->found_posts,
			'total_pages'   => (int) $query->max_num_pages,
			'page'          => $page,
			'per_page'      => $per_page,
		);

		return new WP_REST_Response( $response, 200 );
	}

	/**
	 * GET /vehicles/{id}: Fetch detailed vehicle metadata.
	 */
	public function get_vehicle( WP_REST_Request $request ) {
		$id           = (int) $request->get_param( 'id' );
		$vehicle_data = carzuri_get_vehicle_data( $id );

		if ( ! $vehicle_data ) {
			return new WP_REST_Response( array( 'message' => __( 'Vehicle not found.', 'carzuri-core' ) ), 404 );
		}

		return new WP_REST_Response( $vehicle_data, 200 );
	}

	/**
	 * Toggle favorite status.
	 * POST /favorites
	 */
	public function toggle_favorite( WP_REST_Request $request ) {
		global $wpdb;

		$user_id    = get_current_user_id();
		$vehicle_id = (int) $request->get_param( 'vehicle_id' );

		$post = get_post( $vehicle_id );
		if ( ! $post || $post->post_type !== 'vehicle' ) {
			return new WP_REST_Response( array( 'message' => __( 'Invalid vehicle ID.', 'carzuri-core' ) ), 400 );
		}

		$table_name = $wpdb->prefix . 'carzuri_favorites';

		$favorite = $wpdb->get_row( $wpdb->prepare(
			"SELECT id FROM $table_name WHERE user_id = %d AND vehicle_id = %d",
			$user_id,
			$vehicle_id
		) );

		if ( $favorite ) {
			$wpdb->delete(
				$table_name,
				array( 'user_id' => $user_id, 'vehicle_id' => $vehicle_id ),
				array( '%d', '%d' )
			);
			$is_favorite = false;
			$message     = __( 'Removed from favorites.', 'carzuri-core' );
		} else {
			$wpdb->insert(
				$table_name,
				array(
					'user_id'    => $user_id,
					'vehicle_id' => $vehicle_id,
					'created_at' => current_time( 'mysql' ),
				),
				array( '%d', '%d', '%s' )
			);
			$is_favorite = true;
			$message     = __( 'Added to favorites.', 'carzuri-core' );
		}

		return new WP_REST_Response( array(
			'vehicle_id'  => $vehicle_id,
			'is_favorite' => $is_favorite,
			'message'     => $message,
		), 200 );
	}

	/**
	 * GET /favorites: Retrieve favorite listings of current user.
	 */
	public function get_favorites( WP_REST_Request $request ) {
		global $wpdb;

		$user_id    = get_current_user_id();
		$table_name = $wpdb->prefix . 'carzuri_favorites';

		$results = $wpdb->get_col( $wpdb->prepare(
			"SELECT vehicle_id FROM $table_name WHERE user_id = %d ORDER BY created_at DESC",
			$user_id
		) );

		$vehicles = array();
		foreach ( $results as $vehicle_id ) {
			$vehicle_data = carzuri_get_vehicle_data( (int) $vehicle_id );
			if ( $vehicle_data ) {
				$vehicles[] = $vehicle_data;
			}
		}

		return new WP_REST_Response( $vehicles, 200 );
	}

	/**
	 * POST /notifications/mark-read
	 */
	public function mark_notifications_read( WP_REST_Request $request ) {
		global $wpdb;

		$user_id         = get_current_user_id();
		$notification_id = $request->get_param( 'notification_id' );
		$all             = $request->get_param( 'all' );

		$table_name = $wpdb->prefix . 'carzuri_notifications';

		if ( $all && filter_var( $all, FILTER_VALIDATE_BOOLEAN ) ) {
			$updated = $wpdb->update(
				$table_name,
				array( 'is_read' => 1 ),
				array( 'user_id' => $user_id ),
				array( '%d' ),
				array( '%d' )
			);
			$message = __( 'All notifications marked as read.', 'carzuri-core' );
		} elseif ( is_numeric( $notification_id ) ) {
			$updated = $wpdb->update(
				$table_name,
				array( 'is_read' => 1 ),
				array( 'user_id' => $user_id, 'id' => absint( $notification_id ) ),
				array( '%d' ),
				array( '%d', '%d' )
			);
			$message = __( 'Notification marked as read.', 'carzuri-core' );
		} else {
			return new WP_REST_Response( array( 'message' => __( 'Invalid parameters.', 'carzuri-core' ) ), 400 );
		}

		return new WP_REST_Response( array( 'success' => true, 'message' => $message ), 200 );
	}

	/**
	 * GET /notifications: Fetch notifications of current user.
	 */
	public function get_notifications( WP_REST_Request $request ) {
		global $wpdb;

		$user_id    = get_current_user_id();
		$table_name = $wpdb->prefix . 'carzuri_notifications';

		$notifications = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $table_name WHERE user_id = %d ORDER BY created_at DESC LIMIT 50",
			$user_id
		), ARRAY_A );

		foreach ( $notifications as &$item ) {
			$item['id']      = (int) $item['id'];
			$item['user_id'] = (int) $item['user_id'];
			$item['is_read'] = (int) $item['is_read'] === 1;
		}

		$unread_count = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND is_read = 0",
			$user_id
		) );

		return new WP_REST_Response( array(
			'notifications' => $notifications,
			'unread_count'  => $unread_count,
		), 200 );
	}

	/**
	 * POST /contact
	 */
	public function handle_contact_form( WP_REST_Request $request ) {
		$honeypot = $request->get_param( 'cz_hp_field' );
		if ( ! empty( $honeypot ) ) {
			return new WP_REST_Response(
				array(
					'success' => true,
					'message' => __( 'Thanks! Your message has been sent — we will get back to you soon.', 'carzuri-core' ),
				),
				200
			);
		}

		$name    = sanitize_text_field( (string) $request->get_param( 'contact_name' ) );
		$email   = sanitize_email( (string) $request->get_param( 'contact_email' ) );
		$phone   = sanitize_text_field( (string) $request->get_param( 'contact_phone' ) );
		$message = sanitize_textarea_field( (string) $request->get_param( 'contact_message' ) );

		if ( empty( $name ) || empty( $email ) || empty( $message ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Please fill in all required fields.', 'carzuri-core' ),
				),
				400
			);
		}

		if ( ! is_email( $email ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Please enter a valid email address.', 'carzuri-core' ),
				),
				400
			);
		}

		$recipient = function_exists( 'carzuri_get_site_notification_email' )
			? carzuri_get_site_notification_email()
			: get_option( 'admin_email' );

		$site_name = get_bloginfo( 'name' );
		$subject   = sprintf( __( 'New Contact Form Message from %s', 'carzuri-core' ), $name );

		$body  = "You have a new message from the Contact page on {$site_name}:\n\n";
		$body .= "Name: {$name}\n";
		$body .= "Email: {$email}\n";
		$body .= 'Phone: ' . ( ! empty( $phone ) ? $phone : 'Not provided' ) . "\n\n";
		$body .= "Message:\n{$message}\n";

		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			'Reply-To: ' . $name . ' <' . $email . '>',
		);

		$sent = wp_mail( $recipient, $subject, $body, $headers );

		if ( $sent ) {
			return new WP_REST_Response(
				array(
					'success' => true,
					'message' => __( 'Thanks! Your message has been sent — we will get back to you soon.', 'carzuri-core' ),
				),
				200
			);
		}

		return new WP_REST_Response(
			array(
				'success' => false,
				'message' => __( 'Sorry, something went wrong sending your message. Please try again or email us directly.', 'carzuri-core' ),
			),
			500
		);
	}

	/**
	 * GET /blog/latest-posts
	 */
	public function get_latest_blog_posts( WP_REST_Request $request ) {
		$count = $request->get_param( 'count' ) ? absint( $request->get_param( 'count' ) ) : 3;
		$count = max( 1, min( $count, 12 ) );

		$query = new WP_Query( array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => $count,
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );

		$posts = array();

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$thumb_id = get_post_thumbnail_id( get_the_ID() );
				$posts[]  = array(
					'id'                 => get_the_ID(),
					'title'              => get_the_title(),
					'excerpt'            => wp_strip_all_tags( get_the_excerpt() ),
					'permalink'          => get_permalink(),
					'date'               => get_the_date( 'c' ),
					'featured_image_url' => $thumb_id ? wp_get_attachment_url( $thumb_id ) : '',
				);
			}
			wp_reset_postdata();
		}

		return new WP_REST_Response( $posts, 200 );
	}

	/**
	 * POST /verify-device
	 */
	public function verify_device( WP_REST_Request $request ) {
		$user_id  = absint( $request->get_param( 'user_id' ) );
		$code     = sanitize_text_field( (string) $request->get_param( 'code' ) );
		$remember = filter_var( $request->get_param( 'remember' ), FILTER_VALIDATE_BOOLEAN );

		if ( ! $user_id || empty( $code ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Missing verification details.', 'carzuri-core' ),
				),
				400
			);
		}

		if ( ! carzuri_verify_device_code( $user_id, $code ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'That code is incorrect or has expired. Please try again or request a new one.', 'carzuri-core' ),
				),
				400
			);
		}

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Account not found.', 'carzuri-core' ),
				),
				404
			);
		}

		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, $remember );
		do_action( 'wp_login', $user->user_login, $user );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Verified! Redirecting...', 'carzuri-core' ),
			),
			200
		);
	}

	/**
	 * POST /verify-device/resend
	 */
	public function resend_device_code( WP_REST_Request $request ) {
		$user_id = absint( $request->get_param( 'user_id' ) );

		if ( ! $user_id || false === get_transient( 'carzuri_device_code_' . $user_id ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'No pending verification found for this account. Please try logging in again.', 'carzuri-core' ),
				),
				400
			);
		}

		carzuri_send_device_verification_code( $user_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'A new code has been sent to your email.', 'carzuri-core' ),
			),
			200
		);
	}

	/**
	 * POST /register-device-token
	 *
	 * Registers (or updates) a Firebase Cloud Messaging device token for
	 * the current logged-in user, called by the Android app's JS bridge
	 * once it has requested notification permission and received a token
	 * back from the Push Notifications plugin.
	 */
	public function register_device_token( WP_REST_Request $request ) {
		global $wpdb;

		$token    = sanitize_text_field( (string) $request->get_param( 'token' ) );
		$platform = sanitize_text_field( (string) $request->get_param( 'platform' ) );

		if ( empty( $token ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Missing device token.', 'carzuri-core' ),
				),
				400
			);
		}

		$table   = $wpdb->prefix . 'carzuri_device_tokens';
		$user_id = get_current_user_id();

		$existing_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM $table WHERE user_id = %d AND token = %s",
				$user_id,
				$token
			)
		);

		if ( $existing_id ) {
			$wpdb->update(
				$table,
				array( 'last_used_at' => current_time( 'mysql' ) ),
				array( 'id' => $existing_id ),
				array( '%s' ),
				array( '%d' )
			);
		} else {
			$wpdb->insert(
				$table,
				array(
					'user_id'      => $user_id,
					'token'        => $token,
					'platform'     => $platform ? $platform : 'android',
					'created_at'   => current_time( 'mysql' ),
					'last_used_at' => current_time( 'mysql' ),
				),
				array( '%d', '%s', '%s', '%s', '%s' )
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Device registered for push notifications.', 'carzuri-core' ),
			),
			200
		);
	}

	/**
	 * Permissions verification for favorites.
	 */
	public function check_favorites_permission( WP_REST_Request $request ) {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		return carzuri_user_can( 'carzuri_save_favorites' );
	}

	/**
	 * Permissions verification for notifications.
	 */
	public function check_notifications_permission( WP_REST_Request $request ) {
		return is_user_logged_in();
	}
}
