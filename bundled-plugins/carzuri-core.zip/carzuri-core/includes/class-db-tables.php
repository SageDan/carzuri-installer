<?php
namespace Carzuri\Core;

/**
 * Handles creation and upgrades of the custom database tables.
 *
 * @package           Carzuri_Core
 * @subpackage        Carzuri_Core/includes
 */
class DatabaseTables {

	/**
	 * Initialize database routines.
	 */
	public function init() {
		// Run a version check on admin_init or plugins_loaded
		add_action( 'plugins_loaded', array( $this, 'check_version' ) );
	}

	/**
	 * Compare database version option and trigger upgrade if needed.
	 */
	public function check_version() {
		$current_version = get_option( 'carzuri_db_version', '0.0.0' );
		if ( version_compare( $current_version, CARZURI_CORE_DB_VERSION, '<' ) ) {
			$this->create_tables();
		}
	}

	/**
	 * Create or update custom database tables using dbDelta.
	 */
	public function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// Table names with custom carzuri_ prefix.
		$table_favorites            = $wpdb->prefix . 'carzuri_favorites';
		$table_saved_searches       = $wpdb->prefix . 'carzuri_saved_searches';
		$table_inquiries            = $wpdb->prefix . 'carzuri_inquiries';
		$table_valuations           = $wpdb->prefix . 'carzuri_valuations';
		$table_finance_applications = $wpdb->prefix . 'carzuri_finance_applications';
		$table_notifications        = $wpdb->prefix . 'carzuri_notifications';
		$table_reviews              = $wpdb->prefix . 'carzuri_reviews';
		$table_conversations        = $wpdb->prefix . 'carzuri_conversations';
		$table_messages             = $wpdb->prefix . 'carzuri_messages';
		$table_known_devices        = $wpdb->prefix . 'carzuri_known_devices';
		$table_device_tokens        = $wpdb->prefix . 'carzuri_device_tokens';

		// Load dbDelta.
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "";

		// 1. Favorites Table
		$sql .= "CREATE TABLE $table_favorites (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			vehicle_id bigint(20) unsigned NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY user_vehicle (user_id,vehicle_id)
		) $charset_collate;\n";

		// 2. Saved Searches Table
		$sql .= "CREATE TABLE $table_saved_searches (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			search_name varchar(255) DEFAULT NULL,
			filters_json longtext NOT NULL,
			alert_enabled tinyint(1) DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id)
		) $charset_collate;\n";

		// 3. Inquiries Table
		$sql .= "CREATE TABLE $table_inquiries (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			vehicle_id bigint(20) unsigned NOT NULL,
			buyer_user_id bigint(20) unsigned DEFAULT NULL,
			buyer_name varchar(255) NOT NULL,
			buyer_email varchar(255) NOT NULL,
			buyer_phone varchar(50) NOT NULL,
			message text DEFAULT NULL,
			dealer_id bigint(20) unsigned NOT NULL,
			status varchar(50) DEFAULT 'new',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id),
			KEY vehicle_id (vehicle_id),
			KEY dealer_id (dealer_id)
		) $charset_collate;\n";

		// 4. Valuations Table
		$sql .= "CREATE TABLE $table_valuations (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned DEFAULT NULL,
			make varchar(100) DEFAULT NULL,
			model varchar(100) DEFAULT NULL,
			year int(11) DEFAULT NULL,
			mileage int(11) DEFAULT NULL,
			`condition` varchar(50) DEFAULT NULL,
			accident_history varchar(50) DEFAULT NULL,
			service_history varchar(50) DEFAULT NULL,
			estimated_market_value int(11) DEFAULT NULL,
			dealer_purchase_value int(11) DEFAULT NULL,
			private_sale_estimate int(11) DEFAULT NULL,
			confidence_score int(11) DEFAULT NULL,
			estimated_time_to_sell varchar(100) DEFAULT NULL,
			raw_ai_response longtext DEFAULT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id)
		) $charset_collate;\n";

		// 5. Finance Applications Table
		$sql .= "CREATE TABLE $table_finance_applications (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned DEFAULT NULL,
			vehicle_id bigint(20) unsigned DEFAULT NULL,
			applicant_name varchar(255) NOT NULL,
			applicant_email varchar(255) NOT NULL,
			applicant_phone varchar(50) NOT NULL,
			vehicle_price int(11) DEFAULT NULL,
			deposit_amount int(11) DEFAULT NULL,
			loan_term_months int(11) DEFAULT NULL,
			documents_json longtext DEFAULT NULL,
			status varchar(50) DEFAULT 'submitted',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id),
			KEY vehicle_id (vehicle_id)
		) $charset_collate;\n";

		// 6. Notifications Table
		$sql .= "CREATE TABLE $table_notifications (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			type varchar(50) NOT NULL,
			title varchar(255) NOT NULL,
			message text DEFAULT NULL,
			link_url varchar(500) DEFAULT NULL,
			is_read tinyint(1) DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id),
			KEY is_read (is_read)
		) $charset_collate;\n";

		// 7. Reviews Table
		$sql .= "CREATE TABLE $table_reviews (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			vehicle_id bigint(20) unsigned NOT NULL,
			dealer_id bigint(20) unsigned NOT NULL,
			rating tinyint(1) unsigned NOT NULL,
			review_text text DEFAULT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY user_vehicle (user_id,vehicle_id),
			KEY dealer_id (dealer_id),
			KEY vehicle_id (vehicle_id)
		) $charset_collate;\n";

		// 8. Conversations Table
		$sql .= "CREATE TABLE $table_conversations (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			vehicle_id bigint(20) unsigned NOT NULL DEFAULT 0,
			buyer_id bigint(20) unsigned NOT NULL,
			dealer_id bigint(20) unsigned NOT NULL,
			created_at datetime NOT NULL,
			last_message_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY buyer_dealer_vehicle (buyer_id,dealer_id,vehicle_id),
			KEY buyer_id (buyer_id),
			KEY dealer_id (dealer_id)
		) $charset_collate;\n";

		// 9. Messages Table
		$sql .= "CREATE TABLE $table_messages (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			conversation_id bigint(20) unsigned NOT NULL,
			sender_id bigint(20) unsigned NOT NULL,
			message_text text NOT NULL,
			is_read tinyint(1) DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			KEY conversation_id (conversation_id)
		) $charset_collate;\n";

		// 10. Known Devices Table (New Device Email Verification feature)
		$sql .= "CREATE TABLE $table_known_devices (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			device_token_hash char(64) NOT NULL,
			created_at datetime NOT NULL,
			last_seen_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY user_device (user_id,device_token_hash),
			KEY user_id (user_id)
		) $charset_collate;\n";

		// 11. Device Tokens Table (Push Notifications, Android app)
		// One row per (user, Firebase token) pair — a user may have several
		// devices/installs, each getting its own row. 'token' is the raw
		// Firebase Cloud Messaging registration token for that install;
		// carzuri_send_push_notification() sends to every token on file
		// for a user whenever any existing notification fires.
		$sql .= "CREATE TABLE $table_device_tokens (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			token varchar(255) NOT NULL,
			platform varchar(20) DEFAULT 'android',
			created_at datetime NOT NULL,
			last_used_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY user_token (user_id,token(191)),
			KEY user_id (user_id)
		) $charset_collate;\n";

		// Run dbDelta.
		dbDelta( $sql );

		// Record the database version.
		update_option( 'carzuri_db_version', CARZURI_CORE_DB_VERSION );
	}
}
