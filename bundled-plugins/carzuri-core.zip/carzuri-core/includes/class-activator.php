<?php
namespace Carzuri\Core;

/**
 * Fired during plugin activation.
 *
 * @package           Carzuri_Core
 * @subpackage        Carzuri_Core/includes
 * @author            Carzuri
 */
class Activator {

	/**
	 * Run the activation routine.
	 */
	public static function activate() {
		// Include database creation class and trigger installation.
		require_once plugin_dir_path( __DIR__ ) . 'includes/class-db-tables.php';
		$db = new DatabaseTables();
		$db->create_tables();

		// Include custom roles class and trigger creation.
		require_once plugin_dir_path( __DIR__ ) . 'includes/class-user-roles.php';
		$roles = new UserRoles();
		$roles->create_roles();

		// Set default settings if they don't exist.
		if ( false === get_option( 'carzuri_currency_symbol' ) ) {
			update_option( 'carzuri_currency_symbol', 'KSh' );
		}
		if ( false === get_option( 'carzuri_items_per_page' ) ) {
			update_option( 'carzuri_items_per_page', 10 );
		}
		if ( false === get_option( 'carzuri_default_locations' ) ) {
			update_option( 'carzuri_default_locations', "Nairobi\nMombasa\nKisumu\nNakuru\nEldoret" );
		}

		// Flush rewrite rules for CPTs and taxonomies.
		require_once plugin_dir_path( __DIR__ ) . 'includes/class-cpt-vehicle.php';
		require_once plugin_dir_path( __DIR__ ) . 'includes/class-taxonomies.php';
		
		$tax = new Taxonomies();
		$tax->register_taxonomies();

		$cpt = new CPTVehicle();
		$cpt->register_cpt();

		flush_rewrite_rules();
	}
}
