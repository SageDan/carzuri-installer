<?php
namespace Carzuri\Core;

/**
 * Registers custom taxonomies for vehicles.
 *
 * @package           Carzuri_Core
 * @subpackage        Carzuri_Core/includes
 */
class Taxonomies {

	/**
	 * Initialize Taxonomies hooks.
	 */
	public function init() {
		add_action( 'init', array( $this, 'register_taxonomies' ) );
		add_action( 'init', array( $this, 'register_term_meta' ) );

		// Admin fields for vehicle_model -> parent make linking
		add_action( 'vehicle_model_add_form_fields', array( $this, 'add_vehicle_model_fields' ) );
		add_action( 'vehicle_model_edit_form_fields', array( $this, 'edit_vehicle_model_fields' ), 10, 2 );
		add_action( 'created_vehicle_model', array( $this, 'save_vehicle_model_meta' ) );
		add_action( 'edited_vehicle_model', array( $this, 'save_vehicle_model_meta' ) );

		// Admin column for Associated Make in Model taxonomy table
		add_filter( 'manage_edit-vehicle_model_columns', array( $this, 'add_model_columns' ) );
		add_filter( 'manage_vehicle_model_custom_column', array( $this, 'render_model_custom_column' ), 10, 3 );

		// Remove the block editor's own auto-generated sidebar taxonomy
		// panels for Make and Model on the vehicle edit screen. These are
		// rendered by Gutenberg's JS independently of 'meta_box_cb' (which
		// only affects the classic editor), so a small inline script is
		// needed to explicitly remove them by panel name. The custom
		// dependent "Vehicle Make"/"Vehicle Model" dropdowns in the
		// Specifications metabox remain the single source of truth.
		add_action( 'admin_footer-post.php', array( $this, 'remove_duplicate_taxonomy_panels' ) );
		add_action( 'admin_footer-post-new.php', array( $this, 'remove_duplicate_taxonomy_panels' ) );
	}

	/**
	 * Print an inline script on the vehicle edit screen only, removing the
	 * block editor's default sidebar panels for the vehicle_make and
	 * vehicle_model taxonomies.
	 */
	public function remove_duplicate_taxonomy_panels() {
		$screen = get_current_screen();
		if ( ! $screen || $screen->post_type !== 'vehicle' ) {
			return;
		}
		?>
		<script>
		wp.domReady( function() {
			var unsubscribe = wp.data.subscribe( function() {
				if ( wp.data.select( 'core/edit-post' ) ) {
					wp.data.dispatch( 'core/edit-post' ).removeEditorPanel( 'taxonomy-panel-vehicle_make' );
					wp.data.dispatch( 'core/edit-post' ).removeEditorPanel( 'taxonomy-panel-vehicle_model' );
					unsubscribe();
				}
			} );
		} );
		</script>
		<?php
	}

	/**
	 * Register vehicle custom taxonomies.
	 */
	public function register_taxonomies() {

		// 1. Vehicle Make (e.g. Toyota, BMW)
		$labels_make = array(
			'name'                       => _x( 'Makes', 'Taxonomy General Name', 'carzuri-core' ),
			'singular_name'              => _x( 'Make', 'Taxonomy Singular Name', 'carzuri-core' ),
			'menu_name'                  => __( 'Makes', 'carzuri-core' ),
			'all_items'                  => __( 'All Makes', 'carzuri-core' ),
			'parent_item'                => __( 'Parent Make', 'carzuri-core' ),
			'parent_item_colon'          => __( 'Parent Make:', 'carzuri-core' ),
			'new_item_name'              => __( 'New Make Name', 'carzuri-core' ),
			'add_new_item'               => __( 'Add New Make', 'carzuri-core' ),
			'edit_item'                  => __( 'Edit Make', 'carzuri-core' ),
			'update_item'                => __( 'Update Make', 'carzuri-core' ),
			'view_item'                  => __( 'View Make', 'carzuri-core' ),
			'separate_items_with_commas' => __( 'Separate makes with commas', 'carzuri-core' ),
			'add_or_remove_items'        => __( 'Add or remove makes', 'carzuri-core' ),
			'choose_from_most_used'      => __( 'Choose from the most used', 'carzuri-core' ),
			'popular_items'              => __( 'Popular Makes', 'carzuri-core' ),
			'search_items'               => __( 'Search Makes', 'carzuri-core' ),
			'not_found'                  => __( 'Not Found', 'carzuri-core' ),
			'no_terms'                   => __( 'No makes', 'carzuri-core' ),
			'items_list'                 => __( 'Makes list', 'carzuri-core' ),
			'items_list_navigation'      => __( 'Makes list navigation', 'carzuri-core' ),
		);
		$args_make = array(
			'labels'                     => $labels_make,
			'hierarchical'               => false, // flat make/model or flat list as requested
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'show_in_rest'               => true,
			'rest_base'                  => 'vehicle_make',
			// Suppresses WordPress's default sidebar "Makes" picker on the
			// vehicle edit screen only — Vehicles > Makes admin screen and
			// Quick Edit are both unaffected. The custom "Vehicle Make"
			// dropdown in the Specifications metabox is the single source
			// of truth for setting this on a vehicle, avoiding two
			// independent UI paths that could set conflicting values on
			// the same save.
			'meta_box_cb'                => false,
		);
		register_taxonomy( 'vehicle_make', array( 'vehicle' ), $args_make );

		// 2. Vehicle Model (e.g. CX-5, Prado, C-Class) - Flat taxonomy linked to Make via related_make_term_id term meta
		$labels_model = array(
			'name'                       => _x( 'Models', 'Taxonomy General Name', 'carzuri-core' ),
			'singular_name'              => _x( 'Model', 'Taxonomy Singular Name', 'carzuri-core' ),
			'menu_name'                  => __( 'Models', 'carzuri-core' ),
			'all_items'                  => __( 'All Models', 'carzuri-core' ),
			'parent_item'                => __( 'Parent Model', 'carzuri-core' ),
			'parent_item_colon'          => __( 'Parent Model:', 'carzuri-core' ),
			'new_item_name'              => __( 'New Model Name', 'carzuri-core' ),
			'add_new_item'               => __( 'Add New Model', 'carzuri-core' ),
			'edit_item'                  => __( 'Edit Model', 'carzuri-core' ),
			'update_item'                => __( 'Update Model', 'carzuri-core' ),
			'view_item'                  => __( 'View Model', 'carzuri-core' ),
			'separate_items_with_commas' => __( 'Separate models with commas', 'carzuri-core' ),
			'add_or_remove_items'        => __( 'Add or remove models', 'carzuri-core' ),
			'choose_from_most_used'      => __( 'Choose from the most used', 'carzuri-core' ),
			'popular_items'              => __( 'Popular Models', 'carzuri-core' ),
			'search_items'               => __( 'Search Models', 'carzuri-core' ),
			'not_found'                  => __( 'Not Found', 'carzuri-core' ),
			'no_terms'                   => __( 'No models', 'carzuri-core' ),
			'items_list'                 => __( 'Models list', 'carzuri-core' ),
			'items_list_navigation'      => __( 'Models list navigation', 'carzuri-core' ),
		);
		$args_model = array(
			'labels'                     => $labels_model,
			'hierarchical'               => false, // flat taxonomy — Make/Model link stored via term meta
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'show_in_rest'               => true,
			'rest_base'                  => 'vehicle_model',
			// Same reasoning as vehicle_make above — the custom "Vehicle
			// Model" dropdown in the Specifications metabox (dependent on
			// the selected Make) is the single source of truth.
			'meta_box_cb'                => false,
		);
		register_taxonomy( 'vehicle_model', array( 'vehicle' ), $args_model );

		// 3. Vehicle Body Type (e.g. SUV, Sedan)
		$labels_body = array(
			'name'                       => _x( 'Body Types', 'Taxonomy General Name', 'carzuri-core' ),
			'singular_name'              => _x( 'Body Type', 'Taxonomy Singular Name', 'carzuri-core' ),
			'menu_name'                  => __( 'Body Types', 'carzuri-core' ),
			'all_items'                  => __( 'All Body Types', 'carzuri-core' ),
			'new_item_name'              => __( 'New Body Type Name', 'carzuri-core' ),
			'add_new_item'               => __( 'Add New Body Type', 'carzuri-core' ),
			'edit_item'                  => __( 'Edit Body Type', 'carzuri-core' ),
			'update_item'                => __( 'Update Body Type', 'carzuri-core' ),
			'view_item'                  => __( 'View Body Type', 'carzuri-core' ),
			'separate_items_with_commas' => __( 'Separate body types with commas', 'carzuri-core' ),
			'add_or_remove_items'        => __( 'Add or remove body types', 'carzuri-core' ),
			'choose_from_most_used'      => __( 'Choose from the most used', 'carzuri-core' ),
			'popular_items'              => __( 'Popular Body Types', 'carzuri-core' ),
			'search_items'               => __( 'Search Body Types', 'carzuri-core' ),
			'not_found'                  => __( 'Not Found', 'carzuri-core' ),
			'no_terms'                   => __( 'No body types', 'carzuri-core' ),
			'items_list'                 => __( 'Body types list', 'carzuri-core' ),
			'items_list_navigation'      => __( 'Body types list navigation', 'carzuri-core' ),
		);
		$args_body = array(
			'labels'                     => $labels_body,
			'hierarchical'               => false,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'show_in_rest'               => true,
			'rest_base'                  => 'vehicle_body_type',
		);
		register_taxonomy( 'vehicle_body_type', array( 'vehicle' ), $args_body );

		// 4. Vehicle Location (e.g. Nairobi, Mombasa)
		$labels_loc = array(
			'name'                       => _x( 'Locations', 'Taxonomy General Name', 'carzuri-core' ),
			'singular_name'              => _x( 'Location', 'Taxonomy Singular Name', 'carzuri-core' ),
			'menu_name'                  => __( 'Locations', 'carzuri-core' ),
			'all_items'                  => __( 'All Locations', 'carzuri-core' ),
			'new_item_name'              => __( 'New Location Name', 'carzuri-core' ),
			'add_new_item'               => __( 'Add New Location', 'carzuri-core' ),
			'edit_item'                  => __( 'Edit Location', 'carzuri-core' ),
			'update_item'                => __( 'Update Location', 'carzuri-core' ),
			'view_item'                  => __( 'View Location', 'carzuri-core' ),
			'separate_items_with_commas' => __( 'Separate locations with commas', 'carzuri-core' ),
			'add_or_remove_items'        => __( 'Add or remove locations', 'carzuri-core' ),
			'choose_from_most_used'      => __( 'Choose from the most used', 'carzuri-core' ),
			'popular_items'              => __( 'Popular Locations', 'carzuri-core' ),
			'search_items'               => __( 'Search Locations', 'carzuri-core' ),
			'not_found'                  => __( 'Not Found', 'carzuri-core' ),
			'no_terms'                   => __( 'No locations', 'carzuri-core' ),
			'items_list'                 => __( 'Locations list', 'carzuri-core' ),
			'items_list_navigation'      => __( 'Locations list navigation', 'carzuri-core' ),
		);
		$args_loc = array(
			'labels'                     => $labels_loc,
			'hierarchical'               => false,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'show_in_rest'               => true,
			'rest_base'                  => 'vehicle_location',
		);
		register_taxonomy( 'vehicle_location', array( 'vehicle' ), $args_loc );
	}

	/**
	 * Register term meta for vehicle_model taxonomy.
	 */
	public function register_term_meta() {
		register_term_meta( 'vehicle_model', 'related_make_term_id', array(
			'type'              => 'integer',
			'description'       => 'The term_id of the corresponding vehicle_make term',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'absint',
		) );
	}

	/**
	 * Add "Parent Make" field to the Add Model admin screen.
	 */
	public function add_vehicle_model_fields( $taxonomy ) {
		$makes = get_terms( array(
			'taxonomy'   => 'vehicle_make',
			'hide_empty' => false,
			'orderby'    => 'name',
			'order'      => 'ASC',
		) );
		?>
		<div class="form-field term-group">
			<label for="related_make_term_id"><?php _e( 'Parent Make', 'carzuri-core' ); ?></label>
			<select name="related_make_term_id" id="related_make_term_id" class="postform">
				<option value="0"><?php _e( '— Select Parent Make —', 'carzuri-core' ); ?></option>
				<?php if ( ! empty( $makes ) && ! is_wp_error( $makes ) ) : ?>
					<?php foreach ( $makes as $make ) : ?>
						<option value="<?php echo esc_attr( $make->term_id ); ?>"><?php echo esc_html( $make->name ); ?></option>
					<?php endforeach; ?>
				<?php endif; ?>
			</select>
			<p><?php _e( 'Select the vehicle Make that this Model belongs to.', 'carzuri-core' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Edit "Parent Make" field on the Edit Model admin screen.
	 */
	public function edit_vehicle_model_fields( $term, $taxonomy ) {
		$related_make_id = (int) get_term_meta( $term->term_id, 'related_make_term_id', true );
		$makes = get_terms( array(
			'taxonomy'   => 'vehicle_make',
			'hide_empty' => false,
			'orderby'    => 'name',
			'order'      => 'ASC',
		) );
		?>
		<tr class="form-field term-group-wrap">
			<th scope="row"><label for="related_make_term_id"><?php _e( 'Parent Make', 'carzuri-core' ); ?></label></th>
			<td>
				<select name="related_make_term_id" id="related_make_term_id" class="postform">
					<option value="0"><?php _e( '— Select Parent Make —', 'carzuri-core' ); ?></option>
					<?php if ( ! empty( $makes ) && ! is_wp_error( $makes ) ) : ?>
						<?php foreach ( $makes as $make ) : ?>
							<option value="<?php echo esc_attr( $make->term_id ); ?>" <?php selected( $related_make_id, $make->term_id ); ?>>
								<?php echo esc_html( $make->name ); ?>
							</option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
				<p class="description"><?php _e( 'Select the vehicle Make that this Model belongs to.', 'carzuri-core' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Save the related_make_term_id term meta on model create/edit.
	 */
	public function save_vehicle_model_meta( $term_id ) {
		if ( isset( $_POST['related_make_term_id'] ) ) {
			$make_id = absint( $_POST['related_make_term_id'] );
			if ( $make_id > 0 ) {
				update_term_meta( $term_id, 'related_make_term_id', $make_id );
			} else {
				delete_term_meta( $term_id, 'related_make_term_id' );
			}
		}
	}

	/**
	 * Add custom columns to the Model taxonomy list table.
	 */
	public function add_model_columns( $columns ) {
		$new_columns = array();
		foreach ( $columns as $key => $title ) {
			$new_columns[ $key ] = $title;
			if ( $key === 'name' ) {
				$new_columns['parent_make'] = __( 'Parent Make', 'carzuri-core' );
			}
		}
		return $new_columns;
	}

	/**
	 * Render custom column content for Model taxonomy list table.
	 */
	public function render_model_custom_column( $content, $column_name, $term_id ) {
		if ( $column_name === 'parent_make' ) {
			$make_id = (int) get_term_meta( $term_id, 'related_make_term_id', true );
			if ( $make_id > 0 ) {
				$make_term = get_term( $make_id, 'vehicle_make' );
				if ( $make_term && ! is_wp_error( $make_term ) ) {
					return esc_html( $make_term->name );
				}
			}
			return '<span style="color:#999;">' . esc_html__( 'None', 'carzuri-core' ) . '</span>';
		}
		return $content;
	}
}
