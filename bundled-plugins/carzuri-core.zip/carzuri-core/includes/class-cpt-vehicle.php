<?php
namespace Carzuri\Core;

/**
 * Registers the Custom Post Type 'vehicle' and its meta fields, and provides edit screens.
 *
 * @package           Carzuri_Core
 * @subpackage        Carzuri_Core/includes
 */
class CPTVehicle {

	/**
	 * Initialize the CPT and register its meta fields.
	 */
	public function init() {
		add_action( 'init', array( $this, 'register_cpt' ) );
		add_action( 'init', array( $this, 'register_meta_fields' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_vehicle_meta_box' ) );
		add_action( 'save_post_vehicle', array( $this, 'save_vehicle_meta' ) );
		
		// Track vehicle views
		add_action( 'wp_head', array( $this, 'track_vehicle_views' ) );
	}

	/**
	 * Register 'vehicle' CPT.
	 */
	public function register_cpt() {
		$labels = array(
			'name'                  => _x( 'Vehicles', 'Post Type General Name', 'carzuri-core' ),
			'singular_name'         => _x( 'Vehicle', 'Post Type Singular Name', 'carzuri-core' ),
			'menu_name'             => __( 'Vehicles', 'carzuri-core' ),
			'name_admin_bar'        => __( 'Vehicle', 'carzuri-core' ),
			'add_new'               => __( 'Add New', 'carzuri-core' ),
			'add_new_item'          => __( 'Add New Vehicle', 'carzuri-core' ),
			'new_item'              => __( 'New Vehicle', 'carzuri-core' ),
			'edit_item'             => __( 'Edit Vehicle', 'carzuri-core' ),
			'update_item'           => __( 'Update Vehicle', 'carzuri-core' ),
			'view_item'             => __( 'View Vehicle', 'carzuri-core' ),
			'view_items'            => __( 'View Vehicles', 'carzuri-core' ),
			'search_items'          => __( 'Search Vehicle', 'carzuri-core' ),
			'not_found'             => __( 'No vehicles found', 'carzuri-core' ),
			'not_found_in_trash'    => __( 'No vehicles found in Trash', 'carzuri-core' ),
			'all_items'             => __( 'All Vehicles', 'carzuri-core' ),
		);

		$args = array(
			'label'                 => __( 'Vehicle', 'carzuri-core' ),
			'description'           => __( 'Vehicles listed on Carzuri', 'carzuri-core' ),
			'labels'                => $labels,
			'supports'              => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
			'hierarchical'          => false,
			'public'                => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'menu_position'         => 5,
			'menu_icon'             => 'dashicons-car',
			'show_in_nav_menus'     => true,
			'can_export'            => true,
			'has_archive'           => true,
			'exclude_from_search'   => false,
			'publicly_queryable'    => true,
			'show_in_rest'          => true,
			'rest_base'             => 'vehicles',
		);

		register_post_type( 'vehicle', $args );
	}

	/**
	 * Register meta fields with show_in_rest => true.
	 *
	 * NOTE: 'carzuri_location' (a free-text Location field) was removed
	 * here as part of the Location field consolidation — it duplicated
	 * the real `vehicle_location` taxonomy (already assignable via
	 * WordPress's native taxonomy sidebar panel on this screen, since
	 * that taxonomy was never given a custom meta_box_cb override) and
	 * was never guaranteed to agree with it. The taxonomy is now the
	 * single source of truth for a vehicle's location everywhere.
	 */
	public function register_meta_fields() {
		$meta_keys = array(
			'carzuri_price' => array(
				'type'              => 'integer',
				'description'       => 'Vehicle price in KSh',
				'single'            => true,
				'sanitize_callback' => 'absint',
			),
			'carzuri_year' => array(
				'type'              => 'integer',
				'description'       => 'Year of manufacture',
				'single'            => true,
				'sanitize_callback' => 'absint',
			),
			'carzuri_mileage' => array(
				'type'              => 'integer',
				'description'       => 'Mileage in km',
				'single'            => true,
				'sanitize_callback' => 'absint',
			),
			'carzuri_condition' => array(
				'type'              => 'string',
				'description'       => 'Vehicle condition: new/used/certified-pre-owned',
				'single'            => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'carzuri_transmission' => array(
				'type'              => 'string',
				'description'       => 'Transmission: automatic/manual',
				'single'            => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'carzuri_fuel_type' => array(
				'type'              => 'string',
				'description'       => 'Fuel type: petrol/diesel/hybrid/electric',
				'single'            => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'carzuri_engine_size' => array(
				'type'              => 'string',
				'description'       => 'Engine capacity, e.g., 2.0L',
				'single'            => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'carzuri_vin' => array(
				'type'              => 'string',
				'description'       => 'Vehicle Identification Number',
				'single'            => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'carzuri_registration_number' => array(
				'type'              => 'string',
				'description'       => 'Kenyan number plate format',
				'single'            => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'carzuri_dealer_id' => array(
				'type'              => 'integer',
				'description'       => 'WP user ID of the owning dealer (0 = platform-owned)',
				'single'            => true,
				'sanitize_callback' => 'absint',
			),
			'carzuri_status' => array(
				'type'              => 'string',
				'description'       => 'Listing status: available/reserved/sold/pending-approval',
				'single'            => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'carzuri_featured' => array(
				'type'              => 'boolean',
				'description'       => 'Is the listing featured?',
				'single'            => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
			),
			'carzuri_gallery_ids' => array(
				'type'              => 'array',
				'description'       => 'Array of media attachment IDs',
				'single'            => true,
				'sanitize_callback' => array( $this, 'sanitize_gallery_ids' ),
				'show_in_rest' => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array(
							'type' => 'integer',
						),
					),
				),
			),
			'carzuri_accident_history' => array(
				'type'              => 'string',
				'description'       => 'Accident history: none/minor/major',
				'single'            => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'carzuri_service_history' => array(
				'type'              => 'string',
				'description'       => 'Service history: full/partial/none',
				'single'            => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'carzuri_views_count' => array(
				'type'              => 'integer',
				'description'       => 'Count of single views',
				'single'            => true,
				'sanitize_callback' => 'absint',
			),
		);

		foreach ( $meta_keys as $key => $args ) {
			register_post_meta( 'vehicle', $key, array(
				'show_in_rest'      => isset( $args['show_in_rest'] ) ? $args['show_in_rest'] : true,
				'single'            => $args['single'],
				'type'              => $args['type'],
				'description'       => $args['description'],
				'sanitize_callback' => $args['sanitize_callback'],
			) );
		}
	}

	/**
	 * Sanitize function for gallery arrays.
	 */
	public function sanitize_gallery_ids( $value ) {
		if ( is_string( $value ) ) {
			$value = json_decode( $value, true );
		}
		if ( ! is_array( $value ) ) {
			return array();
		}
		return array_values( array_filter( array_map( 'absint', $value ) ) );
	}

	/**
	 * Add Vehicle Meta Box in the WP Admin post editor.
	 */
	public function add_vehicle_meta_box() {
		add_meta_box(
			'carzuri_vehicle_details',
			__( 'Vehicle Specifications & Settings', 'carzuri-core' ),
			array( $this, 'render_vehicle_meta_box' ),
			'vehicle',
			'normal',
			'high'
		);
	}

	/**
	 * Render fields in the admin metabox.
	 */
	public function render_vehicle_meta_box( $post ) {
		// Nonce field for verification.
		wp_nonce_field( 'save_carzuri_vehicle_meta', 'carzuri_vehicle_nonce' );

		// Retrieve existing meta values.
		$price          = get_post_meta( $post->ID, 'carzuri_price', true );
		$year           = get_post_meta( $post->ID, 'carzuri_year', true );
		$mileage        = get_post_meta( $post->ID, 'carzuri_mileage', true );
		$condition      = get_post_meta( $post->ID, 'carzuri_condition', true );
		$transmission   = get_post_meta( $post->ID, 'carzuri_transmission', true );
		$fuel_type      = get_post_meta( $post->ID, 'carzuri_fuel_type', true );
		$engine_size    = get_post_meta( $post->ID, 'carzuri_engine_size', true );
		$vin            = get_post_meta( $post->ID, 'carzuri_vin', true );
		$reg_number     = get_post_meta( $post->ID, 'carzuri_registration_number', true );
		$dealer_id      = get_post_meta( $post->ID, 'carzuri_dealer_id', true );
		$status         = get_post_meta( $post->ID, 'carzuri_status', true );
		$featured       = get_post_meta( $post->ID, 'carzuri_featured', true );
		$gallery_ids    = get_post_meta( $post->ID, 'carzuri_gallery_ids', true );
		$accident_hist  = get_post_meta( $post->ID, 'carzuri_accident_history', true );
		$service_hist   = get_post_meta( $post->ID, 'carzuri_service_history', true );
		$views_count    = get_post_meta( $post->ID, 'carzuri_views_count', true );

		// Retrieve assigned taxonomy terms
		$current_makes  = wp_get_object_terms( $post->ID, 'vehicle_make' );
		$current_make_id = ( ! empty( $current_makes ) && ! is_wp_error( $current_makes ) ) ? (int) $current_makes[0]->term_id : 0;

		$current_models = wp_get_object_terms( $post->ID, 'vehicle_model' );
		$current_model_id = ( ! empty( $current_models ) && ! is_wp_error( $current_models ) ) ? (int) $current_models[0]->term_id : 0;

		// Get all makes and models
		$all_makes  = get_terms( array( 'taxonomy' => 'vehicle_make', 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );
		$all_models = get_terms( array( 'taxonomy' => 'vehicle_model', 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );

		// Default values
		if ( $dealer_id === '' ) { $dealer_id = 0; }
		if ( $status === '' ) { $status = 'available'; }
		if ( $views_count === '' ) { $views_count = 0; }
		if ( ! is_array( $gallery_ids ) ) { $gallery_ids = array(); }

		// Output styling using design system vars inside the WP Admin page
		?>
		<style>
			.carzuri-meta-grid {
				display: grid;
				grid-template-columns: 1fr 1fr;
				gap: 16px;
				padding: 10px;
			}
			.carzuri-meta-field {
				display: flex;
				flex-direction: column;
				min-width: 0;
			}
			.carzuri-meta-field label {
				font-weight: 600;
				margin-bottom: 4px;
				color: #23282d;
			}
			.carzuri-meta-field input, .carzuri-meta-field select {
				padding: 8px;
				font-size: 14px;
				border-radius: 4px;
				border: 1px solid #ddd;
				width: 100%;
			}
			.carzuri-meta-full {
				grid-column: span 2;
			}
		</style>
		<div class="carzuri-meta-grid">

			<div class="carzuri-meta-field">
				<label for="carzuri_make_term_id"><?php _e( 'Vehicle Make', 'carzuri-core' ); ?></label>
				<select id="carzuri_make_term_id" name="carzuri_make_term_id">
					<option value="0"><?php _e( '— Select Make —', 'carzuri-core' ); ?></option>
					<?php if ( ! empty( $all_makes ) && ! is_wp_error( $all_makes ) ) : ?>
						<?php foreach ( $all_makes as $make_term ) : ?>
							<option value="<?php echo esc_attr( $make_term->term_id ); ?>" <?php selected( $current_make_id, $make_term->term_id ); ?>>
								<?php echo esc_html( $make_term->name ); ?>
							</option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_model_term_id"><?php _e( 'Vehicle Model', 'carzuri-core' ); ?></label>
				<select id="carzuri_model_term_id" name="carzuri_model_term_id">
					<option value="0"><?php _e( '— Select Model —', 'carzuri-core' ); ?></option>
					<?php if ( ! empty( $all_models ) && ! is_wp_error( $all_models ) ) : ?>
						<?php foreach ( $all_models as $model_term ) : 
							$related_make = (int) get_term_meta( $model_term->term_id, 'related_make_term_id', true );
						?>
							<option value="<?php echo esc_attr( $model_term->term_id ); ?>" data-make-id="<?php echo esc_attr( $related_make ); ?>" <?php selected( $current_model_id, $model_term->term_id ); ?>>
								<?php echo esc_html( $model_term->name ); ?>
							</option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
			
			<div class="carzuri-meta-field">
				<label for="carzuri_price"><?php _e( 'Price (KSh)', 'carzuri-core' ); ?></label>
				<input type="number" id="carzuri_price" name="carzuri_price" value="<?php echo esc_attr( $price ); ?>" placeholder="e.g. 2500000" min="0" step="1" required />
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_year"><?php _e( 'Year of Manufacture', 'carzuri-core' ); ?></label>
				<input type="number" id="carzuri_year" name="carzuri_year" value="<?php echo esc_attr( $year ); ?>" placeholder="e.g. 2018" min="1900" max="2100" required />
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_mileage"><?php _e( 'Mileage (km)', 'carzuri-core' ); ?></label>
				<input type="number" id="carzuri_mileage" name="carzuri_mileage" value="<?php echo esc_attr( $mileage ); ?>" placeholder="e.g. 45000" min="0" step="1" required />
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_condition"><?php _e( 'Condition', 'carzuri-core' ); ?></label>
				<select id="carzuri_condition" name="carzuri_condition">
					<option value="used" <?php selected( $condition, 'used' ); ?>><?php _e( 'Used', 'carzuri-core' ); ?></option>
					<option value="new" <?php selected( $condition, 'new' ); ?>><?php _e( 'New', 'carzuri-core' ); ?></option>
					<option value="certified-pre-owned" <?php selected( $condition, 'certified-pre-owned' ); ?>><?php _e( 'Certified Pre-Owned', 'carzuri-core' ); ?></option>
				</select>
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_transmission"><?php _e( 'Transmission', 'carzuri-core' ); ?></label>
				<select id="carzuri_transmission" name="carzuri_transmission">
					<option value="automatic" <?php selected( $transmission, 'automatic' ); ?>><?php _e( 'Automatic', 'carzuri-core' ); ?></option>
					<option value="manual" <?php selected( $transmission, 'manual' ); ?>><?php _e( 'Manual', 'carzuri-core' ); ?></option>
				</select>
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_fuel_type"><?php _e( 'Fuel Type', 'carzuri-core' ); ?></label>
				<select id="carzuri_fuel_type" name="carzuri_fuel_type">
					<option value="petrol" <?php selected( $fuel_type, 'petrol' ); ?>><?php _e( 'Petrol', 'carzuri-core' ); ?></option>
					<option value="diesel" <?php selected( $fuel_type, 'diesel' ); ?>><?php _e( 'Diesel', 'carzuri-core' ); ?></option>
					<option value="hybrid" <?php selected( $fuel_type, 'hybrid' ); ?>><?php _e( 'Hybrid', 'carzuri-core' ); ?></option>
					<option value="electric" <?php selected( $fuel_type, 'electric' ); ?>><?php _e( 'Electric', 'carzuri-core' ); ?></option>
				</select>
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_engine_size"><?php _e( 'Engine Size', 'carzuri-core' ); ?></label>
				<input type="text" id="carzuri_engine_size" name="carzuri_engine_size" value="<?php echo esc_attr( $engine_size ); ?>" placeholder="e.g. 2.0L or 3000cc" />
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_vin"><?php _e( 'VIN (Vehicle Identification Number)', 'carzuri-core' ); ?></label>
				<input type="text" id="carzuri_vin" name="carzuri_vin" value="<?php echo esc_attr( $vin ); ?>" placeholder="17-digit VIN" />
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_registration_number"><?php _e( 'Registration Number (Plate)', 'carzuri-core' ); ?></label>
				<input type="text" id="carzuri_registration_number" name="carzuri_registration_number" value="<?php echo esc_attr( $reg_number ); ?>" placeholder="e.g. KDL 123A" />
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_dealer_id"><?php _e( 'Dealer / Owner (User ID)', 'carzuri-core' ); ?></label>
				<input type="number" id="carzuri_dealer_id" name="carzuri_dealer_id" value="<?php echo esc_attr( $dealer_id ); ?>" placeholder="0 for Platform" min="0" step="1" />
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_status"><?php _e( 'Status', 'carzuri-core' ); ?></label>
				<select id="carzuri_status" name="carzuri_status">
					<option value="available" <?php selected( $status, 'available' ); ?>><?php _e( 'Available', 'carzuri-core' ); ?></option>
					<option value="reserved" <?php selected( $status, 'reserved' ); ?>><?php _e( 'Reserved', 'carzuri-core' ); ?></option>
					<option value="sold" <?php selected( $status, 'sold' ); ?>><?php _e( 'Sold', 'carzuri-core' ); ?></option>
					<option value="pending-approval" <?php selected( $status, 'pending-approval' ); ?>><?php _e( 'Pending Approval', 'carzuri-core' ); ?></option>
				</select>
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_accident_history"><?php _e( 'Accident History', 'carzuri-core' ); ?></label>
				<select id="carzuri_accident_history" name="carzuri_accident_history">
					<option value="none" <?php selected( $accident_hist, 'none' ); ?>><?php _e( 'None', 'carzuri-core' ); ?></option>
					<option value="minor" <?php selected( $accident_hist, 'minor' ); ?>><?php _e( 'Minor', 'carzuri-core' ); ?></option>
					<option value="major" <?php selected( $accident_hist, 'major' ); ?>><?php _e( 'Major', 'carzuri-core' ); ?></option>
				</select>
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_service_history"><?php _e( 'Service History', 'carzuri-core' ); ?></label>
				<select id="carzuri_service_history" name="carzuri_service_history">
					<option value="full" <?php selected( $service_hist, 'full' ); ?>><?php _e( 'Full History', 'carzuri-core' ); ?></option>
					<option value="partial" <?php selected( $service_hist, 'partial' ); ?>><?php _e( 'Partial History', 'carzuri-core' ); ?></option>
					<option value="none" <?php selected( $service_hist, 'none' ); ?>><?php _e( 'No History', 'carzuri-core' ); ?></option>
				</select>
			</div>

			<div class="carzuri-meta-field">
				<label for="carzuri_featured" style="display:inline-flex; align-items:center;">
					<input type="checkbox" id="carzuri_featured" name="carzuri_featured" value="1" <?php checked( $featured, true ); ?> style="margin-right:8px; margin-top:0;" />
					<?php _e( 'Featured Vehicle (homepage highlight)', 'carzuri-core' ); ?>
				</label>
			</div>

			<div class="carzuri-meta-field">
				<label><?php _e( 'Views Count', 'carzuri-core' ); ?></label>
				<input type="text" value="<?php echo esc_attr( $views_count ); ?>" disabled style="background:#eee;" />
			</div>

			<div class="carzuri-meta-field carzuri-meta-full">
				<label for="carzuri_gallery_ids_input"><?php _e( 'Additional Gallery Image IDs (Comma separated integers)', 'carzuri-core' ); ?></label>
				<input type="text" id="carzuri_gallery_ids_input" name="carzuri_gallery_ids" value="<?php echo esc_attr( implode( ',', $gallery_ids ) ); ?>" placeholder="e.g. 102,105,108" />
			</div>

			<div class="carzuri-meta-field carzuri-meta-full">
				<p style="margin: 0; color: #6b7280; font-size: 13px;">
					<?php _e( 'Location is set via the "Locations" taxonomy panel in the sidebar of this screen, not here — this keeps a single source of truth for filtering and display.', 'carzuri-core' ); ?>
				</p>
			</div>

		</div>

		<script>
		(function() {
			var makeSelect = document.getElementById('carzuri_make_term_id');
			var modelSelect = document.getElementById('carzuri_model_term_id');
			if (!makeSelect || !modelSelect) return;

			// Store all model options initially
			var modelOptions = [];
			for (var i = 0; i < modelSelect.options.length; i++) {
				var opt = modelSelect.options[i];
				modelOptions.push({
					value: opt.value,
					text: opt.text,
					makeId: opt.getAttribute('data-make-id') || '0',
					selected: opt.selected
				});
			}

			function filterModels() {
				var selectedMake = makeSelect.value;
				var currentModelVal = modelSelect.value;

				// Reset options
				modelSelect.innerHTML = '';

				var placeholder = document.createElement('option');
				placeholder.value = '0';
				placeholder.text = '<?php echo esc_js( __( '— Select Model —', 'carzuri-core' ) ); ?>';
				modelSelect.appendChild(placeholder);

				var matchCount = 0;
				for (var j = 0; j < modelOptions.length; j++) {
					var item = modelOptions[j];
					if (item.value === '0') continue;

					// If make is 0, show all models. If make selected, show models linked to that make.
					if (selectedMake === '0' || selectedMake === '' || item.makeId === selectedMake) {
						var newOpt = document.createElement('option');
						newOpt.value = item.value;
						newOpt.text = item.text;
						newOpt.setAttribute('data-make-id', item.makeId);
						if (item.value === currentModelVal) {
							newOpt.selected = true;
						}
						modelSelect.appendChild(newOpt);
						matchCount++;
					}
				}

				if (selectedMake !== '0' && selectedMake !== '' && matchCount === 0) {
					var emptyOpt = document.createElement('option');
					emptyOpt.value = '0';
					emptyOpt.text = '<?php echo esc_js( __( 'No models available for this make', 'carzuri-core' ) ); ?>';
					modelSelect.appendChild(emptyOpt);
				}
			}

			makeSelect.addEventListener('change', filterModels);
			// Initial filter run on page load
			filterModels();
		})();
		</script>
		<?php
	}

	/**
	 * Save vehicle metadata.
	 */
	public function save_vehicle_meta( $post_id ) {
		// Verify Nonce.
		if ( ! isset( $_POST['carzuri_vehicle_nonce'] ) || ! wp_verify_nonce( $_POST['carzuri_vehicle_nonce'], 'save_carzuri_vehicle_meta' ) ) {
			return;
		}

		// Prevent autosaves.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Check permission.
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Save Make and Model taxonomy terms if posted
		if ( isset( $_POST['carzuri_make_term_id'] ) ) {
			$make_term_id = absint( $_POST['carzuri_make_term_id'] );
			if ( $make_term_id > 0 ) {
				wp_set_object_terms( $post_id, array( $make_term_id ), 'vehicle_make' );
			} else {
				wp_set_object_terms( $post_id, array(), 'vehicle_make' );
			}
		}

		if ( isset( $_POST['carzuri_model_term_id'] ) ) {
			$model_term_id = absint( $_POST['carzuri_model_term_id'] );
			if ( $model_term_id > 0 ) {
				wp_set_object_terms( $post_id, array( $model_term_id ), 'vehicle_model' );
			} else {
				wp_set_object_terms( $post_id, array(), 'vehicle_model' );
			}
		}

		// Update fields.
		// NOTE: 'carzuri_location' removed from this list — see the note in
		// register_meta_fields() above. Location is now saved solely via
		// WordPress's native vehicle_location taxonomy sidebar panel.
		$fields = array(
			'carzuri_price'               => 'absint',
			'carzuri_year'                => 'absint',
			'carzuri_mileage'             => 'absint',
			'carzuri_condition'           => 'sanitize_text_field',
			'carzuri_transmission'        => 'sanitize_text_field',
			'carzuri_fuel_type'           => 'sanitize_text_field',
			'carzuri_engine_size'         => 'sanitize_text_field',
			'carzuri_vin'                 => 'sanitize_text_field',
			'carzuri_registration_number' => 'sanitize_text_field',
			'carzuri_dealer_id'           => 'absint',
			'carzuri_status'              => 'sanitize_text_field',
			'carzuri_accident_history'    => 'sanitize_text_field',
			'carzuri_service_history'     => 'sanitize_text_field',
		);

		foreach ( $fields as $key => $sanitize ) {
			if ( isset( $_POST[ $key ] ) ) {
				$val = $_POST[ $key ];
				update_post_meta( $post_id, $key, call_user_func( $sanitize, $val ) );
			}
		}

		// Handle checkbox.
		$featured = isset( $_POST['carzuri_featured'] ) ? true : false;
		update_post_meta( $post_id, 'carzuri_featured', $featured );

		// Handle gallery array.
		if ( isset( $_POST['carzuri_gallery_ids'] ) ) {
			$raw_ids = sanitize_text_field( $_POST['carzuri_gallery_ids'] );
			if ( empty( $raw_ids ) ) {
				$gallery_array = array();
			} else {
				$gallery_array = array_filter( array_map( 'absint', explode( ',', $raw_ids ) ) );
			}
			update_post_meta( $post_id, 'carzuri_gallery_ids', $gallery_array );
		}
	}

	/**
	 * Increment views count on single views.
	 */
	public function track_vehicle_views() {
		if ( is_singular( 'vehicle' ) ) {
			global $post;
			$views = (int) get_post_meta( $post->ID, 'carzuri_views_count', true );
			update_post_meta( $post->ID, 'carzuri_views_count', $views + 1 );
		}
	}
}
