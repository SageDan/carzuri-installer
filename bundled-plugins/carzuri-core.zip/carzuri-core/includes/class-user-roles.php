<?php
namespace Carzuri\Core;

/**
 * Manages custom user roles, capabilities, and capability mapping.
 *
 * @package           Carzuri_Core
 * @subpackage        Carzuri_Core/includes
 */
class UserRoles {

	/**
	 * Initialize roles actions.
	 */
	public function init() {
		// Hook map_meta_cap to restrict dealer operations to their own vehicles.
		add_filter( 'map_meta_cap', array( $this, 'map_dealer_meta_capabilities' ), 10, 4 );
	}

	/**
	 * Register/create the custom user roles and assign their core capabilities.
	 */
	public function create_roles() {
		// 1. Carzuri Buyer.
		add_role(
			'carzuri_buyer',
			__( 'Carzuri Buyer', 'carzuri-core' ),
			array(
				'read'                    => true,
				'carzuri_save_favorites'  => true,
				'carzuri_submit_inquiry'  => true,
				'carzuri_apply_finance'   => true,
			)
		);

		// 2. Carzuri Dealer.
		add_role(
			'carzuri_dealer',
			__( 'Carzuri Dealer', 'carzuri-core' ),
			array(
				'read'                         => true,
				'carzuri_manage_own_vehicles'  => true,
				'carzuri_view_own_leads'       => true,
				
				// Standard WP capabilities required to access post editor
				'edit_posts'                   => true,
				'publish_posts'                => true,
				'delete_posts'                 => true,
				'edit_published_posts'         => true,
				'delete_published_posts'       => true,
				'upload_files'                 => true,
			)
		);

		// 3. Carzuri Admin.
		add_role(
			'carzuri_admin',
			__( 'Carzuri Admin', 'carzuri-core' ),
			array(
				'read'                         => true,
				'edit_posts'                   => true,
				'edit_others_posts'            => true,
				'publish_posts'                => true,
				'delete_posts'                 => true,
				'delete_others_posts'          => true,
				'edit_published_posts'         => true,
				'edit_private_posts'           => true,
				'read_private_posts'           => true,
				'delete_published_posts'       => true,
				'delete_private_posts'         => true,
				'upload_files'                 => true,
				'manage_categories'            => true, // for taxonomies
				
				// Carzuri Custom Caps
				'carzuri_save_favorites'       => true,
				'carzuri_submit_inquiry'       => true,
				'carzuri_apply_finance'        => true,
				'carzuri_manage_own_vehicles'  => true,
				'carzuri_view_own_leads'       => true,
				'carzuri_manage_all_vehicles'  => true,
				'carzuri_manage_settings'      => true,
			)
		);

		// Also add these caps to the default administrator so they have master power.
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->add_cap( 'carzuri_save_favorites' );
			$admin->add_cap( 'carzuri_submit_inquiry' );
			$admin->add_cap( 'carzuri_apply_finance' );
			$admin->add_cap( 'carzuri_manage_own_vehicles' );
			$admin->add_cap( 'carzuri_view_own_leads' );
			$admin->add_cap( 'carzuri_manage_all_vehicles' );
			$admin->add_cap( 'carzuri_manage_settings' );
		}
	}

	/**
	 * Map meta capabilities to enforce dealer limits.
	 * Dealers can only edit/delete their own vehicle posts.
	 *
	 * @param array  $caps    The user's actual capabilities mapping.
	 * @param string $cap     The meta capability being checked.
	 * @param int    $user_id The user ID.
	 * @param array  $args    Arguments passed to has_cap (typically contains post ID as first element).
	 * @return array
	 */
	public function map_dealer_meta_capabilities( $caps, $cap, $user_id, $args ) {
		// Only intercept edit, delete, or read meta capabilities on vehicles.
		if ( ! in_array( $cap, array( 'edit_post', 'delete_post', 'read_post' ), true ) ) {
			return $caps;
		}

		if ( empty( $args ) ) {
			return $caps;
		}

		$post_id = $args[0];
		if ( get_post_type( $post_id ) !== 'vehicle' ) {
			return $caps;
		}

		// WP Administrators and Carzuri Admins bypass dealer mapping.
		if ( user_can( $user_id, 'carzuri_manage_all_vehicles' ) || user_can( $user_id, 'administrator' ) ) {
			return $caps;
		}

		// If the user has a dealer role.
		if ( user_can( $user_id, 'carzuri_dealer' ) ) {
			$dealer_id = (int) get_post_meta( $post_id, 'carzuri_dealer_id', true );

			// Check if this dealer is the assigned owner of the vehicle.
			if ( $dealer_id === $user_id ) {
				// Permit action if they possess general capabilities to edit posts
				return array( 'edit_posts' );
			} else {
				// Block editing/deletion by forcing a capability they definitely don't have.
				return array( 'do_not_allow' );
			}
		}

		return $caps;
	}
}
