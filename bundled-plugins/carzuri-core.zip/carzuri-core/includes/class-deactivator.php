<?php
namespace Carzuri\Core;

/**
 * Fired during plugin deactivation.
 *
 * @package           Carzuri_Core
 * @subpackage        Carzuri_Core/includes
 * @author            Carzuri
 */
class Deactivator {

	/**
	 * Run the deactivation routine.
	 */
	public static function deactivate() {
		// Flush rewrite rules.
		flush_rewrite_rules();
	}
}
