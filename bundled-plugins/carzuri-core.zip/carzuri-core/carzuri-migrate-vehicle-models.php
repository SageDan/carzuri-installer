<?php
/**
 * Carzuri — Vehicle Model Taxonomy One-Time Migration Script
 * 
 * Purpose: Migrates existing vehicle titles to the new `vehicle_model` taxonomy
 * without data loss. Skips ambiguous titles and generates a manual review report.
 * 
 * Usage:
 * - Via WP-CLI:
 *   wp eval-file carzuri-migrate-vehicle-models.php
 * 
 * - Or include from an admin hook / secure runner with manage_options permission.
 *
 * @package Carzuri_Core
 * @version 1.0.5
 */

// Safety check
if ( ! defined( 'ABSPATH' ) && ! defined( 'WP_CLI' ) ) {
	if ( php_sapi_name() !== 'cli' ) {
		die( 'Direct access not permitted.' );
	}
}

// Function to run migration
function carzuri_run_vehicle_models_migration( $dry_run = false ) {
	$output = array(
		'total_scanned'   => 0,
		'migrated'        => 0,
		'already_tagged'  => 0,
		'no_make'         => 0,
		'needs_review'    => array(),
		'success_log'     => array(),
	);

	echo "======================================================\n";
	echo " Carzuri: Vehicle Model Taxonomy Migration (v1.0.5)\n";
	echo " Mode: " . ( $dry_run ? "DRY RUN (no database writes)" : "LIVE EXECUTION" ) . "\n";
	echo "======================================================\n\n";

	// Known model catalogue mapped by make slug/name (normalized lowercase)
	$model_catalogue = array(
		'toyota' => array(
			'Land Cruiser Prado' => array( '/\b(prado|land\s*cruiser\s*prado|tx|tz)\b/i' ),
			'Land Cruiser'       => array( '/\b(land\s*cruiser|v8|lc200|lc300|lc70|lc79)\b/i' ),
			'Hilux'              => array( '/\b(hilux|revo|vigo|surf)\b/i' ),
			'Harrier'            => array( '/\b(harrier)\b/i' ),
			'RAV4'               => array( '/\b(rav\s*4|rav4)\b/i' ),
			'Premio'             => array( '/\b(premio)\b/i' ),
			'Allion'             => array( '/\b(allion)\b/i' ),
			'Vitz'               => array( '/\b(vitz)\b/i' ),
			'Yaris'              => array( '/\b(yaris|yaris\s*cross)\b/i' ),
			'Corolla Cross'      => array( '/\b(corolla\s*cross)\b/i' ),
			'Corolla Fielder'    => array( '/\b(fielder|corolla\s*fielder)\b/i' ),
			'Corolla Axio'       => array( '/\b(axio|corolla\s*axio)\b/i' ),
			'Corolla'            => array( '/\b(corolla)\b/i' ),
			'Crown'              => array( '/\b(crown|crown\s*athlete|crown\s*majesta|crown\s*royal)\b/i' ),
			'Fortuner'           => array( '/\b(fortuner)\b/i' ),
			'Wish'               => array( '/\b(wish)\b/i' ),
			'Passo'              => array( '/\b(passo)\b/i' ),
			'Mark X'             => array( '/\b(mark\s*x|mark-x)\b/i' ),
			'Noah'               => array( '/\b(noah)\b/i' ),
			'Voxy'               => array( '/\b(voxy)\b/i' ),
			'Alphard'            => array( '/\b(alphard)\b/i' ),
			'Vellfire'           => array( '/\b(vellfire)\b/i' ),
			'HiAce'              => array( '/\b(hiace|hi-ace)\b/i' ),
			'Rush'               => array( '/\b(rush)\b/i' ),
			'C-HR'               => array( '/\b(c-hr|chr)\b/i' ),
			'Vanguard'           => array( '/\b(vanguard)\b/i' ),
			'Probox'             => array( '/\b(probox)\b/i' ),
			'Succeed'            => array( '/\b(succeed)\b/i' ),
			'Auris'              => array( '/\b(auris)\b/i' ),
			'Ractis'             => array( '/\b(ractis)\b/i' ),
			'Sienta'             => array( '/\b(sienta)\b/i' ),
			'Camry'              => array( '/\b(camry)\b/i' ),
			'Hilux Revo'         => array( '/\b(revo)\b/i' ),
		),
		'mazda' => array(
			'CX-5'               => array( '/\b(cx-5|cx5|cx\s*5)\b/i' ),
			'CX-3'               => array( '/\b(cx-3|cx3|cx\s*3)\b/i' ),
			'CX-30'              => array( '/\b(cx-30|cx30|cx\s*30)\b/i' ),
			'CX-8'               => array( '/\b(cx-8|cx8|cx\s*8)\b/i' ),
			'CX-9'               => array( '/\b(cx-9|cx9|cx\s*9)\b/i' ),
			'Demio'              => array( '/\b(demio|mazda\s*2|mazda2)\b/i' ),
			'Axela'              => array( '/\b(axela|mazda\s*3|mazda3)\b/i' ),
			'Atenza'             => array( '/\b(atenza|mazda\s*6|mazda6)\b/i' ),
			'BT-50'              => array( '/\b(bt-50|bt50)\b/i' ),
			'Premacy'            => array( '/\b(premacy)\b/i' ),
			'Biante'             => array( '/\b(biante)\b/i' ),
		),
		'nissan' => array(
			'X-Trail'            => array( '/\b(x-trail|xtrail|x\s*trail)\b/i' ),
			'Note'               => array( '/\b(note|e-power|epower)\b/i' ),
			'Juke'               => array( '/\b(juke)\b/i' ),
			'Serena'             => array( '/\b(serena)\b/i' ),
			'Dualis'             => array( '/\b(dualis)\b/i' ),
			'Qashqai'            => array( '/\b(qashqai)\b/i' ),
			'Tiida'              => array( '/\b(tiida|latio)\b/i' ),
			'Teana'              => array( '/\b(teana)\b/i' ),
			'Navara'             => array( '/\b(navara|np300)\b/i' ),
			'Patrol'             => array( '/\b(patrol|y62|y61)\b/i' ),
			'Sylphy'             => array( '/\b(sylphy|bluebird)\b/i' ),
			'March'              => array( '/\b(march|micra)\b/i' ),
			'Murano'             => array( '/\b(murano)\b/i' ),
			'Ad Van'             => array( '/\b(ad\s*van|ad)\b/i' ),
		),
		'subaru' => array(
			'Forester'           => array( '/\b(forester|xt|sj5|sj|sk9)\b/i' ),
			'Outback'            => array( '/\b(outback|bs9|br9)\b/i' ),
			'XV'                 => array( '/\b(subaru\s*xv|xv|crosstrek)\b/i' ),
			'Legacy'             => array( '/\b(legacy|b4|touring\s*wagon)\b/i' ),
			'Impreza'            => array( '/\b(impreza|g4|sport)\b/i' ),
			'Levorg'             => array( '/\b(levorg)\b/i' ),
			'WRX'                => array( '/\b(wrx|sti)\b/i' ),
			'Exiga'              => array( '/\b(exiga)\b/i' ),
			'Trezia'             => array( '/\b(trezia)\b/i' ),
		),
		'mercedes-benz' => array(
			'C-Class'            => array( '/\b(c-class|c180|c200|c220|c250|c300|c43|c63|w205|w204|w206)\b/i' ),
			'E-Class'            => array( '/\b(e-class|e200|e220|e250|e300|e350|e400|w212|w213)\b/i' ),
			'S-Class'            => array( '/\b(s-class|s350|s400|s500|w222|w223)\b/i' ),
			'GLC'                => array( '/\b(glc|glc220|glc250|glc300|glc43|glc63)\b/i' ),
			'GLE'                => array( '/\b(gle|gle250|gle350|gle400|gle450|gle53|gle63)\b/i' ),
			'GLA'                => array( '/\b(gla|gla180|gla200|gla250|gla45)\b/i' ),
			'GLB'                => array( '/\b(glb|glb200|glb250)\b/i' ),
			'GLS'                => array( '/\b(gls|gls350|gls400|gls450|gls500)\b/i' ),
			'CLA'                => array( '/\b(cla|cla180|cla200|cla250|cla45)\b/i' ),
			'A-Class'            => array( '/\b(a-class|a180|a200|a250|a35|a45)\b/i' ),
			'G-Class'            => array( '/\b(g-class|g63|g350|g500|g-wagon)\b/i' ),
		),
		'bmw' => array(
			'3 Series'           => array( '/\b(3\s*series|320i|320d|328i|330i|335i|m340i|f30|g20)\b/i' ),
			'5 Series'           => array( '/\b(5\s*series|520i|520d|528i|530i|535i|540i|f10|g30)\b/i' ),
			'1 Series'           => array( '/\b(1\s*series|116i|118i|120i|125i|m135i|m140i)\b/i' ),
			'7 Series'           => array( '/\b(7\s*series|730i|730d|740i|750i)\b/i' ),
			'X1'                 => array( '/\b(x1|x-1)\b/i' ),
			'X3'                 => array( '/\b(x3|x-3)\b/i' ),
			'X4'                 => array( '/\b(x4|x-4)\b/i' ),
			'X5'                 => array( '/\b(x5|x-5)\b/i' ),
			'X6'                 => array( '/\b(x6|x-6)\b/i' ),
			'X7'                 => array( '/\b(x7|x-7)\b/i' ),
			'4 Series'           => array( '/\b(4\s*series|420i|428i|430i|435i)\b/i' ),
		),
		'honda' => array(
			'CR-V'               => array( '/\b(cr-v|crv|cr\s*v)\b/i' ),
			'Vezel'              => array( '/\b(vezel|hr-v|hrv)\b/i' ),
			'Fit'                => array( '/\b(fit|jazz)\b/i' ),
			'Civic'              => array( '/\b(civic)\b/i' ),
			'Accord'             => array( '/\b(accord)\b/i' ),
			'Freed'              => array( '/\b(freed)\b/i' ),
			'Stream'             => array( '/\b(stream)\b/i' ),
			'Insight'            => array( '/\b(insight)\b/i' ),
			'Stepwgn'            => array( '/\b(stepwgn|stepwagon)\b/i' ),
			'Shuttle'            => array( '/\b(shuttle)\b/i' ),
		),
		'volkswagen' => array(
			'Golf'               => array( '/\b(golf|golf\s*tsi|golf\s*gti|golf\s*r|golf\s*variant)\b/i' ),
			'Tiguan'             => array( '/\b(tiguan|tiguan\s*allspace)\b/i' ),
			'Touareg'            => array( '/\b(touareg)\b/i' ),
			'Passat'             => array( '/\b(passat|passat\s*variant)\b/i' ),
			'Polo'               => array( '/\b(polo)\b/i' ),
			'Arteon'             => array( '/\b(arteon)\b/i' ),
			'Amarok'             => array( '/\b(amarok)\b/i' ),
			'T-Roc'              => array( '/\b(t-roc|troc)\b/i' ),
			'T-Cross'            => array( '/\b(t-cross|tcross)\b/i' ),
			'Touran'             => array( '/\b(touran)\b/i' ),
		),
		'mitsubishi' => array(
			'Outlander'          => array( '/\b(outlander|outlander\s*phev)\b/i' ),
			'Pajero'             => array( '/\b(pajero|pajero\s*sport|montero)\b/i' ),
			'RVR'                => array( '/\b(rvr|asx)\b/i' ),
			'Eclipse Cross'      => array( '/\b(eclipse\s*cross)\b/i' ),
			'L200'               => array( '/\b(l200|triton)\b/i' ),
			'Delica'             => array( '/\b(delica|d:5|d5)\b/i' ),
		),
		'isuzu' => array(
			'D-Max'              => array( '/\b(d-max|dmax|d\s*max)\b/i' ),
			'MU-X'               => array( '/\b(mu-x|mux|mu\s*x)\b/i' ),
			'N-Series'           => array( '/\b(n-series|npr|nqr|elf)\b/i' ),
			'F-Series'           => array( '/\b(f-series|frr|fsr|forward)\b/i' ),
		),
		'land-rover' => array(
			'Range Rover Sport'  => array( '/\b(range\s*rover\s*sport|rr\s*sport)\b/i' ),
			'Range Rover Evoque' => array( '/\b(evoque|range\s*rover\s*evoque)\b/i' ),
			'Range Rover Velar'  => array( '/\b(velar|range\s*rover\s*velar)\b/i' ),
			'Range Rover'        => array( '/\b(range\s*rover|vogue|autobiography)\b/i' ),
			'Defender'           => array( '/\b(defender|defender\s*110|defender\s*90)\b/i' ),
			'Discovery Sport'    => array( '/\b(discovery\s*sport)\b/i' ),
			'Discovery'          => array( '/\b(discovery|discovery\s*4|discovery\s*5)\b/i' ),
		),
		'audi' => array(
			'A4'                 => array( '/\b(a4|a4\s*avant|a4\s*allroad)\b/i' ),
			'A6'                 => array( '/\b(a6|a6\s*avant)\b/i' ),
			'Q3'                 => array( '/\b(q3)\b/i' ),
			'Q5'                 => array( '/\b(q5)\b/i' ),
			'Q7'                 => array( '/\b(q7)\b/i' ),
			'Q8'                 => array( '/\b(q8)\b/i' ),
			'A3'                 => array( '/\b(a3|a3\s*sedan)\b/i' ),
			'A5'                 => array( '/\b(a5|a5\s*sportback)\b/i' ),
		),
		'suzuki' => array(
			'Jimny'              => array( '/\b(jimny|jimny\s*sierra)\b/i' ),
			'Swift'              => array( '/\b(swift|swift\s*sport)\b/i' ),
			'Vitara'             => array( '/\b(vitara|escudo|grand\s*vitara)\b/i' ),
			'Alto'               => array( '/\b(alto)\b/i' ),
			'Hustler'            => array( '/\b(hustler)\b/i' ),
			'Solio'              => array( '/\b(solio)\b/i' ),
			'Spacia'             => array( '/\b(spacia)\b/i' ),
		),
		'ford' => array(
			'Ranger'             => array( '/\b(ranger|wildtrak|raptor)\b/i' ),
			'Everest'            => array( '/\b(everest)\b/i' ),
			'Focus'              => array( '/\b(focus)\b/i' ),
			'Mustang'            => array( '/\b(mustang)\b/i' ),
			'Explorer'           => array( '/\b(explorer)\b/i' ),
			'Escape'             => array( '/\b(escape|kuga)\b/i' ),
		),
		'hyundai' => array(
			'Tucson'             => array( '/\b(tucson)\b/i' ),
			'Santa Fe'           => array( '/\b(santa\s*fe)\b/i' ),
			'Elantra'            => array( '/\b(elantra)\b/i' ),
			'Sonata'             => array( '/\b(sonata)\b/i' ),
			'Creta'              => array( '/\b(creta)\b/i' ),
			'Palisade'           => array( '/\b(palisade)\b/i' ),
			'Kona'               => array( '/\b(kona)\b/i' ),
		),
		'kia' => array(
			'Sportage'           => array( '/\b(sportage)\b/i' ),
			'Sorento'            => array( '/\b(sorento)\b/i' ),
			'Cerato'             => array( '/\b(cerato|forte)\b/i' ),
			'Rio'                => array( '/\b(rio)\b/i' ),
			'Seltos'             => array( '/\b(seltos)\b/i' ),
			'Carnival'           => array( '/\b(carnival|sedona)\b/i' ),
		),
	);

	// Query all vehicle posts
	$vehicles = get_posts( array(
		'post_type'      => 'vehicle',
		'post_status'    => array( 'publish', 'draft', 'pending' ),
		'posts_per_page' => -1,
	) );

	$output['total_scanned'] = count( $vehicles );

	foreach ( $vehicles as $vehicle ) {
		$post_id    = $vehicle->ID;
		$post_title = $vehicle->post_title;

		// 1. Check existing model terms
		$existing_models = wp_get_object_terms( $post_id, 'vehicle_model' );
		if ( ! empty( $existing_models ) && ! is_wp_error( $existing_models ) ) {
			$output['already_tagged']++;
			continue;
		}

		// 2. Check assigned make term
		$assigned_makes = wp_get_object_terms( $post_id, 'vehicle_make' );
		if ( empty( $assigned_makes ) || is_wp_error( $assigned_makes ) ) {
			$output['no_make']++;
			$output['needs_review'][] = array(
				'id'     => $post_id,
				'title'  => $post_title,
				'reason' => 'No Make assigned to vehicle.',
			);
			continue;
		}

		$make_term = $assigned_makes[0];
		$make_slug_norm = sanitize_title( $make_term->slug );
		$make_name_norm = sanitize_title( $make_term->name );

		// Find catalogue entry for make (checking slug and name normalized)
		$models_for_make = array();
		if ( isset( $model_catalogue[ $make_slug_norm ] ) ) {
			$models_for_make = $model_catalogue[ $make_slug_norm ];
		} elseif ( isset( $model_catalogue[ $make_name_norm ] ) ) {
			$models_for_make = $model_catalogue[ $make_name_norm ];
		} else {
			// Search catalogue keys
			foreach ( $model_catalogue as $cat_make => $models ) {
				$cat_make_norm = sanitize_title( $cat_make );
				if ( $cat_make_norm === $make_slug_norm || $cat_make_norm === $make_name_norm || strpos( $make_slug_norm, $cat_make_norm ) !== false ) {
					$models_for_make = $models;
					break;
				}
			}
		}

		if ( empty( $models_for_make ) ) {
			$output['needs_review'][] = array(
				'id'     => $post_id,
				'title'  => $post_title,
				'make'   => $make_term->name,
				'reason' => "Make '{$make_term->name}' has no predefined model catalogue entries.",
			);
			continue;
		}

		// Sort models by canonical string length descending so more specific/multi-word patterns are evaluated first
		uksort( $models_for_make, function( $a, $b ) {
			return strlen( $b ) - strlen( $a );
		} );

		// Match title against models
		$matched_models = array();

		foreach ( $models_for_make as $canonical_model_name => $patterns ) {
			foreach ( $patterns as $pattern ) {
				if ( preg_match( $pattern, $post_title ) ) {
					$matched_models[] = $canonical_model_name;
					break; // Found pattern match for this canonical model
				}
			}
		}

		// Disambiguate broader/narrower pattern pairs (e.g. Corolla vs. Corolla Cross/Fielder/Axio; Land Cruiser vs. Land Cruiser Prado; Hilux vs. Hilux Revo)
		// If a more specific compound model matches, suppress the broader parent model for the same title
		if ( count( $matched_models ) > 1 ) {
			$filtered_matches = array();
			foreach ( $matched_models as $model_a ) {
				$is_broader_subset = false;
				foreach ( $matched_models as $model_b ) {
					if ( $model_a === $model_b ) {
						continue;
					}
					// If model_a is a substring/subset of model_b (e.g. 'Land Cruiser' inside 'Land Cruiser Prado' or 'Corolla' inside 'Corolla Cross')
					if ( stripos( $model_b, $model_a ) !== false ) {
						$is_broader_subset = true;
						break;
					}
				}
				if ( ! $is_broader_subset ) {
					$filtered_matches[] = $model_a;
				}
			}
			$matched_models = array_values( array_unique( $filtered_matches ) );
		}

		$match_count = count( $matched_models );
		$matched_model_name = ( $match_count === 1 ) ? $matched_models[0] : null;

		// If ambiguous (multiple distinct models matched) or no match found
		if ( $match_count !== 1 || ! $matched_model_name ) {
			$output['needs_review'][] = array(
				'id'     => $post_id,
				'title'  => $post_title,
				'make'   => $make_term->name,
				'reason' => $match_count > 1 ? "Ambiguous match ({$match_count} distinct models detected: " . implode( ', ', $matched_models ) . ")." : "No recognized model in title.",
			);
			continue;
		}

		// Confident match! Tag vehicle with model taxonomy term
		if ( ! $dry_run ) {
			// Find or create vehicle_model term
			$term = get_term_by( 'name', $matched_model_name, 'vehicle_model' );
			if ( ! $term || is_wp_error( $term ) ) {
				$new_term_info = wp_insert_term( $matched_model_name, 'vehicle_model', array(
					'slug' => sanitize_title( $matched_model_name ),
				) );
				if ( is_wp_error( $new_term_info ) ) {
					$output['needs_review'][] = array(
						'id'     => $post_id,
						'title'  => $post_title,
						'make'   => $make_term->name,
						'reason' => "Failed to create term '{$matched_model_name}': " . $new_term_info->get_error_message(),
					);
					continue;
				}
				$term_id = $new_term_info['term_id'];
			} else {
				$term_id = $term->term_id;
			}

			// Ensure related_make_term_id is set on term
			update_term_meta( $term_id, 'related_make_term_id', (int) $make_term->term_id );

			// Associate term with vehicle post
			wp_set_object_terms( $post_id, array( (int) $term_id ), 'vehicle_model' );
		}

		$output['migrated']++;
		$output['success_log'][] = "Post #{$post_id} [{$post_title}] -> Make: {$make_term->name} | Model: {$matched_model_name}";
	}

	// Print Summary
	echo "=== MIGRATION SUMMARY ===\n";
	echo "Total Vehicles Scanned:  {$output['total_scanned']}\n";
	echo "Successfully Migrated:   {$output['migrated']}\n";
	echo "Already Had Model Term:  {$output['already_tagged']}\n";
	echo "Skipped (No Make Found): {$output['no_make']}\n";
	echo "Needs Manual Review:     " . count( $output['needs_review'] ) . "\n\n";

	if ( ! empty( $output['success_log'] ) ) {
		echo "--- Sample Migrated Items ---\n";
		foreach ( array_slice( $output['success_log'], 0, 15 ) as $log_line ) {
			echo "[OK] " . $log_line . "\n";
		}
		if ( count( $output['success_log'] ) > 15 ) {
			echo "... and " . ( count( $output['success_log'] ) - 15 ) . " more.\n";
		}
		echo "\n";
	}

	if ( ! empty( $output['needs_review'] ) ) {
		echo "--- Items Requiring Manual Review ---\n";
		foreach ( $output['needs_review'] as $item ) {
			$make_info = isset( $item['make'] ) ? " [Make: {$item['make']}]" : "";
			echo "[REVIEW] #{$item['id']}: \"{$item['title']}\"{$make_info} -> Reason: {$item['reason']}\n";
		}
		echo "\n";
	}

	return $output;
}

// Auto-run if executed via WP-CLI
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	$is_dry = in_array( '--dry-run', $GLOBALS['argv'] ?? array() );
	carzuri_run_vehicle_models_migration( $is_dry );
}
