=== Carzuri Core ===
Contributors: carzuri
Donate link: https://carzuri.com
Tags: vehicles, automotive, marketplace, dealer, rest-api
Requires at least: 5.6
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: Apache-2.0
License URI: http://www.apache.org/licenses/LICENSE-2.0

== Description ==

Carzuri Core is the vital foundation plugin for the Carzuri listing ecosystem. 
This plugin defines shared data structures, user roles, security levels, and the core REST API that all other Carzuri plugins (listings, dealer marketplace, valuation, finance, and dashboard) depend on.

== Installation ==

1. Upload the `carzuri-core` folder to the `/wp-content/plugins/` directory, or upload the `carzuri-core.zip` file via **Plugins → Add New → Upload Plugin**.
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Configure settings via the newly added top-level **Carzuri** admin menu.
4. Verify the setup on any test page using the shortcode `[carzuri_core_test]`.

== Frequently Asked Questions ==

= Is this a front-end vehicle display plugin? =
No. This is a foundational utility plugin. It registers the vehicle post type, custom taxonomies, and custom database tables. Front-end listing layouts and dealer dashboards are handled by their respective extension modules.

= How do I access the REST API? =
The REST API routes are enqueued under the `carzuri/v1` namespace. For example, query listings at `/wp-json/carzuri/v1/vehicles`.

== Changelog ==

= 1.0.0 =
* Initial foundation release.
* Added "vehicle" Custom Post Type and custom metabox spec panel.
* Added Custom User Roles (carzuri_buyer, carzuri_dealer, carzuri_admin).
* Added Custom DB Tables (favorites, saved searches, inquiries, valuations, finance apps, notifications).
* Added REST API endpoints for vehicles, favorites, and notifications.
* Added enqueued CSS Design System variables.
