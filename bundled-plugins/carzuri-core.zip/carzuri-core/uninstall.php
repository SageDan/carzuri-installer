<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package           Carzuri_Core
 */

// If uninstall not called from WordPress, exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// 1. Delete Options.
$options_to_delete = array(
	'carzuri_db_version',
	'carzuri_currency_symbol',
	'carzuri_default_locations',
	'carzuri_items_per_page',
	'carzuri_gemini_api_key',
	'carzuri_payment_gateway_key',
);

foreach ( $options_to_delete as $option ) {
	delete_option( $option );
}

// 2. Drop Custom Tables.
$tables_to_drop = array(
	$wpdb->prefix . 'carzuri_favorites',
	$wpdb->prefix . 'carzuri_saved_searches',
	$wpdb->prefix . 'carzuri_inquiries',
	$wpdb->prefix . 'carzuri_valuations',
	$wpdb->prefix . 'carzuri_finance_applications',
	$wpdb->prefix . 'carzuri_notifications',
);

foreach ( $tables_to_drop as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS `$table`" );
}

// 3. Remove Custom User Roles.
require_once ABSPATH . 'wp-admin/includes/user.php';

remove_role( 'carzuri_buyer' );
remove_role( 'carzuri_dealer' );
remove_role( 'carzuri_admin' );

// 4. Delete Custom Posts (Optional, but let's clear custom meta of vehicle posts if posts are left, or let WP handle them. Usually we leave user content like posts unless requested, but we can clean up CPT cache).
wp_cache_flush();
