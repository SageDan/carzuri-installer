<?php
namespace Carzuri\Core;

/**
 * Creates the WordPress Admin settings interface.
 *
 * @package           Carzuri_Core
 * @subpackage        Carzuri_Core/admin
 */
class AdminSettings {

	/**
	 * Initialize Admin Settings menu.
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Create Admin Menu structures.
	 */
	public function add_admin_menu() {
		// Parent top-level "Carzuri" Menu.
		add_menu_page(
			__( 'Carzuri', 'carzuri-core' ),
			__( 'Carzuri', 'carzuri-core' ),
			'carzuri_manage_settings',
			'carzuri',
			array( $this, 'render_dashboard' ),
			'dashicons-car',
			30
		);

		// Settings Submenu under "Carzuri".
		add_submenu_page(
			'carzuri',
			__( 'Settings', 'carzuri-core' ),
			__( 'Settings', 'carzuri-core' ),
			'carzuri_manage_settings',
			'carzuri-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Register settings using standard Settings API.
	 */
	public function register_settings() {
		// 1. General settings
		register_setting( 'carzuri_settings_general', 'carzuri_currency_symbol', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => 'KSh',
		) );

		register_setting( 'carzuri_settings_general', 'carzuri_items_per_page', array(
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'default'           => 10,
		) );

		register_setting( 'carzuri_settings_general', 'carzuri_default_locations', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_textarea_field',
			'default'           => "Nairobi\nMombasa\nKisumu\nNakuru\nEldoret",
		) );

		// 2. Secret keys settings (autoload => false for security and performance)
		register_setting( 'carzuri_settings_keys', 'carzuri_gemini_api_key', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );

		register_setting( 'carzuri_settings_keys', 'carzuri_gemini_model', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => 'gemini-3.6-flash',
		) );

		register_setting( 'carzuri_settings_keys', 'carzuri_payment_gateway_key', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );
	}

	/**
	 * Temporary main landing page placeholder.
	 */
	public function render_dashboard() {
		?>
		<div class="wrap carzuri-admin-wrap" style="max-width: 800px; margin-top: 20px;">
			<h1 style="display:flex; align-items:center; font-weight:700;">
				<span class="dashicons dashicons-car" style="font-size:32px; width:32px; height:32px; margin-right:10px;"></span>
				<?php _e( 'Carzuri Platform Dashboard', 'carzuri-core' ); ?>
			</h1>
			<p class="description" style="font-size:15px; margin-bottom: 20px;">
				<?php _e( 'Welcome to the Carzuri core engine. This core module manages background database structures, roles, and REST pathways powering the Carzuri listing ecosystem.', 'carzuri-core' ); ?>
			</p>
			
			<div class="card" style="padding: 20px; border-radius: 8px; border: 1px solid #ccd0d4; background:#fff;">
				<h2><?php _e( 'Core Engine Status', 'carzuri-core' ); ?></h2>
				<p><strong><?php _e( 'Database Version:', 'carzuri-core' ); ?></strong> <code><?php echo esc_html( get_option( 'carzuri_db_version', '1.0.0' ) ); ?></code> (Status: Online)</p>
				<p><strong><?php _e( 'REST Base Route:', 'carzuri-core' ); ?></strong> <code><?php echo esc_url( rest_url( 'carzuri/v1/' ) ); ?></code></p>
				<p>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=carzuri-settings' ) ); ?>" class="button button-primary"><?php _e( 'Configure Platform Settings', 'carzuri-core' ); ?></a>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=vehicle' ) ); ?>" class="button button-secondary"><?php _e( 'Manage Listings Stock', 'carzuri-core' ); ?></a>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Render settings page with tab triggers.
	 */
	public function render_settings_page() {
		// Active tab detector
		$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'general';
		?>
		<div class="wrap carzuri-admin-wrap" style="max-width: 800px; margin-top: 20px;">
			<h1><?php _e( 'Carzuri Settings', 'carzuri-core' ); ?></h1>
			
			<h2 class="nav-tab-wrapper" style="margin-bottom: 20px;">
				<a href="?page=carzuri-settings&tab=general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">
					<?php _e( 'General Config', 'carzuri-core' ); ?>
				</a>
				<a href="?page=carzuri-settings&tab=api_keys" class="nav-tab <?php echo $active_tab === 'api_keys' ? 'nav-tab-active' : ''; ?>">
					<?php _e( 'API Keys & Secrets', 'carzuri-core' ); ?>
				</a>
			</h2>

			<form method="post" action="options.php" style="background:#fff; padding:24px; border-radius:8px; border:1px solid #ccd0d4;">
				<?php
				if ( $active_tab === 'general' ) {
					settings_fields( 'carzuri_settings_general' );
					?>
					<h2><?php _e( 'Platform Listings Setup', 'carzuri-core' ); ?></h2>
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="carzuri_currency_symbol"><?php _e( 'Currency Symbol', 'carzuri-core' ); ?></label>
								</th>
								<td>
									<input name="carzuri_currency_symbol" type="text" id="carzuri_currency_symbol" value="<?php echo esc_attr( get_option( 'carzuri_currency_symbol', 'KSh' ) ); ?>" class="regular-text" style="width:120px;" />
									<p class="description"><?php _e( 'Display prefix for price queries, e.g. KSh or $', 'carzuri-core' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="carzuri_items_per_page"><?php _e( 'Items per Page', 'carzuri-core' ); ?></label>
								</th>
								<td>
									<input name="carzuri_items_per_page" type="number" id="carzuri_items_per_page" value="<?php echo esc_attr( get_option( 'carzuri_items_per_page', 10 ) ); ?>" class="small-text" style="width:120px;" min="1" max="100" />
									<p class="description"><?php _e( 'Default pagination limit for API and shortcode loops.', 'carzuri-core' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="carzuri_default_locations"><?php _e( 'Supported Locations List', 'carzuri-core' ); ?></label>
								</th>
								<td>
									<textarea name="carzuri_default_locations" id="carzuri_default_locations" rows="6" class="large-text" style="width:100%; max-width:400px;"><?php echo esc_textarea( get_option( 'carzuri_default_locations', "Nairobi\nMombasa\nKisumu\nNakuru\nEldoret" ) ); ?></textarea>
									<p class="description"><?php _e( 'Enter locations to utilize inside filters, one per line.', 'carzuri-core' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
					<?php
				} else {
					settings_fields( 'carzuri_settings_keys' );
					?>
					<h2><?php _e( 'Third-Party Connection Keys', 'carzuri-core' ); ?></h2>
					<p class="description" style="margin-bottom:20px;">
						<?php _e( 'Configure security connections utilized by advanced valuation and pricing plugins. These values are autoload-disabled for database safety.', 'carzuri-core' ); ?>
					</p>
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="carzuri_gemini_api_key"><?php _e( 'Gemini AI API Key', 'carzuri-core' ); ?></label>
								</th>
								<td>
									<input name="carzuri_gemini_api_key" type="password" id="carzuri_gemini_api_key" value="<?php echo esc_attr( get_option( 'carzuri_gemini_api_key', '' ) ); ?>" class="regular-text" style="width:100%; max-width:400px;" />
									<p class="description"><?php _e( 'Required for automatic vehicle price valuation modeling.', 'carzuri-core' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="carzuri_gemini_model"><?php _e( 'Gemini Model Version', 'carzuri-core' ); ?></label>
								</th>
								<td>
									<input
										name="carzuri_gemini_model"
										type="text"
										id="carzuri_gemini_model"
										list="carzuri_gemini_model_suggestions"
										value="<?php echo esc_attr( get_option( 'carzuri_gemini_model', 'gemini-3.6-flash' ) ); ?>"
										class="regular-text"
										style="width:100%; max-width:400px;"
									/>
									<datalist id="carzuri_gemini_model_suggestions">
										<option value="gemini-3.6-flash">
										<option value="gemini-2.5-flash">
										<option value="gemini-2.5-pro">
										<option value="gemini-2.0-flash">
										<option value="gemini-1.5-flash">
										<option value="gemini-1.5-pro">
									</datalist>
									<p class="description">
										<?php _e( 'The exact Gemini model ID to use for AI Smart Valuation requests. Pick a suggestion from the dropdown, or type any other valid Gemini model ID directly. If valuations start failing due to high demand on the current model, switching to an alternative (often an older or lighter version) here can restore service immediately — no code changes needed.', 'carzuri-core' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="carzuri_payment_gateway_key"><?php _e( 'Payment Gateway API Key', 'carzuri-core' ); ?></label>
								</th>
								<td>
									<input name="carzuri_payment_gateway_key" type="password" id="carzuri_payment_gateway_key" value="<?php echo esc_attr( get_option( 'carzuri_payment_gateway_key', '' ) ); ?>" class="regular-text" style="width:100%; max-width:400px;" />
									<p class="description"><?php _e( 'Connect key for processing user listing subscriptions.', 'carzuri-core' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
					<?php
				}

				submit_button();
				?>
			</form>
		</div>
		<?php
	}
}
