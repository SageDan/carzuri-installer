<?php
/**
 * Plugin Name:       Carzuri Core
 * Plugin URI:        https://carzuri.com
 * Description:       The foundational plugin for the Carzuri platform. Defines CPTs, taxonomies, database tables, user roles, REST API endpoints, and design systems.
 * Version:           1.0.8
 * Author:            Carzuri
 * Author URI:        https://carzuri.com
 * License:           Apache-2.0
 * License URI:       http://www.apache.org/licenses/LICENSE-2.0
 * Text Domain:       carzuri-core
 * Domain Path:       /languages
 * Namespace:         Carzuri\Core
 *
 * @package           Carzuri_Core
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

// Define Plugin Constants.
define( 'CARZURI_CORE_VERSION', '1.0.8' );
define( 'CARZURI_CORE_PATH', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_CORE_URL', plugin_dir_url( __FILE__ ) );
define( 'CARZURI_CORE_DB_VERSION', '1.0.5' );

// Include global helper functions.
require_once CARZURI_CORE_PATH . 'includes/helpers.php';

// Include other core files.
require_once CARZURI_CORE_PATH . 'includes/class-activator.php';
require_once CARZURI_CORE_PATH . 'includes/class-deactivator.php';
require_once CARZURI_CORE_PATH . 'includes/class-db-tables.php';
require_once CARZURI_CORE_PATH . 'includes/class-user-roles.php';
require_once CARZURI_CORE_PATH . 'includes/class-cpt-vehicle.php';
require_once CARZURI_CORE_PATH . 'includes/class-taxonomies.php';
require_once CARZURI_CORE_PATH . 'includes/class-rest-api.php';
require_once CARZURI_CORE_PATH . 'admin/class-admin-settings.php';

/**
 * Register Activation Hook.
 */
function activate_carzuri_core() {
	require_once CARZURI_CORE_PATH . 'includes/class-activator.php';
	Carzuri\Core\Activator::activate();
}
register_activation_hook( __FILE__, 'activate_carzuri_core' );

/**
 * Register Deactivation Hook.
 */
function deactivate_carzuri_core() {
	require_once CARZURI_CORE_PATH . 'includes/class-deactivator.php';
	Carzuri\Core\Deactivator::deactivate();
}
register_deactivation_hook( __FILE__, 'deactivate_carzuri_core' );

/**
 * Bootstrap the Carzuri Core components.
 */
function run_carzuri_core() {
	// Initialize database tables checking / migrations.
	$db_tables = new Carzuri\Core\DatabaseTables();
	$db_tables->init();

	// Initialize Custom User Roles & Capabilities.
	$user_roles = new Carzuri\Core\UserRoles();
	$user_roles->init();

	// Initialize custom taxonomies.
	$taxonomies = new Carzuri\Core\Taxonomies();
	$taxonomies->init();

	// Initialize Custom Post Type (CPT) - Vehicle.
	$cpt_vehicle = new Carzuri\Core\CPTVehicle();
	$cpt_vehicle->init();

	// Initialize REST API Endpoints.
	$rest_api = new Carzuri\Core\RestAPI();
	$rest_api->init();

	// Initialize Admin Settings Page.
	if ( is_admin() ) {
		$admin_settings = new Carzuri\Core\AdminSettings();
		$admin_settings->init();
	}

	// Enqueue shared core styling and script.
	add_action( 'wp_enqueue_scripts', 'carzuri_core_enqueue_assets' );
	add_action( 'admin_enqueue_scripts', 'carzuri_core_enqueue_admin_assets' );
}

/**
 * Enqueue front-end core assets.
 */
function carzuri_core_enqueue_assets() {
	wp_enqueue_style( 'carzuri-design-system', CARZURI_CORE_URL . 'assets/css/carzuri-design-system.css', array(), CARZURI_CORE_VERSION );
	wp_enqueue_script( 'carzuri-core', CARZURI_CORE_URL . 'assets/js/carzuri-core.js', array( 'jquery' ), CARZURI_CORE_VERSION, true );
	
	// Localize API parameters for logged-in requests.
	// 'user_id' is used by the Android app's push notification bridge in
	// carzuri-core.js, which only registers a device token once it can
	// confirm a real logged-in user (0 = logged out).
	wp_localize_script( 'carzuri-core', 'carzuriSettings', array(
		'root'    => esc_url_raw( rest_url() ),
		'nonce'   => wp_create_nonce( 'wp_rest' ),
		'user_id' => get_current_user_id(),
	) );
}

/**
 * Enqueue back-end admin assets.
 */
function carzuri_core_enqueue_admin_assets() {
	wp_enqueue_style( 'carzuri-design-system', CARZURI_CORE_URL . 'assets/css/carzuri-design-system.css', array(), CARZURI_CORE_VERSION );
}

// Register a minimal test shortcode for visual validation of plumbing.
add_shortcode( 'carzuri_core_test', 'carzuri_core_test_shortcode' );

/**
 * Render test info and list vehicles in the design system style.
 */
function carzuri_core_test_shortcode() {
	ob_start();

	// Check for existing vehicles
	$query = new WP_Query( array(
		'post_type'      => 'vehicle',
		'post_status'    => 'publish',
		'posts_per_page' => 3,
	) );

	?>
	<div class="carzuri-test-container" style="font-family: var(--carzuri-font-body); color: var(--carzuri-white);">
		<div class="carzuri-card" style="margin-bottom: 24px; border-left: 4px solid var(--carzuri-gold);">
			<h3 style="font-family: var(--carzuri-font-heading); margin-top: 0; color: var(--carzuri-gold); font-size: 20px;">
				Carzuri Core Plumbing Test
			</h3>
			<p>The Carzuri Core foundation is <strong>Active</strong>. All tables, taxonomies, and user roles are registered successfully.</p>
			
			<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin: 20px 0; font-size: 13px;">
				<div>
					<h4 style="color: var(--carzuri-gold); margin: 0 0 8px 0;">Custom Tables</h4>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">_carzuri_favorites</code>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">_carzuri_saved_searches</code>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">_carzuri_inquiries</code>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">_carzuri_valuations</code>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">_carzuri_finance_applications</code>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">_carzuri_notifications</code>
				</div>
				<div>
					<h4 style="color: var(--carzuri-gold); margin: 0 0 8px 0;">Taxonomies</h4>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">vehicle_make</code>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">vehicle_model</code>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">vehicle_body_type</code>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">vehicle_location</code>
				</div>
				<div>
					<h4 style="color: var(--carzuri-gold); margin: 0 0 8px 0;">User Roles</h4>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">carzuri_buyer</code>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">carzuri_dealer</code>
					<code style="background: var(--carzuri-navy-dark); padding: 4px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">carzuri_admin</code>
				</div>
			</div>
		</div>

		<?php if ( $query->have_posts() ) : ?>
			<h4 style="font-family: var(--carzuri-font-heading); color: var(--carzuri-gold); margin-bottom: 12px;">Wired Vehicle Listings</h4>
			<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px;">
				<?php while ( $query->have_posts() ) : $query->the_post(); 
					$data = carzuri_get_vehicle_data( get_the_ID() );
				?>
					<div class="carzuri-card">
						<?php if ( $data['featured'] ) : ?>
							<span class="carzuri-badge-featured" style="margin-bottom: 12px;">Featured</span>
						<?php endif; ?>
						<h3 style="font-family: var(--carzuri-font-heading); margin: 0 0 8px 0; font-size: 18px;"><?php the_title(); ?></h3>
						<p style="color: var(--carzuri-gray-text); font-size: 14px; margin-bottom: 16px;">
							<?php echo esc_html( $data['condition'] ) . ' | ' . esc_html( $data['year'] ) . ' | ' . esc_html( $data['mileage'] ) . ' km'; ?>
						</p>
						<p style="font-size: 20px; font-weight: 700; color: var(--carzuri-gold); margin-bottom: 16px;">
							<?php echo esc_html( carzuri_format_price( $data['price'] ) ); ?>
						</p>
						<a href="<?php the_permalink(); ?>" class="carzuri-btn-primary" style="width: 100%;">View Plumbing Data</a>
					</div>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		<?php else : ?>
			<div class="carzuri-card" style="text-align: center; padding: 40px 20px;">
				<p style="color: var(--carzuri-gray-text); margin-bottom: 16px;">No vehicles found in stock yet. Use WordPress Admin editor to add some!</p>
				<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=vehicle' ) ); ?>" class="carzuri-btn-primary">Add First Vehicle</a>
			</div>
		<?php endif; ?>
	</div>
	<?php

	return ob_get_clean();
}

// Fire up the engine!
run_carzuri_core();
