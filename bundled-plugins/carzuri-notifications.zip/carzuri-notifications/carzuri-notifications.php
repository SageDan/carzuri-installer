<?php
/**
 * Plugin Name: Carzuri Notifications
 * Plugin URI: https://carzuri.com/plugins/notifications
 * Description: Bell-icon notification UI and mark-as-read REST handler for the Carzuri suite.
 * Version: 1.0.0
 * Author: Carzuri Marketplace Team
 * Author URI: https://carzuri.com
 * License: GPL-2.0+
 * Text Domain: carzuri-notifications
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('CARZURI_NOTIFICATIONS_VERSION', '1.0.0');
define('CARZURI_NOTIFICATIONS_PATH', plugin_dir_path(__FILE__));
define('CARZURI_NOTIFICATIONS_URL', plugin_dir_url(__FILE__));

/**
 * Enqueue front-end notification scripts and styles.
 */
function carzuri_notifications_enqueue_assets() {
    // Only enqueue for logged-in users
    if (!is_user_logged_in()) {
        return;
    }

    // Enqueue Core Design System if registered by Core plugin
    if (wp_style_is('carzuri-design-system', 'registered')) {
        wp_enqueue_style('carzuri-design-system');
    }

    // Enqueue Notification Plugin CSS using design system tokens
    wp_enqueue_style(
        'carzuri-notifications-style',
        CARZURI_NOTIFICATIONS_URL . 'assets/css/notifications.css',
        array(),
        CARZURI_NOTIFICATIONS_VERSION
    );

    // Enqueue Notification Plugin Vanilla JS
    wp_enqueue_script(
        'carzuri-notifications-script',
        CARZURI_NOTIFICATIONS_URL . 'assets/js/notifications.js',
        array('jquery'),
        CARZURI_NOTIFICATIONS_VERSION,
        true
    );

    // Localize REST API parameters safely
    wp_localize_script('carzuri-notifications-script', 'carzuriNotificationsData', array(
        'restUrl'     => esc_url_raw(rest_url('carzuri/v1/notifications')),
        'markReadUrl' => esc_url_raw(rest_url('carzuri/v1/notifications/mark-read')),
        'nonce'       => wp_create_nonce('wp_rest'),
        'isLoggedIn'  => is_user_logged_in(),
        'userId'      => get_current_user_id(),
        'pollInterval'=> 30000,
        'i18n'        => array(
            'title'          => __('Notifications', 'carzuri-notifications'),
            'markAllRead'    => __('Mark all read', 'carzuri-notifications'),
            'noNotifications'=> __('No notifications yet', 'carzuri-notifications'),
            'justNow'        => __('Just now', 'carzuri-notifications'),
            'viewLink'       => __('View details', 'carzuri-notifications'),
            'errorLoading'   => __('Unable to load notifications', 'carzuri-notifications'),
        )
    ));
}
add_action('wp_enqueue_scripts', 'carzuri_notifications_enqueue_assets');

/**
 * Render the bell notification container hook in site header/footer.
 * Coordinates placement without requiring manual template edits.
 */
function carzuri_notifications_render_bell_container() {
    if (!is_user_logged_in()) {
        return; // Output nothing for logged-out visitors
    }

    // Output container for JS component rendering
    echo '<div id="carzuri-notifications-root" class="carzuri-notifications-fixed-wrapper" data-user-id="' . esc_attr(get_current_user_id()) . '"></div>';
}
add_action('wp_footer', 'carzuri_notifications_render_bell_container', 20);

/**
 * Core Fallback REST API registration (guarded so it defers to Core if active).
 */
function carzuri_notifications_register_fallback_routes() {
    $routes = rest_get_server()->get_routes();
    if (isset($routes['/carzuri/v1/notifications'])) {
        return;
    }

    register_rest_route('carzuri/v1', '/notifications', array(
        'methods'             => 'GET',
        'callback'            => 'carzuri_notifications_rest_get_notifications',
        'permission_callback' => function() { return is_user_logged_in(); },
    ));

    register_rest_route('carzuri/v1', '/notifications/mark-read', array(
        'methods'             => 'POST',
        'callback'            => 'carzuri_notifications_rest_mark_read',
        'permission_callback' => function() { return is_user_logged_in(); },
    ));
}
add_action('rest_api_init', 'carzuri_notifications_register_fallback_routes', 99);

/**
 * Fallback callback: Get notifications for current logged in user.
 */
function carzuri_notifications_rest_get_notifications($request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $table_name = $wpdb->prefix . 'carzuri_notifications';

    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) !== $table_name) {
        return new WP_REST_Response(array(), 200);
    }

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT id, user_id, type, title, message, link_url, is_read, created_at 
         FROM {$table_name} 
         WHERE user_id = %d 
         ORDER BY created_at DESC 
         LIMIT 50",
        $user_id
    ), ARRAY_A);

    if (is_array($results)) {
        foreach ($results as &$row) {
            $row['id'] = (int) $row['id'];
            $row['user_id'] = (int) $row['user_id'];
            $row['is_read'] = (int) $row['is_read'];
        }
    } else {
        $results = array();
    }

    return new WP_REST_Response($results, 200);
}

/**
 * Fallback callback: Mark notifications as read.
 */
function carzuri_notifications_rest_mark_read($request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $table_name = $wpdb->prefix . 'carzuri_notifications';
    $params = $request->get_json_params();

    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) !== $table_name) {
        return new WP_REST_Response(array('success' => true, 'updated' => 0), 200);
    }

    if (!empty($params['all'])) {
        $updated = $wpdb->update(
            $table_name,
            array('is_read' => 1),
            array('user_id' => $user_id, 'is_read' => 0),
            array('%d'),
            array('%d', '%d')
        );
    } elseif (!empty($params['ids']) && is_array($params['ids'])) {
        $ids = array_map('absint', $params['ids']);
        $id_placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $query = $wpdb->prepare(
            "UPDATE {$table_name} SET is_read = 1 WHERE user_id = %d AND id IN ({$id_placeholders})",
            array_merge(array($user_id), $ids)
        );
        $updated = $wpdb->query($query);
    } else {
        return new WP_Error('invalid_params', 'Missing notification IDs or all parameter', array('status' => 400));
    }

    return new WP_REST_Response(array('success' => true, 'updated' => $updated), 200);
}
