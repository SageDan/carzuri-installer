(function ($) {
    'use strict';

    if (typeof carzuriNotificationsData === 'undefined' || !carzuriNotificationsData.isLoggedIn) {
        return;
    }

    var state = {
        notifications: [],
        unreadCount: 0,
        isOpen: false,
        isLoading: false
    };

    var $root = null;

    function init() {
        $root = $('#carzuri-notifications-root');
        if (!$root.length) {
            $root = $('<div id="carzuri-notifications-root" class="carzuri-notifications-fixed-wrapper"></div>').appendTo('body');
        }

        renderSkeleton();
        fetchNotifications();

        if (carzuriNotificationsData.pollInterval > 0) {
            setInterval(fetchNotifications, carzuriNotificationsData.pollInterval);
        }

        $(document).on('click', function (e) {
            if (state.isOpen && !$root.is(e.target) && $root.has(e.target).length === 0) {
                state.isOpen = false;
                updatePanelVisibility();
            }
        });
    }

    function renderSkeleton() {
        var html = '<div class="carzuri-notifications-container">' +
            '<button type="button" class="carzuri-bell-btn" id="carzuri-bell-trigger" aria-label="Notifications" aria-expanded="false">' +
                '<svg class="carzuri-bell-icon" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                    '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>' +
                    '<path d="M13.73 21a2 2 0 0 1-3.46 0"></path>' +
                '</svg>' +
                '<span class="carzuri-unread-badge" id="carzuri-bell-badge" style="display:none;">0</span>' +
            '</button>' +
            '<div class="carzuri-notifications-panel" id="carzuri-notifications-panel" style="display:none;" aria-hidden="true">' +
                '<div class="carzuri-panel-header">' +
                    '<h3 class="carzuri-panel-title">' + escapeHtml(carzuriNotificationsData.i18n.title) + '</h3>' +
                    '<button type="button" class="carzuri-mark-all-btn" id="carzuri-mark-all-btn">' + escapeHtml(carzuriNotificationsData.i18n.markAllRead) + '</button>' +
                '</div>' +
                '<div class="carzuri-panel-body" id="carzuri-panel-body">' +
                    '<div class="carzuri-loading-spinner"><div class="carzuri-spinner"></div></div>' +
                '</div>' +
            '</div>' +
        '</div>';

        $root.html(html);

        $('#carzuri-bell-trigger').on('click', function (e) {
            e.stopPropagation();
            state.isOpen = !state.isOpen;
            updatePanelVisibility();

            if (state.isOpen && state.unreadCount > 0) {
                markAsRead({ all: true });
            }
        });

        $('#carzuri-mark-all-btn').on('click', function (e) {
            e.stopPropagation();
            markAsRead({ all: true });
        });
    }

    function fetchNotifications() {
        $.ajax({
            url: carzuriNotificationsData.restUrl,
            method: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', carzuriNotificationsData.nonce);
            },
            success: function (response) {
    if (response && Array.isArray(response.notifications)) {
        state.notifications = response.notifications;
        calculateUnreadCount();
        renderList();
    }
},
            error: function () {
                $('#carzuri-panel-body').html('<div class="carzuri-empty-msg error">' + escapeHtml(carzuriNotificationsData.i18n.errorLoading) + '</div>');
            }
        });
    }

    function calculateUnreadCount() {
        var count = 0;
        for (var i = 0; i < state.notifications.length; i++) {
            if (!state.notifications[i].is_read) {
                count++;
            }
        }
        state.unreadCount = count;
        updateBadge();
    }

    function updateBadge() {
        var $badge = $('#carzuri-bell-badge');
        if (state.unreadCount > 0) {
            $badge.text(state.unreadCount > 99 ? '99+' : state.unreadCount).show().addClass('bounce');
            setTimeout(function() { $badge.removeClass('bounce'); }, 600);
        } else {
            $badge.hide();
        }
    }

    function updatePanelVisibility() {
        var $panel = $('#carzuri-notifications-panel');
        var $btn = $('#carzuri-bell-trigger');

        if (state.isOpen) {
            $panel.show().attr('aria-hidden', 'false');
            $btn.attr('aria-expanded', 'true').addClass('active');
            renderList();
        } else {
            $panel.hide().attr('aria-hidden', 'true');
            $btn.attr('aria-expanded', 'false').removeClass('active');
        }
    }

    function markAsRead(payload) {
        $.ajax({
            url: carzuriNotificationsData.markReadUrl,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(payload),
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', carzuriNotificationsData.nonce);
            },
            success: function () {
                if (payload.all) {
                    for (var i = 0; i < state.notifications.length; i++) {
                        state.notifications[i].is_read = 1;
                    }
                } else if (payload.ids && Array.isArray(payload.ids)) {
                    for (var j = 0; j < state.notifications.length; j++) {
                        if (payload.ids.indexOf(state.notifications[j].id) !== -1) {
                            state.notifications[j].is_read = 1;
                        }
                    }
                }
                calculateUnreadCount();
                renderList();
            }
        });
    }

    function renderList() {
        var $body = $('#carzuri-panel-body');

        if (!state.notifications.length) {
            $body.html('<div class="carzuri-empty-state">' +
                '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="1.5"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>' +
                '<p class="carzuri-empty-msg">' + escapeHtml(carzuriNotificationsData.i18n.noNotifications) + '</p>' +
            '</div>');
            return;
        }

        var html = '<ul class="carzuri-notifications-list">';
        for (var i = 0; i < state.notifications.length; i++) {
            var item = state.notifications[i];
            var isUnread = !item.is_read;
            var timeAgo = formatRelativeTime(item.created_at);
            var itemClass = 'carzuri-notification-item' + (isUnread ? ' unread' : '');

            html += '<li class="' + itemClass + '" data-id="' + item.id + '" data-link="' + escapeHtml(item.link_url || '') + '">';
            html += '<div class="carzuri-notif-content">';
            html += '<div class="carzuri-notif-title">' + escapeHtml(item.title) + '</div>';
            html += '<div class="carzuri-notif-message">' + escapeHtml(item.message) + '</div>';
            html += '<div class="carzuri-notif-meta">';
            html += '<span class="carzuri-notif-time">' + escapeHtml(timeAgo) + '</span>';
            if (item.link_url) {
                html += '<span class="carzuri-notif-link-indicator">' + escapeHtml(carzuriNotificationsData.i18n.viewLink) + ' &rarr;</span>';
            }
            html += '</div></div>';
            if (isUnread) {
                html += '<span class="carzuri-unread-dot"></span>';
            }
            html += '</li>';
        }
        html += '</ul>';

        $body.html(html);

        $body.find('.carzuri-notification-item').on('click', function () {
            var id = $(this).data('id');
            var link = $(this).data('link');

            markAsRead({ ids: [id] });

            if (link) {
                window.location.href = link;
            }
        });
    }

    function formatRelativeTime(dateStr) {
        if (!dateStr) return '';
        var date = new Date(dateStr.replace(/-/g, '/'));
        if (isNaN(date.getTime())) {
            date = new Date(dateStr);
        }
        var now = new Date();
        var diffSec = Math.floor((now - date) / 1000);

        if (diffSec < 60) return carzuriNotificationsData.i18n.justNow;
        var diffMin = Math.floor(diffSec / 60);
        if (diffMin < 60) return diffMin + 'm ago';
        var diffHr = Math.floor(diffMin / 60);
        if (diffHr < 24) return diffHr + 'h ago';
        var diffDays = Math.floor(diffHr / 24);
        if (diffDays < 7) return diffDays + 'd ago';
        return date.toLocaleDateString();
    }

    function escapeHtml(text) {
        if (!text) return '';
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    $(document).ready(init);

})(jQuery);