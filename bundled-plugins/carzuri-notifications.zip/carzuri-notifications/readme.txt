=== Carzuri Notifications ===
Contributors: carzuriteam
Tags: notifications, carzuri, marketplace, header bell, REST API
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later

Front-end header bell icon notification drawer and mark-as-read integration for the Carzuri suite.

== Description ==

Carzuri Notifications (v1.0.0) is a focused, light-weight notification consumer plugin designed as part of the Carzuri independent plugin ecosystem (alongside Core, Listings, Favorites, Dealer Marketplace, Inquiry & Lead System).

This module surfaces real-time notification alerts from Core's existing `wp_carzuri_notifications` database table via Core's REST API endpoints (`GET carzuri/v1/notifications` and `POST carzuri/v1/notifications/mark-read`).

Features:
* Header-area fixed Bell Icon UI with live unread badge counter.
* Slide-out panel listing recent alerts (newest first).
* Relative human timestamp calculation ("Just now", "10m ago", "2h ago").
* Click-to-link support for leads, favorited price drops, and inquiries.
* Immediate client-side badge update upon mark-as-read REST call.
* Strict logged-in check: only renders for logged-in users, zero footprint for visitors.
* Enforces Core's `carzuri-design-system` CSS variable tokens.

== Installation ==

1. Upload `carzuri-notifications` directory to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Ensure Carzuri Core is active (or standalone fallback will activate automatically).
4. Log in as a registered user on the front-end to view the notification bell in the site header.

== REST API Endpoints Used ==

* GET /wp-json/carzuri/v1/notifications
  Retrieves array of notification objects for current user.

* POST /wp-json/carzuri/v1/notifications/mark-read
  Accepts `{ "ids": [1, 2] }` or `{ "all": true }` to set `is_read = 1`.

== Database Table Schema (Core Managed) ==

Table: `wp_carzuri_notifications`
* id (BIGINT 20)
* user_id (BIGINT 20)
* type (VARCHAR 50)
* title (VARCHAR 255)
* message (TEXT)
* link_url (VARCHAR 255)
* is_read (TINYINT 1)
* created_at (DATETIME)

== Changelog ==

= 1.0.0 =
* Initial release of Carzuri Notifications.
