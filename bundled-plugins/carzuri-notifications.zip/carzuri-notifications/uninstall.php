<?php
/**
 * Fired when the Carzuri Notifications plugin is uninstalled.
 *
 * @package Carzuri_Notifications
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Note: As specified in module requirements, this plugin is read-only
// and does not own or drop the shared Core wp_carzuri_notifications table.
// Clean up any transient options if created in future versions.
delete_option('carzuri_notifications_version');
