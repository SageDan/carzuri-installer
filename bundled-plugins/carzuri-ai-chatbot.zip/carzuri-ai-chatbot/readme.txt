=== Carzuri AI Chatbot ===
Contributors: carzuri
Tags: automotive, marketplace, chatbot, gemini-ai, kenya, car-sales, rest-api
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
License: GPLv2 or later

AI-powered buyer assistant and vehicle finder plugin for the Carzuri Automotive Marketplace.

== Description ==

Carzuri AI Chatbot connects buyers on your Carzuri automotive marketplace with live vehicle inventory using Google Gemini AI.

Features:
* Floating, fixed-position chat widget injected site-wide via `wp_footer`.
* Real-time vehicle inventory matching using `GET carzuri/v1/vehicles`.
* KSh currency support (Kenyan Shillings formatted).
* Automatic buyer inquiry intent detection with instant "Contact This Dealer" inline form calling `POST carzuri/v1/inquiries`.
* Reads existing `carzuri_gemini_api_key` option without needing extra configuration.
* Protected against Astra theme CSS overrides (SVG icons & input paddings).
* REST API route `POST carzuri/v1/chatbot/message` registered safely on `rest_api_init` hook.

== Installation ==

1. Download the `carzuri-ai-chatbot.zip` file.
2. In your WordPress admin dashboard, navigate to **Plugins > Add New > Upload Plugin**.
3. Choose `carzuri-ai-chatbot.zip` and click **Install Now**.
4. Click **Activate Plugin**.
5. Ensure your site option `carzuri_gemini_api_key` is set with a valid Google Gemini API key.
