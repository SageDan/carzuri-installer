<?php
/**
 * Gemini AI Integration & Inventory Grounding Service
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Gemini {

	/**
	 * Query Gemini API with site inventory context & buyer message
	 *
	 * @param string $user_message
	 * @param array $history
	 * @return array
	 */
	public static function query_chatbot( $user_message, $history = array() ) {
		// Read site option carzuri_gemini_api_key
		$api_key = get_option( 'carzuri_gemini_api_key' );

		if ( empty( $api_key ) ) {
			return array(
				'reply'            => 'Chat assistant is temporarily unavailable. Please try again shortly or contact Carzuri support.',
				'suggested_action' => null,
			);
		}

		// Fetch current real inventory context internally from carzuri/v1/vehicles
		$inventory_context = self::get_inventory_context();

		// Construct prompt for Gemini
		$system_instructions = "You are the official Carzuri AI Chatbot and Buyer Assistant for Carzuri (carzuri.com), Kenya's premier online car marketplace.

STRICT MANDATES:
1. CURRENCY: ALL vehicle prices MUST be formatted in Kenyan Shillings as 'KSh' followed by comma-formatted numbers (e.g. 'KSh 2,450,000' or 'KSh 5,850,000'). NEVER use '$' or 'USD'.
2. INVENTORY GROUNDING: ONLY recommend vehicles listed in the CURRENT CARZURI INVENTORY context below. Never invent vehicle listings, prices, or specs that are not in this data.
3. INQUIRY INTENT DETECTION:
   If the buyer asks to buy, inquire, contact dealer, test drive, or shows strong interest in a specific listing, return a JSON response containing:
   - 'reply': Friendly explanation text in Markdown.
   - 'suggested_action': { 'type': 'submit_inquiry', 'vehicle_id': <number>, 'vehicle_title': '<string>', 'dealer_name': '<string>' }
   If no specific vehicle intent, set 'suggested_action': null.

CURRENT CARZURI INVENTORY:
" . $inventory_context;

		// Build API Endpoint URL (Gemini 3.6 Flash model)
		$endpoint_url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=' . esc_attr( $api_key );

		// Prepare conversation contents array
		$contents = array();

		// Add system instruction as initial turn or context
		$contents[] = array(
			'role'  => 'user',
			'parts' => array( array( 'text' => $system_instructions ) ),
		);
		$contents[] = array(
			'role'  => 'model',
			'parts' => array( array( 'text' => 'Understood. I am ready to assist Carzuri buyers using real inventory and KSh pricing.' ) ),
		);

		// Append rolling conversation history
		if ( ! empty( $history ) && is_array( $history ) ) {
			foreach ( $history as $turn ) {
				$role = ( isset( $turn['sender'] ) && $turn['sender'] === 'user' ) ? 'user' : 'model';
				$text = isset( $turn['text'] ) ? sanitize_text_field( $turn['text'] ) : '';
				if ( ! empty( $text ) ) {
					$contents[] = array(
						'role'  => $role,
						'parts' => array( array( 'text' => $text ) ),
					);
				}
			}
		}

		// Append current user message
		$contents[] = array(
			'role'  => 'user',
			'parts' => array( array( 'text' => $user_message ) ),
		);

		$request_body = array(
			'contents'         => $contents,
			'generationConfig' => array(
				'responseMimeType' => 'application/json',
				'temperature'      => 0.2,
			),
		);

		// Execute HTTP POST to Gemini API
		$response = wp_remote_post(
			$endpoint_url,
			array(
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( $request_body ),
				'timeout' => 20,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'reply'            => 'Unable to connect to assistant service at the moment. Please try again in a few seconds.',
				'suggested_action' => null,
			);
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! empty( $data['candidates'][0]['content']['parts'][0]['text'] ) ) {
			$raw_text = $data['candidates'][0]['content']['parts'][0]['text'];
			$parsed   = json_decode( $raw_text, true );

			if ( is_array( $parsed ) && isset( $parsed['reply'] ) ) {
				return array(
					'reply'            => $parsed['reply'],
					'suggested_action' => isset( $parsed['suggested_action'] ) ? $parsed['suggested_action'] : null,
				);
			}

			return array(
				'reply'            => $raw_text,
				'suggested_action' => null,
			);
		}

		return array(
			'reply'            => 'Thank you for reaching out! Please browse our vehicle listings or contact us directly.',
			'suggested_action' => null,
		);
	}

	/**
	 * Internal helper to fetch carzuri/v1/vehicles inventory
	 *
	 * @return string
	 */
	private static function get_inventory_context() {
		// Attempt internal REST dispatch to GET carzuri/v1/vehicles
		$request  = new WP_REST_Request( 'GET', '/carzuri/v1/vehicles' );
		$response = rest_do_request( $request );

		$vehicles = array();

		if ( ! $response->is_error() ) {
			$data = $response->get_data();
			if ( is_array( $data ) && isset( $data['vehicles'] ) ) {
				$vehicles = $data['vehicles'];
			}
		}

		// Fallback if internal rest dispatch is empty
		if ( empty( $vehicles ) ) {
			$fallback_url = rest_url( 'carzuri/v1/vehicles' );
			$res          = wp_remote_get( $fallback_url, array( 'timeout' => 10 ) );
			if ( ! is_wp_error( $res ) ) {
				$body = wp_remote_retrieve_body( $res );
				$data = json_decode( $body, true );
				if ( isset( $data['vehicles'] ) ) {
					$vehicles = $data['vehicles'];
				}
			}
		}

		if ( empty( $vehicles ) ) {
			return 'No live inventory available currently.';
		}

		$lines = array();
		foreach ( $vehicles as $v ) {
			$id          = isset( $v['id'] ) ? $v['id'] : '';
			$title       = isset( $v['title'] ) ? $v['title'] : '';
			$price       = isset( $v['price_formatted'] ) ? $v['price_formatted'] : ( isset( $v['price'] ) ? 'KSh ' . number_format( $v['price'] ) : '' );
			$mileage     = isset( $v['mileage'] ) ? $v['mileage'] : '';
			$location    = isset( $v['location'] ) ? $v['location'] : '';
			$dealer      = isset( $v['dealer_name'] ) ? $v['dealer_name'] : '';
			$condition   = isset( $v['condition'] ) ? $v['condition'] : '';

			$lines[] = sprintf(
				'- Vehicle ID #%s: %s | Price: %s | Mileage: %s | Condition: %s | Location: %s | Dealer: %s',
				$id,
				$title,
				$price,
				$mileage,
				$condition,
				$location,
				$dealer
			);
		}

		return implode( "
", $lines );
	}
}
