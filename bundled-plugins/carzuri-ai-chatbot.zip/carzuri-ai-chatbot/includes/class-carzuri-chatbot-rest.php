<?php
/**
 * REST API Route Handler for Carzuri Chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Chatbot_REST {

	/**
	 * Register rest routes under carzuri/v1 REST namespace.
	 * Triggered on rest_api_init.
	 */
	public static function register_routes() {
		register_rest_route(
			'carzuri/v1',
			'/chatbot/message',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_chat_message' ),
				'permission_callback' => '__return_true', // Available for guests & buyers site-wide
			)
		);
	}

	/**
	 * Callback handler for POST carzuri/v1/chatbot/message
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public static function handle_chat_message( $request ) {
		$params  = $request->get_json_params();
		$message = isset( $params['message'] ) ? sanitize_text_field( $params['message'] ) : '';
		$history = isset( $params['history'] ) && is_array( $params['history'] ) ? $params['history'] : array();

		if ( empty( trim( $message ) ) ) {
			return new WP_REST_Response(
				array(
					'reply'            => 'Please provide a valid question or car search query.',
					'suggested_action' => null,
				),
				400
			);
		}

		// Delegate request to Gemini API service with inventory context
		$response = Carzuri_Gemini::query_chatbot( $message, $history );

		return new WP_REST_Response( $response, 200 );
	}
}
