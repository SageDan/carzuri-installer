<?php
/**
 * Plugin Name:       Carzuri AI Chatbot
 * Plugin URI:        https://carzuri.com/plugins/ai-chatbot
 * Description:       Official AI Buyer Assistant & Vehicle Finder for Carzuri Marketplace. Powered by Google Gemini AI with real-time KSh inventory matching and instant dealer inquiry integration.
 * Version:           1.0.2
 * Author:            Carzuri Engineering
 * Author URI:        https://carzuri.com
 * Text Domain:       carzuri-ai-chatbot
 * Domain Path:       /languages
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CARZURI_CHATBOT_VERSION', '1.0.2' );
define( 'CARZURI_CHATBOT_PATH', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_CHATBOT_URL', plugin_dir_url( __FILE__ ) );

// Include core plugin classes.
require_once CARZURI_CHATBOT_PATH . 'includes/class-carzuri-chatbot-rest.php';
require_once CARZURI_CHATBOT_PATH . 'includes/class-carzuri-gemini.php';

/**
 * Register REST API routes.
 * CRITICAL RULE: MUST be hooked into rest_api_init to prevent conflicts with Elementor or theme init.
 */
add_action( 'rest_api_init', array( 'Carzuri_Chatbot_REST', 'register_routes' ) );

/**
 * Enqueue front-end scripts and styles.
 */
function carzuri_chatbot_enqueue_assets() {
	// Enqueue CSS with high priority to override theme defaults
	wp_enqueue_style(
		'carzuri-chatbot-style',
		CARZURI_CHATBOT_URL . 'assets/css/carzuri-chatbot.css',
		array(),
		CARZURI_CHATBOT_VERSION
	);

	// Enqueue JS
	wp_enqueue_script(
		'carzuri-chatbot-script',
		CARZURI_CHATBOT_URL . 'assets/js/carzuri-chatbot.js',
		array(),
		CARZURI_CHATBOT_VERSION,
		true
	);

	// Localize script with site REST URL and nonce
	wp_localize_script(
		'carzuri-chatbot-script',
		'carzuriChatbotVars',
		array(
			'restUrl'     => esc_url_raw( rest_url( 'carzuri/v1/' ) ),
			'nonce'       => wp_create_nonce( 'wp_rest' ),
			'siteName'    => get_bloginfo( 'name' ),
			'currency'    => 'KSh',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'carzuri_chatbot_enqueue_assets' );

/**
 * Render the site-wide floating chatbot widget in footer.
 */
function carzuri_render_chatbot_widget() {
	?>
	<div id="carzuri-chatbot-widget-root" class="carzuri-chatbot-container">
		<!-- Floating Launcher Button -->
		<button id="carzuri-chat-trigger" class="carzuri-chat-trigger-btn" aria-label="Open Carzuri AI Buyer Assistant">
			<span class="carzuri-trigger-icon">
				<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="carzuri-icon-svg"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/><path d="M8 12h.01"/><path d="M12 12h.01"/><path d="M16 12h.01"/></svg>
			</span>
			<span class="carzuri-trigger-label">Carzuri AI Assistant</span>
			<span class="carzuri-unread-dot"></span>
		</button>

		<!-- Expanded Chat Panel -->
		<div id="carzuri-chat-panel" class="carzuri-chat-panel-box carzuri-hidden" role="dialog" aria-labelledby="carzuri-chat-title">
			<div class="carzuri-chat-header">
				<div class="carzuri-chat-header-info">
					<div class="carzuri-avatar-circle">
						<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="carzuri-icon-svg"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 12 10s-6.7.6-8.5 1.1C2.7 11.3 2 12.1 2 13v3c0 .6.4 1 1 1h2"/><path d="M5 17a2 2 0 1 0 4 0 2 2 0 0 0-4 0z"/><path d="M15 17a2 2 0 1 0 4 0 2 2 0 0 0-4 0z"/><path d="M12 10V5"/><path d="M10 5h4"/></svg>
					</div>
					<div>
						<h3 id="carzuri-chat-title" class="carzuri-chat-title">Carzuri Buyer Assistant</h3>
						<p class="carzuri-chat-subtitle"><span class="carzuri-online-indicator"></span> Live Inventory</p>
					</div>
				</div>
				<button id="carzuri-chat-close" class="carzuri-chat-close-btn" aria-label="Close Chat">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="carzuri-icon-svg"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
				</button>
			</div>

			<div id="carzuri-chat-messages" class="carzuri-chat-body">
				<div class="carzuri-chat-msg carzuri-msg-bot">
					<div class="carzuri-msg-content">
						<p>Jambo! 👋 I'm your <strong>Carzuri Buyer Assistant</strong>.</p>
						<p>How can I help you find your dream car today in Kenya? Ask me about our live inventory, prices (KSh), specs, fuel efficiency, or dealer locations!</p>
						<div class="carzuri-quick-prompts">
							<button class="carzuri-prompt-btn" data-prompt="What SUVs do you have under KSh 3,000,000?">SUVs under KSh 3M</button>
							<button class="carzuri-prompt-btn" data-prompt="Tell me about the Subaru Forester EyeSight">Subaru Forester Specs</button>
							<button class="carzuri-prompt-btn" data-prompt="Show me Toyota Land Cruiser Prado listings">Toyota Prado</button>
						</div>
					</div>
				</div>
			</div>

			<div class="carzuri-chat-footer">
				<form id="carzuri-chat-form" class="carzuri-chat-input-row">
					<input type="text" id="carzuri-chat-input" class="carzuri-chat-field" placeholder="Ask about cars, prices (KSh), specs..." autocomplete="off" required />
					<button type="submit" id="carzuri-chat-send" class="carzuri-chat-send-btn" aria-label="Send Message">
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="carzuri-icon-svg"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
					</button>
				</form>
				<div class="carzuri-footer-tag">Official Carzuri Automotive Marketplace • All prices in KSh</div>
			</div>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'carzuri_render_chatbot_widget' );
