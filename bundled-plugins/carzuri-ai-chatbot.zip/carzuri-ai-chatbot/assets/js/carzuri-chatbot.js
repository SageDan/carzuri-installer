/**
 * Carzuri AI Chatbot - Front-End Logic
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const triggerBtn = document.getElementById('carzuri-chat-trigger');
    const panel = document.getElementById('carzuri-chat-panel');
    const closeBtn = document.getElementById('carzuri-chat-close');
    const chatForm = document.getElementById('carzuri-chat-form');
    const chatInput = document.getElementById('carzuri-chat-input');
    const messagesContainer = document.getElementById('carzuri-chat-messages');

    // In-memory conversation history for this session
    let chatHistory = [];

    if (!triggerBtn || !panel) return;

    // Toggle Chat Panel
    triggerBtn.addEventListener('click', function () {
      panel.classList.toggle('carzuri-hidden');
      if (!panel.classList.contains('carzuri-hidden')) {
        chatInput.focus();
        scrollToBottom();
      }
    });

    if (closeBtn) {
      closeBtn.addEventListener('click', function () {
        panel.classList.add('carzuri-hidden');
      });
    }

    // Quick prompt chip click handler
    document.addEventListener('click', function (e) {
      if (e.target && e.target.classList.contains('carzuri-prompt-btn')) {
        const promptText = e.target.getAttribute('data-prompt');
        if (promptText) {
          chatInput.value = promptText;
          sendMessage(promptText);
        }
      }
    });

    // Form Submit Handler
    if (chatForm) {
      chatForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const userMsg = chatInput.value.trim();
        if (!userMsg) return;
        sendMessage(userMsg);
      });
    }

    // Send Message Function
    function sendMessage(messageText) {
      // 1. Render User Message
      renderUserMessage(messageText);
      chatInput.value = '';

      // 2. Add to history
      chatHistory.push({ sender: 'user', text: messageText });

      // 3. Show Typing Indicator
      const typingEl = renderTypingIndicator();
      scrollToBottom();

      // Get REST URL from localized vars or fallback
      const restBase = (typeof carzuriChatbotVars !== 'undefined' && carzuriChatbotVars.restUrl)
        ? carzuriChatbotVars.restUrl
        : '/carzuri/v1/';

      const endpoint = restBase + 'chatbot/message';

      // 4. Fetch from REST API
      fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': (typeof carzuriChatbotVars !== 'undefined' ? carzuriChatbotVars.nonce : '')
        },
        body: JSON.stringify({
          message: messageText,
          history: chatHistory.slice(-6) // Rolling window of 6 turns
        })
      })
        .then(function (res) {
          return res.json();
        })
        .then(function (data) {
          removeTypingIndicator(typingEl);

          const reply = data.reply || "Thank you for asking! Please explore our car listings.";
          renderBotMessage(reply, data.suggested_action);

          chatHistory.push({ sender: 'bot', text: reply });
          scrollToBottom();
        })
        .catch(function (err) {
          console.error('Carzuri Chatbot REST Error:', err);
          removeTypingIndicator(typingEl);
          renderBotMessage("Sorry, I am having trouble connecting to Carzuri inventory right now. Please try again shortly.");
          scrollToBottom();
        });
    }

    function renderUserMessage(text) {
      const msgDiv = document.createElement('div');
      msgDiv.className = 'carzuri-chat-msg carzuri-msg-user';
      msgDiv.innerHTML = '<div class="carzuri-msg-content"><p>' + escapeHtml(text) + '</p></div>';
      messagesContainer.appendChild(msgDiv);
    }

    function renderBotMessage(text, suggestedAction) {
      const msgDiv = document.createElement('div');
      msgDiv.className = 'carzuri-chat-msg carzuri-msg-bot';

      let formattedText = escapeHtml(text)
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n/g, '<br/>');

      let actionHtml = '';
      if (suggestedAction && suggestedAction.type === 'submit_inquiry' && suggestedAction.vehicle_id) {
        actionHtml = `
          <div class="carzuri-action-box">
            <button class="carzuri-dealer-contact-btn" data-v-id="${suggestedAction.vehicle_id}" data-v-title="${escapeHtml(suggestedAction.vehicle_title || 'this vehicle')}">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="carzuri-icon-svg"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
              Contact Dealer for ${escapeHtml(suggestedAction.vehicle_title || 'Vehicle')}
            </button>
            <div class="carzuri-inquiry-slot"></div>
          </div>
        `;
      }

      msgDiv.innerHTML = '<div class="carzuri-msg-content">' + formattedText + actionHtml + '</div>';
      messagesContainer.appendChild(msgDiv);

      // Attach listener for inquiry button if rendered
      const dealerBtn = msgDiv.querySelector('.carzuri-dealer-contact-btn');
      if (dealerBtn) {
        dealerBtn.addEventListener('click', function () {
          const vId = dealerBtn.getAttribute('data-v-id');
          const vTitle = dealerBtn.getAttribute('data-v-title');
          const slot = msgDiv.querySelector('.carzuri-inquiry-slot');
          if (slot) {
            renderInlineInquiryForm(slot, vId, vTitle);
          }
        });
      }
    }

    function renderInlineInquiryForm(container, vehicleId, vehicleTitle) {
      container.innerHTML = `
        <div class="carzuri-inquiry-form-card">
          <h4>Submit Inquiry for ${vehicleTitle}</h4>
          <form class="carzuri-inline-inquiry-form">
            <div class="carzuri-form-group">
              <input type="text" class="carzuri-field-input inq-name" placeholder="Your Full Name" required />
            </div>
            <div class="carzuri-form-group">
              <input type="email" class="carzuri-field-input inq-email" placeholder="Email Address" required />
            </div>
            <div class="carzuri-form-group">
              <input type="tel" class="carzuri-field-input inq-phone" placeholder="Phone (e.g. 0712345678)" required />
            </div>
            <div class="carzuri-form-group">
              <input type="text" class="carzuri-field-input inq-msg" placeholder="Optional message for dealer" value="I am interested in ${vehicleTitle}. Please call me." />
            </div>
            <button type="submit" class="carzuri-submit-inquiry-btn">Send Inquiry to Dealer</button>
          </form>
          <div class="carzuri-inq-status" style="margin-top:6px; font-size:11px;"></div>
        </div>
      `;

      const form = container.querySelector('.carzuri-inline-inquiry-form');
      const statusDiv = container.querySelector('.carzuri-inq-status');

      form.addEventListener('submit', function (e) {
        e.preventDefault();
        const name = container.querySelector('.inq-name').value;
        const email = container.querySelector('.inq-email').value;
        const phone = container.querySelector('.inq-phone').value;
        const msg = container.querySelector('.inq-msg').value;

        statusDiv.innerHTML = '<span style="color:#D97706;">Submitting inquiry...</span>';

        const restBase = (typeof carzuriChatbotVars !== 'undefined' && carzuriChatbotVars.restUrl)
          ? carzuriChatbotVars.restUrl
          : '/carzuri/v1/';

        fetch(restBase + 'inquiries', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            vehicle_id: Number(vehicleId),
            buyer_name: name,
            buyer_email: email,
            buyer_phone: phone,
            message: msg
          })
        })
          .then(res => res.json())
          .then(data => {
            if (data.success) {
              container.innerHTML = `<div style="padding:10px; background:#D1FAE5; color:#065F46; border-radius:6px; font-size:12px; margin-top:8px;">✅ ${data.message}</div>`;
            } else {
              statusDiv.innerHTML = `<span style="color:#DC2626;">${data.message || 'Error submitting inquiry.'}</span>`;
            }
          })
          .catch(err => {
            statusDiv.innerHTML = '<span style="color:#DC2626;">Error submitting inquiry. Please try again.</span>';
          });
      });
    }

    function renderTypingIndicator() {
      const msgDiv = document.createElement('div');
      msgDiv.className = 'carzuri-chat-msg carzuri-msg-bot carzuri-typing-msg';
      msgDiv.innerHTML = '<div class="carzuri-msg-content" style="color:#64748B; font-style:italic;">Carzuri AI Assistant is searching live inventory...</div>';
      messagesContainer.appendChild(msgDiv);
      return msgDiv;
    }

    function removeTypingIndicator(el) {
      if (el && el.parentNode) {
        el.parentNode.removeChild(el);
      }
    }

    function scrollToBottom() {
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    function escapeHtml(str) {
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }
  });
})();
