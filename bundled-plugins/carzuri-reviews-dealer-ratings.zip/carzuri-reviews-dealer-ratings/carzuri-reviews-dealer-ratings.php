<?php
/**
 * Plugin Name: Carzuri Reviews & Dealer Ratings
 * Plugin URI:  https://carzuri.com
 * Description: Custom automotive marketplace review and dealer rating system tied to verified buyer inquiries.
 * Version:     1.0.1
 * Author:      Carzuri Engineering
 * Author URI:  https://carzuri.com
 * Text Domain: carzuri-reviews
 * Domain Path: /languages
 * License:     GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('CARZURI_REVIEWS_VERSION', '1.0.1');
define('CARZURI_REVIEWS_PATH', plugin_dir_path(__FILE__));
define('CARZURI_REVIEWS_URL', plugin_dir_url(__FILE__));

class Carzuri_Reviews_Plugin {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        
        // CRITICAL REQUIREMENT: Must register REST routes strictly on 'rest_api_init'
        // Registering on earlier hooks causes fatal site initialization errors with Elementor.
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        
        add_shortcode('carzuri_vehicle_reviews', array($this, 'render_vehicle_reviews_shortcode'));
        add_shortcode('carzuri_dealer_reviews', array($this, 'render_dealer_reviews_shortcode'));
    }

    /**
     * Register scripts and styles safely.
     */
    public function register_assets() {
        wp_register_style(
            'carzuri-reviews-style',
            CARZURI_REVIEWS_URL . 'assets/css/carzuri-reviews.css',
            array('carzuri-design-system'),
            CARZURI_REVIEWS_VERSION
        );

        wp_register_script(
            'carzuri-reviews-script',
            CARZURI_REVIEWS_URL . 'assets/js/carzuri-reviews.js',
            array('jquery'),
            CARZURI_REVIEWS_VERSION,
            true
        );
    }

    /**
     * Register REST API routes under 'carzuri/v1/' namespace.
     * Always attached to 'rest_api_init'.
     */
    public function register_rest_routes() {
        $namespace = 'carzuri/v1';

        // 1. POST carzuri/v1/reviews
        register_rest_route($namespace, '/reviews', array(
            'methods'  => 'POST',
            'callback' => array($this, 'handle_submit_review'),
            'permission_callback' => array($this, 'check_user_logged_in'),
            'args'     => array(
                'vehicle_id' => array(
                    'required'          => true,
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function($param) {
                        return is_numeric($param) && $param > 0;
                    }
                ),
                'rating' => array(
                    'required'          => true,
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function($param) {
                        return is_numeric($param) && $param >= 1 && $param <= 5;
                    }
                ),
                'review_text' => array(
                    'required'          => false,
                    'sanitize_callback' => 'sanitize_textarea_field',
                    'default'           => ''
                ),
            )
        ));

        // 2. GET carzuri/v1/reviews/vehicle/{vehicle_id}
        register_rest_route($namespace, '/reviews/vehicle/(?P<vehicle_id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_vehicle_reviews'),
            'permission_callback' => '__return_true',
            'args'                 => array(
                'vehicle_id' => array(
                    'sanitize_callback' => 'absint',
                ),
            )
        ));

        // 3. GET carzuri/v1/reviews/dealer/{dealer_id}
        register_rest_route($namespace, '/reviews/dealer/(?P<dealer_id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_dealer_reviews'),
            'permission_callback' => '__return_true',
            'args'                 => array(
                'dealer_id' => array(
                    'sanitize_callback' => 'absint',
                ),
                'page' => array(
                    'sanitize_callback' => 'absint',
                    'default'           => 1,
                ),
                'per_page' => array(
                    'sanitize_callback' => 'absint',
                    'default'           => 10,
                )
            )
        ));

        // 4. GET carzuri/v1/reviews/eligibility/{vehicle_id}
        register_rest_route($namespace, '/reviews/eligibility/(?P<vehicle_id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_review_eligibility'),
            'permission_callback' => array($this, 'check_user_logged_in'),
            'args'                 => array(
                'vehicle_id' => array(
                    'sanitize_callback' => 'absint',
                ),
            )
        ));
    }

    /**
     * Permission callback: Verify user is logged in.
     */
    public function check_user_logged_in() {
        if (!is_user_logged_in()) {
            return new WP_Error(
                'rest_not_logged_in',
                __('You must be logged in to submit or check review eligibility.', 'carzuri-reviews'),
                array('status' => 401)
            );
        }
        return true;
    }

    /**
     * Server-side eligibility check:
     * User is eligible ONLY IF a row exists in carzuri_inquiries where buyer_user_id == current user ID AND vehicle_id matches.
     */
    private function user_is_eligible_for_vehicle($user_id, $vehicle_id) {
        global $wpdb;
        $inquiries_table = $wpdb->prefix . 'carzuri_inquiries';

        $query = $wpdb->prepare(
            "SELECT COUNT(*) FROM {$inquiries_table} WHERE buyer_user_id = %d AND vehicle_id = %d",
            $user_id,
            $vehicle_id
        );

        $count = $wpdb->get_var($query);
        return intval($count) > 0;
    }

    /**
     * Endpoint handler: POST carzuri/v1/reviews
     */
    public function handle_submit_review($request) {
        global $wpdb;

        $user_id = get_current_user_id();
        $vehicle_id = absint($request->get_param('vehicle_id'));
        $rating = absint($request->get_param('rating'));
        $review_text = sanitize_textarea_field($request->get_param('review_text'));

        // 1. Verify vehicle post exists
        $vehicle_post = get_post($vehicle_id);
        if (!$vehicle_post || $vehicle_post->post_type !== 'vehicle') {
            return new WP_Error(
                'invalid_vehicle',
                __('The specified vehicle does not exist or is invalid.', 'carzuri-reviews'),
                array('status' => 404)
            );
        }

        // 2. Server-side eligibility check against carzuri_inquiries table
        if (!$this->user_is_eligible_for_vehicle($user_id, $vehicle_id)) {
            return new WP_Error(
                'not_eligible',
                __('Reviews are available only to buyers who have submitted an inquiry for this vehicle.', 'carzuri-reviews'),
                array('status' => 403)
            );
        }

        // 3. Fetch real dealer_id from post meta 'carzuri_dealer_id' (do NOT trust client payload)
        $dealer_id = absint(get_post_meta($vehicle_id, 'carzuri_dealer_id', true));
        if (!$dealer_id) {
            $dealer_id = absint($vehicle_post->post_author);
        }

        $reviews_table = $wpdb->prefix . 'carzuri_reviews';
        $now = current_time('mysql');

        // Check if user already submitted a review for this vehicle
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$reviews_table} WHERE user_id = %d AND vehicle_id = %d",
            $user_id,
            $vehicle_id
        ));

        if ($existing) {
            // Update existing review respecting UNIQUE KEY user_vehicle (user_id, vehicle_id)
            $updated = $wpdb->update(
                $reviews_table,
                array(
                    'rating'      => $rating,
                    'review_text' => $review_text,
                    'dealer_id'   => $dealer_id,
                    'updated_at'  => $now
                ),
                array('id' => $existing->id),
                array('%d', '%s', '%d', '%s'),
                array('%d')
            );

            if ($updated === false) {
                return new WP_Error(
                    'db_error',
                    __('Database error while updating review.', 'carzuri-reviews'),
                    array('status' => 500)
                );
            }

            return new WP_REST_Response(array(
                'success' => true,
                'message' => __('Your review has been updated successfully.', 'carzuri-reviews'),
                'action'  => 'updated',
                'review'  => array(
                    'id'          => intval($existing->id),
                    'vehicle_id'  => $vehicle_id,
                    'dealer_id'   => $dealer_id,
                    'rating'      => $rating,
                    'review_text' => $review_text,
                    'updated_at'  => $now
                )
            ), 200);

        } else {
            // Insert new review
            $inserted = $wpdb->insert(
                $reviews_table,
                array(
                    'user_id'     => $user_id,
                    'vehicle_id'  => $vehicle_id,
                    'dealer_id'   => $dealer_id,
                    'rating'      => $rating,
                    'review_text' => $review_text,
                    'created_at'  => $now,
                    'updated_at'  => $now
                ),
                array('%d', '%d', '%d', '%d', '%s', '%s', '%s')
            );

            if ($inserted === false) {
                return new WP_Error(
                    'db_error',
                    __('Database error while saving review.', 'carzuri-reviews'),
                    array('status' => 500)
                );
            }

            return new WP_REST_Response(array(
                'success' => true,
                'message' => __('Thank you! Your review has been submitted.', 'carzuri-reviews'),
                'action'  => 'created',
                'review'  => array(
                    'id'          => intval($wpdb->insert_id),
                    'vehicle_id'  => $vehicle_id,
                    'dealer_id'   => $dealer_id,
                    'rating'      => $rating,
                    'review_text' => $review_text,
                    'created_at'  => $now
                )
            ), 201);
        }
    }

    /**
     * Endpoint handler: GET carzuri/v1/reviews/vehicle/{vehicle_id}
     */
    public function get_vehicle_reviews($request) {
        global $wpdb;
        $vehicle_id = absint($request->get_param('vehicle_id'));
        $reviews_table = $wpdb->prefix . 'carzuri_reviews';

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT id, user_id, rating, review_text, created_at, updated_at 
             FROM {$reviews_table} 
             WHERE vehicle_id = %d 
             ORDER BY created_at DESC",
            $vehicle_id
        ));

        $formatted = array();
        $total_stars = 0;

        foreach ($results as $row) {
            $user_info = get_userdata($row->user_id);
            $display_name = $user_info ? $user_info->display_name : __('Verified Buyer', 'carzuri-reviews');
            $total_stars += intval($row->rating);

            // Never expose email or sensitive fields
            $formatted[] = array(
                'id'                => intval($row->id),
                'reviewer_name'     => esc_html($display_name),
                'rating'            => intval($row->rating),
                'review_text'       => esc_html($row->review_text),
                'created_at'        => $row->created_at,
                'created_formatted' => date_i18n(get_option('date_format'), strtotime($row->created_at))
            );
        }

        $total_reviews = count($formatted);
        $average_rating = $total_reviews > 0 ? round($total_stars / $total_reviews, 1) : 0.0;

        return new WP_REST_Response(array(
            'success'        => true,
            'vehicle_id'     => $vehicle_id,
            'average_rating' => $average_rating,
            'total_reviews'  => $total_reviews,
            'reviews'        => $formatted
        ), 200);
    }

    /**
     * Endpoint handler: GET carzuri/v1/reviews/dealer/{dealer_id}
     */
    public function get_dealer_reviews($request) {
        global $wpdb;
        $dealer_id = absint($request->get_param('dealer_id'));
        $page = max(1, absint($request->get_param('page')));
        $per_page = max(1, min(50, absint($request->get_param('per_page'))));
        $offset = ($page - 1) * $per_page;

        $reviews_table = $wpdb->prefix . 'carzuri_reviews';

        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT COUNT(*) as total_count, AVG(rating) as avg_rating 
             FROM {$reviews_table} 
             WHERE dealer_id = %d",
            $dealer_id
        ));

        $total_reviews = intval($stats->total_count ?? 0);
        $average_rating = $total_reviews > 0 ? round(floatval($stats->avg_rating), 1) : 0.0;

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT id, user_id, vehicle_id, rating, review_text, created_at 
             FROM {$reviews_table} 
             WHERE dealer_id = %d 
             ORDER BY created_at DESC 
             LIMIT %d OFFSET %d",
            $dealer_id,
            $per_page,
            $offset
        ));

        $formatted = array();

        foreach ($results as $row) {
            $user_info = get_userdata($row->user_id);
            $display_name = $user_info ? $user_info->display_name : __('Verified Buyer', 'carzuri-reviews');
            
            $vehicle_title = get_the_title($row->vehicle_id);
            if (!$vehicle_title) {
                $vehicle_title = sprintf(__('Vehicle #%d', 'carzuri-reviews'), $row->vehicle_id);
            }
            $vehicle_link = get_permalink($row->vehicle_id);

            $formatted[] = array(
                'id'                => intval($row->id),
                'reviewer_name'     => esc_html($display_name),
                'vehicle_id'        => intval($row->vehicle_id),
                'vehicle_title'     => esc_html($vehicle_title),
                'vehicle_permalink' => esc_url($vehicle_link),
                'rating'            => intval($row->rating),
                'review_text'       => esc_html($row->review_text),
                'created_at'        => $row->created_at,
                'created_formatted' => date_i18n(get_option('date_format'), strtotime($row->created_at))
            );
        }

        $total_pages = $total_reviews > 0 ? ceil($total_reviews / $per_page) : 1;

        return new WP_REST_Response(array(
            'success'        => true,
            'dealer_id'      => $dealer_id,
            'average_rating' => $average_rating,
            'total_reviews'  => $total_reviews,
            'page'           => $page,
            'per_page'       => $per_page,
            'total_pages'    => $total_pages,
            'reviews'        => $formatted
        ), 200);
    }

    /**
     * Endpoint handler: GET carzuri/v1/reviews/eligibility/{vehicle_id}
     */
    public function get_review_eligibility($request) {
        global $wpdb;
        $user_id = get_current_user_id();
        $vehicle_id = absint($request->get_param('vehicle_id'));

        if (!$user_id) {
            return new WP_REST_Response(array(
                'logged_in'    => false,
                'eligible'     => false,
                'has_reviewed' => false,
                'message'      => __('Please log in to check review eligibility.', 'carzuri-reviews')
            ), 200);
        }

        $eligible = $this->user_is_eligible_for_vehicle($user_id, $vehicle_id);

        $reviews_table = $wpdb->prefix . 'carzuri_reviews';
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id, rating, review_text, created_at, updated_at FROM {$reviews_table} WHERE user_id = %d AND vehicle_id = %d",
            $user_id,
            $vehicle_id
        ));

        $has_reviewed = !empty($existing);
        $existing_data = null;

        if ($existing) {
            $existing_data = array(
                'id'          => intval($existing->id),
                'rating'      => intval($existing->rating),
                'review_text' => esc_html($existing->review_text),
                'updated_at'  => $existing->updated_at
            );
        }

        $message = '';
        if (!$eligible) {
            $message = __('Reviews are available to buyers who have inquired about this vehicle.', 'carzuri-reviews');
        } elseif ($has_reviewed) {
            $message = __('You have already reviewed this vehicle. You can update your existing review below.', 'carzuri-reviews');
        } else {
            $message = __('You are eligible to review this vehicle.', 'carzuri-reviews');
        }

        return new WP_REST_Response(array(
            'logged_in'       => true,
            'eligible'        => $eligible,
            'has_reviewed'    => $has_reviewed,
            'existing_review' => $existing_data,
            'message'         => $message
        ), 200);
    }

    /**
     * Render Shortcode [carzuri_vehicle_reviews vehicle_id=""]
     */
    public function render_vehicle_reviews_shortcode($atts) {
        $atts = shortcode_atts(array(
            'vehicle_id' => 0,
        ), $atts, 'carzuri_vehicle_reviews');

        $vehicle_id = absint($atts['vehicle_id']);

        // Auto-detect vehicle_id if on single vehicle post page
        if (!$vehicle_id) {
            if (is_singular('vehicle')) {
                $vehicle_id = get_the_ID();
            } else {
                $vehicle_id = get_the_ID();
            }
        }

        if (!$vehicle_id) {
            return '<div class="carzuri-reviews-notice carzuri-notice-warning">' . 
                   esc_html__('Vehicle ID could not be determined.', 'carzuri-reviews') . 
                   '</div>';
        }

        wp_enqueue_style('carzuri-reviews-style');
        wp_enqueue_script('carzuri-reviews-script');

        $user_id = get_current_user_id();

        wp_localize_script('carzuri-reviews-script', 'carzuriReviewsData', array(
            'rest_url'     => esc_url_raw(rest_url('carzuri/v1/')),
            'nonce'        => wp_create_nonce('wp_rest'),
            'user_id'      => $user_id,
            'is_logged_in' => is_user_logged_in(),
            'vehicle_id'   => $vehicle_id,
            'login_url'    => wp_login_url(get_permalink($vehicle_id))
        ));

        ob_start();
        ?>
        <div id="carzuri-vehicle-reviews-root" class="carzuri-reviews-container" data-vehicle-id="<?php echo esc_attr($vehicle_id); ?>">
            <div class="carzuri-reviews-loading">
                <span class="carzuri-spinner"></span> <?php esc_html_e('Loading reviews...', 'carzuri-reviews'); ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render Shortcode [carzuri_dealer_reviews dealer_id=""]
     */
    public function render_dealer_reviews_shortcode($atts) {
        $atts = shortcode_atts(array(
            'dealer_id' => 0,
        ), $atts, 'carzuri_dealer_reviews');

        $dealer_id = absint($atts['dealer_id']);

        if (!$dealer_id) {
            return '<div class="carzuri-reviews-notice carzuri-notice-error">' .
                   '<strong>' . esc_html__('Carzuri Dealer Ratings:', 'carzuri-reviews') . '</strong> ' .
                   esc_html__('The shortcode [carzuri_dealer_reviews] requires a dealer_id attribute (e.g. [carzuri_dealer_reviews dealer_id="123"]).', 'carzuri-reviews') .
                   '</div>';
        }

        wp_enqueue_style('carzuri-reviews-style');
        wp_enqueue_script('carzuri-reviews-script');

        wp_localize_script('carzuri-reviews-script', 'carzuriReviewsData', array(
            'rest_url' => esc_url_raw(rest_url('carzuri/v1/')),
            'nonce'    => wp_create_nonce('wp_rest')
        ));

        ob_start();
        ?>
        <div id="carzuri-dealer-reviews-root-<?php echo esc_attr($dealer_id); ?>" class="carzuri-reviews-container carzuri-dealer-reviews-container" data-dealer-id="<?php echo esc_attr($dealer_id); ?>">
            <div class="carzuri-reviews-loading">
                <span class="carzuri-spinner"></span> <?php esc_html_e('Loading dealer ratings...', 'carzuri-reviews'); ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

add_action('plugins_loaded', array('Carzuri_Reviews_Plugin', 'get_instance'));
