/**
 * Carzuri Reviews & Dealer Ratings - Frontend Controller
 * File: assets/js/carzuri-reviews.js
 */
(function($) {
    'use strict';

    // Helper SVG Star generator with explicit size protection
    function renderStarSvg(fillPercent, sizeClass) {
        sizeClass = sizeClass || '';
        var uniqueId = 'star-grad-' + Math.floor(Math.random() * 1000000);
        var percentStr = Math.max(0, Math.min(100, fillPercent)) + '%';

        return '<svg class="carzuri-star-icon ' + sizeClass + '" viewBox="0 0 24 24" aria-hidden="true">' +
            '<defs>' +
                '<linearGradient id="' + uniqueId + '" x1="0%" y1="0%" x2="100%" y2="0%">' +
                    '<stop offset="' + percentStr + '" stop-color="var(--carzuri-gold, #D97706)" />' +
                    '<stop offset="' + percentStr + '" stop-color="#E2E8F0" />' +
                '</linearGradient>' +
            '</defs>' +
            '<path fill="url(#' + uniqueId + ')" d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>' +
        '</svg>';
    }

    function renderStarRatingGroup(rating, sizeClass) {
        var html = '<div class="carzuri-stars-wrapper" aria-label="Rating: ' + rating + ' out of 5 stars">';
        for (var i = 1; i <= 5; i++) {
            var diff = rating - (i - 1);
            var fill = 0;
            if (diff >= 1) {
                fill = 100;
            } else if (diff > 0) {
                fill = Math.round(diff * 100);
            }
            html += renderStarSvg(fill, sizeClass);
        }
        html += '</div>';
        return html;
    }

    // Vehicle Reviews App
    function initVehicleReviewsApp($container) {
        var vehicleId = $container.data('vehicle-id');
        var restUrl = carzuriReviewsData ? carzuriReviewsData.rest_url : '/wp-json/carzuri/v1/';
        var nonce = carzuriReviewsData ? carzuriReviewsData.nonce : '';
        var isLoggedIn = carzuriReviewsData ? !!carzuriReviewsData.is_logged_in : false;
        var loginUrl = carzuriReviewsData ? carzuriReviewsData.login_url : '/wp-login.php';

        function loadData() {
            var vehicleReq = $.ajax({
                url: restUrl + 'reviews/vehicle/' + vehicleId,
                method: 'GET',
                dataType: 'json'
            });

            var eligReq = null;
            if (isLoggedIn) {
                eligReq = $.ajax({
                    url: restUrl + 'reviews/eligibility/' + vehicleId,
                    method: 'GET',
                    headers: { 'X-WP-Nonce': nonce },
                    dataType: 'json'
                });
            }

            $.when(vehicleReq, eligReq).done(function(vehRes, eligRes) {
                var vehData = vehRes[0] || {};
                var eligData = eligRes ? (eligRes[0] || {}) : { logged_in: false, eligible: false };
                renderUI(vehData, eligData);
            }).fail(function(err) {
                $container.html('<div class="carzuri-reviews-notice carzuri-notice-error">Unable to load reviews at this time.</div>');
            });
        }

        function renderUI(vehData, eligData) {
            var avg = vehData.average_rating || 0;
            var total = vehData.total_reviews || 0;
            var reviews = vehData.reviews || [];

            var html = '';

            // 1. Header & Summary Stats
            html += '<div class="carzuri-reviews-header">';
                html += '<div class="carzuri-reviews-summary-card">';
                    html += '<div class="carzuri-score-large">' + avg.toFixed(1) + '</div>';
                    html += '<div class="carzuri-summary-stars">';
                        html += renderStarRatingGroup(avg, 'large');
                        html += '<div class="carzuri-total-count">' + total + ' ' + (total === 1 ? 'verified review' : 'verified reviews') + '</div>';
                    html += '</div>';
                html += '</div>';
            html += '</div>';

            // 2. Eligibility & Review Form Section
            html += '<div class="carzuri-form-section">';
            if (!isLoggedIn) {
                html += '<div class="carzuri-eligibility-box carzuri-box-info">';
                    html += '<p>Have you inquired about this vehicle? Log in to leave a verified rating and review.</p>';
                    html += '<a href="' + loginUrl + '" class="carzuri-btn carzuri-btn-outline">Log In to Review</a>';
                html += '</div>';
            } else if (!eligData.eligible) {
                html += '<div class="carzuri-eligibility-box carzuri-box-neutral">';
                    html += '<svg class="carzuri-info-icon" viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>';
                    html += '<span>Reviews are available to buyers who have inquired about this vehicle.</span>';
                html += '</div>';
            } else {
                // User is logged in & ELIGIBLE!
                var existing = eligData.existing_review || null;
                var selectedRating = existing ? existing.rating : 5;
                var reviewText = existing ? existing.review_text : '';

                html += '<form class="carzuri-review-form" id="carzuri-submit-review-form">';
                    html += '<h3 class="carzuri-form-title">' + (existing ? 'Edit Your Review' : 'Write a Verified Review') + '</h3>';
                    html += '<p class="carzuri-form-subtitle">' + eligData.message + '</p>';

                    html += '<div class="carzuri-form-field">';
                        html += '<label class="carzuri-label">Overall Rating <span class="carzuri-required">*</span></label>';
                        html += '<div class="carzuri-interactive-stars" id="carzuri-star-picker" data-current="' + selectedRating + '">';
                        for (var r = 1; r <= 5; r++) {
                            var activeClass = r <= selectedRating ? 'active' : '';
                            html += '<button type="button" class="carzuri-star-btn ' + activeClass + '" data-value="' + r + '" aria-label="Rate ' + r + ' stars">';
                                html += '<svg class="carzuri-star-icon large" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
                            html += '</button>';
                        }
                        html += '</div>';
                        html += '<input type="hidden" name="rating" id="carzuri-rating-input" value="' + selectedRating + '">';
                    html += '</div>';

                    html += '<div class="carzuri-form-field">';
                        html += '<label for="carzuri-review-textarea" class="carzuri-label">Your Review <span class="carzuri-optional">(Optional)</span></label>';
                        html += '<textarea id="carzuri-review-textarea" name="review_text" rows="4" placeholder="Share your experience with this vehicle or dealer...">' + reviewText + '</textarea>';
                    html += '</div>';

                    html += '<div class="carzuri-form-actions">';
                        html += '<button type="submit" class="carzuri-btn carzuri-btn-primary" id="carzuri-submit-btn">';
                            html += (existing ? 'Update Review' : 'Submit Review');
                        html += '</button>';
                    html += '</div>';
                    html += '<div id="carzuri-form-message"></div>';
                html += '</form>';
            }
            html += '</div>';

            // 3. Reviews List Section
            html += '<div class="carzuri-reviews-list-section">';
                html += '<h3 class="carzuri-section-title">Verified Buyer Reviews (' + total + ')</h3>';
                if (reviews.length === 0) {
                    html += '<div class="carzuri-empty-state">No reviews have been submitted for this vehicle yet.</div>';
                } else {
                    html += '<div class="carzuri-reviews-feed">';
                    $.each(reviews, function(idx, item) {
                        html += '<div class="carzuri-review-card">';
                            html += '<div class="carzuri-card-top">';
                                html += '<div class="carzuri-reviewer-info">';
                                    html += '<div class="carzuri-avatar-badge">' + item.reviewer_name.charAt(0).toUpperCase() + '</div>';
                                    html += '<div>';
                                        html += '<strong class="carzuri-reviewer-name">' + item.reviewer_name + '</strong>';
                                        html += '<span class="carzuri-verified-badge"><svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg> Verified Buyer</span>';
                                    html += '</div>';
                                html += '</div>';
                                html += '<div class="carzuri-card-rating">';
                                    html += renderStarRatingGroup(item.rating, 'small');
                                    html += '<span class="carzuri-review-date">' + item.created_formatted + '</span>';
                                html += '</div>';
                            html += '</div>';
                            if (item.review_text) {
                                html += '<p class="carzuri-review-body">' + item.review_text + '</p>';
                            }
                        html += '</div>';
                    });
                    html += '</div>';
                }
            html += '</div>';

            $container.html(html);
            bindFormEvents($container, vehicleId);
        }

        function bindFormEvents($container, vehicleId) {
            // Interactive Star Rating Picker
            $container.find('.carzuri-star-btn').on('mouseenter', function() {
                var val = $(this).data('value');
                $container.find('.carzuri-star-btn').each(function() {
                    var btnVal = $(this).data('value');
                    if (btnVal <= val) {
                        $(this).addClass('hover-active');
                    } else {
                        $(this).removeClass('hover-active');
                    }
                });
            });

            $container.find('.carzuri-interactive-stars').on('mouseleave', function() {
                $container.find('.carzuri-star-btn').removeClass('hover-active');
            });

            $container.find('.carzuri-star-btn').on('click', function(e) {
                e.preventDefault();
                var val = $(this).data('value');
                $('#carzuri-rating-input').val(val);
                $container.find('.carzuri-interactive-stars').attr('data-current', val);
                $container.find('.carzuri-star-btn').each(function() {
                    var btnVal = $(this).data('value');
                    if (btnVal <= val) {
                        $(this).addClass('active');
                    } else {
                        $(this).removeClass('active');
                    }
                });
            });

            // Handle AJAX Submit
            $container.find('#carzuri-submit-review-form').on('submit', function(e) {
                e.preventDefault();
                var $btn = $('#carzuri-submit-btn');
                var $msg = $('#carzuri-form-message');
                var rating = $('#carzuri-rating-input').val();
                var reviewText = $('#carzuri-review-textarea').val();

                $btn.prop('disabled', true).addClass('carzuri-loading-btn').text('Submitting...');
                $msg.removeClass('carzuri-msg-success carzuri-msg-error').empty();

                $.ajax({
                    url: restUrl + 'reviews',
                    method: 'POST',
                    headers: { 'X-WP-Nonce': nonce },
                    contentType: 'application/json',
                    data: JSON.stringify({
                        vehicle_id: parseInt(vehicleId, 10),
                        rating: parseInt(rating, 10),
                        review_text: reviewText
                    })
                }).done(function(res) {
                    $msg.addClass('carzuri-msg-success').text(res.message || 'Review saved successfully!');
                    setTimeout(function() {
                        loadData();
                    }, 1200);
                }).fail(function(err) {
                    var errMsg = 'Error submitting review. Please try again.';
                    if (err.responseJSON && err.responseJSON.message) {
                        errMsg = err.responseJSON.message;
                    }
                    $msg.addClass('carzuri-msg-error').text(errMsg);
                    $btn.prop('disabled', false).removeClass('carzuri-loading-btn').text('Submit Review');
                });
            });
        }

        loadData();
    }

    // Dealer Reviews App
    function initDealerReviewsApp($container) {
        var dealerId = $container.data('dealer-id');
        var restUrl = carzuriReviewsData ? carzuriReviewsData.rest_url : '/wp-json/carzuri/v1/';

        function loadDealerData(page) {
            page = page || 1;
            $.ajax({
                url: restUrl + 'reviews/dealer/' + dealerId + '?page=' + page,
                method: 'GET',
                dataType: 'json'
            }).done(function(res) {
                renderDealerUI(res, page);
            }).fail(function() {
                $container.html('<div class="carzuri-reviews-notice carzuri-notice-error">Unable to load dealer ratings.</div>');
            });
        }

        function renderDealerUI(res, currentPage) {
            var avg = res.average_rating || 0;
            var total = res.total_reviews || 0;
            var reviews = res.reviews || [];
            var totalPages = res.total_pages || 1;

            var html = '';

            // Header Summary
            html += '<div class="carzuri-dealer-summary-box">';
                html += '<div class="carzuri-dealer-badge">Carzuri Verified Dealer Rating</div>';
                html += '<div class="carzuri-score-large">' + avg.toFixed(1) + '</div>';
                html += renderStarRatingGroup(avg, 'large');
                html += '<div class="carzuri-total-count">' + total + ' total reviews across dealer inventory</div>';
            html += '</div>';

            // Feed
            html += '<div class="carzuri-reviews-list-section">';
                html += '<h3 class="carzuri-section-title">Dealer Inventory Reviews</h3>';
                if (reviews.length === 0) {
                    html += '<div class="carzuri-empty-state">No reviews recorded for this dealer yet.</div>';
                } else {
                    html += '<div class="carzuri-reviews-feed">';
                    $.each(reviews, function(idx, item) {
                        html += '<div class="carzuri-review-card">';
                            html += '<div class="carzuri-card-top">';
                                html += '<div>';
                                    html += '<strong class="carzuri-reviewer-name">' + item.reviewer_name + '</strong>';
                                    html += '<div class="carzuri-vehicle-tag">Reviewed for: <a href="' + item.vehicle_permalink + '" class="carzuri-vehicle-link">' + item.vehicle_title + '</a></div>';
                                html += '</div>';
                                html += '<div class="carzuri-card-rating">';
                                    html += renderStarRatingGroup(item.rating, 'small');
                                    html += '<span class="carzuri-review-date">' + item.created_formatted + '</span>';
                                html += '</div>';
                            html += '</div>';
                            if (item.review_text) {
                                html += '<p class="carzuri-review-body">' + item.review_text + '</p>';
                            }
                        html += '</div>';
                    });
                    html += '</div>';

                    // Pagination
                    if (totalPages > 1) {
                        html += '<div class="carzuri-pagination">';
                        for (var p = 1; p <= totalPages; p++) {
                            var activeClass = p === currentPage ? 'active' : '';
                            html += '<button class="carzuri-page-btn ' + activeClass + '" data-page="' + p + '">' + p + '</button>';
                        }
                        html += '</div>';
                    }
                }
            html += '</div>';

            $container.html(html);

            $container.find('.carzuri-page-btn').on('click', function(e) {
                e.preventDefault();
                var p = $(this).data('page');
                loadDealerData(p);
            });
        }

        loadDealerData(1);
    }

    // Auto Init on Document Ready
    $(document).ready(function() {
        $('#carzuri-vehicle-reviews-root').each(function() {
            initVehicleReviewsApp($(this));
        });

        $('.carzuri-dealer-reviews-container').each(function() {
            initDealerReviewsApp($(this));
        });
    });

})(jQuery);
