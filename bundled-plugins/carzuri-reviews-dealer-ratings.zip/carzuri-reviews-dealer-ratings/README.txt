=== Carzuri Reviews & Dealer Ratings ===
Contributors: Carzuri Engineering
Tags: automotive, car dealer, reviews, ratings, marketplace
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 1.0.1
License: GPLv2 or later

A custom automotive marketplace review & dealer rating system for Carzuri.

== Description ==

Carzuri Reviews & Dealer Ratings provides verified review collection and aggregated dealer ratings for the Carzuri automotive marketplace.

= Key Features =
* Verified Inquiry Eligibility: Server-side validation against `carzuri_inquiries` table ensures only users who submitted a real vehicle inquiry can submit a review.
* Re-submission & Update: Updates existing review rows based on UNIQUE KEY `user_vehicle (user_id, vehicle_id)`.
* Vehicle Single Shortcode: `[carzuri_vehicle_reviews vehicle_id=""]` (auto-detects current vehicle ID if omitted).
* Dealer Ratings Aggregate Shortcode: `[carzuri_dealer_reviews dealer_id=""]` (aggregates all vehicle reviews for the given dealer).
* Safe Elementor / Astra Compatibility: REST API registered strictly on `rest_api_init` hook; SVG star dimensions protected with `!important`; input padding rules protected with `!important`.

== Installation ==

1. Upload the `carzuri-reviews-dealer-ratings` folder to the `/wp-content/plugins/` directory, or upload the ZIP file directly via WordPress Admin -> Plugins -> Add New -> Upload Plugin.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Add the shortcode `[carzuri_vehicle_reviews]` to single vehicle templates or pages.
4. Add the shortcode `[carzuri_dealer_reviews dealer_id="123"]` to dealer profile pages.

== Database Assumptions ==

This plugin operates directly on existing database tables created by Carzuri Core:
- `{$wpdb->prefix}carzuri_reviews`
- `{$wpdb->prefix}carzuri_inquiries`
- Meta key `carzuri_dealer_id` on post type `vehicle`

This plugin does NOT attempt to create or modify database tables.

== REST Endpoints ==

- POST `carzuri/v1/reviews` (Requires login & verified inquiry eligibility)
- GET `carzuri/v1/reviews/vehicle/{vehicle_id}`
- GET `carzuri/v1/reviews/dealer/{dealer_id}`
- GET `carzuri/v1/reviews/eligibility/{vehicle_id}`
