<?php
/**
 * Uninstall handler for Carzuri Reviews & Dealer Ratings
 *
 * WordPress only executes this file when the plugin is deleted from the
 * Plugins screen (not on a simple deactivate), so it's safe to drop the
 * table here — this never runs during normal use.
 *
 * @package Carzuri_Reviews
 */

// If uninstall not called from WordPress, exit (standard WP safeguard —
// prevents this file from being run directly or by anything other than
// WordPress's own uninstall process).
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

$table_name = $wpdb->prefix . 'carzuri_reviews';

// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name cannot be parameterized; not user input.
$wpdb->query( "DROP TABLE IF EXISTS {$table_name}" );
