<?php
/**
 * Plugin Name: Carzuri Login Screen
 * Plugin URI:  https://carzuri.co.ke
 * Description: Restyles the WordPress login, lost-password, and reset-password screens to match Carzuri's real navy/gold design system. Works alongside ASE (which handles the logo swap) — this plugin only restyles everything around it.
 * Version:     1.0.0
 * Author:      Carzuri Engineering
 * Text Domain: carzuri-login-screen
 * License:     GPLv2 or later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Point the logo link (top of the login card) at the real homepage
 * instead of WordPress.org.
 */
add_filter( 'login_headerurl', function () {
	return home_url( '/' );
} );

/**
 * Point the logo's title/alt text at the real site name instead of "WordPress".
 */
add_filter( 'login_headertext', function () {
	return get_bloginfo( 'name' );
} );

/**
 * Enqueue the login screen styles.
 */
add_action( 'login_enqueue_scripts', 'carzuri_login_screen_styles' );

function carzuri_login_screen_styles() {
	?>
	<style>
		:root {
			--cz-color-navy: #0A111F;
			--cz-color-navy-card: #121A2E;
			--cz-color-gold: #D4AF37;
		}

		html {
			background-color: var(--cz-color-navy) !important;
		}

		body.login {
			background-color: var(--cz-color-navy);
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
			position: relative;
			overflow-x: hidden;
			min-height: 100vh;
		}

		/* Decorative textured background, matching the homepage hero */
		body.login::before,
		body.login::after {
			content: "";
			position: fixed;
			top: 0;
			bottom: 0;
			width: 45%;
			opacity: 0.12;
			pointer-events: none;
			background-repeat: no-repeat;
			background-size: cover;
			background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 600'%3E%3Cpath d='M-100,50 L50,136.6 L50,310 L-100,396.6 L-250,310 L-250,136.6 Z' stroke='%23D4AF37' stroke-width='1.5' fill='none'/%3E%3Cpath d='M50,223.3 L200,310 L200,483.3 L50,570 L-100,483.3 L-100,310 Z' stroke='%23D4AF37' stroke-width='1' fill='none'/%3E%3Cpath d='M-150,396.6 L0,483.3 L0,656.6 L-150,743.3 L-300,656.6 L-300,483.3 Z' stroke='%23D4AF37' stroke-width='1' fill='none'/%3E%3C/svg%3E");
		}
		body.login::before {
			left: 0;
		}
		body.login::after {
			right: 0;
			transform: scaleX(-1);
		}

		/* Soft radial gold glow behind the card */
		#login {
			position: relative;
			z-index: 2;
			padding-top: 6vh;
		}
		#login::before {
			content: "";
			position: absolute;
			top: 50%;
			left: 50%;
			width: 700px;
			height: 700px;
			transform: translate(-50%, -50%);
			background: radial-gradient(circle, rgba(212,175,55,0.14) 0%, rgba(212,175,55,0) 65%);
			pointer-events: none;
			z-index: -1;
		}

		/* Logo area (ASE swaps the image itself; this just sizes/positions it) */
		#login h1 a {
			width: 220px;
			height: 90px;
			background-size: contain;
			margin-bottom: 24px;
		}

		/* The main login card */
		#loginform,
		#lostpasswordform,
		#resetpassform,
		#registerform {
			background-color: var(--cz-color-navy-card) !important;
			border: 1px solid rgba(212, 175, 55, 0.25) !important;
			border-radius: 12px !important;
			box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4) !important;
			padding: 32px 32px 24px 32px !important;
		}

		/* Field labels */
		#login label {
			color: #D1D5DB !important;
			font-size: 13px !important;
			font-weight: 600 !important;
		}

		/* Text/password inputs */
		#login form .input,
		#login input[type="text"],
		#login input[type="password"],
		#login input[type="email"] {
			background-color: var(--cz-color-navy) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			border-radius: 6px !important;
			color: #FFFFFF !important;
			padding: 10px 14px !important;
			font-size: 14px !important;
			box-shadow: none !important;
		}
		#login form .input:focus,
		#login input[type="text"]:focus,
		#login input[type="password"]:focus,
		#login input[type="email"]:focus {
			border-color: var(--cz-color-gold) !important;
			box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.15) !important;
		}

		/* Remember-me checkbox row */
		#login .forgetmenot label {
			color: #9CA3AF !important;
			font-size: 13px !important;
		}

		/* Primary submit button */
		#login .button-primary,
		#login #wp-submit {
			background-color: var(--cz-color-gold) !important;
			border: 1.5px solid var(--cz-color-gold) !important;
			color: var(--cz-color-navy) !important;
			font-weight: 700 !important;
			text-transform: uppercase;
			letter-spacing: 0.4px;
			font-size: 12.5px !important;
			padding: 10px 22px !important;
			height: auto !important;
			border-radius: 6px !important;
			box-shadow: none !important;
			text-shadow: none !important;
			transition: background-color 0.2s ease, border-color 0.2s ease;
		}
		#login .button-primary:hover,
		#login #wp-submit:hover {
			background-color: #c19b26 !important;
			border-color: #c19b26 !important;
		}

		/* Links below the form ("Lost your password?", "Register", "Back to site") */
		#nav a,
		#backtoblog a {
			color: #9CA3AF !important;
			font-size: 13px !important;
			text-decoration: none !important;
			transition: color 0.15s ease;
		}
		#nav a:hover,
		#backtoblog a:hover {
			color: var(--cz-color-gold) !important;
		}

		/* Error / message notices */
		#login #login_error,
		#login .message,
		#login .success {
			background-color: rgba(212, 175, 55, 0.08) !important;
			border-left: 4px solid var(--cz-color-gold) !important;
			color: #F3F4F6 !important;
			border-radius: 4px;
			box-shadow: none !important;
		}
		#login #login_error {
			border-left-color: #EF4444 !important;
		}

		/* Password strength meter (registration / reset password) */
		#login .indicator-hint {
			color: #9CA3AF !important;
			font-size: 12px !important;
		}

		/* Language switcher dropdown at the bottom, if present */
		#language-switcher {
			text-align: center;
		}
		#language-switcher .locale-input-wrapper select {
			background-color: var(--cz-color-navy-card) !important;
			color: #FFFFFF !important;
			border: 1px solid rgba(255,255,255,0.12) !important;
			border-radius: 6px !important;
		}

		@media (max-width: 480px) {
			#login {
				width: 92% !important;
				padding-top: 8vh;
			}
			#loginform,
			#lostpasswordform,
			#resetpassform,
			#registerform {
				padding: 24px 20px 20px 20px !important;
			}
		}
	</style>
	<?php
}
