<?php
/**
 * Plugin Name: Carzuri Finance Calculator
 * Plugin URI:  https://carzuri.co.ke/plugins/carzuri-finance-calculator
 * Description: A lightweight, client-side vehicle loan & finance amortization calculator for Carzuri Marketplace.
 * Version:     1.0.0
 * Author:      Carzuri Engineering
 * Author URI:  https://carzuri.co.ke
 * License:     GPL-2.0+
 * Text Domain: carzuri-finance-calc
 *
 * @package Carzuri_Finance_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'CARZURI_FINANCE_CALC_VERSION', '1.0.0' );
define( 'CARZURI_FINANCE_CALC_PATH', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_FINANCE_CALC_URL', plugin_dir_url( __FILE__ ) );

/**
 * Register and enqueue frontend scripts and styles.
 */
function carzuri_finance_calc_enqueue_assets() {
	// Register CSS with dependency on Carzuri Core design system handle if active
	wp_register_style(
		'carzuri-finance-calculator-css',
		CARZURI_FINANCE_CALC_URL . 'assets/css/carzuri-finance-calculator.css',
		array( 'carzuri-design-system' ),
		CARZURI_FINANCE_CALC_VERSION
	);

	// Register external JS file (no inline script blocks)
	wp_register_script(
		'carzuri-finance-calculator-js',
		CARZURI_FINANCE_CALC_URL . 'assets/js/carzuri-finance-calculator.js',
		array(),
		CARZURI_FINANCE_CALC_VERSION,
		true
	);

	// Pass localization data to script
	wp_localize_script(
		'carzuri-finance-calculator-js',
		'carzuriFinanceCalcSettings',
		array(
			'currencySymbol' => 'KSh',
			'currencyPos'    => 'left',
			'thousandsSep'   => ',',
			'decimalSep'     => '.',
			'decimals'       => 0,
			'defaultRate'    => 13,
			'defaultTerm'    => 36,
			'defaultDownPct' => 20,
		)
	);
}
add_action( 'wp_enqueue_scripts', 'carzuri_finance_calc_enqueue_assets' );

/**
 * Render shortcode [carzuri_finance_calculator]
 *
 * @param array $atts Shortcode attributes.
 * @return string Rendered HTML widget markup.
 */
function carzuri_finance_calculator_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'vehicle_id'               => 0,
			'default_price'            => 2500000,
			'default_down_payment_pct' => 20,
			'default_interest_rate'    => 13,
			'default_term'             => 36,
			'title'                    => __( 'Finance Calculator', 'carzuri-finance-calc' ),
			'subtitle'                 => __( 'Estimate your monthly loan repayments in seconds', 'carzuri-finance-calc' ),
		),
		$atts,
		'carzuri_finance_calculator'
	);

	$price = floatval( $atts['default_price'] );
	$vehicle_title = '';

	// Pre-fill price from vehicle post meta if vehicle_id is provided or current global post is vehicle
	$vehicle_id = intval( $atts['vehicle_id'] );
	if ( ! $vehicle_id && is_singular( 'vehicle' ) ) {
		$vehicle_id = get_the_ID();
	}

	if ( $vehicle_id > 0 ) {
		// Read exact post meta key 'carzuri_price' matching Core convention
		$meta_price = get_post_meta( $vehicle_id, 'carzuri_price', true );
		if ( '' !== $meta_price && is_numeric( $meta_price ) ) {
			$price = floatval( $meta_price );
		}
		$vehicle_title = get_the_title( $vehicle_id );
	}

	// Enqueue styles and scripts specifically when shortcode is output
	wp_enqueue_style( 'carzuri-finance-calculator-css' );
	wp_enqueue_script( 'carzuri-finance-calculator-js' );

	// Buffer output template
	ob_start();
	include CARZURI_FINANCE_CALC_PATH . 'templates/calculator-widget.php';
	return ob_get_clean();
}
add_shortcode( 'carzuri_finance_calculator', 'carzuri_finance_calculator_shortcode' );
