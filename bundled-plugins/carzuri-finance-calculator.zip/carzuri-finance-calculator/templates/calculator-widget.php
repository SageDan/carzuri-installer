<?php
/**
 * Shortcode Template: Carzuri Finance Calculator Widget
 *
 * Variables passed from shortcode:
 * - $price (float)
 * - $atts (array)
 * - $vehicle_title (string)
 *
 * @package Carzuri_Finance_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$down_pct   = floatval( $atts['default_down_payment_pct'] );
$down_amt   = round( ( $price * $down_pct ) / 100 );
$rate       = floatval( $atts['default_interest_rate'] );
$term       = intval( $atts['default_term'] );
?>

<div class="carzuri-finance-calc-wrapper" data-vehicle-price="<?php echo esc_attr( $price ); ?>">
	<div class="carzuri-calc-header">
		<h3 class="carzuri-calc-title">
			<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
				<rect x="4" y="2" width="16" height="20" rx="2"></rect>
				<line x1="8" y1="6" x2="16" y2="6"></line>
				<line x1="16" y1="14" x2="16" y2="18"></line>
				<path d="M16 10h.01"></path>
				<path d="M12 10h.01"></path>
				<path d="M8 10h.01"></path>
				<path d="M12 14h.01"></path>
				<path d="M8 14h.01"></path>
				<path d="M12 18h.01"></path>
				<path d="M8 18h.01"></path>
			</svg>
			<?php echo esc_html( $atts['title'] ); ?>
		</h3>
		<?php if ( ! empty( $vehicle_title ) ) : ?>
			<p class="carzuri-calc-subtitle">
				<?php printf( esc_html__( 'Estimating financing for %s', 'carzuri-finance-calc' ), '<strong>' . esc_html( $vehicle_title ) . '</strong>' ); ?>
			</p>
		<?php elseif ( ! empty( $atts['subtitle'] ) ) : ?>
			<p class="carzuri-calc-subtitle"><?php echo esc_html( $atts['subtitle'] ); ?></p>
		<?php endif; ?>
	</div>

	<div class="carzuri-calc-grid">
		<!-- Inputs Column -->
		<div class="carzuri-calc-form">
			<!-- Vehicle Price Input -->
			<div class="carzuri-field-group">
				<div class="carzuri-field-label-row">
					<label class="carzuri-field-label"><?php esc_html_e( 'Vehicle Price', 'carzuri-finance-calc' ); ?></label>
					<span class="carzuri-field-hint"><?php esc_html_e( 'Total purchase price', 'carzuri-finance-calc' ); ?></span>
				</div>
				<div class="carzuri-input-prefix-wrapper">
					<span class="carzuri-input-prefix">KSh</span>
					<input type="number" 
						class="carzuri-calc-input carzuri-input-price" 
						value="<?php echo esc_attr( $price ); ?>" 
						min="100000" 
						max="30000000" 
						step="50000" />
				</div>
				<input type="range" 
					class="carzuri-calc-slider carzuri-slider-price" 
					value="<?php echo esc_attr( $price ); ?>" 
					min="100000" 
					max="30000000" 
					step="50000" />
			</div>

			<!-- Down Payment Input -->
			<div class="carzuri-field-group">
				<div class="carzuri-field-label-row">
					<label class="carzuri-field-label"><?php esc_html_e( 'Down Payment', 'carzuri-finance-calc' ); ?></label>
					<div class="carzuri-toggle-pills">
						<button type="button" class="carzuri-pill-btn carzuri-down-pill active" data-mode="amount">KSh</button>
						<button type="button" class="carzuri-pill-btn carzuri-down-pill" data-mode="percent">%</button>
					</div>
				</div>
				<div class="carzuri-input-prefix-wrapper">
					<span class="carzuri-input-prefix">KSh</span>
					<input type="number" 
						class="carzuri-calc-input carzuri-input-down" 
						value="<?php echo esc_attr( $down_amt ); ?>" 
						min="0" 
						step="10000" />
				</div>
				<input type="range" 
					class="carzuri-calc-slider carzuri-slider-down" 
					value="<?php echo esc_attr( $down_amt ); ?>" 
					min="0" 
					max="<?php echo esc_attr( $price ); ?>" 
					step="10000" />
			</div>

			<!-- Interest Rate Input -->
			<div class="carzuri-field-group">
				<div class="carzuri-field-label-row">
					<label class="carzuri-field-label"><?php esc_html_e( 'Annual Interest Rate', 'carzuri-finance-calc' ); ?></label>
					<span class="carzuri-field-hint"><?php esc_html_e( 'Kenyan market average: 12% - 16%', 'carzuri-finance-calc' ); ?></span>
				</div>
				<div class="carzuri-input-prefix-wrapper">
					<input type="number" 
						class="carzuri-calc-input carzuri-input-rate" 
						style="padding-left: 14px;" 
						value="<?php echo esc_attr( $rate ); ?>" 
						min="1" 
						max="36" 
						step="0.25" />
					<span class="carzuri-input-suffix">%</span>
				</div>
			</div>

			<!-- Loan Term Select -->
			<div class="carzuri-field-group">
				<label class="carzuri-field-label"><?php esc_html_e( 'Loan Term (Months)', 'carzuri-finance-calc' ); ?></label>
				<select class="carzuri-calc-select carzuri-select-term">
					<option value="12" <?php selected( $term, 12 ); ?>>12 Months (1 Year)</option>
					<option value="24" <?php selected( $term, 24 ); ?>>24 Months (2 Years)</option>
					<option value="36" <?php selected( $term, 36 ); ?>>36 Months (3 Years)</option>
					<option value="48" <?php selected( $term, 48 ); ?>>48 Months (4 Years)</option>
					<option value="60" <?php selected( $term, 60 ); ?>>60 Months (5 Years)</option>
					<option value="72" <?php selected( $term, 72 ); ?>>72 Months (6 Years)</option>
				</select>
			</div>
		</div>

		<!-- Calculation Results Card -->
		<div class="carzuri-calc-results-card">
			<div class="carzuri-result-primary">
				<div class="carzuri-result-label"><?php esc_html_e( 'Estimated Monthly Payment', 'carzuri-finance-calc' ); ?></div>
				<div class="carzuri-result-amount carzuri-out-monthly">KSh 0</div>
			</div>

			<div class="carzuri-result-breakdown">
				<div class="carzuri-breakdown-row">
					<span class="label"><?php esc_html_e( 'Loan Principal', 'carzuri-finance-calc' ); ?></span>
					<span class="value carzuri-out-principal">KSh 0</span>
				</div>
				<div class="carzuri-breakdown-row">
					<span class="label"><?php esc_html_e( 'Down Payment Ratio', 'carzuri-finance-calc' ); ?></span>
					<span class="value carzuri-out-down-pct">0%</span>
				</div>
				<div class="carzuri-breakdown-row">
					<span class="label"><?php esc_html_e( 'Total Interest Paid', 'carzuri-finance-calc' ); ?></span>
					<span class="value carzuri-out-interest">KSh 0</span>
				</div>
				<div class="carzuri-breakdown-row">
					<span class="label"><?php esc_html_e( 'Total Amount Repaid', 'carzuri-finance-calc' ); ?></span>
					<span class="value carzuri-out-total">KSh 0</span>
				</div>

				<div style="margin-top: 8px;">
					<div class="carzuri-field-label-row" style="margin-bottom: 4px;">
						<span class="label" style="font-size: 0.75rem; color: #94a3b8;">Principal vs. Interest Ratio</span>
					</div>
					<div class="carzuri-loan-bar-wrapper">
						<div class="carzuri-bar-principal" style="width: 70%;"></div>
						<div class="carzuri-bar-interest" style="width: 30%;"></div>
					</div>
				</div>
			</div>

			<button type="button" class="carzuri-schedule-toggle-btn">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<line x1="8" y1="6" x2="21" y2="6"></line>
					<line x1="8" y1="12" x2="21" y2="12"></line>
					<line x1="8" y1="18" x2="21" y2="18"></line>
					<line x1="3" y1="6" x2="3.01" y2="6"></line>
					<line x1="3" y1="12" x2="3.01" y2="12"></line>
					<line x1="3" y1="18" x2="3.01" y2="18"></line>
				</svg>
				<span class="btn-text"><?php esc_html_e( 'View Full Schedule Breakdown', 'carzuri-finance-calc' ); ?></span>
			</button>

			<?php
			// "Ready to Apply?" CTA — previously the calculator had no path
			// forward into an actual finance application at all; someone
			// could estimate a payment here and then had to independently
			// go find the Finance Application page themselves. Looks up
			// the real page URL the same way other templates on this site
			// do (match by shortcode content, fallback to the known slug),
			// and — when this calculator instance is tied to a specific
			// vehicle — carries that vehicle_id through via the URL so the
			// application form actually pre-fills it (see the matching fix
			// in class-carzuri-finance-shortcodes.php, which previously
			// only ever read vehicle_id from a shortcode attribute, never
			// from the URL).
			$finance_app_url = home_url( '/finance-application-form/' );
			global $wpdb;
			$finance_app_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_finance_application_form%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
			if ( $finance_app_page_id ) {
				$finance_app_url = get_permalink( $finance_app_page_id );
			}

			$vehicle_id_for_link = isset( $atts['vehicle_id'] ) ? intval( $atts['vehicle_id'] ) : 0;
			if ( $vehicle_id_for_link > 0 ) {
				$finance_app_url = add_query_arg( 'vehicle_id', $vehicle_id_for_link, $finance_app_url );
			}
			?>
			<a href="<?php echo esc_url( $finance_app_url ); ?>" class="carzuri-calc-apply-cta">
				<?php esc_html_e( 'Ready to Apply?', 'carzuri-finance-calc' ); ?> &rarr;
			</a>
		</div>
	</div>

	<!-- Amortization Schedule Table Collapsible -->
	<div class="carzuri-schedule-container" style="display: none;">
		<h4 style="font-size: 0.95rem; font-weight: 700; margin: 0 0 12px 0; color: var(--carzuri-navy-dark, #0b192c);">
			<?php esc_html_e( 'Monthly Amortization Schedule', 'carzuri-finance-calc' ); ?>
		</h4>
		<div class="carzuri-schedule-table-scroll">
			<table class="carzuri-schedule-table">
				<thead>
					<tr>
						<th>#</th>
						<th>Payment</th>
						<th>Principal</th>
						<th>Interest</th>
						<th>Remaining Balance</th>
					</tr>
				</thead>
				<tbody class="carzuri-schedule-tbody">
					<!-- Dynamically populated via assets/js/carzuri-finance-calculator.js -->
				</tbody>
			</table>
		</div>
	</div>
</div>

<style>
.carzuri-calc-apply-cta {
	display: block;
	text-align: center;
	margin-top: 12px;
	padding: 12px 20px;
	background-color: #d4af37;
	color: #0b192c !important;
	font-weight: 700;
	font-size: 0.875rem;
	text-decoration: none;
	border-radius: 8px;
	transition: background-color 0.15s ease;
}
.carzuri-calc-apply-cta:hover {
	background-color: #c19b26;
}
</style>
