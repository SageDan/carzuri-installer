=== Carzuri Finance Calculator ===
Contributors: carzuridev
Tags: carzuri, finance, loan, calculator, amortization, kenya
Requires at least: 5.8
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight, pure client-side vehicle loan and finance calculator plugin for the Carzuri Marketplace ecosystem.

== Description ==

Carzuri Finance Calculator provides a instant, mobile-responsive loan payment estimator widget for car buyers.
It uses standard loan amortization mathematics to compute estimated monthly payments, total interest paid over the term, and total repayment amounts without any server round-trips or database calls.

Features:
* Shortcode [carzuri_finance_calculator]
* Live calculation on input change
* Pre-fill price from vehicle post meta 'carzuri_price' via vehicle_id attribute
* Kenyan Shilling (KSh) localization formatting
* Standard loan terms (12, 24, 36, 48, 60, 72 months)
* Collapsible monthly amortization schedule table
* Fully responsive and styled with Carzuri Core design system tokens

== Installation ==

1. Upload the `carzuri-finance-calculator` directory to the `/wp-content/plugins/` directory, or upload the plugin ZIP directly via WP Admin.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Place `[carzuri_finance_calculator]` on any page, post, or widget area.

== Shortcode Attributes ==

* `vehicle_id` (int) - ID of the listing post. Pre-fills price from 'carzuri_price' meta key. Default: 0
* `default_price` (float) - Initial vehicle price if vehicle_id is not set. Default: 2500000
* `default_down_payment_pct` (float) - Down payment percentage. Default: 20
* `default_interest_rate` (float) - Annual interest rate percentage. Default: 13
* `default_term` (int) - Loan term in months. Default: 36
* `title` (string) - Widget title. Default: "Finance Calculator"
* `subtitle` (string) - Widget subtitle text.

Example Usage:
`[carzuri_finance_calculator vehicle_id="1052"]`
`[carzuri_finance_calculator default_price="3800000" default_interest_rate="14.5"]`

== Frequently Asked Questions ==

= Does this plugin require a database table or REST API? =
No. It is purely client-side and lightweight, causing zero database load.

= Does it integrate with Carzuri Core design system? =
Yes! It depends on CSS handle `carzuri-design-system` and uses CSS variables like `--carzuri-navy-dark` and `--carzuri-gold`.

== Changelog ==

= 1.0.0 =
* Initial release of Carzuri Finance Calculator.
