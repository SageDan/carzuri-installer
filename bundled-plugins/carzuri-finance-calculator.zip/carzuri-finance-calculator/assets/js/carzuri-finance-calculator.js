/**
 * Carzuri Finance Calculator - Client-side Amortization Engine
 * Version: 1.0.0
 * Pure JavaScript - No inline script tags required.
 */

(function() {
  'use strict';

  function formatCurrency(amount, symbol, decimals, thousandsSep, decimalSep) {
    if (isNaN(amount) || !isFinite(amount)) amount = 0;
    symbol = symbol || 'KSh';
    decimals = (typeof decimals !== 'undefined') ? decimals : 0;
    thousandsSep = thousandsSep || ',';
    decimalSep = decimalSep || '.';

    var fixedAmount = amount.toFixed(decimals);
    var parts = fixedAmount.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSep);
    
    var formatted = parts.join(decimalSep);
    return symbol + ' ' + formatted;
  }

  function calculateAmortization(price, downPaymentAmount, annualRate, termMonths) {
    var principal = price - downPaymentAmount;
    if (principal < 0) principal = 0;

    var monthlyRate = (annualRate / 100) / 12;
    var monthlyPayment = 0;

    if (principal > 0 && termMonths > 0) {
      if (monthlyRate > 0) {
        var compound = Math.pow(1 + monthlyRate, termMonths);
        monthlyPayment = principal * (monthlyRate * compound) / (compound - 1);
      } else {
        monthlyPayment = principal / termMonths;
      }
    }

    var totalRepayment = monthlyPayment * termMonths;
    var totalInterest = totalRepayment - principal;
    if (totalInterest < 0) totalInterest = 0;

    // Generate schedule array
    var schedule = [];
    var balance = principal;
    for (var m = 1; m <= termMonths; m++) {
      var interestForMonth = balance * monthlyRate;
      var principalForMonth = monthlyPayment - interestForMonth;
      if (m === termMonths) {
        principalForMonth = balance;
        monthlyPayment = principalForMonth + interestForMonth;
      }
      balance -= principalForMonth;
      if (balance < 0) balance = 0;

      schedule.push({
        month: m,
        payment: monthlyPayment,
        principal: principalForMonth,
        interest: interestForMonth,
        balance: balance
      });
    }

    return {
      principal: principal,
      downPaymentAmount: downPaymentAmount,
      monthlyPayment: monthlyPayment,
      totalInterest: totalInterest,
      totalRepayment: totalRepayment,
      schedule: schedule
    };
  }

  function initCalculatorInstance(container) {
    if (container.dataset.initialized === 'true') return;
    container.dataset.initialized = 'true';

    // Inputs
    var priceInput = container.querySelector('.carzuri-input-price');
    var priceSlider = container.querySelector('.carzuri-slider-price');
    var downInput = container.querySelector('.carzuri-input-down');
    var downSlider = container.querySelector('.carzuri-slider-down');
    var rateInput = container.querySelector('.carzuri-input-rate');
    var termSelect = container.querySelector('.carzuri-select-term');
    
    // Pill Toggles for Down Payment
    var downTypePills = container.querySelectorAll('.carzuri-down-pill');

    // Outputs
    var monthlyOutput = container.querySelector('.carzuri-out-monthly');
    var principalOutput = container.querySelector('.carzuri-out-principal');
    var downPctOutput = container.querySelector('.carzuri-out-down-pct');
    var interestOutput = container.querySelector('.carzuri-out-interest');
    var totalOutput = container.querySelector('.carzuri-out-total');
    
    // Bar elements
    var barPrincipal = container.querySelector('.carzuri-bar-principal');
    var barInterest = container.querySelector('.carzuri-bar-interest');

    // Schedule container & toggle
    var scheduleBtn = container.querySelector('.carzuri-schedule-toggle-btn');
    var scheduleBox = container.querySelector('.carzuri-schedule-container');
    var scheduleBody = container.querySelector('.carzuri-schedule-tbody');

    var downPaymentMode = 'amount'; // 'amount' or 'percent'

    // Settings fallback
    var settings = window.carzuriFinanceCalcSettings || {
      currencySymbol: 'KSh',
      decimals: 0,
      thousandsSep: ',',
      decimalSep: '.'
    };

    function updateCalculations() {
      var price = parseFloat(priceInput.value) || 0;
      var rawDown = parseFloat(downInput.value) || 0;
      var rate = parseFloat(rateInput.value) || 0;
      var term = parseInt(termSelect.value, 10) || 36;

      var downAmount = 0;
      var downPct = 0;

      if (downPaymentMode === 'percent') {
        downPct = Math.min(Math.max(rawDown, 0), 100);
        downAmount = (price * downPct) / 100;
      } else {
        downAmount = Math.min(Math.max(rawDown, 0), price);
        downPct = price > 0 ? (downAmount / price) * 100 : 0;
      }

      var result = calculateAmortization(price, downAmount, rate, term);

      // Render Outputs
      if (monthlyOutput) {
        monthlyOutput.textContent = formatCurrency(
          result.monthlyPayment,
          settings.currencySymbol,
          settings.decimals,
          settings.thousandsSep,
          settings.decimalSep
        );
      }

      if (principalOutput) {
        principalOutput.textContent = formatCurrency(
          result.principal,
          settings.currencySymbol,
          settings.decimals,
          settings.thousandsSep,
          settings.decimalSep
        );
      }

      if (downPctOutput) {
        downPctOutput.textContent = downPct.toFixed(1) + '%';
      }

      if (interestOutput) {
        interestOutput.textContent = formatCurrency(
          result.totalInterest,
          settings.currencySymbol,
          settings.decimals,
          settings.thousandsSep,
          settings.decimalSep
        );
      }

      if (totalOutput) {
        totalOutput.textContent = formatCurrency(
          result.totalRepayment,
          settings.currencySymbol,
          settings.decimals,
          settings.thousandsSep,
          settings.decimalSep
        );
      }

      // Update progress bar ratio
      if (barPrincipal && barInterest) {
        var total = result.totalRepayment;
        if (total > 0) {
          var pPct = (result.principal / total) * 100;
          var iPct = (result.totalInterest / total) * 100;
          barPrincipal.style.width = pPct + '%';
          barInterest.style.width = iPct + '%';
        } else {
          barPrincipal.style.width = '100%';
          barInterest.style.width = '0%';
        }
      }

      // Render Amortization Schedule Table if table body exists
      if (scheduleBody && scheduleBox && scheduleBox.style.display !== 'none') {
        renderScheduleTable(result.schedule);
      }
    }

    function renderScheduleTable(schedule) {
      if (!scheduleBody) return;
      var html = '';
      for (var i = 0; i < schedule.length; i++) {
        var row = schedule[i];
        html += '<tr>' +
          '<td>' + row.month + '</td>' +
          '<td>' + formatCurrency(row.payment, settings.currencySymbol) + '</td>' +
          '<td>' + formatCurrency(row.principal, settings.currencySymbol) + '</td>' +
          '<td>' + formatCurrency(row.interest, settings.currencySymbol) + '</td>' +
          '<td>' + formatCurrency(row.balance, settings.currencySymbol) + '</td>' +
        '</tr>';
      }
      scheduleBody.innerHTML = html;
    }

    // Sync input box and slider for price
    if (priceInput && priceSlider) {
      priceInput.addEventListener('input', function() {
        priceSlider.value = priceInput.value;
        updateCalculations();
      });
      priceSlider.addEventListener('input', function() {
        priceInput.value = priceSlider.value;
        updateCalculations();
      });
    }

    // Sync input box and slider for down payment
    if (downInput && downSlider) {
      downInput.addEventListener('input', function() {
        downSlider.value = downInput.value;
        updateCalculations();
      });
      downSlider.addEventListener('input', function() {
        downInput.value = downSlider.value;
        updateCalculations();
      });
    }

    // Rate & Term listeners
    if (rateInput) {
      rateInput.addEventListener('input', updateCalculations);
    }
    if (termSelect) {
      termSelect.addEventListener('change', updateCalculations);
    }

    // Handle Down Payment mode toggle pills
    downTypePills.forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        downTypePills.forEach(function(b) { b.classList.remove('active'); });
        btn.classList.add('active');
        
        var mode = btn.dataset.mode; // 'amount' or 'percent'
        if (mode !== downPaymentMode) {
          var price = parseFloat(priceInput.value) || 0;
          var curVal = parseFloat(downInput.value) || 0;

          if (mode === 'percent') {
            // Convert amount to percent
            downPaymentMode = 'percent';
            var pct = price > 0 ? (curVal / price) * 100 : 20;
            downInput.value = Math.round(pct);
            if (downSlider) {
              downSlider.max = "80";
              downSlider.value = Math.round(pct);
            }
          } else {
            // Convert percent to amount
            downPaymentMode = 'amount';
            var amt = (price * curVal) / 100;
            downInput.value = Math.round(amt);
            if (downSlider) {
              downSlider.max = price.toString();
              downSlider.value = Math.round(amt);
            }
          }
          updateCalculations();
        }
      });
    });

    // Toggle Schedule Box
    if (scheduleBtn && scheduleBox) {
      scheduleBtn.addEventListener('click', function(e) {
        e.preventDefault();
        var isHidden = scheduleBox.style.display === 'none' || scheduleBox.style.display === '';
        scheduleBox.style.display = isHidden ? 'block' : 'none';
        scheduleBtn.querySelector('.btn-text').textContent = isHidden ? 'Hide Amortization Schedule' : 'View Full Schedule Breakdown';
        if (isHidden) {
          updateCalculations();
        }
      });
    }

    // Initial calc trigger
    updateCalculations();
  }

  // Auto-initialize all calculator widgets on page load
  function initAllCalculators() {
    var widgets = document.querySelectorAll('.carzuri-finance-calc-wrapper');
    for (var i = 0; i < widgets.length; i++) {
      initCalculatorInstance(widgets[i]);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAllCalculators);
  } else {
    initAllCalculators();
  }

  // Expose function for dynamic shortcode rendering in SPAs / previews
  window.CarzuriFinanceCalc = {
    init: initAllCalculators,
    initInstance: initCalculatorInstance
  };
})();
