<?php
/**
 * Plugin Name:       Carzuri Payments
 * Plugin URI:        https://carzuri.co.ke
 * Description:       Shared M-Pesa Daraja payment engine for the Carzuri platform, with per-feature revenue toggles (dealer subscriptions, featured listings, commissions, fees) that stay off until deliberately switched on.
 * Version:           1.0.0
 * Author:            Carzuri Platform Team
 * Author URI:        https://carzuri.co.ke
 * Text Domain:       carzuri-payments
 * Domain Path:       /languages
 * License:           Apache-2.0
 * License URI:       http://www.apache.org/licenses/LICENSE-2.0
 * Namespace:         Carzuri\Payments
 *
 * @package Carzuri_Payments
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'CARZURI_PAYMENTS_VERSION', '1.0.0' );
define( 'CARZURI_PAYMENTS_PATH', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_PAYMENTS_URL', plugin_dir_url( __FILE__ ) );
define( 'CARZURI_PAYMENTS_DB_VERSION', '1.0.0' );

// The full, known set of revenue features this plugin can gate. Any new
// revenue idea added in the future should get a new key here and a new
// toggle in the admin settings screen — everything else (the M-Pesa
// engine, the transactions log, the initiate/callback REST endpoints)
// is already generic and reusable as-is.
define( 'CARZURI_PAYMENTS_KNOWN_FEATURES', array(
	'dealer_subscription',
	'featured_listing',
	'vehicle_sale_commission',
	'finance_referral',
	'inspection_fee',
	'trade_in_facilitation',
) );

require_once CARZURI_PAYMENTS_PATH . 'includes/helpers.php';
require_once CARZURI_PAYMENTS_PATH . 'includes/class-activator.php';
require_once CARZURI_PAYMENTS_PATH . 'includes/class-db-tables.php';
require_once CARZURI_PAYMENTS_PATH . 'includes/class-mpesa-client.php';
require_once CARZURI_PAYMENTS_PATH . 'includes/class-rest-api.php';
require_once CARZURI_PAYMENTS_PATH . 'admin/class-admin-settings.php';

/**
 * Register Activation Hook.
 */
function activate_carzuri_payments() {
	require_once CARZURI_PAYMENTS_PATH . 'includes/class-activator.php';
	Carzuri\Payments\Activator::activate();
}
register_activation_hook( __FILE__, 'activate_carzuri_payments' );

/**
 * Bootstrap the Carzuri Payments components.
 */
function run_carzuri_payments() {
	// Keep the transactions table current on every load, same pattern as
	// Core's own DatabaseTables version-check.
	$db_tables = new Carzuri\Payments\DatabaseTables();
	$db_tables->init();

	// REST endpoints: initiate + M-Pesa callback.
	$rest_api = new Carzuri\Payments\RestAPI();
	$rest_api->init();

	// Admin Settings page (M-Pesa credentials + feature toggles).
	if ( is_admin() ) {
		$admin_settings = new Carzuri\Payments\AdminSettings();
		$admin_settings->init();
	}
}
add_action( 'plugins_loaded', 'run_carzuri_payments' );
