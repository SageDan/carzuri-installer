<?php
/**
 * Global helper functions for Carzuri Payments.
 *
 * @package Carzuri_Payments
 */

if ( ! function_exists( 'carzuri_payments_is_feature_enabled' ) ) {
	/**
	 * Check whether a given revenue feature has been switched on by the
	 * site owner. Every feature defaults to OFF until explicitly enabled
	 * from Carzuri → Settings → Payments → Revenue Features.
	 *
	 * This is the single gate every future feature (dealer subscriptions,
	 * featured listings, commissions, fees, etc.) should check before
	 * offering or processing a real charge — flipping a feature on later
	 * is then just a settings change, not a code change.
	 *
	 * @param string $feature One of the keys in CARZURI_PAYMENTS_KNOWN_FEATURES.
	 * @return bool
	 */
	function carzuri_payments_is_feature_enabled( $feature ) {
		if ( ! defined( 'CARZURI_PAYMENTS_KNOWN_FEATURES' ) || ! in_array( $feature, CARZURI_PAYMENTS_KNOWN_FEATURES, true ) ) {
			return false;
		}

		$option_name = 'carzuri_payments_enable_' . $feature;
		return filter_var( get_option( $option_name, false ), FILTER_VALIDATE_BOOLEAN );
	}
}

if ( ! function_exists( 'carzuri_payments_get_mpesa_credentials' ) ) {
	/**
	 * Retrieve the configured M-Pesa Daraja credentials as a single array,
	 * so callers never need to remember each individual option name.
	 *
	 * @return array
	 */
	function carzuri_payments_get_mpesa_credentials() {
		return array(
			'consumer_key'    => get_option( 'carzuri_mpesa_consumer_key', '' ),
			'consumer_secret' => get_option( 'carzuri_mpesa_consumer_secret', '' ),
			'passkey'         => get_option( 'carzuri_mpesa_passkey', '' ),
			'shortcode'       => get_option( 'carzuri_mpesa_shortcode', '' ),
			'environment'     => get_option( 'carzuri_mpesa_environment', 'sandbox' ),
		);
	}
}

if ( ! function_exists( 'carzuri_payments_log_transaction' ) ) {
	/**
	 * Insert a new row into wp_carzuri_transactions.
	 *
	 * @param array $data Column => value pairs. 'created_at'/'updated_at' are set automatically.
	 * @return int|false Insert ID, or false on failure.
	 */
	function carzuri_payments_log_transaction( $data ) {
		global $wpdb;

		$table = $wpdb->prefix . 'carzuri_transactions';
		$now   = current_time( 'mysql' );

		$defaults = array(
			'user_id'               => get_current_user_id(),
			'feature'               => '',
			'reference_id'          => 0,
			'amount'                => 0,
			'phone_number'          => '',
			'status'                => 'pending',
			'merchant_request_id'   => '',
			'checkout_request_id'   => '',
			'mpesa_receipt_number'  => '',
			'result_code'           => null,
			'result_desc'           => '',
			'raw_callback_payload'  => '',
			'created_at'            => $now,
			'updated_at'            => $now,
		);

		$row = wp_parse_args( $data, $defaults );

		$inserted = $wpdb->insert( $table, $row );

		return $inserted ? $wpdb->insert_id : false;
	}
}
