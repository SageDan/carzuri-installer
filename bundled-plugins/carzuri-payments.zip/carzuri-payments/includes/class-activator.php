<?php
namespace Carzuri\Payments;

/**
 * Fired during plugin activation.
 *
 * @package Carzuri_Payments
 */
class Activator {

	/**
	 * Run the activation routine.
	 */
	public static function activate() {
		require_once plugin_dir_path( __DIR__ ) . 'includes/class-db-tables.php';
		$db = new DatabaseTables();
		$db->create_tables();

		// M-Pesa credentials — all empty until the site owner fills them in.
		// Environment defaults to 'sandbox' so nothing can accidentally
		// process a real charge before it has been deliberately switched
		// to 'production'.
		$defaults = array(
			'carzuri_mpesa_consumer_key'    => '',
			'carzuri_mpesa_consumer_secret' => '',
			'carzuri_mpesa_passkey'         => '',
			'carzuri_mpesa_shortcode'       => '',
			'carzuri_mpesa_environment'     => 'sandbox',
		);

		foreach ( $defaults as $option => $value ) {
			if ( false === get_option( $option ) ) {
				update_option( $option, $value, false ); // autoload => false: these are secrets.
			}
		}

		// Every revenue feature defaults to OFF. Activating this plugin
		// must never, by itself, change what any visitor to the live site
		// sees or is charged.
		if ( defined( 'CARZURI_PAYMENTS_KNOWN_FEATURES' ) ) {
			foreach ( CARZURI_PAYMENTS_KNOWN_FEATURES as $feature ) {
				$option = 'carzuri_payments_enable_' . $feature;
				if ( false === get_option( $option ) ) {
					update_option( $option, false );
				}
			}
		}
	}
}
