<?php
namespace Carzuri\Payments;

/**
 * Thin wrapper around Safaricom's M-Pesa Daraja API (OAuth + STK Push).
 * Used by RestAPI::initiate_payment() and, in future, by any specific
 * revenue feature once it is switched on. This class deliberately knows
 * nothing about *why* a payment is happening — that's the caller's job.
 *
 * @package Carzuri_Payments
 */
class MpesaClient {

	/**
	 * Base API host for the configured environment.
	 *
	 * @param string $environment 'sandbox' or 'production'.
	 * @return string
	 */
	private static function get_base_url( $environment ) {
		return ( 'production' === $environment )
			? 'https://api.safaricom.co.ke'
			: 'https://sandbox.safaricom.co.ke';
	}

	/**
	 * Obtain (and briefly cache) an OAuth access token from Safaricom.
	 * Tokens are valid for ~1 hour; cached for 55 minutes to stay safely
	 * inside that window without hammering the endpoint on every request.
	 *
	 * @return string|\WP_Error Access token string, or WP_Error on failure.
	 */
	public static function get_access_token() {
		$creds = carzuri_payments_get_mpesa_credentials();

		if ( empty( $creds['consumer_key'] ) || empty( $creds['consumer_secret'] ) ) {
			return new \WP_Error(
				'carzuri_mpesa_not_configured',
				__( 'M-Pesa Daraja credentials have not been configured yet.', 'carzuri-payments' )
			);
		}

		$cache_key    = 'carzuri_mpesa_access_token_' . $creds['environment'];
		$cached_token = get_transient( $cache_key );
		if ( $cached_token ) {
			return $cached_token;
		}

		$url = self::get_base_url( $creds['environment'] ) . '/oauth/v1/generate?grant_type=client_credentials';

		$response = wp_remote_get( $url, array(
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( $creds['consumer_key'] . ':' . $creds['consumer_secret'] ),
			),
			'timeout' => 20,
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( empty( $body['access_token'] ) ) {
			return new \WP_Error(
				'carzuri_mpesa_auth_failed',
				__( 'Failed to authenticate with M-Pesa Daraja. Please verify the configured credentials.', 'carzuri-payments' )
			);
		}

		set_transient( $cache_key, $body['access_token'], 55 * MINUTE_IN_SECONDS );

		return $body['access_token'];
	}

	/**
	 * Initiate an STK Push ("Lipa Na M-Pesa Online") request — this is
	 * what triggers the "Enter M-Pesa PIN" prompt on the payer's phone.
	 *
	 * @param string $phone               Phone number in 2547XXXXXXXX format.
	 * @param float  $amount              Amount in KES (whole numbers only — M-Pesa does not support decimals).
	 * @param string $account_reference   Short reference shown to the payer (max ~12 chars recommended).
	 * @param string $transaction_desc    Short description shown to the payer.
	 * @param string $callback_url        Full URL Safaricom should call back once the payer responds.
	 * @return array|\WP_Error Decoded response body, or WP_Error on failure.
	 */
	public static function initiate_stk_push( $phone, $amount, $account_reference, $transaction_desc, $callback_url ) {
		$creds = carzuri_payments_get_mpesa_credentials();

		if ( empty( $creds['shortcode'] ) || empty( $creds['passkey'] ) ) {
			return new \WP_Error(
				'carzuri_mpesa_not_configured',
				__( 'M-Pesa Daraja shortcode/passkey have not been configured yet.', 'carzuri-payments' )
			);
		}

		$token = self::get_access_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}

		$timestamp = gmdate( 'YmdHis' );
		$password  = base64_encode( $creds['shortcode'] . $creds['passkey'] . $timestamp );

		$url = self::get_base_url( $creds['environment'] ) . '/mpesa/stkpush/v1/processrequest';

		$payload = array(
			'BusinessShortCode' => $creds['shortcode'],
			'Password'          => $password,
			'Timestamp'         => $timestamp,
			'TransactionType'   => 'CustomerPayBillOnline',
			'Amount'            => (int) round( $amount ), // M-Pesa amounts are whole numbers.
			'PartyA'            => $phone,
			'PartyB'            => $creds['shortcode'],
			'PhoneNumber'       => $phone,
			'CallBackURL'       => $callback_url,
			'AccountReference'  => substr( $account_reference, 0, 12 ),
			'TransactionDesc'   => substr( $transaction_desc, 0, 100 ),
		);

		$response = wp_remote_post( $url, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
			),
			'body'    => wp_json_encode( $payload ),
			'timeout' => 20,
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( empty( $body ) || ! isset( $body['ResponseCode'] ) ) {
			return new \WP_Error(
				'carzuri_mpesa_stk_failed',
				__( 'M-Pesa did not return a valid response for this payment request.', 'carzuri-payments' )
			);
		}

		return $body;
	}
}
