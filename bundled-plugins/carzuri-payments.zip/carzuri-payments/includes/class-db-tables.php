<?php
namespace Carzuri\Payments;

/**
 * Handles creation and upgrades of the wp_carzuri_transactions table.
 *
 * @package Carzuri_Payments
 */
class DatabaseTables {

	/**
	 * Initialize database routines.
	 */
	public function init() {
		add_action( 'plugins_loaded', array( $this, 'check_version' ) );
	}

	/**
	 * Compare stored database version option and trigger upgrade if needed.
	 */
	public function check_version() {
		$current_version = get_option( 'carzuri_payments_db_version', '0.0.0' );
		if ( version_compare( $current_version, CARZURI_PAYMENTS_DB_VERSION, '<' ) ) {
			$this->create_tables();
		}
	}

	/**
	 * Create or update the transactions table using dbDelta.
	 */
	public function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$table_name       = $wpdb->prefix . 'carzuri_transactions';

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// One shared log for every revenue feature. `feature` identifies
		// which one a given row belongs to (see CARZURI_PAYMENTS_KNOWN_FEATURES
		// in the main plugin file); `reference_id` is a generic pointer to
		// whatever this payment was for (a vehicle ID for a featured-listing
		// fee, a dealer's user ID for a subscription renewal, etc.) — its
		// meaning depends on `feature` and is not itself a foreign key to
		// any single table.
		$sql = "CREATE TABLE $table_name (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			feature varchar(50) NOT NULL,
			reference_id bigint(20) unsigned DEFAULT 0,
			amount decimal(10,2) NOT NULL DEFAULT 0.00,
			phone_number varchar(20) DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'pending',
			merchant_request_id varchar(100) DEFAULT '',
			checkout_request_id varchar(100) DEFAULT '',
			mpesa_receipt_number varchar(50) DEFAULT '',
			result_code int(11) DEFAULT NULL,
			result_desc text DEFAULT NULL,
			raw_callback_payload longtext DEFAULT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id),
			KEY feature (feature),
			KEY status (status),
			KEY checkout_request_id (checkout_request_id)
		) $charset_collate;";

		dbDelta( $sql );

		update_option( 'carzuri_payments_db_version', CARZURI_PAYMENTS_DB_VERSION );
	}
}
