<?php
namespace Carzuri\Payments;

use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Error;

/**
 * REST routes for Carzuri Payments, under the existing carzuri/v1
 * namespace shared with Core.
 *
 * @package Carzuri_Payments
 */
class RestAPI {

	protected $namespace = 'carzuri/v1';

	/**
	 * Initialize REST hooks.
	 */
	public function init() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register routes.
	 */
	public function register_routes() {

		// POST /carzuri/v1/payments/initiate
		// The single generic entry point any future feature calls to start
		// a real M-Pesa charge. Refuses immediately if that feature's
		// toggle is off — this is what makes "switch a revenue stream on
		// later" a settings change rather than a deployment.
		register_rest_route( $this->namespace, '/payments/initiate', array(
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'initiate_payment' ),
				'permission_callback' => array( $this, 'check_logged_in' ),
				'args'                => array(
					'feature' => array(
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'phone' => array(
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'amount' => array(
						'required'          => true,
						// NOTE: floatval() is a raw PHP built-in. Since PHP 8,
						// built-in functions throw ArgumentCountError if called
						// with more arguments than they accept — and WordPress
						// always calls a sanitize_callback with 3 arguments
						// ($value, $request, $param_name), which floatval()
						// rejects. Wrapping it in a closure that only forwards
						// the single value it needs avoids the crash. WordPress's
						// own functions (absint, sanitize_text_field, etc.) don't
						// have this problem since they're written in PHP and
						// silently ignore extra arguments.
						'sanitize_callback' => function( $value ) {
							return floatval( $value );
						},
					),
					'reference_id' => array(
						'required'          => false,
						'sanitize_callback' => 'absint',
					),
					'description' => array(
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			),
		) );

		// POST /carzuri/v1/payments/mpesa-callback
		// Public — Safaricom calls this directly, with no WordPress auth
		// of any kind, so it can never require a logged-in user or nonce.
		register_rest_route( $this->namespace, '/payments/mpesa-callback', array(
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_mpesa_callback' ),
				'permission_callback' => '__return_true',
			),
		) );
	}

	/**
	 * Permission check: any logged-in user may attempt to initiate a
	 * payment — the feature-toggle check inside initiate_payment() is
	 * what actually decides whether anything happens.
	 */
	public function check_logged_in() {
		return is_user_logged_in();
	}

	/**
	 * Handler: POST /carzuri/v1/payments/initiate
	 */
	public function initiate_payment( WP_REST_Request $request ) {
		$feature      = $request->get_param( 'feature' );
		$phone        = $request->get_param( 'phone' );
		$amount       = (float) $request->get_param( 'amount' );
		$reference_id = (int) $request->get_param( 'reference_id' );
		$description  = $request->get_param( 'description' );

		if ( ! defined( 'CARZURI_PAYMENTS_KNOWN_FEATURES' ) || ! in_array( $feature, CARZURI_PAYMENTS_KNOWN_FEATURES, true ) ) {
			return new WP_REST_Response( array(
				'success' => false,
				'message' => __( 'Unknown payment feature requested.', 'carzuri-payments' ),
			), 400 );
		}

		// The gate: if the site owner has not switched this specific
		// revenue feature on, refuse cleanly here — no M-Pesa call is
		// ever made, and nothing on the site should have offered this
		// option to the user in the first place.
		if ( ! carzuri_payments_is_feature_enabled( $feature ) ) {
			return new WP_REST_Response( array(
				'success' => false,
				'message' => __( 'This feature is not currently available.', 'carzuri-payments' ),
			), 403 );
		}

		if ( empty( $phone ) || empty( $amount ) || $amount <= 0 ) {
			return new WP_REST_Response( array(
				'success' => false,
				'message' => __( 'A valid phone number and amount are required.', 'carzuri-payments' ),
			), 400 );
		}

		// Normalize to Safaricom's expected 2547XXXXXXXX format.
		$phone = preg_replace( '/\D/', '', $phone );
		if ( 0 === strpos( $phone, '0' ) ) {
			$phone = '254' . substr( $phone, 1 );
		} elseif ( 0 === strpos( $phone, '+254' ) ) {
			$phone = substr( $phone, 1 );
		}

		$callback_url = rest_url( $this->namespace . '/payments/mpesa-callback' );

		$result = MpesaClient::initiate_stk_push(
			$phone,
			$amount,
			$feature,
			$description ? $description : ucwords( str_replace( '_', ' ', $feature ) ),
			$callback_url
		);

		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response( array(
				'success' => false,
				'message' => $result->get_error_message(),
			), 502 );
		}

		// ResponseCode "0" means Safaricom accepted the request and has
		// sent the prompt to the payer's phone — it does NOT mean payment
		// has succeeded yet. The real outcome only arrives later, via the
		// callback endpoint below.
		$accepted = isset( $result['ResponseCode'] ) && '0' === (string) $result['ResponseCode'];

		$transaction_id = carzuri_payments_log_transaction( array(
			'feature'             => $feature,
			'reference_id'        => $reference_id,
			'amount'              => $amount,
			'phone_number'        => $phone,
			'status'              => $accepted ? 'pending' : 'failed',
			'merchant_request_id' => isset( $result['MerchantRequestID'] ) ? $result['MerchantRequestID'] : '',
			'checkout_request_id' => isset( $result['CheckoutRequestID'] ) ? $result['CheckoutRequestID'] : '',
			'result_desc'         => isset( $result['ResponseDescription'] ) ? $result['ResponseDescription'] : '',
		) );

		if ( ! $accepted ) {
			return new WP_REST_Response( array(
				'success' => false,
				'message' => isset( $result['ResponseDescription'] ) ? $result['ResponseDescription'] : __( 'M-Pesa declined this payment request.', 'carzuri-payments' ),
			), 502 );
		}

		return new WP_REST_Response( array(
			'success'             => true,
			'message'             => __( 'Check your phone and enter your M-Pesa PIN to complete payment.', 'carzuri-payments' ),
			'transaction_id'      => $transaction_id,
			'checkout_request_id' => $result['CheckoutRequestID'],
		), 200 );
	}

	/**
	 * Handler: POST /carzuri/v1/payments/mpesa-callback
	 *
	 * Safaricom's own documented payload shape:
	 * { "Body": { "stkCallback": {
	 *     "MerchantRequestID": "...", "CheckoutRequestID": "...",
	 *     "ResultCode": 0, "ResultDesc": "...",
	 *     "CallbackMetadata": { "Item": [ {"Name":"Amount","Value":...},
	 *       {"Name":"MpesaReceiptNumber","Value":"..."},
	 *       {"Name":"TransactionDate","Value":...},
	 *       {"Name":"PhoneNumber","Value":...} ] }
	 * } } }
	 *
	 * Must always respond 200 with ResultCode 0 in the body, regardless
	 * of what it found — that is what tells Safaricom to stop retrying.
	 */
	public function handle_mpesa_callback( WP_REST_Request $request ) {
		global $wpdb;

		$raw_body = $request->get_body();
		$data     = json_decode( $raw_body, true );

		$callback = isset( $data['Body']['stkCallback'] ) ? $data['Body']['stkCallback'] : null;

		if ( ! $callback || empty( $callback['CheckoutRequestID'] ) ) {
			// Malformed/unexpected payload — log nothing to update, but
			// still acknowledge so Safaricom does not keep retrying.
			return new WP_REST_Response( array( 'ResultCode' => 0, 'ResultDesc' => 'Accepted' ), 200 );
		}

		$checkout_request_id = sanitize_text_field( $callback['CheckoutRequestID'] );
		$result_code          = isset( $callback['ResultCode'] ) ? (int) $callback['ResultCode'] : null;
		$result_desc          = isset( $callback['ResultDesc'] ) ? sanitize_text_field( $callback['ResultDesc'] ) : '';
		$mpesa_receipt        = '';

		if ( ! empty( $callback['CallbackMetadata']['Item'] ) && is_array( $callback['CallbackMetadata']['Item'] ) ) {
			foreach ( $callback['CallbackMetadata']['Item'] as $item ) {
				if ( isset( $item['Name'] ) && 'MpesaReceiptNumber' === $item['Name'] && isset( $item['Value'] ) ) {
					$mpesa_receipt = sanitize_text_field( $item['Value'] );
				}
			}
		}

		$status = ( 0 === $result_code ) ? 'success' : 'failed';

		$table = $wpdb->prefix . 'carzuri_transactions';

		$wpdb->update(
			$table,
			array(
				'status'                => $status,
				'result_code'           => $result_code,
				'result_desc'           => $result_desc,
				'mpesa_receipt_number'  => $mpesa_receipt,
				'raw_callback_payload'  => $raw_body,
				'updated_at'            => current_time( 'mysql' ),
			),
			array( 'checkout_request_id' => $checkout_request_id ),
			array( '%s', '%d', '%s', '%s', '%s', '%s' ),
			array( '%s' )
		);

		// Always acknowledge — this is a Safaricom requirement, not a
		// reflection of whether our own update above succeeded.
		return new WP_REST_Response( array( 'ResultCode' => 0, 'ResultDesc' => 'Accepted' ), 200 );
	}
}
