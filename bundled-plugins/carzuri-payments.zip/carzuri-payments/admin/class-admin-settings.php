<?php
namespace Carzuri\Payments;

/**
 * Admin Settings page for Carzuri Payments — added as a submenu under
 * Core's existing top-level "Carzuri" menu, matching that plugin's own
 * settings-page pattern (tabs via nav-tab-wrapper, Settings API groups).
 *
 * @package Carzuri_Payments
 */
class AdminSettings {

	/**
	 * Initialize Admin Settings menu.
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Add "Payments" as a submenu under Core's existing "Carzuri" menu.
	 */
	public function add_admin_menu() {
		add_submenu_page(
			'carzuri',
			__( 'Payments', 'carzuri-payments' ),
			__( 'Payments', 'carzuri-payments' ),
			'carzuri_manage_settings',
			'carzuri-payments-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Register settings using the standard Settings API.
	 */
	public function register_settings() {
		// 1. M-Pesa Daraja credentials (autoload => false — these are secrets).
		register_setting( 'carzuri_payments_mpesa', 'carzuri_mpesa_consumer_key', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );
		register_setting( 'carzuri_payments_mpesa', 'carzuri_mpesa_consumer_secret', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );
		register_setting( 'carzuri_payments_mpesa', 'carzuri_mpesa_passkey', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );
		register_setting( 'carzuri_payments_mpesa', 'carzuri_mpesa_shortcode', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );
		register_setting( 'carzuri_payments_mpesa', 'carzuri_mpesa_environment', array(
			'type'              => 'string',
			'sanitize_callback' => array( $this, 'sanitize_environment' ),
			'default'           => 'sandbox',
		) );

		// 2. Revenue feature toggles — every single one defaults to OFF.
		if ( defined( 'CARZURI_PAYMENTS_KNOWN_FEATURES' ) ) {
			foreach ( CARZURI_PAYMENTS_KNOWN_FEATURES as $feature ) {
				register_setting( 'carzuri_payments_features', 'carzuri_payments_enable_' . $feature, array(
					'type'              => 'boolean',
					'sanitize_callback' => 'rest_sanitize_boolean',
					'default'           => false,
				) );
			}
		}
	}

	/**
	 * Restrict the Environment field to a known-safe pair of values,
	 * defaulting to the safer 'sandbox' for anything unrecognized.
	 */
	public function sanitize_environment( $value ) {
		return ( 'production' === $value ) ? 'production' : 'sandbox';
	}

	/**
	 * Human-readable labels for each revenue feature, for the toggle list.
	 */
	private function get_feature_labels() {
		return array(
			'dealer_subscription'     => array(
				'label'       => __( 'Dealer Subscriptions', 'carzuri-payments' ),
				'description' => __( 'Recurring fee for dealers to maintain an active account and listing access.', 'carzuri-payments' ),
			),
			'featured_listing'        => array(
				'label'       => __( 'Featured Listings', 'carzuri-payments' ),
				'description' => __( 'Fee for a dealer to have a vehicle marked Featured on the homepage and listings.', 'carzuri-payments' ),
			),
			'vehicle_sale_commission' => array(
				'label'       => __( 'Vehicle Sales Commission', 'carzuri-payments' ),
				'description' => __( 'A commission taken when a listed vehicle sells through the platform.', 'carzuri-payments' ),
			),
			'finance_referral'        => array(
				'label'       => __( 'Finance Referral Commission', 'carzuri-payments' ),
				'description' => __( 'A commission when a buyer\'s financing application results in an approved loan.', 'carzuri-payments' ),
			),
			'inspection_fee'          => array(
				'label'       => __( 'Vehicle Inspection Fees', 'carzuri-payments' ),
				'description' => __( 'A paid add-on for a professional vehicle inspection before purchase.', 'carzuri-payments' ),
			),
			'trade_in_facilitation'   => array(
				'label'       => __( 'Trade-In Facilitation Fee', 'carzuri-payments' ),
				'description' => __( 'A fee tied to the AI Smart Valuation / Trade-In flow.', 'carzuri-payments' ),
			),
		);
	}

	/**
	 * Render the settings page with tab triggers.
	 */
	public function render_settings_page() {
		$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'mpesa';
		$callback_url = rest_url( 'carzuri/v1/payments/mpesa-callback' );
		?>
		<div class="wrap carzuri-admin-wrap" style="max-width: 800px; margin-top: 20px;">
			<h1><?php _e( 'Carzuri Payments', 'carzuri-payments' ); ?></h1>

			<h2 class="nav-tab-wrapper" style="margin-bottom: 20px;">
				<a href="?page=carzuri-payments-settings&tab=mpesa" class="nav-tab <?php echo $active_tab === 'mpesa' ? 'nav-tab-active' : ''; ?>">
					<?php _e( 'M-Pesa Credentials', 'carzuri-payments' ); ?>
				</a>
				<a href="?page=carzuri-payments-settings&tab=features" class="nav-tab <?php echo $active_tab === 'features' ? 'nav-tab-active' : ''; ?>">
					<?php _e( 'Revenue Features', 'carzuri-payments' ); ?>
				</a>
			</h2>

			<?php if ( 'mpesa' === $active_tab ) : ?>

				<div class="notice notice-info" style="padding: 12px; margin-bottom: 20px;">
					<p style="margin:0;"><strong><?php _e( 'Callback URL to register with Safaricom:', 'carzuri-payments' ); ?></strong><br>
					<code><?php echo esc_html( $callback_url ); ?></code></p>
				</div>

				<form method="post" action="options.php" style="background:#fff; padding:24px; border-radius:8px; border:1px solid #ccd0d4;">
					<?php settings_fields( 'carzuri_payments_mpesa' ); ?>
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row"><label for="carzuri_mpesa_environment"><?php _e( 'Environment', 'carzuri-payments' ); ?></label></th>
								<td>
									<select name="carzuri_mpesa_environment" id="carzuri_mpesa_environment">
										<option value="sandbox" <?php selected( get_option( 'carzuri_mpesa_environment', 'sandbox' ), 'sandbox' ); ?>><?php _e( 'Sandbox (testing)', 'carzuri-payments' ); ?></option>
										<option value="production" <?php selected( get_option( 'carzuri_mpesa_environment', 'sandbox' ), 'production' ); ?>><?php _e( 'Production (live payments)', 'carzuri-payments' ); ?></option>
									</select>
									<p class="description"><?php _e( 'Always test fully in Sandbox before switching to Production.', 'carzuri-payments' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="carzuri_mpesa_consumer_key"><?php _e( 'Consumer Key', 'carzuri-payments' ); ?></label></th>
								<td><input name="carzuri_mpesa_consumer_key" type="password" id="carzuri_mpesa_consumer_key" value="<?php echo esc_attr( get_option( 'carzuri_mpesa_consumer_key', '' ) ); ?>" class="regular-text" style="width:100%; max-width:400px;" autocomplete="off" /></td>
							</tr>
							<tr>
								<th scope="row"><label for="carzuri_mpesa_consumer_secret"><?php _e( 'Consumer Secret', 'carzuri-payments' ); ?></label></th>
								<td><input name="carzuri_mpesa_consumer_secret" type="password" id="carzuri_mpesa_consumer_secret" value="<?php echo esc_attr( get_option( 'carzuri_mpesa_consumer_secret', '' ) ); ?>" class="regular-text" style="width:100%; max-width:400px;" autocomplete="off" /></td>
							</tr>
							<tr>
								<th scope="row"><label for="carzuri_mpesa_passkey"><?php _e( 'Passkey', 'carzuri-payments' ); ?></label></th>
								<td><input name="carzuri_mpesa_passkey" type="password" id="carzuri_mpesa_passkey" value="<?php echo esc_attr( get_option( 'carzuri_mpesa_passkey', '' ) ); ?>" class="regular-text" style="width:100%; max-width:400px;" autocomplete="off" /></td>
							</tr>
							<tr>
								<th scope="row"><label for="carzuri_mpesa_shortcode"><?php _e( 'Business Shortcode', 'carzuri-payments' ); ?></label></th>
								<td><input name="carzuri_mpesa_shortcode" type="text" id="carzuri_mpesa_shortcode" value="<?php echo esc_attr( get_option( 'carzuri_mpesa_shortcode', '' ) ); ?>" class="regular-text" style="width:100%; max-width:400px;" /></td>
							</tr>
						</tbody>
					</table>
					<?php submit_button(); ?>
				</form>

			<?php else : ?>

				<div class="notice notice-warning" style="padding: 12px; margin-bottom: 20px;">
					<p style="margin:0;"><?php _e( 'Every feature below is OFF by default. Turning one on makes it start charging real money the next time it is used — only enable a feature once you are ready for that.', 'carzuri-payments' ); ?></p>
				</div>

				<form method="post" action="options.php" style="background:#fff; padding:24px; border-radius:8px; border:1px solid #ccd0d4;">
					<?php settings_fields( 'carzuri_payments_features' ); ?>
					<table class="form-table" role="presentation">
						<tbody>
							<?php foreach ( $this->get_feature_labels() as $feature_key => $info ) : ?>
								<tr>
									<th scope="row"><?php echo esc_html( $info['label'] ); ?></th>
									<td>
										<label>
											<input type="hidden" name="carzuri_payments_enable_<?php echo esc_attr( $feature_key ); ?>" value="0" />
											<input type="checkbox" name="carzuri_payments_enable_<?php echo esc_attr( $feature_key ); ?>" value="1" <?php checked( carzuri_payments_is_feature_enabled( $feature_key ) ); ?> />
											<?php _e( 'Enabled', 'carzuri-payments' ); ?>
										</label>
										<p class="description"><?php echo esc_html( $info['description'] ); ?></p>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					<?php submit_button(); ?>
				</form>

			<?php endif; ?>
		</div>
		<?php
	}
}
