/**
 * Carzuri Finance Application Form Handler
 * Enqueued via carzuri_finance_application_form shortcode
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        var $form = $('#carzuri-finance-form');
        var $messageContainer = $('#carzuri-finance-message');
        var $submitBtn = $('#carzuri-finance-submit');

        if (!$form.length) return;

        $form.on('submit', function(e) {
            e.preventDefault();

            var formData = new FormData(this);
            var restUrl = typeof carzuriFinanceVars !== 'undefined' ? carzuriFinanceVars.restUrl : '/wp-json/carzuri/v1/finance-applications';
            var nonce = typeof carzuriFinanceVars !== 'undefined' ? carzuriFinanceVars.nonce : '';

            $submitBtn.prop('disabled', true).html('<div class="carzuri-spinner"></div> Submitting...');
            $messageContainer.empty().hide();

            $.ajax({
                url: restUrl,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-WP-Nonce': nonce
                },
                success: function(response) {
                    $submitBtn.prop('disabled', false).html('Submit Finance Application');
                    if (response && response.success) {
                        $messageContainer.html(
                            '<div class="carzuri-alert carzuri-alert-success">' +
                            '<svg class="carzuri-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>' +
                            '<div><strong>Success!</strong> ' + (response.message || 'Your application has been submitted successfully.') + ' Application ID: #' + response.id + '</div>' +
                            '</div>'
                        ).show();
                        $form[0].reset();
                    } else {
                        $messageContainer.html(
                            '<div class="carzuri-alert carzuri-alert-danger">' +
                            '<div>' + (response.message || 'Submission failed. Please try again.') + '</div>' +
                            '</div>'
                        ).show();
                    }
                },
                error: function(xhr) {
                    $submitBtn.prop('disabled', false).html('Submit Finance Application');
                    var msg = 'An error occurred during submission.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        msg = xhr.responseJSON.message;
                    }
                    $messageContainer.html(
                        '<div class="carzuri-alert carzuri-alert-danger">' +
                        '<div>' + msg + '</div>' +
                        '</div>'
                    ).show();
                }
            });
        });
    });
})(jQuery);
