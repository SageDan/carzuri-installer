/**
 * Carzuri Admin Review Queue Handler
 * Enqueued via carzuri_finance_admin_queue shortcode
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        var $tableBody = $('#carzuri-admin-table-body');
        var $statusFilter = $('#carzuri-status-filter');

        if (!$tableBody.length) return;

        var restUrl = typeof carzuriAdminVars !== 'undefined' ? carzuriAdminVars.restUrl : '/wp-json/carzuri/v1/finance-applications';
        var nonce = typeof carzuriAdminVars !== 'undefined' ? carzuriAdminVars.nonce : '';

        function loadAdminApplications(status) {
            var url = restUrl;
            if (status && status !== 'all') {
                url += '?status=' + encodeURIComponent(status);
            }

            $tableBody.html('<tr><td colspan="8" class="carzuri-text-center carzuri-py-4"><div class="carzuri-spinner-box"><div class="carzuri-spinner"></div> Loading queue...</div></td></tr>');

            $.ajax({
                url: url,
                method: 'GET',
                headers: {
                    'X-WP-Nonce': nonce
                },
                success: function(response) {
                    if (response && response.success && Array.isArray(response.data)) {
                        renderAdminTable(response.data);
                    } else {
                        $tableBody.html('<tr><td colspan="8" class="carzuri-text-center">Error loading queue data.</td></tr>');
                    }
                },
                error: function(xhr) {
                    var msg = 'Failed to load applications.';
                    if (xhr.status === 403 || xhr.status === 401) {
                        msg = 'Access denied. You must be a carzuri_admin to view this queue.';
                    }
                    $tableBody.html('<tr><td colspan="8" class="carzuri-text-center carzuri-alert-danger">' + msg + '</td></tr>');
                }
            });
        }

        function renderAdminTable(applications) {
            if (applications.length === 0) {
                $tableBody.html('<tr><td colspan="8" class="carzuri-text-center carzuri-py-4 carzuri-text-muted">No finance applications found.</td></tr>');
                return;
            }

            var html = '';
            $.each(applications, function(index, app) {
                var statusClass = 'carzuri-status-' + app.status;
                
                var docsHtml = 'None';
                if (app.documents && app.documents.length > 0) {
                    docsHtml = $.map(app.documents, function(doc) {
                        return '<a href="' + doc.url + '" target="_blank" class="carzuri-btn carzuri-btn-sm" style="margin-right:2px;" title="View File">Doc #' + doc.id + '</a>';
                    }).join(' ');
                }

                // When no vehicle is linked to this application (e.g. the
                // AI Valuation trade-in flow, which never sets vehicle_id),
                // the REST API returns vehicle_title as the literal string
                // 'N/A' and vehicle_id as null. Shown as a clean, clearly
                // intentional muted label instead of "Vehicle #N/A".
                var vehicleDisplay = (app.vehicle_title !== 'N/A')
                    ? escapeHtml(app.vehicle_title)
                    : '<span class="carzuri-text-muted" style="font-style:italic;">No vehicle specified</span>';

                html += '<tr data-app-id="' + app.id + '">' +
                    '<td><strong>#' + app.id + '</strong></td>' +
                    '<td>' +
                        '<div><strong>' + escapeHtml(app.applicant_name) + '</strong></div>' +
                        '<div class="carzuri-text-muted" style="font-size:0.75rem;">' + escapeHtml(app.applicant_email) + '</div>' +
                        '<div class="carzuri-text-muted" style="font-size:0.75rem;">' + escapeHtml(app.applicant_phone) + '</div>' +
                    '</td>' +
                    '<td>' +
                        '<div>' + vehicleDisplay + '</div>' +
                        '<div class="carzuri-text-muted">KSh ' + Number(app.vehicle_price).toLocaleString('en-US', {minimumFractionDigits: 2}) + '</div>' +
                    '</td>' +
                    '<td>' +
                        '<div>Dep: KSh ' + Number(app.deposit_amount).toLocaleString('en-US', {minimumFractionDigits: 2}) + '</div>' +
                        '<div class="carzuri-text-muted">' + app.loan_term_months + ' Months</div>' +
                    '</td>' +
                    '<td>' + docsHtml + '</td>' +
                    '<td>' + app.created_at + '</td>' +
                    '<td><span class="carzuri-status-badge ' + statusClass + '">' + app.status.replace('_', ' ').toUpperCase() + '</span></td>' +
                    '<td>' +
                        '<select class="carzuri-select carzuri-select-sm carzuri-status-update-select" data-app-id="' + app.id + '">' +
                            '<option value="submitted" ' + (app.status === 'submitted' ? 'selected' : '') + '>Submitted</option>' +
                            '<option value="under_review" ' + (app.status === 'under_review' ? 'selected' : '') + '>Under Review</option>' +
                            '<option value="approved" ' + (app.status === 'approved' ? 'selected' : '') + '>Approved</option>' +
                            '<option value="declined" ' + (app.status === 'declined' ? 'selected' : '') + '>Declined</option>' +
                        '</select>' +
                        '<button type="button" class="carzuri-btn carzuri-btn-sm carzuri-btn-danger carzuri-delete-app-btn" data-app-id="' + app.id + '" data-app-name="' + escapeHtml(app.applicant_name) + '" style="margin-top:6px; width:100%;" title="Permanently delete this application">Delete</button>' +
                    '</td>' +
                    '</tr>';
            });

            $tableBody.html(html);
        }

        // Handle Status Change
        $(document).on('change', '.carzuri-status-update-select', function() {
            var $select = $(this);
            var appId = $select.data('app-id');
            var newStatus = $select.val();

            $select.prop('disabled', true);

            $.ajax({
                url: restUrl + '/' + appId + '/status',
                method: 'POST',
                headers: {
                    'X-WP-Nonce': nonce
                },
                contentType: 'application/json',
                data: JSON.stringify({ status: newStatus }),
                success: function(response) {
                    $select.prop('disabled', false);
                    if (response && response.success) {
                        loadAdminApplications($statusFilter.val());
                    } else {
                        alert(response.message || 'Failed to update status.');
                    }
                },
                error: function(xhr) {
                    $select.prop('disabled', false);
                    alert('Error updating status.');
                }
            });
        });

        // Handle Delete — permanent, hard delete with no undo, so a real
        // confirmation naming the applicant is required before the request
        // is sent (same pattern as the Admin Portal's Unpublish/Reject
        // confirmations elsewhere on this site).
        $(document).on('click', '.carzuri-delete-app-btn', function() {
            var $btn = $(this);
            var appId = $btn.data('app-id');
            var appName = $btn.data('app-name') || ('Application #' + appId);

            var confirmed = confirm('Permanently delete the finance application from "' + appName + '" (App #' + appId + ')?\n\nThis cannot be undone.');
            if (!confirmed) {
                return;
            }

            $btn.prop('disabled', true).text('Deleting...');

            $.ajax({
                url: restUrl + '/' + appId,
                method: 'DELETE',
                headers: {
                    'X-WP-Nonce': nonce
                },
                success: function(response) {
                    if (response && response.success) {
                        $('tr[data-app-id="' + appId + '"]').fadeOut(200, function() {
                            $(this).remove();
                            if ($tableBody.find('tr').length === 0) {
                                loadAdminApplications($statusFilter.val());
                            }
                        });
                    } else {
                        alert(response.message || 'Failed to delete application.');
                        $btn.prop('disabled', false).text('Delete');
                    }
                },
                error: function(xhr) {
                    var msg = 'Error deleting application.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        msg = xhr.responseJSON.message;
                    }
                    alert(msg);
                    $btn.prop('disabled', false).text('Delete');
                }
            });
        });

        // Filter change listener
        $statusFilter.on('change', function() {
            loadAdminApplications($(this).val());
        });

        function escapeHtml(string) {
            return String(string).replace(/[&<>"']/g, function(s) {
                return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s];
            });
        }

        loadAdminApplications('all');
    });
})(jQuery);
