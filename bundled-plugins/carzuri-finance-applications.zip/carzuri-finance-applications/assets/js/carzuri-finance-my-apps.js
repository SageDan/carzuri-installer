/**
 * Carzuri My Finance Applications Dashboard Handler
 * Enqueued via carzuri_my_finance_applications shortcode
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        var $container = $('#carzuri-my-apps-container');
        if (!$container.length) return;

        var restUrl = typeof carzuriMyFinanceVars !== 'undefined' ? carzuriMyFinanceVars.restUrl : '/wp-json/carzuri/v1/my-finance-applications';
        var nonce = typeof carzuriMyFinanceVars !== 'undefined' ? carzuriMyFinanceVars.nonce : '';

        function loadMyApplications() {
            $.ajax({
                url: restUrl,
                method: 'GET',
                headers: {
                    'X-WP-Nonce': nonce
                },
                success: function(response) {
                    if (response && response.success && Array.isArray(response.data)) {
                        renderApplicationsList(response.data);
                    } else {
                        $container.html('<div class="carzuri-alert carzuri-alert-warning">Unable to load your applications.</div>');
                    }
                },
                error: function(xhr) {
                    var msg = 'Failed to fetch your applications.';
                    if (xhr.status === 401) {
                        msg = 'Please log in to view your applications.';
                    }
                    $container.html('<div class="carzuri-alert carzuri-alert-danger">' + msg + '</div>');
                }
            });
        }

        function renderApplicationsList(applications) {
            if (applications.length === 0) {
                $container.html(
                    '<div class="carzuri-alert carzuri-alert-info">' +
                    'You have not submitted any finance applications yet.' +
                    '</div>'
                );
                return;
            }

            var html = '<div class="carzuri-table-responsive"><table class="carzuri-table"><thead><tr>' +
                '<th>App ID</th>' +
                '<th>Vehicle</th>' +
                '<th>Price & Deposit</th>' +
                '<th>Term</th>' +
                '<th>Date</th>' +
                '<th>Status</th>' +
                '<th>Documents</th>' +
                '</tr></thead><tbody>';

            $.each(applications, function(index, app) {
                var statusClass = 'carzuri-status-' + app.status;
                var statusLabel = app.status.replace('_', ' ').toUpperCase();

                var docsHtml = 'None';
                if (app.documents && app.documents.length > 0) {
                    docsHtml = $.map(app.documents, function(doc) {
                        return '<a href="' + doc.url + '" target="_blank" class="carzuri-btn carzuri-btn-sm" style="margin-right:4px;">Doc #' + doc.id + '</a>';
                    }).join(' ');
                }

                // When no vehicle is linked to this application (e.g. the
                // AI Valuation trade-in flow, which never sets vehicle_id),
                // the REST API returns vehicle_title as the literal string
                // 'N/A' and vehicle_id as null. Previously this rendered as
                // the awkward "Vehicle #N/A"; now shown as a clean, clearly
                // intentional muted label instead.
                var vehicleDisplay = (app.vehicle_title !== 'N/A')
                    ? escapeHtml(app.vehicle_title)
                    : '<span class="carzuri-text-muted" style="font-style:italic;">No vehicle specified</span>';

                html += '<tr>' +
                    '<td><strong>#' + app.id + '</strong></td>' +
                    '<td>' + vehicleDisplay + '</td>' +
                    '<td>KSh ' + Number(app.vehicle_price).toLocaleString('en-US', {minimumFractionDigits: 2}) + ' (Dep: KSh ' + Number(app.deposit_amount).toLocaleString('en-US', {minimumFractionDigits: 2}) + ')</td>' +
                    '<td>' + app.loan_term_months + ' Mos</td>' +
                    '<td>' + app.created_at + '</td>' +
                    '<td><span class="carzuri-status-badge ' + statusClass + '">' + statusLabel + '</span></td>' +
                    '<td>' + docsHtml + '</td>' +
                    '</tr>';
            });

            html += '</tbody></table></div>';
            $container.html(html);
        }

        // This file had no HTML-escaping helper at all before this fix (the
        // admin queue script already had one). Added here so the vehicle
        // title — which comes from a real WordPress post title and could in
        // principle contain characters like < or & — can't break the table
        // markup. Small, low-risk addition alongside the requested fix.
        function escapeHtml(string) {
            return String(string).replace(/[&<>"']/g, function(s) {
                return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s];
            });
        }

        loadMyApplications();
    });
})(jQuery);
