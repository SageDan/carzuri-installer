<?php
/**
 * REST API Controller for Carzuri Finance Applications
 *
 * @package Carzuri_Finance
 */

if (!defined('ABSPATH')) {
    exit;
}

class Carzuri_Finance_REST extends WP_REST_Controller {

    protected $namespace = 'carzuri/v1';
    protected $rest_base = 'finance-applications';

    public function register_routes() {
        // Public POST for application submission (guests & logged-in users)
        register_rest_route($this->namespace, '/' . $this->rest_base, array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array($this, 'create_application'),
                'permission_callback' => '__return_true', // Guest submissions permitted
            ),
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array($this, 'get_all_applications'),
                'permission_callback' => array($this, 'check_admin_permissions'),
            ),
        ));

        // Authenticated user's applications
        register_rest_route($this->namespace, '/my-finance-applications', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array($this, 'get_my_applications'),
                'permission_callback' => array($this, 'check_user_permissions'),
            ),
        ));

        // Admin update status endpoint
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)/status', array(
            array(
                'methods'             => array('POST', 'PATCH'),
                'callback'            => array($this, 'update_application_status'),
                'permission_callback' => array($this, 'check_admin_permissions'),
            ),
        ));

        // Admin delete endpoint — permanently removes a single application
        // record (e.g. test submissions). Hard delete, admin-only, same
        // permission gate as the rest of the admin queue.
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => array($this, 'delete_application'),
                'permission_callback' => array($this, 'check_admin_permissions'),
            ),
        ));
    }

    /**
     * Check if request is from an authenticated user
     */
    public function check_user_permissions() {
        return is_user_logged_in();
    }

    /**
     * Check if request is from a user with carzuri_admin role or capability
     */
    public function check_admin_permissions() {
        if (!is_user_logged_in()) {
            return new WP_Error('rest_forbidden', __('You must be logged in to access this resource.', 'carzuri-finance'), array('status' => 401));
        }

        $user = wp_get_current_user();
        if (in_array('carzuri_admin', (array) $user->roles) || current_user_can('manage_carzuri_finance') || current_user_can('manage_options')) {
            return true;
        }

        return new WP_Error('rest_forbidden', __('You do not have administrative permissions to review applications.', 'carzuri-finance'), array('status' => 403));
    }

    /**
     * POST carzuri/v1/finance-applications
     */
    public function create_application($request) {
        $params = $request->get_params();

        // Validate required fields
        if (empty($params['applicant_name']) || empty($params['applicant_email']) || empty($params['applicant_phone'])) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => __('Please fill in all required contact information (Name, Email, Phone).', 'carzuri-finance')
            ), 400);
        }

        $user_id = is_user_logged_in() ? get_current_user_id() : null;
        $attachment_ids = array();

        // Process File Uploads using WordPress media_handle_upload() pattern
        if (!empty($_FILES)) {
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');

            foreach ($_FILES as $file_key => $file_array) {
                if (!empty($file_array['name'])) {
                    // Upload file to WordPress media library
                    $attachment_id = media_handle_upload($file_key, 0);
                    if (!is_wp_error($attachment_id)) {
                        $attachment_ids[] = $attachment_id;
                    }
                }
            }
        }

        // Store attachment IDs as JSON array in documents_json
        $documents_json = !empty($attachment_ids) ? wp_json_encode($attachment_ids) : null;

        $data = array(
            'user_id'          => $user_id,
            'vehicle_id'       => !empty($params['vehicle_id']) ? intval($params['vehicle_id']) : null,
            'applicant_name'   => sanitize_text_field($params['applicant_name']),
            'applicant_email'  => sanitize_email($params['applicant_email']),
            'applicant_phone'  => sanitize_text_field($params['applicant_phone']),
            'vehicle_price'    => isset($params['vehicle_price']) ? floatval($params['vehicle_price']) : 0.00,
            'deposit_amount'   => isset($params['deposit_amount']) ? floatval($params['deposit_amount']) : 0.00,
            'loan_term_months' => isset($params['loan_term_months']) ? intval($params['loan_term_months']) : 36,
            'status'           => 'submitted',
            'documents_json'   => $documents_json,
        );

        $application_id = Carzuri_Finance_DB::insert_application($data);

        if (!$application_id) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => __('Failed to save application to database. Please try again.', 'carzuri-finance')
            ), 500);
        }

        // Send Email Notification to site admin via carzuri_get_site_notification_email()
        Carzuri_Finance_Applications::notify_admin_new_application($application_id, $data);

        return new WP_REST_Response(array(
            'success'        => true,
            'id'             => $application_id,
            'status'         => 'submitted',
            'message'        => __('Your finance application has been submitted successfully!', 'carzuri-finance'),
            'attachment_ids' => $attachment_ids
        ), 201);
    }

    /**
     * GET carzuri/v1/my-finance-applications
     */
    public function get_my_applications($request) {
        $user_id = get_current_user_id();
        $applications = Carzuri_Finance_DB::get_user_applications($user_id);

        $formatted = array();
        foreach ($applications as $app) {
            $formatted[] = $this->format_application_response($app);
        }

        return new WP_REST_Response(array(
            'success' => true,
            'data'    => $formatted
        ), 200);
    }

    /**
     * GET carzuri/v1/finance-applications (Admin review queue)
     */
    public function get_all_applications($request) {
        $status = $request->get_param('status');
        $applications = Carzuri_Finance_DB::get_all_applications($status);

        $formatted = array();
        foreach ($applications as $app) {
            $formatted[] = $this->format_application_response($app);
        }

        return new WP_REST_Response(array(
            'success' => true,
            'data'    => $formatted
        ), 200);
    }

    /**
     * PATCH carzuri/v1/finance-applications/{id}/status
     */
    public function update_application_status($request) {
        $id = $request->get_param('id');
        $params = $request->get_json_params();
        
        if (empty($params['status'])) {
            $params = $request->get_body_params();
        }

        $new_status = isset($params['status']) ? sanitize_key($params['status']) : '';
        $allowed_statuses = array('submitted', 'under_review', 'approved', 'declined');

        if (!in_array($new_status, $allowed_statuses, true)) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => __('Invalid status value specified.', 'carzuri-finance')
            ), 400);
        }

        $updated = Carzuri_Finance_DB::update_status($id, $new_status);

        if ($updated) {
            return new WP_REST_Response(array(
                'success' => true,
                'id'      => intval($id),
                'status'  => $new_status,
                'message' => sprintf(__('Application #%d status updated to %s.', 'carzuri-finance'), $id, $new_status)
            ), 200);
        }

        return new WP_REST_Response(array(
            'success' => false,
            'message' => __('Failed to update application status.', 'carzuri-finance')
        ), 500);
    }

    /**
     * DELETE carzuri/v1/finance-applications/{id}
     *
     * Permanently removes a single application record. Admin-only (same
     * permission gate as the rest of the admin queue). This is a hard
     * delete with no undo — intended for cleaning up test submissions or
     * genuinely erroneous entries, not for normal application lifecycle
     * management (use the status endpoint — submitted/under_review/
     * approved/declined — for that instead).
     */
    public function delete_application($request) {
        $id = intval($request->get_param('id'));

        $existing = Carzuri_Finance_DB::get_application($id);
        if (!$existing) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => __('Application not found.', 'carzuri-finance')
            ), 404);
        }

        $deleted = Carzuri_Finance_DB::delete_application($id);

        if ($deleted) {
            return new WP_REST_Response(array(
                'success' => true,
                'id'      => $id,
                'message' => sprintf(__('Application #%d permanently deleted.', 'carzuri-finance'), $id)
            ), 200);
        }

        return new WP_REST_Response(array(
            'success' => false,
            'message' => __('Failed to delete application.', 'carzuri-finance')
        ), 500);
    }

    /**
     * Helper to format application DB object with document URLs and vehicle details
     */
    private function format_application_response($app) {
        $documents = array();
        if (!empty($app->documents_json)) {
            $attachment_ids = json_decode($app->documents_json, true);
            if (is_array($attachment_ids)) {
                foreach ($attachment_ids as $att_id) {
                    $url = wp_get_attachment_url($att_id);
                    $filename = get_the_title($att_id);
                    $documents[] = array(
                        'id'       => $att_id,
                        'url'      => $url ? $url : '#',
                        'filename' => $filename ? $filename : 'Document #' . $att_id
                    );
                }
            }
        }

        $vehicle_title = 'N/A';
        if (!empty($app->vehicle_id)) {
            $post = get_post($app->vehicle_id);
            if ($post) {
                $vehicle_title = $post->post_title;
            }
        }

        return array(
            'id'               => intval($app->id),
            'user_id'          => $app->user_id ? intval($app->user_id) : null,
            'vehicle_id'       => $app->vehicle_id ? intval($app->vehicle_id) : null,
            'vehicle_title'    => $vehicle_title,
            'applicant_name'   => $app->applicant_name,
            'applicant_email'  => $app->applicant_email,
            'applicant_phone'  => $app->applicant_phone,
            'vehicle_price'    => floatval($app->vehicle_price),
            'deposit_amount'   => floatval($app->deposit_amount),
            'loan_term_months' => intval($app->loan_term_months),
            'status'           => $app->status,
            'documents'        => $documents,
            'created_at'       => $app->created_at,
            'updated_at'       => $app->updated_at,
        );
    }
}
