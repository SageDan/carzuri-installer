<?php
/**
 * Database Handler for Carzuri Finance Applications
 *
 * @package Carzuri_Finance
 */

if (!defined('ABSPATH')) {
    exit;
}

class Carzuri_Finance_DB {

    public static function get_table_name() {
        global $wpdb;
        return $wpdb->prefix . 'carzuri_finance_applications';
    }

    /**
     * Create or update the wp_carzuri_finance_applications table using dbDelta
     */
    public static function create_table() {
        global $wpdb;
        $table_name = self::get_table_name();
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NULL,
            vehicle_id bigint(20) unsigned NULL,
            applicant_name varchar(255) NOT NULL,
            applicant_email varchar(255) NOT NULL,
            applicant_phone varchar(50) NOT NULL,
            vehicle_price decimal(10,2) NOT NULL DEFAULT '0.00',
            deposit_amount decimal(10,2) NOT NULL DEFAULT '0.00',
            loan_term_months int(11) NOT NULL DEFAULT '36',
            status varchar(50) NOT NULL DEFAULT 'submitted',
            documents_json longtext NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY vehicle_id (vehicle_id),
            KEY status (status)
        ) {$charset_collate};";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Insert a new application record
     */
    public static function insert_application($data) {
        global $wpdb;
        $table_name = self::get_table_name();

        $inserted = $wpdb->insert(
            $table_name,
            array(
                'user_id'          => !empty($data['user_id']) ? intval($data['user_id']) : null,
                'vehicle_id'       => !empty($data['vehicle_id']) ? intval($data['vehicle_id']) : null,
                'applicant_name'   => sanitize_text_field($data['applicant_name']),
                'applicant_email'  => sanitize_email($data['applicant_email']),
                'applicant_phone'  => sanitize_text_field($data['applicant_phone']),
                'vehicle_price'    => floatval($data['vehicle_price']),
                'deposit_amount'   => floatval($data['deposit_amount']),
                'loan_term_months' => intval($data['loan_term_months']),
                'status'           => !empty($data['status']) ? sanitize_key($data['status']) : 'submitted',
                'documents_json'   => isset($data['documents_json']) ? $data['documents_json'] : null,
                'created_at'       => current_time('mysql'),
                'updated_at'       => current_time('mysql'),
            ),
            array(
                '%d', // user_id
                '%d', // vehicle_id
                '%s', // applicant_name
                '%s', // applicant_email
                '%s', // applicant_phone
                '%f', // vehicle_price
                '%f', // deposit_amount
                '%d', // loan_term_months
                '%s', // status
                '%s', // documents_json
                '%s', // created_at
                '%s', // updated_at
            )
        );

        if ($inserted) {
            return $wpdb->insert_id;
        }

        return false;
    }

    /**
     * Get a single application by ID
     */
    public static function get_application($id) {
        global $wpdb;
        $table_name = self::get_table_name();
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", intval($id)));
    }

    /**
     * Get applications for a specific user_id
     */
    public static function get_user_applications($user_id) {
        global $wpdb;
        $table_name = self::get_table_name();
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} WHERE user_id = %d ORDER BY created_at DESC", intval($user_id)));
    }

    /**
     * Get all applications with optional status filtering
     */
    public static function get_all_applications($status = null) {
        global $wpdb;
        $table_name = self::get_table_name();

        if (!empty($status) && $status !== 'all') {
            return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} WHERE status = %s ORDER BY created_at DESC", sanitize_key($status)));
        }

        return $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY created_at DESC");
    }

    /**
     * Update application status
     */
    public static function update_status($id, $status) {
        global $wpdb;
        $table_name = self::get_table_name();

        $updated = $wpdb->update(
            $table_name,
            array(
                'status'     => sanitize_key($status),
                'updated_at' => current_time('mysql'),
            ),
            array('id' => intval($id)),
            array('%s', '%s'),
            array('%d')
        );

        return $updated !== false;
    }

    /**
     * Permanently delete a single application record by ID.
     * Used by the Admin Queue's Delete action (e.g. for removing test
     * submissions) — this is a hard delete, not a status change, and cannot
     * be undone. Does NOT delete any attached documents from the Media
     * Library (their attachment IDs live in documents_json); that's left as
     * a manual, separate cleanup step if ever needed.
     */
    public static function delete_application($id) {
        global $wpdb;
        $table_name = self::get_table_name();

        $deleted = $wpdb->delete(
            $table_name,
            array('id' => intval($id)),
            array('%d')
        );

        return $deleted !== false && $deleted > 0;
    }
}
