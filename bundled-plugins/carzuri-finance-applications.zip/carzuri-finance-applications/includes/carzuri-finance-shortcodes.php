<?php
/**
 * Shortcodes Handler for Carzuri Finance Applications
 *
 * @package Carzuri_Finance
 */

if (!defined('ABSPATH')) {
    exit;
}

class Carzuri_Finance_Shortcodes {

    public function register() {
        add_shortcode('carzuri_finance_application_form', array($this, 'render_application_form'));
        add_shortcode('carzuri_my_finance_applications', array($this, 'render_my_applications'));
        add_shortcode('carzuri_finance_admin_queue', array($this, 'render_admin_queue'));
    }

    /**
     * Shortcode: [carzuri_finance_application_form vehicle_id="123"]
     */
    public function render_application_form($atts) {
        $atts = shortcode_atts(array(
            'vehicle_id' => '',
        ), $atts, 'carzuri_finance_application_form');

        $vehicle_id = !empty($atts['vehicle_id']) ? intval($atts['vehicle_id']) : 0;
        $vehicle_price = 0;
        $vehicle_title = '';

        if ($vehicle_id > 0) {
            $post = get_post($vehicle_id);
            if ($post) {
                $vehicle_title = $post->post_title;
                // Reading carzuri_price post meta, same as Finance Calculator
                $meta_price = get_post_meta($vehicle_id, 'carzuri_price', true);
                if (!empty($meta_price) && is_numeric($meta_price)) {
                    $vehicle_price = floatval($meta_price);
                }
            }
        }

        // Read trade-in details handed off from AI Smart Valuation's "Request
        // Trade-In & Apply for Finance" link (?trade_in_make, trade_in_model,
        // trade_in_year, trade_in_value). There is no dedicated trade-in
        // column in wp_carzuri_finance_applications, so the trade-in value is
        // applied to the existing deposit_amount field — a trade-in
        // functioning as a down payment is standard practice in vehicle
        // financing — and the vehicle details are shown to the applicant in
        // an info banner so the handoff is visibly carried through, even
        // though only the numeric value is actually saved on submission.
        $trade_in_make  = isset($_GET['trade_in_make']) ? sanitize_text_field(wp_unslash($_GET['trade_in_make'])) : '';
        $trade_in_model = isset($_GET['trade_in_model']) ? sanitize_text_field(wp_unslash($_GET['trade_in_model'])) : '';
        $trade_in_year  = isset($_GET['trade_in_year']) ? absint($_GET['trade_in_year']) : 0;
        $trade_in_value = isset($_GET['trade_in_value']) ? floatval($_GET['trade_in_value']) : 0;
        $has_trade_in   = ($trade_in_value > 0);

        // Prefill user details if logged in
        $user_name = '';
        $user_email = '';
        $user_phone = '';

        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            $user_name = trim($current_user->first_name . ' ' . $current_user->last_name);
            if (empty($user_name)) {
                $user_name = $current_user->display_name;
            }
            $user_email = $current_user->user_email;
            $user_phone = get_user_meta($current_user->ID, 'phone_number', true);
        }

        // Enqueue JS & CSS
        wp_enqueue_style('carzuri-finance-styles');
        wp_enqueue_script(
            'carzuri-finance-form',
            CARZURI_FINANCE_URL . 'assets/js/carzuri-finance-form.js',
            array('jquery'),
            CARZURI_FINANCE_VERSION,
            true
        );

        wp_localize_script('carzuri-finance-form', 'carzuriFinanceVars', array(
            'restUrl' => esc_url_raw(rest_url('carzuri/v1/finance-applications')),
            'nonce'   => wp_create_nonce('wp_rest')
        ));

        ob_start();
        ?>
        <div class="carzuri-finance-wrapper carzuri-card">
            <div class="carzuri-card-header carzuri-flex-between">
            <div class="carzuri-card-title-group">
                <span class="carzuri-badge carzuri-badge-primary">
                    <svg class="carzuri-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                        <line x1="1" y1="10" x2="23" y2="10"/>
                    </svg>
                    <?php _e('Finance Application', 'carzuri-finance'); ?>
                </span>
                <h2 class="carzuri-heading-lg"><?php _e('Apply for Vehicle Financing', 'carzuri-finance'); ?></h2>
                <p class="carzuri-text-muted"><?php _e('Complete the form below to submit your financing application for review.', 'carzuri-finance'); ?></p>
            </div>
            <a href="<?php echo esc_url( home_url( '/my-finance-applications/' ) ); ?>" class="carzuri-btn carzuri-btn-sm" style="white-space: nowrap;">
                <?php _e('View My Applications', 'carzuri-finance'); ?> &rarr;
            </a>
        </div>

            <form id="carzuri-finance-form" class="carzuri-form" enctype="multipart/form-data">
                <input type="hidden" name="vehicle_id" value="<?php echo esc_attr($vehicle_id); ?>">

                <?php if (!empty($vehicle_title)) : ?>
                    <div class="carzuri-alert carzuri-alert-info">
                        <svg class="carzuri-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <line x1="12" y1="16" x2="12" y2="12"/>
                            <line x1="12" y1="8" x2="12.01" y2="8"/>
                        </svg>
                        <div>
                            <strong><?php _e('Selected Vehicle:', 'carzuri-finance'); ?></strong> <?php echo esc_html($vehicle_title); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($has_trade_in) : ?>
                    <div class="carzuri-alert carzuri-alert-info">
                        <svg class="carzuri-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                        </svg>
                        <div>
                            <strong><?php _e('Trade-In Applied:', 'carzuri-finance'); ?></strong>
                            <?php
                            $trade_in_label = trim($trade_in_year . ' ' . $trade_in_make . ' ' . $trade_in_model);
                            if ($trade_in_label) {
                                echo esc_html($trade_in_label) . ' — ';
                            }
                            $formatted_trade_in = function_exists('carzuri_format_price')
                                ? carzuri_format_price($trade_in_value)
                                : 'KSh ' . number_format($trade_in_value);
                            echo esc_html($formatted_trade_in) . ' ' . esc_html__('has been applied as your deposit below — feel free to adjust it.', 'carzuri-finance');
                            ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="carzuri-grid carzuri-grid-2">
                    <div class="carzuri-form-group">
                        <label for="applicant_name" class="carzuri-label"><?php _e('Full Name *', 'carzuri-finance'); ?></label>
                        <input type="text" id="applicant_name" name="applicant_name" class="carzuri-input" value="<?php echo esc_attr($user_name); ?>" required placeholder="<?php _e('e.g. John Doe', 'carzuri-finance'); ?>">
                    </div>

                    <div class="carzuri-form-group">
                        <label for="applicant_email" class="carzuri-label"><?php _e('Email Address *', 'carzuri-finance'); ?></label>
                        <input type="email" id="applicant_email" name="applicant_email" class="carzuri-input" value="<?php echo esc_attr($user_email); ?>" required placeholder="<?php _e('john@example.com', 'carzuri-finance'); ?>">
                    </div>
                </div>

                <div class="carzuri-grid carzuri-grid-3">
                    <div class="carzuri-form-group">
                        <label for="applicant_phone" class="carzuri-label"><?php _e('Phone Number *', 'carzuri-finance'); ?></label>
                        <input type="tel" id="applicant_phone" name="applicant_phone" class="carzuri-input" value="<?php echo esc_attr($user_phone); ?>" required placeholder="<?php _e('+1 (555) 000-0000', 'carzuri-finance'); ?>">
                    </div>

                    <div class="carzuri-form-group">
                        <label for="vehicle_price" class="carzuri-label"><?php _e('Vehicle Price (KSh)', 'carzuri-finance'); ?></label>
                        <input type="number" step="0.01" id="vehicle_price" name="vehicle_price" class="carzuri-input" value="<?php echo esc_attr($vehicle_price > 0 ? $vehicle_price : ''); ?>" placeholder="25000.00">
                    </div>

                    <div class="carzuri-form-group">
                        <label for="deposit_amount" class="carzuri-label"><?php _e('Deposit / Down Payment (KSh)', 'carzuri-finance'); ?></label>
                        <input type="number" step="0.01" id="deposit_amount" name="deposit_amount" class="carzuri-input" value="<?php echo esc_attr($has_trade_in ? $trade_in_value : '5000.00'); ?>" placeholder="5000.00">
                    </div>
                </div>

                <div class="carzuri-form-group">
                    <label for="loan_term_months" class="carzuri-label"><?php _e('Preferred Loan Term', 'carzuri-finance'); ?></label>
                    <select id="loan_term_months" name="loan_term_months" class="carzuri-select">
                        <option value="12"><?php _e('12 Months (1 Year)', 'carzuri-finance'); ?></option>
                        <option value="24"><?php _e('24 Months (2 Years)', 'carzuri-finance'); ?></option>
                        <option value="36" selected><?php _e('36 Months (3 Years)', 'carzuri-finance'); ?></option>
                        <option value="48"><?php _e('48 Months (4 Years)', 'carzuri-finance'); ?></option>
                        <option value="60"><?php _e('60 Months (5 Years)', 'carzuri-finance'); ?></option>
                        <option value="72"><?php _e('72 Months (6 Years)', 'carzuri-finance'); ?></option>
                    </select>
                </div>

                <div class="carzuri-section-divider">
                    <h3 class="carzuri-heading-sm"><?php _e('Required Documents', 'carzuri-finance'); ?></h3>
                    <p class="carzuri-text-sm carzuri-text-muted"><?php _e('Upload clear scans or photos of your government-issued ID and recent proof of income (e.g., pay stub or bank statement).', 'carzuri-finance'); ?></p>
                </div>

                <div class="carzuri-grid carzuri-grid-2">
                    <div class="carzuri-form-group">
                        <label for="id_document" class="carzuri-label">
                            <svg class="carzuri-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                                <polyline points="14 2 14 8 20 8"/>
                                <line x1="16" y1="13" x2="8" y2="13"/>
                                <line x1="16" y1="17" x2="8" y2="17"/>
                                <polyline points="10 9 9 9 8 9"/>
                            </svg>
                            <?php _e('Government-Issued ID (Passport/Driver License)', 'carzuri-finance'); ?>
                        </label>
                        <input type="file" id="id_document" name="id_document" accept=".pdf,.png,.jpg,.jpeg" class="carzuri-file-input">
                    </div>

                    <div class="carzuri-form-group">
                        <label for="income_proof" class="carzuri-label">
                            <svg class="carzuri-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/>
                                <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
                            </svg>
                            <?php _e('Proof of Income (Pay stub / Bank Statement)', 'carzuri-finance'); ?>
                        </label>
                        <input type="file" id="income_proof" name="income_proof" accept=".pdf,.png,.jpg,.jpeg" class="carzuri-file-input">
                    </div>
                </div>

                <div id="carzuri-finance-message" class="carzuri-message-container"></div>

                <div class="carzuri-form-actions">
                    <button type="submit" id="carzuri-finance-submit" class="carzuri-btn carzuri-btn-primary">
                        <svg class="carzuri-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="22" y1="2" x2="11" y2="13"/>
                            <polygon points="22 2 15 22 11 13 2 9 22 2"/>
                        </svg>
                        <?php _e('Submit Finance Application', 'carzuri-finance'); ?>
                    </button>
                </div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Shortcode: [carzuri_my_finance_applications]
     * Logged-in-only view (same login-gated pattern as [carzuri_my_inquiries])
     */
    public function render_my_applications($atts) {
        if (!is_user_logged_in()) {
            return '<div class="carzuri-alert carzuri-alert-warning">' .
                   esc_html__('Please log in to view your submitted finance applications.', 'carzuri-finance') .
                   '</div>';
        }

        wp_enqueue_style('carzuri-finance-styles');
        wp_enqueue_script(
            'carzuri-finance-my-apps',
            CARZURI_FINANCE_URL . 'assets/js/carzuri-finance-my-apps.js',
            array('jquery'),
            CARZURI_FINANCE_VERSION,
            true
        );

        wp_localize_script('carzuri-finance-my-apps', 'carzuriMyFinanceVars', array(
            'restUrl' => esc_url_raw(rest_url('carzuri/v1/my-finance-applications')),
            'nonce'   => wp_create_nonce('wp_rest')
        ));

        ob_start();
        ?>
        <div class="carzuri-finance-wrapper carzuri-card">
            <div class="carzuri-card-header">
                <div class="carzuri-card-title-group">
                    <span class="carzuri-badge carzuri-badge-secondary"><?php _e('Applicant Dashboard', 'carzuri-finance'); ?></span>
                    <h2 class="carzuri-heading-lg"><?php _e('My Finance Applications', 'carzuri-finance'); ?></h2>
                    <p class="carzuri-text-muted"><?php _e('Track the status of your current and past financing requests.', 'carzuri-finance'); ?></p>
                </div>
            </div>

            <div id="carzuri-my-apps-container" class="carzuri-my-apps-loading">
                <div class="carzuri-spinner-box">
                    <div class="carzuri-spinner"></div>
                    <span><?php _e('Loading your applications...', 'carzuri-finance'); ?></span>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Shortcode: [carzuri_finance_admin_queue]
     * Admin review queue front-end dashboard (reusing pattern from Dealer Marketplace — no reliance on wp-admin)
     */
    public function render_admin_queue($atts) {
        $user = wp_get_current_user();
        if (!is_user_logged_in() || (!in_array('carzuri_admin', (array)$user->roles) && !current_user_can('manage_carzuri_finance') && !current_user_can('manage_options'))) {
            return '<div class="carzuri-alert carzuri-alert-danger">' .
                   esc_html__('Access Denied: You must be an administrator with the carzuri_admin role to access the Finance Review Queue.', 'carzuri-finance') .
                   '</div>';
        }

        wp_enqueue_style('carzuri-finance-styles');
        wp_enqueue_script(
            'carzuri-finance-admin',
            CARZURI_FINANCE_URL . 'assets/js/carzuri-finance-admin.js',
            array('jquery'),
            CARZURI_FINANCE_VERSION,
            true
        );

        wp_localize_script('carzuri-finance-admin', 'carzuriAdminVars', array(
            'restUrl' => esc_url_raw(rest_url('carzuri/v1/finance-applications')),
            'nonce'   => wp_create_nonce('wp_rest')
        ));

        ob_start();
        ?>
        <div class="carzuri-finance-wrapper carzuri-card carzuri-admin-card">
            <div class="carzuri-card-header carzuri-flex-between">
                <div>
                    <span class="carzuri-badge carzuri-badge-admin"><?php _e('Carzuri Admin Queue', 'carzuri-finance'); ?></span>
                    <h2 class="carzuri-heading-lg"><?php _e('Finance Applications Queue', 'carzuri-finance'); ?></h2>
                    <p class="carzuri-text-muted"><?php _e('Review submissions, update status workflow, and inspect uploaded documents.', 'carzuri-finance'); ?></p>
                </div>
                <div class="carzuri-admin-filters">
                    <label for="carzuri-status-filter" class="carzuri-sr-only"><?php _e('Filter by Status', 'carzuri-finance'); ?></label>
                    <select id="carzuri-status-filter" class="carzuri-select carzuri-select-sm">
                        <option value="all"><?php _e('All Statuses', 'carzuri-finance'); ?></option>
                        <option value="submitted"><?php _e('Submitted', 'carzuri-finance'); ?></option>
                        <option value="under_review"><?php _e('Under Review', 'carzuri-finance'); ?></option>
                        <option value="approved"><?php _e('Approved', 'carzuri-finance'); ?></option>
                        <option value="declined"><?php _e('Declined', 'carzuri-finance'); ?></option>
                    </select>
                </div>
            </div>

            <!-- Responsive table container with overflow-x: auto -->
            <div class="carzuri-table-responsive">
                <table class="carzuri-table" id="carzuri-admin-queue-table">
                    <thead>
                        <tr>
                            <th><?php _e('ID', 'carzuri-finance'); ?></th>
                            <th><?php _e('Applicant', 'carzuri-finance'); ?></th>
                            <th><?php _e('Vehicle / Price', 'carzuri-finance'); ?></th>
                            <th><?php _e('Deposit & Term', 'carzuri-finance'); ?></th>
                            <th><?php _e('Documents', 'carzuri-finance'); ?></th>
                            <th><?php _e('Date Submitted', 'carzuri-finance'); ?></th>
                            <th><?php _e('Status', 'carzuri-finance'); ?></th>
                            <th><?php _e('Action', 'carzuri-finance'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="carzuri-admin-table-body">
                        <tr>
                            <td colspan="8" class="carzuri-text-center carzuri-py-4">
                                <div class="carzuri-spinner-box">
                                    <div class="carzuri-spinner"></div>
                                    <span><?php _e('Loading application queue...', 'carzuri-finance'); ?></span>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
