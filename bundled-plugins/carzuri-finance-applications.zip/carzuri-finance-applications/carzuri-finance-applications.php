<?php
/**
 * Plugin Name: Carzuri Finance Applications
 * Plugin URI:  https://carzuri.com/plugins/finance-applications
 * Description: Real finance application submission, document uploading, applicant-facing status tracking, and admin review queue for the Carzuri suite.
 * Version:     1.0.0
 * Author:      Carzuri Engineering
 * Author URI:  https://carzuri.com
 * Text Domain: carzuri-finance
 * Domain Path: /languages
 *
 * @package Carzuri_Finance
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define Plugin Constants
define('CARZURI_FINANCE_VERSION', '1.0.0');
define('CARZURI_FINANCE_FILE', __FILE__);
define('CARZURI_FINANCE_PATH', plugin_dir_path(__FILE__));
define('CARZURI_FINANCE_URL', plugin_dir_url(__FILE__));
define('CARZURI_FINANCE_DB_TABLE', 'wp_carzuri_finance_applications');

// Include Class Files
require_once CARZURI_FINANCE_PATH . 'includes/class-carzuri-finance-db.php';
require_once CARZURI_FINANCE_PATH . 'includes/class-carzuri-finance-rest.php';
require_once CARZURI_FINANCE_PATH . 'includes/class-carzuri-finance-shortcodes.php';

/**
 * Main Carzuri Finance Applications Plugin Class
 */
class Carzuri_Finance_Applications {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Activation & Deactivation hooks
        register_activation_hook(CARZURI_FINANCE_FILE, array($this, 'activate_plugin'));

        // Initialize components
        add_action('plugins_loaded', array($this, 'init_plugin'));
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
    }

    public function activate_plugin() {
        Carzuri_Finance_DB::create_table();
        $this->add_roles_and_caps();
    }

    public function add_roles_and_caps() {
        // Ensure carzuri_admin role exists with capability to manage finance applications
        if (!get_role('carzuri_admin')) {
            add_role('carzuri_admin', __('Carzuri Administrator', 'carzuri-finance'), array(
                'read' => true,
                'manage_carzuri_finance' => true,
                'upload_files' => true,
            ));
        } else {
            $role = get_role('carzuri_admin');
            $role->add_cap('manage_carzuri_finance');
        }

        // Also add capability to site administrators for convenience
        $admin_role = get_role('administrator');
        if ($admin_role) {
            $admin_role->add_cap('manage_carzuri_finance');
        }
    }

    public function init_plugin() {
        // Register Shortcodes
        $shortcodes = new Carzuri_Finance_Shortcodes();
        $shortcodes->register();
    }

    public function register_rest_routes() {
        // Register REST Routes
        $rest_controller = new Carzuri_Finance_REST();
        $rest_controller->register_routes();
    }

    public function enqueue_assets() {
        // Enqueue Design System CSS if available, plus plugin specific styles
        wp_register_style(
            'carzuri-design-system',
            CARZURI_FINANCE_URL . 'assets/css/carzuri-design-system-fallback.css',
            array(),
            CARZURI_FINANCE_VERSION
        );

        wp_enqueue_style(
            'carzuri-finance-styles',
            CARZURI_FINANCE_URL . 'assets/css/carzuri-finance.css',
            array('carzuri-design-system'),
            CARZURI_FINANCE_VERSION
        );

        // Scripts are enqueued selectively within shortcode handlers
    }

    /**
     * Helper to get notification email, conforming to Carzuri Suite standards.
     * Checks carzuri_get_site_notification_email() first, falling back to get_option('admin_email').
     */
    public static function get_notification_email() {
        if (function_exists('carzuri_get_site_notification_email')) {
            $email = carzuri_get_site_notification_email();
            if (!empty($email) && is_email($email)) {
                return $email;
            }
        }
        return get_option('admin_email');
    }

    /**
     * Send email notification on new finance application
     */
    public static function notify_admin_new_application($application_id, $data) {
        $to = self::get_notification_email();
        $subject = sprintf(__('[Carzuri Finance] New Application #%d Submitted', 'carzuri-finance'), $application_id);
        
        $body = sprintf("Hello Admin,\n\nA new finance application has been submitted on Carzuri.\n\n");
        $body .= sprintf("Application ID: #%d\n", $application_id);
        $body .= sprintf("Applicant Name: %s\n", $data['applicant_name']);
        $body .= sprintf("Applicant Email: %s\n", $data['applicant_email']);
        $body .= sprintf("Applicant Phone: %s\n", $data['applicant_phone']);
        $body .= sprintf("Vehicle ID: %s\n", $data['vehicle_id'] ? $data['vehicle_id'] : 'N/A');
        $body .= sprintf("Vehicle Price: KSh %s\n", number_format((float)$data['vehicle_price'], 2));
        $body .= sprintf("Deposit Amount: KSh %s\n", number_format((float)$data['deposit_amount'], 2));
        $body .= sprintf("Loan Term: %d months\n", (int)$data['loan_term_months']);
        $body .= sprintf("Status: %s\n\n", $data['status']);
        $body .= sprintf("View application details in the Admin Review Queue.\n\nRegards,\nCarzuri Finance System");

        $headers = array('Content-Type: text/plain; charset=UTF-8');

        return wp_mail($to, $subject, $body, $headers);
    }
}

// Instantiate
Carzuri_Finance_Applications::get_instance();
