=== Carzuri Finance Applications ===
Contributors: carzuri
Tags: finance, auto loan, vehicle financing, car loans, carzuri, application form
Requires at least: 5.8
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Real finance application submission, document upload, applicant-facing status tracking, and admin review queue for the Carzuri suite.

== Description ==

Carzuri Finance Applications is a key component of the Carzuri dealership suite. It integrates seamlessly with Carzuri Core, Vehicle Listings, and the Finance Calculator.

Features:
* Shortcode `[carzuri_finance_application_form]` with optional `vehicle_id` parameter to pre-fill vehicle pricing from `carzuri_price` post meta.
* Integrated document upload for IDs and proof of income, stored safely in WordPress Media Library and referenced in `documents_json`.
* Email notifications to site admin via `carzuri_get_site_notification_email()`.
* Shortcode `[carzuri_my_finance_applications]` providing a login-gated dashboard for applicants to check application statuses.
* Shortcode `[carzuri_finance_admin_queue]` front-end admin review queue restricted to the `carzuri_admin` role with responsive status update controls.
* Complete REST API endpoints under `/wp-json/carzuri/v1/finance-applications`.

== Installation ==

1. Upload `carzuri-finance-applications` directory to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use shortcodes `[carzuri_finance_application_form]`, `[carzuri_my_finance_applications]`, or `[carzuri_finance_admin_queue]` on any page.

== Changelog ==

= 1.0.0 =
* Initial release of Carzuri Finance Applications.
