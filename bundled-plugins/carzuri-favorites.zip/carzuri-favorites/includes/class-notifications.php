<?php
/**
 * Class-Notifications.php
 * Adds manual check trigger under Carzuri -> Settings in WordPress admin area.
 *
 * @package Carzuri_Favorites
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Carzuri_Favorites_Notifications {

    /**
     * Set up admin menu bindings and form hooks.
     */
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'register_admin_tools' ) );
        add_action( 'admin_post_carzuri_favorites_check_now', array( __CLASS__, 'process_manual_check' ) );
    }

    /**
     * Add sub-menu options under Carzuri. Falls back to Options dashboard if parent missing.
     */
    public static function register_admin_tools() {
        $parent_menu = 'options-general.php';

        add_submenu_page(
            $parent_menu,
            __( 'Favorites & Saved Searches', 'carzuri-favorites' ),
            __( 'Favorites & Alerts', 'carzuri-favorites' ),
            'manage_options',
            'carzuri-favorites-settings',
            array( __CLASS__, 'render_admin_settings_dashboard' )
        );
    }

    /**
     * Render settings page controls with a manual check trigger button.
     */
    public static function render_admin_settings_dashboard() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions to view this dashboard.', 'carzuri-favorites' ) );
        }

        // Show a completion notice when the manual alert verification is ran.
        if ( isset( $_GET['alert_checked'] ) && '1' === $_GET['alert_checked'] ) {
            ?>
            <div class="notice notice-success is-dismissible">
                <p><?php esc_html_e( 'Saved searches check completed! New alerts have been logged and synced with Carzuri Core notifications.', 'carzuri-favorites' ); ?></p>
            </div>
            <?php
        }
        ?>
        <div class="wrap carzuri-favorites-admin">
            <h1><?php esc_html_e( 'Carzuri Favorites & Saved Searches Alerts Settings', 'carzuri-favorites' ); ?></h1>
            <p><?php esc_html_e( 'Manage backgrounds, notification logs, and test saved search check triggers.', 'carzuri-favorites' ); ?></p>

            <div class="card" style="max-width: 650px; padding: 24px; margin-top: 24px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <h2 style="margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 12px;"><?php esc_html_e( 'Verify Alerts Manually', 'carzuri-favorites' ); ?></h2>
                <p style="font-size: 14px; color: #50575e; line-height: 1.5;">
                    <?php esc_html_e( 'Usually, listing alerts are automatically computed once daily via standard WordPress WP_Cron. If you want to bypass the daily interval and trigger search matches immediately, click below to evaluate all active searches for new vehicle matches.', 'carzuri-favorites' ); ?>
                </p>
                
                <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" style="margin-top: 20px;">
                    <input type="hidden" name="action" value="carzuri_favorites_check_now">
                    <?php wp_nonce_field( 'carzuri_favorites_manual_verify', 'cz_security_nonce' ); ?>
                    
                    <?php submit_button( __( 'Check Now — Trigger Alert Verifications', 'carzuri-favorites' ), 'primary', 'submit_manual_check' ); ?>
                </form>
            </div>
        </div>
        <?php
    }

    /**
     * Process the POST query from the manual trigger dashboard.
     */
    public static function process_manual_check() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized access.', 'carzuri-favorites' ) );
        }

        check_admin_referer( 'carzuri_favorites_manual_verify', 'cz_security_nonce' );

        // Include cron class if missing.
        require_once CARZURI_FAVORITES_DIR . 'includes/class-cron.php';
        Carzuri_Favorites_Cron::run_daily_check();

        // Redirect back with successful response query args.
        //
        // FIX: this settings page is registered via add_submenu_page() with
        // parent 'options-general.php' (see register_admin_tools() above),
        // so WordPress only correctly renders it — and shows the success
        // notice above — at options-general.php?page=carzuri-favorites-settings.
        // The redirect previously pointed at admin_url('admin.php'), which
        // doesn't match how the page was registered; the manual check itself
        // ran correctly the whole time, but landing on the wrong admin URL
        // meant the settings dashboard (and its notice) never actually
        // rendered afterward.
        wp_safe_redirect( add_query_arg(
            array(
                'page'          => 'carzuri-favorites-settings',
                'alert_checked' => '1'
            ),
            admin_url( 'options-general.php' )
        ) );
        exit;
    }
}
