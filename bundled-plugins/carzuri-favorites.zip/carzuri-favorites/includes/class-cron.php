<?php
/**
 * Class-Cron.php
 * Handles scheduled operations to search for new vehicle listings and generate notifications.
 *
 * @package Carzuri_Favorites
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Carzuri_Favorites_Cron {

    /**
     * Bind daily cron hooks.
     */
    public static function init() {
        add_action( 'carzuri_favorites_daily_cron', array( __CLASS__, 'run_daily_check' ) );
    }

    /**
     * Look up active alerts, check for newly published vehicles matching the filters,
     * and trigger Core notifications for match updates.
     */
    public static function run_daily_check() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'carzuri_saved_searches';

        // Fetch active notification alerts.
        $alerts = $wpdb->get_results(
            "SELECT id, user_id, search_name, filters_json, last_checked_at FROM $table_name WHERE alert_enabled = 1",
            ARRAY_A
        );

        if ( empty( $alerts ) ) {
            return;
        }

        foreach ( $alerts as $alert ) {
            $user_id      = intval( $alert['user_id'] );
            $search_name  = $alert['search_name'];
            $filters      = json_decode( $alert['filters_json'], true );
            $last_checked = $alert['last_checked_at'];

            // Query newly published vehicles since $last_checked timestamp.
            $query_args = array(
                'post_type'      => 'vehicle',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'date_query'     => array(
                    array(
                        'after'     => $last_checked,
                        'inclusive' => false,
                    ),
                ),
            );

            // Construct taxonomy and meta query parameters to match search criteria.
            $meta_query = array( 'relation' => 'AND' );
            $tax_query  = array( 'relation' => 'AND' );

            if ( ! empty( $filters ) ) {
                foreach ( $filters as $key => $value ) {
                    if ( empty( $value ) ) {
                        continue;
                    }

                    // NOTE: these case labels must match the actual filter keys stored
                    // in filters_json, which come from Carzuri Core's real REST API
                    // parameter names (make, body_type, location, price_min, price_max,
                    // year_min, mileage_max, fuel_type, transmission) — NOT the raw
                    // HTML search-bar field names or any other naming.
                    switch ( $key ) {
                        case 'make':
                            $tax_query[] = array(
                                'taxonomy' => 'vehicle_make',
                                'field'    => 'slug',
                                'terms'    => sanitize_title( $value ),
                            );
                            break;
                        case 'body_type':
                            $tax_query[] = array(
                                'taxonomy' => 'vehicle_body_type',
                                'field'    => 'slug',
                                'terms'    => sanitize_title( $value ),
                            );
                            break;
                        case 'location':
                            $tax_query[] = array(
                                'taxonomy' => 'vehicle_location',
                                'field'    => 'slug',
                                'terms'    => sanitize_title( $value ),
                            );
                            break;
                        case 'price_max':
                            // Carzuri Core's real post meta key is "carzuri_price"
                            // (not "_vehicle_price").
                            $meta_query[] = array(
                                'key'     => 'carzuri_price',
                                'value'   => floatval( $value ),
                                'type'    => 'NUMERIC',
                                'compare' => '<=',
                            );
                            break;
                        case 'price_min':
                            $meta_query[] = array(
                                'key'     => 'carzuri_price',
                                'value'   => floatval( $value ),
                                'type'    => 'NUMERIC',
                                'compare' => '>=',
                            );
                            break;
                        case 'year_min':
                            // Carzuri Core's real post meta key is "carzuri_year"
                            // (not "_vehicle_year").
                            $meta_query[] = array(
                                'key'     => 'carzuri_year',
                                'value'   => intval( $value ),
                                'type'    => 'NUMERIC',
                                'compare' => '>=',
                            );
                            break;
                        case 'mileage_max':
                            $meta_query[] = array(
                                'key'     => 'carzuri_mileage',
                                'value'   => intval( $value ),
                                'type'    => 'NUMERIC',
                                'compare' => '<=',
                            );
                            break;
                        case 'fuel_type':
                            $meta_query[] = array(
                                'key'     => 'carzuri_fuel_type',
                                'value'   => sanitize_text_field( $value ),
                                'compare' => '=',
                            );
                            break;
                        case 'transmission':
                            $meta_query[] = array(
                                'key'     => 'carzuri_transmission',
                                'value'   => sanitize_text_field( $value ),
                                'compare' => '=',
                            );
                            break;
                    }
                }
            }

            if ( count( $meta_query ) > 1 ) {
                $query_args['meta_query'] = $meta_query;
            }
            if ( count( $tax_query ) > 1 ) {
                $query_args['tax_query'] = $tax_query;
            }

            $matches_query = new WP_Query( $query_args );
            $new_matches_count = $matches_query->found_posts;

            if ( $new_matches_count > 0 ) {
                // Formulate the user alert title.
                $title = sprintf(
                    _n(
                        '%1$d new vehicle matches your saved search "%2$s"',
                        '%1$d new vehicles match your saved search "%2$s"',
                        $new_matches_count,
                        'carzuri-favorites'
                    ),
                    $new_matches_count,
                    $search_name
                );

                $message = sprintf(
                    __( 'Click to view the new listings matching your saved search "%s".', 'carzuri-favorites' ),
                    $search_name
                );

                // Build redirect path back to search listings.
                $search_link = add_query_arg( $filters, home_url( '/buy-cars/' ) );

                // Delegate alert creation to Carzuri Core's unified notification engine.
                // carzuri_create_notification() requires: $user_id, $type, $title, $message, $link (optional).
                if ( function_exists( 'carzuri_create_notification' ) ) {
                    carzuri_create_notification( $user_id, 'saved_search_alert', $title, $message, $search_link );
                }
            }

            // Update checked log date to ensure queries do not check overlapping periods.
            $wpdb->update(
                $table_name,
                array( 'last_checked_at' => current_time( 'mysql' ) ),
                array( 'id' => $alert['id'] ),
                array( '%s' ),
                array( '%d' )
            );
        }
    }
}