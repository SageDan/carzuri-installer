<?php
/**
 * Class-Shortcodes.php
 * Handles frontend shortcode registration and template loads for Favorites & Saved Searches.
 *
 * @package Carzuri_Favorites
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Carzuri_Favorites_Shortcodes {

    /**
     * Bind shortcodes to WordPress core.
     */
    public static function init() {
        add_shortcode( 'carzuri_my_favorites', array( __CLASS__, 'render_my_favorites' ) );
        add_shortcode( 'carzuri_saved_searches', array( __CLASS__, 'render_saved_searches' ) );
    }

    /**
     * Render the [carzuri_my_favorites] shortcode block.
     * Shows a login notice if not authenticated; otherwise includes the template view.
     *
     * @param array $atts Shortcode attributes.
     * @return string HTML output of shortcode block.
     */
    public static function render_my_favorites( $atts ) {
        if ( ! is_user_logged_in() ) {
            $login_url = wp_login_url( get_permalink() );
            return sprintf(
                '<div class="carzuri-auth-notice">
                    <p>%s</p>
                    <a href="%s" class="cz-btn cz-btn-primary">%s</a>
                </div>',
                esc_html__( 'Log in to view your saved favorites.', 'carzuri-favorites' ),
                esc_url( $login_url ),
                esc_html__( 'Log In', 'carzuri-favorites' )
            );
        }

        ob_start();
        $template_path = CARZURI_FAVORITES_DIR . 'templates/my-favorites-page.php';
        if ( file_exists( $template_path ) ) {
            include $template_path;
        } else {
            echo '<p>' . esc_html__( 'Favorites template not found.', 'carzuri-favorites' ) . '</p>';
        }
        return ob_get_clean();
    }

    /**
     * Render the [carzuri_saved_searches] shortcode block.
     * Shows a login notice if not authenticated; otherwise includes the template view.
     *
     * @param array $atts Shortcode attributes.
     * @return string HTML output of shortcode block.
     */
    public static function render_saved_searches( $atts ) {
        if ( ! is_user_logged_in() ) {
            $login_url = wp_login_url( get_permalink() );
            return sprintf(
                '<div class="carzuri-auth-notice">
                    <p>%s</p>
                    <a href="%s" class="cz-btn cz-btn-primary">%s</a>
                </div>',
                esc_html__( 'Log in to view your saved searches.', 'carzuri-favorites' ),
                esc_url( $login_url ),
                esc_html__( 'Log In', 'carzuri-favorites' )
            );
        }

        ob_start();
        $template_path = CARZURI_FAVORITES_DIR . 'templates/saved-searches-page.php';
        if ( file_exists( $template_path ) ) {
            include $template_path;
        } else {
            echo '<p>' . esc_html__( 'Saved searches template not found.', 'carzuri-favorites' ) . '</p>';
        }
        return ob_get_clean();
    }
}
