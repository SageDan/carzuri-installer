<?php
/**
 * Class-Rest-Extensions.php
 * Registers REST API endpoints to read, create, update, and delete saved searches.
 *
 * @package Carzuri_Favorites
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Carzuri_Favorites_REST {

    /**
     * Hook route initialization to rest_api_init.
     */
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    /**
     * Register endpoints under carzuri/v1 namespace.
     */
    public static function register_routes() {
        // Enpoint: /saved-searches
        register_rest_route( 'carzuri/v1', '/saved-searches', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( __CLASS__, 'get_saved_searches' ),
                'permission_callback' => array( __CLASS__, 'check_auth' ),
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( __CLASS__, 'create_saved_search' ),
                'permission_callback' => array( __CLASS__, 'check_auth' ),
            )
        ) );

        // Endpoint: /saved-searches/{id}
        register_rest_route( 'carzuri/v1', '/saved-searches/(?P<id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => array( __CLASS__, 'delete_saved_search' ),
                'permission_callback' => array( __CLASS__, 'check_auth' ),
            ),
            array(
                'methods'             => 'PATCH', // Supports partial edits like toggling notifications
                'callback'            => array( __CLASS__, 'update_saved_search' ),
                'permission_callback' => array( __CLASS__, 'check_auth' ),
            )
        ) );
    }

    /**
     * Standard authentication validator callback.
     */
    public static function check_auth() {
        return is_user_logged_in();
    }

    /**
     * Fetch all saved searches for the currently logged-in user.
     *
     * @param WP_REST_Request $request The REST request object.
     * @return WP_REST_Response list of saved searches.
     */
    public static function get_saved_searches( $request ) {
        global $wpdb;
        $user_id = get_current_user_id();
        $table_name = $wpdb->prefix . 'carzuri_saved_searches';

        $results = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, search_name, filters_json, alert_enabled, last_checked_at FROM $table_name WHERE user_id = %d ORDER BY id DESC",
            $user_id
        ), ARRAY_A );

        // Decode json configuration back into key-value sets for client representation.
        foreach ( $results as &$row ) {
            $row['filters'] = json_decode( $row['filters_json'], true );
            $row['alert_enabled'] = (bool) $row['alert_enabled'];
            unset( $row['filters_json'] ); // Exclude raw representation.
        }

        return rest_ensure_response( $results );
    }

    /**
     * Create a new saved search for the user.
     *
     * @param WP_REST_Request $request The REST request object containing search name and search query params.
     * @return WP_REST_Response creation status metadata.
     */
    public static function create_saved_search( $request ) {
        global $wpdb;
        $user_id = get_current_user_id();
        $table_name = $wpdb->prefix . 'carzuri_saved_searches';

        $params = $request->get_json_params();
        $search_name = isset( $params['search_name'] ) ? sanitize_text_field( $params['search_name'] ) : '';
        $filters = isset( $params['filters'] ) ? $params['filters'] : array();
        $alert_enabled = isset( $params['alert_enabled'] ) ? (bool) $params['alert_enabled'] : true;

        if ( empty( $search_name ) ) {
            return new WP_Error( 'missing_fields', __( 'Search name is required.', 'carzuri-favorites' ), array( 'status' => 400 ) );
        }

        // Sanitize filter elements.
        $sanitized_filters = array();
        foreach ( $filters as $key => $val ) {
            $sanitized_filters[ sanitize_key( $key ) ] = sanitize_text_field( $val );
        }

        $filters_json = wp_json_encode( $sanitized_filters );

        $result = $wpdb->insert(
            $table_name,
            array(
                'user_id'         => $user_id,
                'search_name'     => $search_name,
                'filters_json'    => $filters_json,
                'alert_enabled'   => $alert_enabled ? 1 : 0,
                'last_checked_at' => current_time( 'mysql' )
            ),
            array( '%d', '%s', '%s', '%d', '%s' )
        );

        if ( ! $result ) {
            return new WP_Error( 'db_insert_failed', __( 'Could not save search configuration to database.', 'carzuri-favorites' ), array( 'status' => 500 ) );
        }

        return rest_ensure_response( array(
            'success' => true,
            'id'      => $wpdb->insert_id,
            'message' => __( 'Search criteria saved successfully!', 'carzuri-favorites' )
        ) );
    }

    /**
     * Delete a saved search entry.
     *
     * @param WP_REST_Request $request The REST request containing search database ID.
     * @return WP_REST_Response deletion status confirmation.
     */
    public static function delete_saved_search( $request ) {
        global $wpdb;
        $user_id = get_current_user_id();
        $table_name = $wpdb->prefix . 'carzuri_saved_searches';
        $id = intval( $request['id'] );

        $result = $wpdb->delete(
            $table_name,
            array( 'id' => $id, 'user_id' => $user_id ),
            array( '%d', '%d' )
        );

        if ( ! $result ) {
            return new WP_Error( 'delete_failed', __( 'Saved search not found or unauthorized to delete.', 'carzuri-favorites' ), array( 'status' => 404 ) );
        }

        return rest_ensure_response( array( 'success' => true, 'message' => __( 'Saved search removed.', 'carzuri-favorites' ) ) );
    }

    /**
     * Update saved search properties (e.g. toggle notification alert state or rename).
     *
     * @param WP_REST_Request $request The REST request object.
     * @return WP_REST_Response update results.
     */
    public static function update_saved_search( $request ) {
        global $wpdb;
        $user_id = get_current_user_id();
        $table_name = $wpdb->prefix . 'carzuri_saved_searches';
        $id = intval( $request['id'] );

        $params = $request->get_json_params();
        $update_data = array();
        $format_strings = array();

        if ( isset( $params['alert_enabled'] ) ) {
            $update_data['alert_enabled'] = $params['alert_enabled'] ? 1 : 0;
            $format_strings[] = '%d';
        }

        if ( isset( $params['search_name'] ) ) {
            $update_data['search_name'] = sanitize_text_field( $params['search_name'] );
            $format_strings[] = '%s';
        }

        if ( empty( $update_data ) ) {
            return new WP_Error( 'empty_fields', __( 'No update fields provided.', 'carzuri-favorites' ), array( 'status' => 400 ) );
        }

        $result = $wpdb->update(
            $table_name,
            $update_data,
            array( 'id' => $id, 'user_id' => $user_id ),
            $format_strings,
            array( '%d', '%d' )
        );

        if ( $result === false ) {
            return new WP_Error( 'db_update_failed', __( 'Database update operation failed.', 'carzuri-favorites' ), array( 'status' => 500 ) );
        }

        return rest_ensure_response( array(
            'success' => true,
            'message' => __( 'Saved search updated successfully.', 'carzuri-favorites' ),
            'updated' => $update_data
        ) );
    }
}
