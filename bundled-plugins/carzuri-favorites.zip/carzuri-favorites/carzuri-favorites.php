<?php
/**
 * Plugin Name: Carzuri Favorites & Saved Searches
 * Plugin URI:  https://github.com/carzuri/carzuri-favorites
 * Description: Enables registered clients to save vehicle listings as favorites and store advanced filter configurations with daily alert checks. Integrates seamlessly with Carzuri Core notifications.
 * Version:     1.0.0
 * Author:      Carzuri Developer Team
 * Text Domain: carzuri-favorites
 * Domain Path: /languages
 * Requires PHP: 7.4
 * Requires at least: 5.8
 *
 * @package Carzuri_Favorites
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Define Plugin Constants.
define( 'CARZURI_FAVORITES_VERSION', '1.0.0' );
define( 'CARZURI_FAVORITES_DIR', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_FAVORITES_URL', plugin_dir_url( __FILE__ ) );

/**
 * Perform Dependency checks on "init" hook at priority 30
 * to ensure that Carzuri Core custom post types and Listings grids are fully loaded first.
 */
add_action( 'init', 'carzuri_favorites_init', 30 );
function carzuri_favorites_init() {
    
    // 1. Dependency checks.
    $dependency_missing = false;
    $missing_plugin = '';

    // Check 1: Vehicle Custom Post Type exists (Confirms Core is active).
    if ( ! post_type_exists( 'vehicle' ) ) {
        $dependency_missing = true;
        $missing_plugin = 'Carzuri Core (vehicle post type is missing)';
    }
    
    // Check 2: Core's helper function exists (Confirms Core's helpers are loaded).
    if ( ! $dependency_missing && ! function_exists( 'carzuri_get_vehicle_data' ) ) {
        $dependency_missing = true;
        $missing_plugin = 'Carzuri Core (carzuri_get_vehicle_data function is missing)';
    }

    // Check 3: Shortcode is registered (Confirms Listings is active).
    if ( ! $dependency_missing && ! shortcode_exists( 'carzuri_vehicle_grid' ) ) {
        $dependency_missing = true;
        $missing_plugin = 'Carzuri Listings (carzuri_vehicle_grid shortcode is missing)';
    }

    // If any dependency fails, deactivate self and show a descriptive admin notice.
    if ( $dependency_missing ) {
        carzuri_favorites_deactivate_self( $missing_plugin );
        return;
    }

    // 2. Load functional classes.
    require_once CARZURI_FAVORITES_DIR . 'includes/class-shortcodes.php';
    require_once CARZURI_FAVORITES_DIR . 'includes/class-rest-extensions.php';
    require_once CARZURI_FAVORITES_DIR . 'includes/class-cron.php';
    require_once CARZURI_FAVORITES_DIR . 'includes/class-notifications.php';

    // 3. Initialize plugin components.
    Carzuri_Favorites_Shortcodes::init();
    Carzuri_Favorites_REST::init();
    Carzuri_Favorites_Cron::init();
    Carzuri_Favorites_Notifications::init();
}

/**
 * Handle self-deactivation when dependencies are unmet, storing the error message.
 *
 * @param string $reason Description of the unmet dependency.
 */
function carzuri_favorites_deactivate_self( $reason ) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    deactivate_plugins( plugin_basename( __FILE__ ) );
    
    // Set transient for admin notice.
    set_transient( 'carzuri_favorites_activation_error', $reason, 30 );
    add_action( 'admin_notices', 'carzuri_favorites_admin_notice_failure' );
}

/**
 * Show a detailed administrator notice upon deactivation due to unmet dependencies.
 */
add_action( 'admin_notices', 'carzuri_favorites_admin_notice_failure' );
function carzuri_favorites_admin_notice_failure() {
    $reason = get_transient( 'carzuri_favorites_activation_error' );
    if ( ! $reason ) {
        return;
    }
    
    delete_transient( 'carzuri_favorites_activation_error' );
    ?>
    <div class="notice notice-error is-dismissible">
        <p>
            <strong><?php esc_html_e( 'Carzuri Favorites & Saved Searches deactivated:', 'carzuri-favorites' ); ?></strong>
            <?php echo sprintf( esc_html__( 'This plugin requires both Carzuri Core and Carzuri Listings. Reason: %s.', 'carzuri-favorites' ), esc_html( $reason ) ); ?>
        </p>
    </div>
    <?php
}

/**
 * Register plugin activation hook.
 */
register_activation_hook( __FILE__, 'carzuri_favorites_activate' );
function carzuri_favorites_activate() {
    global $wpdb;
    
    // Schema creation: wp_carzuri_saved_searches.
    $table_name = $wpdb->prefix . 'carzuri_saved_searches';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        search_name varchar(255) NOT NULL,
        filters_json longtext NOT NULL,
        alert_enabled tinyint(1) DEFAULT 1 NOT NULL,
        last_checked_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        KEY user_id (user_id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );

    // Schedule daily Cron event for alerts if not already scheduled.
    if ( ! wp_next_scheduled( 'carzuri_favorites_daily_cron' ) ) {
        wp_schedule_event( time(), 'daily', 'carzuri_favorites_daily_cron' );
    }
}

/**
 * Register plugin deactivation hook.
 */
register_deactivation_hook( __FILE__, 'carzuri_favorites_deactivate' );
function carzuri_favorites_deactivate() {
    // Clear scheduled cron task on deactivation to prevent leftover events.
    wp_clear_scheduled_hook( 'carzuri_favorites_daily_cron' );
}

/**
 * Enqueue styles and scripts.
 * Note the hard requirement of "carzuri-design-system" as a stylesheet dependency.
 */
add_action( 'wp_enqueue_scripts', 'carzuri_favorites_enqueue_assets' );
function carzuri_favorites_enqueue_assets() {
    // Enqueue the primary design stylesheet.
    wp_enqueue_style(
        'carzuri-favorites-styles',
        CARZURI_FAVORITES_URL . 'assets/css/carzuri-favorites.css',
        array( 'carzuri-design-system' ),
        CARZURI_FAVORITES_VERSION
    );

    // Enqueue favorites script.
    wp_enqueue_script(
        'carzuri-my-favorites-script',
        CARZURI_FAVORITES_URL . 'assets/js/carzuri-my-favorites.js',
        array( 'jquery' ),
        CARZURI_FAVORITES_VERSION,
        true
    );

    // Enqueue saved searches script.
    wp_enqueue_script(
        'carzuri-saved-searches-script',
        CARZURI_FAVORITES_URL . 'assets/js/carzuri-saved-searches.js',
        array( 'jquery' ),
        CARZURI_FAVORITES_VERSION,
        true
    );

    // Provide REST configurations and localization contexts.
    wp_localize_script(
        'carzuri-saved-searches-script',
        'CarzuriFavorites',
        array(
            'rest_url'     => esc_url_raw( rest_url( 'carzuri/v1' ) ),
            'nonce'        => wp_create_nonce( 'wp_rest' ),
            'is_logged_in' => is_user_logged_in(),
            'login_url'    => wp_login_url( get_permalink() )
        )
    );
}
