/**
 * Carzuri Saved Searches JS Asset
 * Performs self-contained integration on Listings archives by injecting the "Save Search" prompt,
 * and handles dashboards AJAX queries (toggles, deletions).
 */
jQuery(document).ready(function($) {

    var filterParams = {};

    /**
     * Check the current URL for tracked filter params and, if any are active,
     * inject the "Save this search" prompt near Listings' search filter bar
     * (unless it's already been injected once).
     *
     * This needs to be callable multiple times, not just once on page load,
     * because Carzuri Listings filters vehicles via AJAX (fetch), which never
     * causes a real page reload — so document.ready only fires once, before
     * any search has actually happened. Listings dispatches a custom
     * "carzuriFiltersUpdated" event after each filtered search completes and
     * updates the URL via history.pushState; we listen for that event below
     * and re-run this check at that point.
     */
    function checkAndInjectSaveSearchPrompt() {
        // Don't inject twice if it's already there from a previous check.
        if ($('#cz-trigger-save-search').length > 0) {
            return;
        }

        var urlParams = new URLSearchParams(window.location.search);
        filterParams = {};
        var hasActiveFilters = false;

        // Note: these must match the actual REST query parameter names Carzuri Core's
        // /vehicles endpoint expects (make, body_type, location, price_min, price_max,
        // year_min, mileage_max, fuel_type, transmission) — NOT the raw HTML form field
        // names used in the search bar markup, since Listings' JS translates those
        // before they ever reach the URL/REST request.
        var trackedParams = ['make', 'body_type', 'price_max', 'price_min', 'year_min', 'mileage_max', 'location', 'fuel_type', 'transmission'];

        trackedParams.forEach(function(param) {
            if (urlParams.has(param) && urlParams.get(param) !== '') {
                filterParams[param] = urlParams.get(param);
                hasActiveFilters = true;
            }
        });

        // Note: Carzuri Listings' search-filter-bar.php template's real outer wrapper
        // class is "carzuri-search-filter-container" (confirmed from the actual
        // deployed template), not "carzuri-search-filter-bar" or "carzuri-filter-wrapper".
        if (hasActiveFilters && $('.carzuri-search-filter-container').length > 0) {
            var targetContainer = $('.carzuri-search-filter-container');

            var savePromptHtml =
                '<div class="carzuri-save-search-prompt">' +
                '  <span style="font-size: 14px; color: #4a5568; font-weight: 500;">Love this criteria? Keep tabs on newly matching uploads.</span>' +
                '  <button id="cz-trigger-save-search" class="cz-btn cz-btn-secondary" style="background: #1a202c; color: #fff; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-weight: 600;">' +
                '    Save This Search' +
                '  </button>' +
                '</div>' +
                '<div id="cz-save-search-modal" class="cz-modal" style="display:none;">' +
                '  <div class="cz-modal-content">' +
                '    <h3>Save Your Search</h3>' +
                '    <p class="cz-modal-desc">Receive real-time dashboard notifications when matching vehicles get published.</p>' +
                '    <div class="cz-form-group">' +
                '      <label for="cz-search-title">Name your search criteria</label>' +
                '      <input type="text" id="cz-search-title" placeholder="e.g. BMW Sedans under 4M" class="cz-input">' +
                '    </div>' +
                '    <div class="cz-form-group cz-checkbox-group" style="margin-top: 16px;">' +
                '      <input type="checkbox" id="cz-alert-toggle" checked style="cursor:pointer;">' +
                '      <label for="cz-alert-toggle" style="cursor:pointer;">Enable new match notification alerts</label>' +
                '    </div>' +
                '    <div class="cz-modal-actions">' +
                '      <button id="cz-modal-close" class="cz-btn" style="background:#e2e8f0; border:none; padding:8px 16px; border-radius:4px; cursor:pointer;">Cancel</button>' +
                '      <button id="cz-modal-save-submit" class="cz-btn" style="background:#1a202c; color:#fff; border:none; padding:8px 16px; border-radius:4px; cursor:pointer; font-weight:600;">Save Search</button>' +
                '    </div>' +
                '  </div>' +
                '</div>';

            targetContainer.after(savePromptHtml);
        } else if (!hasActiveFilters) {
            // Filters were cleared/reset — remove the prompt if it's currently showing.
            $('.carzuri-save-search-prompt').remove();
            $('#cz-save-search-modal').remove();
        }
    }

    // Run once on initial page load (will typically find no active filters yet,
    // since Listings hasn't performed any AJAX search at this point).
    checkAndInjectSaveSearchPrompt();

    // Re-run every time Carzuri Listings finishes a filtered AJAX search.
    document.addEventListener('carzuriFiltersUpdated', checkAndInjectSaveSearchPrompt);

    // Modal Trigger click event
    $(document).on('click', '#cz-trigger-save-search', function(e) {
        e.preventDefault();
        
        // Check localization data to prompt sign-in first.
        if (!CarzuriFavorites.is_logged_in) {
            window.location.href = CarzuriFavorites.login_url;
            return;
        }

        $('#cz-save-search-modal').fadeIn(200);
    });

    // Modal Close
    $(document).on('click', '#cz-modal-close', function(e) {
        e.preventDefault();
        $('#cz-save-search-modal').fadeOut(150);
    });

    // REST POST - Create saved search
    $(document).on('click', '#cz-modal-save-submit', function(e) {
        e.preventDefault();
        
        var name = $('#cz-search-title').val().trim();
        var alertOn = $('#cz-alert-toggle').is(':checked');

        if (!name) {
            alert('Please specify a label for this saved search.');
            return;
        }

        $.ajax({
            url: CarzuriFavorites.rest_url + '/saved-searches',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', CarzuriFavorites.nonce);
            },
            data: JSON.stringify({
                search_name: name,
                filters: filterParams,
                alert_enabled: alertOn
            }),
            contentType: 'application/json',
            success: function(response) {
                $('#cz-save-search-modal').fadeOut(150);
                alert('Search query successfully saved! You can manage alerts in your dashboard.');
            },
            error: function(err) {
                alert('Could not save criteria. Please re-authenticate and retry.');
            }
        });
    });

    // REST PATCH - Toggle alerts on/off
    $('.cz-search-alert-toggle').on('change', function() {
        var id = $(this).data('id');
        var checked = $(this).is(':checked');

        $.ajax({
            url: CarzuriFavorites.rest_url + '/saved-searches/' + id,
            method: 'PATCH',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', CarzuriFavorites.nonce);
            },
            data: JSON.stringify({
                alert_enabled: checked
            }),
            contentType: 'application/json'
        });
    });

    // REST DELETE - Delete saved search
    $('.cz-delete-search-btn').on('click', function(e) {
        e.preventDefault();
        
        var id = $(this).data('id');
        var $card = $(this).closest('.carzuri-search-card');

        if (confirm('Are you sure you want to permanently remove this saved search criteria?')) {
            $.ajax({
                url: CarzuriFavorites.rest_url + '/saved-searches/' + id,
                method: 'DELETE',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', CarzuriFavorites.nonce);
                },
                success: function(response) {
                    $card.slideUp(250, function() {
                        $card.remove();
                    });
                }
            });
        }
    });
});