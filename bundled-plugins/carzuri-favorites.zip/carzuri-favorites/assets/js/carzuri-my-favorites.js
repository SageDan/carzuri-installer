/**
 * Carzuri My Favorites JS Asset
 * Listens to active heart/favorites togglers on the My Favorites view, and triggers
 * fade-and-slide collapsing transitions rather than standard checkbox mutations.
 */
jQuery(document).ready(function($) {
    
    // Bind to the parent favorites grid container.
    $('.carzuri-favorites-grid').on('click', '.cz-favorite-heart, .favorite-toggle-btn', function(e) {
        e.preventDefault();
        
        var $card = $(this).closest('.vehicle-card');
        
        // Add the removing transition class.
        $card.addClass('removing');
        
        // Wait for CSS transitions to finish before altering DOM structure.
        setTimeout(function() {
            $card.remove();
            
            // Check if there are any listings remaining. If empty, swap in the empty state.
            if ($('.carzuri-favorites-grid .vehicle-card').length === 0) {
                $('.carzuri-favorites-grid').replaceWith(
                    '<div class="carzuri-favorites-empty" style="text-align: center; padding: 60px 24px; border: 1px dashed #e2e8f0; border-radius: 8px; background: #fafafa;">' +
                    '  <p style="font-size: 16px; color: #4a5568; margin-bottom: 24px;">You haven\'t saved any favorites yet — start browsing to save vehicles you like</p>' +
                    '  <a href="/buy-cars/" class="cz-btn cz-btn-primary" style="text-decoration: none; padding: 12px 24px; border-radius: 4px; font-weight: 600; display: inline-block;">Browse Vehicles</a>' +
                    '</div>'
                );
            }
        }, 400);
    });
});
