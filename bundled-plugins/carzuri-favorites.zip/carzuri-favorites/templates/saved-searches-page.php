<?php
/**
 * Template for displaying Saved Searches Dashboard via shortcode [carzuri_saved_searches].
 * Displays search cards, filters pill listings, toggles, run-search pathways, and deletability.
 *
 * @package Carzuri_Favorites
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

global $wpdb;
$user_id = get_current_user_id();
$table_name = $wpdb->prefix . 'carzuri_saved_searches';

$saved_searches = $wpdb->get_results( $wpdb->prepare(
    "SELECT id, search_name, filters_json, alert_enabled FROM $table_name WHERE user_id = %d ORDER BY id DESC",
    $user_id
), ARRAY_A );

// Handle empty dashboard condition.
if ( empty( $saved_searches ) ) {
    ?>
    <div class="carzuri-saved-searches-empty" style="text-align: center; padding: 60px 24px; border: 1px dashed #e2e8f0; border-radius: 8px; background: #fafafa;">
        <p style="font-size: 16px; color: #4a5568; margin-bottom: 24px;">
            <?php esc_html_e( "You don't have any saved searches yet. Go filter vehicles and click 'Save This Search'.", 'carzuri-favorites' ); ?>
        </p>
        <a href="<?php echo esc_url( home_url( '/buy-cars/' ) ); ?>" class="cz-btn cz-btn-primary" style="text-decoration: none; padding: 12px 24px; border-radius: 4px; font-weight: 600; display: inline-block;">
            <?php esc_html_e( 'Browse Vehicles', 'carzuri-favorites' ); ?>
        </a>
    </div>
    <?php
    return;
}
?>
<div class="carzuri-saved-searches-container">
    <div class="carzuri-saved-searches-header" style="margin-bottom: 24px;">
        <h2 style="font-size: 24px; color: #1a202c; font-weight: 700; margin: 0 0 6px 0;">
            <?php esc_html_e( 'Your Saved Searches', 'carzuri-favorites' ); ?>
        </h2>
        <p style="font-size: 14px; color: #718096; margin: 0;">
            <?php esc_html_e( 'Receive alerts for new listings and run criteria checks instantly.', 'carzuri-favorites' ); ?>
        </p>
    </div>

    <div class="carzuri-saved-searches-list">
        <?php foreach ( $saved_searches as $search ) : 
            $filters = json_decode( $search['filters_json'], true );
            $pills_markup = array();

            if ( ! empty( $filters ) ) {
                foreach ( $filters as $key => $value ) {
                    if ( empty( $value ) ) {
                        continue;
                    }

                    // Format parameter tags beautifully for visitors.
                    $label = ucwords( str_replace( '_', ' ', $key ) );
                    $display_value = $value;

                    if ( 'max_price' === $key ) {
                        $display_value = 'KSh ' . number_format( floatval( $value ) );
                    } elseif ( 'min_price' === $key ) {
                        $display_value = 'KSh ' . number_format( floatval( $value ) );
                    }

                    $pills_markup[] = sprintf(
                        '<span class="carzuri-filter-pill"><strong>%s:</strong> %s</span>',
                        esc_html( $label ),
                        esc_html( $display_value )
                    );
                }
            }

            $filters_summary = implode( ' • ', $pills_markup );
            $search_url = add_query_arg( $filters, home_url( '/buy-cars/' ) );
            ?>
            <div class="carzuri-search-card" data-id="<?php echo intval( $search['id'] ); ?>" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                <div class="carzuri-search-info" style="flex: 1; padding-right: 20px;">
                    <h3 style="font-size: 18px; color: #2d3748; font-weight: 600; margin: 0 0 8px 0;">
                        <?php echo esc_html( $search['search_name'] ); ?>
                    </h3>
                    <div class="carzuri-search-filters">
                        <?php echo $filters_summary ? $filters_summary : esc_html__( 'All Vehicles (No Filters)', 'carzuri-favorites' ); ?>
                    </div>
                </div>
                
                <div class="carzuri-search-actions" style="display: flex; align-items: center; gap: 20px;">
                    <a href="<?php echo esc_url( $search_url ); ?>" class="cz-btn cz-btn-secondary" style="text-decoration: none; padding: 8px 16px; border: 1px solid #cbd5e0; border-radius: 4px; color: #4a5568; font-size: 14px; font-weight: 500; background: #fff;">
                        <?php esc_html_e( 'Run Search', 'carzuri-favorites' ); ?>
                    </a>

                    <div class="cz-alert-toggle-box" style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 13px; color: #4a5568; font-weight: 500;"><?php esc_html_e( 'Alerts', 'carzuri-favorites' ); ?></span>
                        <label class="cz-switch">
                            <input type="checkbox" class="cz-search-alert-toggle" data-id="<?php echo intval( $search['id'] ); ?>" <?php checked( $search['alert_enabled'], 1 ); ?>>
                            <span class="cz-slider"></span>
                        </label>
                    </div>

                    <button class="cz-delete-search-btn" data-id="<?php echo intval( $search['id'] ); ?>" style="background: none; border: none; color: #e53e3e; font-size: 14px; font-weight: 600; cursor: pointer; padding: 0;">
                        <?php esc_html_e( 'Delete', 'carzuri-favorites' ); ?>
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
