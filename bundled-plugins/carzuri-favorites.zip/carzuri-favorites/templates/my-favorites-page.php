<?php
/**
 * Template for displaying My Favorites Page via shortcode [carzuri_my_favorites].
 * Reuses Listings' custom card element securely.
 *
 * @package Carzuri_Favorites
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

global $wpdb;
$user_id = get_current_user_id();
$table_favorites = $wpdb->prefix . 'carzuri_favorites'; // Core table is the single source of truth.

// Fetch favorited vehicle IDs for the current logged-in user.
$vehicle_ids = $wpdb->get_col( $wpdb->prepare(
    "SELECT vehicle_id FROM $table_favorites WHERE user_id = %d ORDER BY id DESC",
    $user_id
) );

// Handle the empty state when no favorites exist yet.
if ( empty( $vehicle_ids ) ) {
    ?>
    <div class="carzuri-favorites-empty" style="text-align: center; padding: 60px 24px; border: 1px dashed #e2e8f0; border-radius: 8px; background: #fafafa;">
        <p style="font-size: 16px; color: #4a5568; margin-bottom: 24px;">
            <?php esc_html_e( "You haven't saved any favorites yet — start browsing to save vehicles you like", 'carzuri-favorites' ); ?>
        </p>
        <a href="<?php echo esc_url( home_url( '/buy-cars/' ) ); ?>" class="cz-btn cz-btn-primary" style="text-decoration: none; padding: 12px 24px; border-radius: 4px; font-weight: 600; display: inline-block;">
            <?php esc_html_e( 'Browse Vehicles', 'carzuri-favorites' ); ?>
        </a>
    </div>
    <?php
    return;
}

// Set up WP_Query to display active favorited vehicles.
$query_args = array(
    'post_type'      => 'vehicle',
    'post_status'    => 'publish',
    'post__in'       => $vehicle_ids,
    'orderby'        => 'post__in', // Maintain the order added.
    'posts_per_page' => -1,
);

$favorites_query = new WP_Query( $query_args );

if ( $favorites_query->have_posts() ) {
    ?>
    <div class="carzuri-favorites-grid">
        <?php
        while ( $favorites_query->have_posts() ) {
            $favorites_query->the_post();
            
            // Reuse Listings' vehicle-card template by accessing its constant path.
            if ( defined( 'CARZURI_LISTINGS_DIR' ) ) {
                $card_template = CARZURI_LISTINGS_DIR . 'templates/vehicle-card.php';
                if ( file_exists( $card_template ) ) {
                    include $card_template;
                } else {
                    echo '<p class="error">' . esc_html__( 'Vehicle card template missing inside Carzuri Listings.', 'carzuri-favorites' ) . '</p>';
                }
            } else {
                echo '<p class="error">' . esc_html__( 'Active Listings plugin is required to render vehicle grids.', 'carzuri-favorites' ) . '</p>';
            }
        }
        wp_reset_postdata();
        ?>
    </div>
    <?php
} else {
    ?>
    <div class="carzuri-favorites-empty" style="text-align: center; padding: 60px 24px; border: 1px dashed #e2e8f0; border-radius: 8px; background: #fafafa;">
        <p style="font-size: 16px; color: #4a5568; margin-bottom: 24px;">
            <?php esc_html_e( 'The vehicles you favorited are no longer active on our catalog.', 'carzuri-favorites' ); ?>
        </p>
        <a href="<?php echo esc_url( home_url( '/buy-cars/' ) ); ?>" class="cz-btn cz-btn-primary" style="text-decoration: none; padding: 12px 24px; border-radius: 4px; font-weight: 600; display: inline-block;">
            <?php esc_html_e( 'Browse Vehicles', 'carzuri-favorites' ); ?>
        </a>
    </div>
    <?php
}
