<?php
/**
 * Vehicle Card Template.
 * Reusable layout for displaying a single vehicle summary.
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$post_id    = get_the_ID();
$is_featured = get_post_meta( $post_id, 'carzuri_featured', true ) === '1';
$is_new      = ( ( time() - get_the_time( 'U', $post_id ) ) < ( 14 * DAY_IN_SECONDS ) );

$price      = get_post_meta( $post_id, 'carzuri_price', true );
$year       = get_post_meta( $post_id, 'carzuri_year', true );
$fuel       = get_post_meta( $post_id, 'carzuri_fuel_type', true );
$mileage    = get_post_meta( $post_id, 'carzuri_mileage', true );

$location_terms = wp_get_post_terms( $post_id, 'vehicle_location', array( 'fields' => 'names' ) );
$location       = ! empty( $location_terms ) ? $location_terms[0] : 'Nairobi';

// Format mileage
$formatted_mileage = $mileage ? number_format( $mileage ) . ' km' : 'N/A';

// Format price using Core's helper, or fallback to native formatting if not exists
$display_price = '';
if ( function_exists( 'carzuri_format_price' ) ) {
	$display_price = carzuri_format_price( $price );
} else {
	$display_price = 'KSh ' . number_format( $price );
}

// Check if this vehicle is in the user's favorites list
$is_favorited = false;
if ( is_user_logged_in() ) {
	global $wpdb;
	$table_fav = $wpdb->prefix . 'carzuri_favorites';
	if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_fav'" ) === $table_fav ) {
		$is_fav_db = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $table_fav WHERE user_id = %d AND vehicle_id = %d",
			get_current_user_id(),
			$post_id
		) );
		$is_favorited = $is_fav_db > 0;
	} else {
		// Mock favorites session/option
		$mock_favs = get_user_meta( get_current_user_id(), 'carzuri_mock_favorites', true );
		if ( is_array( $mock_favs ) && in_array( $post_id, $mock_favs ) ) {
			$is_favorited = true;
		}
	}
}
?>

<div class="carzuri-vehicle-card" data-vehicle-id="<?php echo esc_attr( $post_id ); ?>" style="background-color: #121A2E; border-radius: 12px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05); display: flex; flex-direction: column; position: relative; cursor: pointer; transition: transform 0.2s, box-shadow 0.2s; box-sizing: border-box; height: 100%;">
	
	<!-- Top: Thumbnail area -->
	<div class="cz-card-thumbnail" style="position: relative; padding-top: 60%; background-color: #0A111F; overflow: hidden;">
		<a href="<?php the_permalink(); ?>" class="cz-card-link-overlay" style="position: absolute; top:0; left:0; width:100%; height:100%; z-index:1;">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'medium_large', array( 'style' => 'position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover; transition: transform 0.3s;' ) ); ?>
			<?php else : ?>
				<div style="position:absolute; top:0; left:0; width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:#1E293B; color:#4B5563; font-size:12px;">No Image Available</div>
			<?php endif; ?>
		</a>

		<!-- Badges (Top-Left) -->
		<div class="cz-badge-container" style="position: absolute; top: 12px; left: 12px; display: flex; gap: 6px; z-index: 2;">
			<?php if ( $is_featured ) : ?>
				<span class="cz-badge-featured" style="background-color: var(--cz-color-gold, #D4AF37); color: #0A111F; font-size: 10px; font-weight: 800; padding: 4px 8px; border-radius: 4px; text-transform: uppercase;">FEATURED</span>
			<?php endif; ?>
			<?php if ( $is_new ) : ?>
				<span class="cz-badge-new" style="background-color: #EF4444; color: #FFFFFF; font-size: 10px; font-weight: 800; padding: 4px 8px; border-radius: 4px; text-transform: uppercase;">NEW</span>
			<?php endif; ?>
		</div>

		<!-- Heart/Favorite Button (Top-Right) -->
		<button class="cz-favorite-toggle-btn" data-vehicle-id="<?php echo esc_attr( $post_id ); ?>" aria-label="<?php esc_attr_e( 'Toggle Favorite', 'carzuri-listings' ); ?>" style="position: absolute; top: 12px; right: 12px; background: rgba(10, 17, 31, 0.6); backdrop-filter: blur(4px); border: none; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 3; color: <?php echo $is_favorited ? 'var(--cz-color-gold, #D4AF37)' : '#FFFFFF'; ?>; transition: transform 0.15s;">
			<svg width="18" height="18" viewBox="0 0 24 24" fill="<?php echo $is_favorited ? 'currentColor' : 'none'; ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
				<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
			</svg>
		</button>

		<!-- Saved Toast Prompt for Non-Logged-in user -->
		<div class="cz-save-prompt" style="display: none; position: absolute; top: 50px; right: 12px; background-color: #EF4444; color: #FFFFFF; padding: 6px 10px; border-radius: 4px; font-size: 11px; z-index: 4; box-shadow: 0 4px 6px rgba(0,0,0,0.1); white-space: nowrap;">
			<a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" style="color: #FFFFFF; font-weight: 700; text-decoration: underline;"><?php esc_html_e( 'Log in', 'carzuri-listings' ); ?></a> <?php esc_html_e( 'to save favorites', 'carzuri-listings' ); ?>
		</div>
	</div>

	<!-- Bottom: Body area -->
	<div class="cz-card-body" style="padding: 16px; display: flex; flex-direction: column; flex-grow: 1; position: relative;">
		
		<!-- Listing Title -->
		<h3 class="cz-card-title" style="margin: 0 0 6px 0; font-size: 15px; font-weight: 700; color: #FFFFFF; font-family: var(--cz-font-sans, sans-serif); line-height: 1.4;">
			<a href="<?php the_permalink(); ?>" style="color: #FFFFFF; text-decoration: none; z-index: 2; position: relative;">
				<?php the_title(); ?>
			</a>
		</h3>

		<!-- Price -->
		<div class="cz-card-price" style="font-size: 18px; font-weight: 800; color: var(--cz-color-gold, #D4AF37); margin-bottom: 12px;">
			<?php echo esc_html( $display_price ); ?>
		</div>

		<!-- Specs row -->
		<div class="cz-card-specs-row" style="display: flex; gap: 12px; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 12px; margin-bottom: 12px; flex-wrap: wrap;">
			
			<!-- Year spec -->
			<div class="cz-spec-item" style="display: flex; align-items: center; gap: 4px; color: #9CA3AF; font-size: 11px;">
				<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
				</svg>
				<span><?php echo esc_html( $year ? $year : 'N/A' ); ?></span>
			</div>

			<!-- Fuel Type spec -->
			<div class="cz-spec-item" style="display: flex; align-items: center; gap: 4px; color: #9CA3AF; font-size: 11px;">
				<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M3 22V4a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v18M14 22V4M6 12h3M6 16h3M18 12h3M18 16h3"/>
				</svg>
				<span><?php echo esc_html( $fuel ? $fuel : 'N/A' ); ?></span>
			</div>

			<!-- Mileage spec -->
			<div class="cz-spec-item" style="display: flex; align-items: center; gap: 4px; color: #9CA3AF; font-size: 11px;">
				<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
				</svg>
				<span><?php echo esc_html( $formatted_mileage ); ?></span>
			</div>

		</div>

		<!-- Location footer row -->
		<div class="cz-card-location" style="display: flex; align-items: center; gap: 4px; color: #9CA3AF; font-size: 11px; margin-top: auto; border-top: 1px solid rgba(255,255,255,0.03); padding-top: 8px;">
			<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
				<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
			</svg>
			<span><?php echo esc_html( $location ); ?></span>
		</div>

	</div>

</div>

