<?php
/**
 * Search and Filter Bar Template.
 * Rendered by the [carzuri_search_bar] shortcode.
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="carzuri-search-filter-container">
	<form id="carzuri-listings-filter-form" action="" method="GET">
		
		<!-- Main horizontal filters grid -->
		<div class="cz-filter-main-row" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)) 150px; gap: 12px; align-items: end;">
			
			<!-- Make Filter -->
			<div class="cz-filter-col">
				<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">MAKE</label>
				<select name="vehicle_make" id="cz-make-dropdown" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px;">
					<option value=""><?php esc_html_e( 'All Makes', 'carzuri-listings' ); ?></option>
					<?php foreach ( $makes as $make ) : ?>
						<option value="<?php echo esc_attr( $make->slug ); ?>"><?php echo esc_html( $make->name ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>

			<!-- Model Filter (Dependent on Make) -->
			<div class="cz-filter-col">
				<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">MODEL</label>
				<select name="vehicle_model" id="cz-model-dropdown" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px;" disabled>
					<option value=""><?php esc_html_e( 'All Models', 'carzuri-listings' ); ?></option>
				</select>
			</div>

			<!-- Body Type Filter -->
			<div class="cz-filter-col">
				<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">BODY TYPE</label>
				<select name="vehicle_body_type" id="cz-body-type-dropdown" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px;">
					<option value=""><?php esc_html_e( 'All Body Types', 'carzuri-listings' ); ?></option>
					<?php foreach ( $body_types as $body_type ) : ?>
						<option value="<?php echo esc_attr( $body_type->slug ); ?>"><?php echo esc_html( $body_type->name ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>

			<!-- Max Price Filter -->
			<div class="cz-filter-col">
				<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">MAX PRICE</label>
				<select name="max_price" id="cz-price-dropdown" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px;">
					<option value=""><?php esc_html_e( 'Any Price', 'carzuri-listings' ); ?></option>
					<option value="1000000"><?php esc_html_e( 'Under 1.0M KSh', 'carzuri-listings' ); ?></option>
					<option value="3000000"><?php esc_html_e( '1.0M - 3.0M KSh', 'carzuri-listings' ); ?></option>
					<option value="5000000"><?php esc_html_e( '3.0M - 5.0M KSh', 'carzuri-listings' ); ?></option>
					<option value="10000000"><?php esc_html_e( '5.0M - 10.0M KSh', 'carzuri-listings' ); ?></option>
					<option value="999999999"><?php esc_html_e( '10.0M+ KSh', 'carzuri-listings' ); ?></option>
				</select>
			</div>

			<!-- Year Filter -->
			<div class="cz-filter-col">
				<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">YEAR</label>
				<select name="vehicle_year" id="cz-year-dropdown" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px;">
					<option value=""><?php esc_html_e( 'Any Year', 'carzuri-listings' ); ?></option>
					<?php 
					$current_year = intval( date( 'Y' ) );
					for ( $y = $current_year; $y >= $current_year - 4; $y-- ) {
						echo '<option value="' . esc_attr( $y ) . '">' . esc_html( $y ) . '</option>';
					}
					?>
					<option value="older"><?php esc_html_e( 'Older', 'carzuri-listings' ); ?></option>
				</select>
			</div>

			<!-- Submit Button -->
			<div class="cz-filter-col">
				<button type="submit" id="cz-search-submit-btn" style="width: 100%; background-color: var(--cz-color-gold, #D4AF37); color: #0A111F; font-weight: 700; border: none; border-radius: 6px; padding: 12px; font-size: 12px; letter-spacing: 0.5px; text-transform: uppercase; cursor: pointer; transition: background-color 0.2s;">
					🔍 SEARCH CARS
				</button>
			</div>

		</div>

		<!-- Advanced search toggle -->
		<div style="margin-top: 14px; text-align: left;">
			<a href="#" id="cz-advanced-search-toggle" style="color: var(--cz-color-gold, #D4AF37); font-size: 12px; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; gap: 4px;">
				<span class="cz-toggle-icon">▼</span> Advanced Search
			</a>
		</div>

		<!-- Expandable Advanced Search Area -->
		<div id="cz-advanced-filters-drawer" style="display: none; margin-top: 16px; border-top: 1px solid rgba(255, 255, 255, 0.05); padding-top: 16px;">
			<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px;">
				
				<!-- Mileage Max Filter -->
				<div>
					<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">MAX MILEAGE (KM)</label>
					<input type="number" name="max_mileage" placeholder="e.g. 100000" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px; box-sizing: border-box;">
				</div>

				<!-- Fuel Type Filter -->
				<div>
					<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">FUEL TYPE</label>
					<select name="fuel_type" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px;">
						<option value=""><?php esc_html_e( 'Any Fuel Type', 'carzuri-listings' ); ?></option>
						<option value="Petrol"><?php esc_html_e( 'Petrol', 'carzuri-listings' ); ?></option>
						<option value="Diesel"><?php esc_html_e( 'Diesel', 'carzuri-listings' ); ?></option>
						<option value="Hybrid"><?php esc_html_e( 'Hybrid', 'carzuri-listings' ); ?></option>
						<option value="Electric"><?php esc_html_e( 'Electric', 'carzuri-listings' ); ?></option>
					</select>
				</div>

				<!-- Transmission Filter -->
				<div>
					<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">TRANSMISSION</label>
					<select name="transmission" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px;">
						<option value=""><?php esc_html_e( 'Any Transmission', 'carzuri-listings' ); ?></option>
						<option value="Automatic"><?php esc_html_e( 'Automatic', 'carzuri-listings' ); ?></option>
						<option value="Manual"><?php esc_html_e( 'Manual', 'carzuri-listings' ); ?></option>
					</select>
				</div>

				<!-- Location Filter -->
				<div>
					<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">LOCATION</label>
					<select name="vehicle_location" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px;">
						<option value=""><?php esc_html_e( 'Any Location', 'carzuri-listings' ); ?></option>
						<?php foreach ( $locations as $loc ) : ?>
							<option value="<?php echo esc_attr( $loc->slug ); ?>"><?php echo esc_html( $loc->name ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<!-- Condition Filter -->
				<div>
					<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">CONDITION</label>
					<?php
					// FIX: these option values previously were "Local Used" /
					// "Foreign Used" / "Brand New" — strings that never
					// actually exist in carzuri_condition post meta. Every
					// real vehicle (whether created via wp-admin or the
					// Dealer Marketplace form) stores exactly 'used', 'new',
					// or 'certified-pre-owned' (see Core's CPTVehicle
					// metabox and the Dealer Marketplace's Add/Edit Vehicle
					// modal — both now aligned on these same three values).
					// The old option values meant this dropdown could never
					// have matched a single vehicle even once the REST API
					// filter existed.
					?>
					<select name="condition" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px;">
						<option value=""><?php esc_html_e( 'Any Condition', 'carzuri-listings' ); ?></option>
						<option value="used"><?php esc_html_e( 'Used', 'carzuri-listings' ); ?></option>
						<option value="new"><?php esc_html_e( 'New', 'carzuri-listings' ); ?></option>
						<option value="certified-pre-owned"><?php esc_html_e( 'Certified Pre-Owned', 'carzuri-listings' ); ?></option>
					</select>
				</div>

			</div>
		</div>

	</form>
</div>

<style>
.carzuri-search-filter-container {
	background-color: #121A2E;
	padding: 20px;
	border-radius: 12px;
	border: 1px solid rgba(255, 255, 255, 0.05);
	margin-bottom: 24px;
}
@media (max-width: 991px) {
	.cz-filter-main-row {
		grid-template-columns: 1fr 1fr !important;
	}
	.cz-filter-main-row .cz-filter-col:last-child {
		grid-column: span 2;
	}
}
@media (max-width: 576px) {
	.cz-filter-main-row {
		grid-template-columns: 1fr !important;
	}
	.cz-filter-main-row .cz-filter-col:last-child {
		grid-column: span 1;
	}
}
</style>
