<?php
/**
 * Single Vehicle Custom Template.
 * Used automatically for all single "vehicle" post types.
 *
 * @package CarzuriListings
 */

get_header(); // Load standard theme header

if ( have_posts() ) :
	while ( have_posts() ) :
		the_post();

		$post_id     = get_the_ID();
		$is_featured = get_post_meta( $post_id, 'carzuri_featured', true ) === '1';
		$is_new      = ( ( time() - get_the_time( 'U' ) ) < ( 14 * DAY_IN_SECONDS ) );

		$price       = get_post_meta( $post_id, 'carzuri_price', true );
		$year        = get_post_meta( $post_id, 'carzuri_year', true );
		$fuel        = get_post_meta( $post_id, 'carzuri_fuel_type', true );
		$mileage     = get_post_meta( $post_id, 'carzuri_mileage', true );
		$transmission = get_post_meta( $post_id, 'carzuri_transmission', true );
		$engine_size  = get_post_meta( $post_id, 'carzuri_engine_size', true );
		$vin         = get_post_meta( $post_id, 'carzuri_vin', true );
		$reg_number  = get_post_meta( $post_id, 'carzuri_registration_number', true );
		$acc_history = get_post_meta( $post_id, 'carzuri_accident_history', true );
		$srv_history = get_post_meta( $post_id, 'carzuri_service_history', true );
		$condition   = get_post_meta( $post_id, 'carzuri_condition', true );
		$dealer_id   = get_post_meta( $post_id, 'carzuri_dealer_id', true );

		// Setup default dealer info if empty
		if ( empty( $dealer_id ) ) {
			$dealer_id = 1;
		}

		$body_types = wp_get_post_terms( $post_id, 'vehicle_body_type', array( 'fields' => 'names' ) );
		$body_type  = ! empty( $body_types ) ? $body_types[0] : 'SUV';

		$makes = wp_get_post_terms( $post_id, 'vehicle_make', array( 'fields' => 'names' ) );
		$make  = ! empty( $makes ) ? $makes[0] : '';

		$model = '';

		// Location — sourced from the vehicle_location taxonomy, the
		// single source of truth for a vehicle's location project-wide
		// (see the Location field consolidation). This was previously
		// missing from this page's spec strip entirely, even though the
		// data itself was always available.
		$location_terms = wp_get_post_terms( $post_id, 'vehicle_location', array( 'fields' => 'names' ) );
		$location       = ! empty( $location_terms ) ? $location_terms[0] : 'Nairobi';

		// Get gallery images
		$gallery_ids = get_post_meta( $post_id, 'carzuri_gallery_ids', true );
		if ( ! is_array( $gallery_ids ) ) {
			$gallery_ids = explode( ',', $gallery_ids );
		}
		$gallery_ids = array_filter( array_map( 'intval', $gallery_ids ) );

		// Masking sensitive data for guest users
		$is_guest   = ! is_user_logged_in();
		$vin_display = $vin ? $vin : '1HGB1234567890123';
		if ( $is_guest && $vin_display ) {
			// Mask all but last 6 characters
			$len = strlen( $vin_display );
			if ( $len > 6 ) {
				$vin_display = str_repeat( '•', $len - 6 ) . substr( $vin_display, -6 );
			}
		}

		$reg_display = $reg_number ? $reg_number : 'KDG 123A';
		if ( $is_guest && $reg_display ) {
			$reg_display = 'K•• •••• (Log in to view)';
		}

		// Dealer details query
		$dealer_user  = get_userdata( $dealer_id );
		$dealer_name  = $dealer_user ? $dealer_user->display_name : 'Verified Carzuri Partner';
		$dealer_badge = get_user_meta( $dealer_id, 'carzuri_verified_dealer', true ) === '1' || true; // Mock true for verified partners

		// Display Price
		$display_price = function_exists( 'carzuri_format_price' ) ? carzuri_format_price( $price ) : 'KSh ' . number_format( $price );
		?>

		<div class="cz-single-vehicle-layout" style="background-color: #0A111F; color: #FFFFFF; font-family: var(--cz-font-sans, sans-serif); min-height: 100vh; padding: 40px 20px; box-sizing: border-box;">
			<div style="max-width: 1200px; margin: 0 auto;">
				
				<!-- Main Section: Left details, Right inquiry sidebar -->
				<div class="cz-single-vehicle-grid" style="display: grid; grid-template-columns: 1fr; gap: 30px;">
					
					<!-- Left Column: Details -->
					<div>
						
						<!-- 1. Photo Gallery Section -->
						<div class="cz-gallery-section" style="margin-bottom: 24px;">
							<!-- Main Image -->
							<div class="cz-main-image-wrap" style="position: relative; padding-top: 56.25%; background-color: #121A2E; border-radius: 12px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05);">
								<?php if ( has_post_thumbnail() ) : ?>
									<img id="cz-gallery-main-view" src="<?php the_post_thumbnail_url( 'large' ); ?>" alt="<?php the_title_attribute(); ?>" style="position: absolute; top:0; left:0; width:100%; height:100%; object-fit: cover;">
								<?php else : ?>
									<div style="position: absolute; top:0; left:0; width:100%; height:100%; display:flex; align-items:center; justify-content:center; color:#4B5563;">No Featured Image</div>
								<?php endif; ?>

								<!-- Badges overlay -->
								<div style="position: absolute; top: 16px; left: 16px; display: flex; gap: 8px;">
									<?php if ( $is_featured ) : ?>
										<span style="background-color: var(--cz-color-gold, #D4AF37); color: #0A111F; font-size: 11px; font-weight: 800; padding: 4px 10px; border-radius: 4px; text-transform: uppercase;">FEATURED</span>
									<?php endif; ?>
									<?php if ( $is_new ) : ?>
										<span style="background-color: #EF4444; color: #FFFFFF; font-size: 11px; font-weight: 800; padding: 4px 10px; border-radius: 4px; text-transform: uppercase;">NEW</span>
									<?php endif; ?>
									<?php if ( $condition ) : ?>
										<span style="background-color: #3B82F6; color: #FFFFFF; font-size: 11px; font-weight: 800; padding: 4px 10px; border-radius: 4px; text-transform: uppercase;"><?php echo esc_html( $condition ); ?></span>
									<?php endif; ?>
								</div>
							</div>

							<!-- Thumbnail strip -->
							<?php if ( ! empty( $gallery_ids ) || has_post_thumbnail() ) : ?>
								<div class="cz-gallery-thumbnails" style="display: flex; gap: 10px; margin-top: 12px; overflow-x: auto; padding-bottom: 8px;">
									<?php if ( has_post_thumbnail() ) : ?>
										<div class="cz-thumb-item cz-thumb-active" data-large-url="<?php the_post_thumbnail_url( 'large' ); ?>" style="width: 80px; height: 50px; flex-shrink: 0; border-radius: 6px; overflow: hidden; border: 2px solid var(--cz-color-gold, #D4AF37); cursor: pointer;">
											<img src="<?php the_post_thumbnail_url( 'thumbnail' ); ?>" style="width:100%; height:100%; object-fit:cover;">
										</div>
									<?php endif; ?>
									<?php 
									foreach ( $gallery_ids as $img_id ) : 
										$img_url_large = wp_get_attachment_image_url( $img_id, 'large' );
										$img_url_thumb = wp_get_attachment_image_url( $img_id, 'thumbnail' );
										if ( $img_url_large ) :
										?>
											<div class="cz-thumb-item" data-large-url="<?php echo esc_url( $img_url_large ); ?>" style="width: 80px; height: 50px; flex-shrink: 0; border-radius: 6px; overflow: hidden; border: 2px solid transparent; cursor: pointer; opacity: 0.7; transition: opacity 0.2s;">
												<img src="<?php echo esc_url( $img_url_thumb ); ?>" style="width:100%; height:100%; object-fit:cover;">
											</div>
										<?php 
										endif;
									endforeach; 
									?>
								</div>
							<?php endif; ?>
						</div>

						<!-- 2. Title & Price block -->
						<div class="cz-title-price-block" style="background-color: #121A2E; padding: 24px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05); margin-bottom: 24px;">
							<h1 style="font-size: 24px; font-weight: 800; color: #FFFFFF; margin: 0 0 10px 0; font-family: var(--cz-font-display, sans-serif);"><?php the_title(); ?></h1>
							<div style="font-size: 28px; font-weight: 800; color: var(--cz-color-gold, #D4AF37);"><?php echo esc_html( $display_price ); ?></div>
						</div>

						<!-- 3. Key Specs strip -->
						<!-- FIX: this grid's inline `style` attribute previously
						     contained "@media(min-width: 600px){...}" directly
						     inside the style="" value — that is not valid CSS
						     and browsers silently ignore it, meaning the
						     intended "6 columns on wider screens" behavior has
						     likely never actually applied; the grid has been
						     stuck at the 3-column mobile value on every screen
						     size. Moved to a real CSS rule below (now 7 columns
						     on desktop, to fit the newly-added Location item),
						     with the base 3-column mobile layout kept inline. -->
						<div class="cz-key-specs-strip" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 24px;">
							
							<!-- Year -->
							<div style="background-color: #121A2E; border: 1px solid rgba(255,255,255,0.05); border-radius: 8px; padding: 12px; text-align: center;">
								<div style="font-size: 11px; font-weight: 700; color: #9CA3AF; margin-bottom: 4px; text-transform: uppercase;">YEAR</div>
								<div style="font-size: 14px; font-weight: 800; color: #FFFFFF;"><?php echo esc_html( $year ? $year : 'N/A' ); ?></div>
							</div>

							<!-- Mileage -->
							<div style="background-color: #121A2E; border: 1px solid rgba(255,255,255,0.05); border-radius: 8px; padding: 12px; text-align: center;">
								<div style="font-size: 11px; font-weight: 700; color: #9CA3AF; margin-bottom: 4px; text-transform: uppercase;">MILEAGE</div>
								<div style="font-size: 14px; font-weight: 800; color: #FFFFFF;"><?php echo esc_html( $mileage ? number_format( $mileage ) . ' km' : 'N/A' ); ?></div>
							</div>

							<!-- Fuel Type -->
							<div style="background-color: #121A2E; border: 1px solid rgba(255,255,255,0.05); border-radius: 8px; padding: 12px; text-align: center;">
								<div style="font-size: 11px; font-weight: 700; color: #9CA3AF; margin-bottom: 4px; text-transform: uppercase;">FUEL TYPE</div>
								<div style="font-size: 14px; font-weight: 800; color: #FFFFFF;"><?php echo esc_html( $fuel ? $fuel : 'N/A' ); ?></div>
							</div>

							<!-- Transmission -->
							<div style="background-color: #121A2E; border: 1px solid rgba(255,255,255,0.05); border-radius: 8px; padding: 12px; text-align: center;">
								<div style="font-size: 11px; font-weight: 700; color: #9CA3AF; margin-bottom: 4px; text-transform: uppercase;">GEARBOX</div>
								<div style="font-size: 14px; font-weight: 800; color: #FFFFFF;"><?php echo esc_html( $transmission ? $transmission : 'N/A' ); ?></div>
							</div>

							<!-- Body Type -->
							<div style="background-color: #121A2E; border: 1px solid rgba(255,255,255,0.05); border-radius: 8px; padding: 12px; text-align: center;">
								<div style="font-size: 11px; font-weight: 700; color: #9CA3AF; margin-bottom: 4px; text-transform: uppercase;">BODY</div>
								<div style="font-size: 14px; font-weight: 800; color: #FFFFFF;"><?php echo esc_html( $body_type ); ?></div>
							</div>

							<!-- Location -->
							<div style="background-color: #121A2E; border: 1px solid rgba(255,255,255,0.05); border-radius: 8px; padding: 12px; text-align: center;">
								<div style="font-size: 11px; font-weight: 700; color: #9CA3AF; margin-bottom: 4px; text-transform: uppercase;">LOCATION</div>
								<div style="font-size: 14px; font-weight: 800; color: #FFFFFF;"><?php echo esc_html( $location ); ?></div>
							</div>

							<!-- Engine Size -->
							<div style="background-color: #121A2E; border: 1px solid rgba(255,255,255,0.05); border-radius: 8px; padding: 12px; text-align: center;">
								<div style="font-size: 11px; font-weight: 700; color: #9CA3AF; margin-bottom: 4px; text-transform: uppercase;">ENGINE</div>
								<div style="font-size: 14px; font-weight: 800; color: #FFFFFF;"><?php echo esc_html( $engine_size ? $engine_size . ' cc' : 'N/A' ); ?></div>
							</div>

						</div>

						<!-- 4. Full Description -->
						<div class="cz-description-section" style="background-color: #121A2E; padding: 24px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05); margin-bottom: 24px;">
							<h3 style="font-size: 16px; font-weight: 800; color: #FFFFFF; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 8px; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.5px;">Vehicle Description</h3>
							<div class="cz-description-content" style="color: #D1D5DB; font-size: 14px; line-height: 1.6;">
								<?php the_content(); ?>
							</div>
						</div>

						<!-- 5. Detailed Specifications Table -->
						<div class="cz-detailed-specs-section" style="background-color: #121A2E; padding: 24px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05); margin-bottom: 24px;">
							<h3 style="font-size: 16px; font-weight: 800; color: #FFFFFF; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 8px; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.5px;">Detailed Specifications</h3>
							
							<table style="width: 100%; border-collapse: collapse; font-size: 13px;">
								<tbody>
									
									<!-- VIN Number -->
									<tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
										<td style="padding: 10px 0; color: #9CA3AF; font-weight: 600; width: 40%;">Chassis/VIN Number:</td>
										<td style="padding: 10px 0; color: #FFFFFF; font-family: monospace;" id="cz-vin-text">
											<?php echo esc_html( $vin_display ); ?>
											<?php if ( $is_guest ) : ?>
												<span style="font-size: 10px; color: var(--cz-color-gold, #D4AF37); margin-left: 8px; cursor: pointer; text-decoration: underline;" onclick="window.location.href='<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>'">[Unlock]</span>
											<?php endif; ?>
										</td>
									</tr>

									<!-- Registration Number -->
									<tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
										<td style="padding: 10px 0; color: #9CA3AF; font-weight: 600;">Registration Plate:</td>
										<td style="padding: 10px 0; color: #FFFFFF;">
											<?php echo esc_html( $reg_display ); ?>
										</td>
									</tr>

									<!-- Accident History -->
									<tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
										<td style="padding: 10px 0; color: #9CA3AF; font-weight: 600;">Accident History:</td>
										<td style="padding: 10px 0; color: #FFFFFF;">
											<?php echo esc_html( $acc_history ? $acc_history : __( 'No major accidents reported', 'carzuri-listings' ) ); ?>
										</td>
									</tr>

									<!-- Service History -->
									<tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
										<td style="padding: 10px 0; color: #9CA3AF; font-weight: 600;">Service History:</td>
										<td style="padding: 10px 0; color: #FFFFFF;">
											<?php echo esc_html( $srv_history ? $srv_history : __( 'Fully serviced, complete log available', 'carzuri-listings' ) ); ?>
										</td>
									</tr>

									<!-- Condition -->
									<tr>
										<td style="padding: 10px 0; color: #9CA3AF; font-weight: 600;">Overall Condition:</td>
										<td style="padding: 10px 0; color: #FFFFFF;">
											<?php echo esc_html( $condition ? $condition : __( 'Excellent', 'carzuri-listings' ) ); ?>
										</td>
									</tr>

								</tbody>
							</table>
						</div>

					</div>

					<!-- Right Column: Inquiry Sidebar -->
					<div>
						
						<!-- A. Dealer Info Card -->
						<div class="cz-dealer-info-card" style="background-color: #121A2E; padding: 24px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05); margin-bottom: 24px; text-align: center;">
							<div class="cz-dealer-avatar" style="width: 64px; height: 64px; border-radius: 50%; background-color: #0A111F; border: 2px solid var(--cz-color-gold, #D4AF37); margin: 0 auto 12px auto; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 20px; color: var(--cz-color-gold, #D4AF37);">
								<?php echo esc_html( substr( $dealer_name, 0, 1 ) ); ?>
							</div>
							
							<h4 style="margin: 0 0 4px 0; font-size: 15px; font-weight: 800; color: #FFFFFF;"><?php echo esc_html( $dealer_name ); ?></h4>
							
							<?php if ( $dealer_badge ) : ?>
								<span style="background-color: rgba(212, 175, 55, 0.1); border: 1px solid var(--cz-color-gold, #D4AF37); color: var(--cz-color-gold, #D4AF37); font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 10px; text-transform: uppercase;">Verified Dealer</span>
							<?php endif; ?>

							<!-- Message Dealer button, reusing Carzuri Messaging's own shortcode -->
							<?php if ( shortcode_exists( 'carzuri_message_dealer_button' ) ) : ?>
								<div style="margin-top: 16px;">
									<?php echo do_shortcode( '[carzuri_message_dealer_button dealer_id="' . intval( $dealer_id ) . '" vehicle_id="' . intval( $post_id ) . '" label="Message Dealer" class="cz-vehicle-message-btn"]' ); ?>
								</div>
							<?php endif; ?>

							<!-- Link to Dealer profile archive placeholder -->
							<a href="<?php echo esc_url( add_query_arg( 'dealer_id', $dealer_id, get_post_type_archive_link( 'vehicle' ) ) ); ?>" style="display: block; font-size: 12px; color: var(--cz-color-gold, #D4AF37); text-decoration: none; font-weight: 700; margin-top: 14px;">
								View Other Listings By This Dealer →
							</a>
						</div>

						<!-- B. Contact Seller Form -->
						<div class="cz-contact-seller-form-wrap" style="background-color: #121A2E; padding: 24px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
							<h3 style="font-size: 15px; font-weight: 800; color: #FFFFFF; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.5px;">Contact Seller</h3>
							
							<form id="cz-listings-contact-form" style="display: flex; flex-direction: column; gap: 12px;">
								<input type="hidden" name="vehicle_id" value="<?php echo esc_attr( $post_id ); ?>">
								
								<!-- Bot Honeypot -->
								<div style="display: none;">
									<input type="text" name="website_url_hp" value="">
								</div>

								<?php 
								$current_user = wp_get_current_user();
								$user_name   = $current_user->exists() ? $current_user->display_name : '';
								$user_email  = $current_user->exists() ? $current_user->user_email : '';
								$required_attr = $current_user->exists() ? '' : 'required';
								?>

								<!-- Name -->
								<div>
									<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 4px;">YOUR NAME *</label>
									<input type="text" name="buyer_name" value="<?php echo esc_attr( $user_name ); ?>" required style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px; box-sizing: border-box;">
								</div>

								<!-- Email -->
								<div>
									<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 4px;">EMAIL ADDRESS *</label>
									<input type="email" name="buyer_email" value="<?php echo esc_attr( $user_email ); ?>" required style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px; box-sizing: border-box;">
								</div>

								<!-- Phone -->
								<div>
									<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 4px;">PHONE NUMBER</label>
									<input type="tel" name="buyer_phone" placeholder="e.g. 0712345678" style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px; box-sizing: border-box;">
								</div>

								<!-- Message -->
								<div>
									<label style="display: block; font-size: 11px; font-weight: 700; color: #9CA3AF; text-transform: uppercase; margin-bottom: 4px;">YOUR MESSAGE *</label>
									<textarea name="message" rows="4" required style="width: 100%; background-color: #0A111F; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; color: #FFFFFF; font-size: 13px; box-sizing: border-box; resize: vertical;">I'm interested in this <?php echo esc_attr( $year . ' ' . $make . ' ' . $model ); ?>, is it still available?</textarea>
								</div>

								<!-- Status feedback -->
								<div id="cz-form-status-msg" style="display: none; padding: 8px; border-radius: 4px; font-size: 12px; text-align: center;"></div>

								<!-- Submit -->
								<button type="submit" id="cz-listings-submit-inquiry" style="width: 100%; background-color: var(--cz-color-gold, #D4AF37); color: #0A111F; font-weight: 700; border: none; border-radius: 6px; padding: 12px; font-size: 12px; text-transform: uppercase; cursor: pointer; letter-spacing: 0.5px;">
									SUBMIT INQUIRY
								</button>
							</form>
						</div>

						<!-- C. Finance Calculator (pre-filled with this vehicle's real price) -->
						<?php if ( shortcode_exists( 'carzuri_finance_calculator' ) ) : ?>
							<div class="cz-single-vehicle-finance-calc" style="background-color: #121A2E; padding: 24px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05); margin-top: 24px;">
								<h3 style="font-size: 15px; font-weight: 800; color: #FFFFFF; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.5px;">Estimate Your Monthly Payment</h3>
								<?php echo do_shortcode( '[carzuri_finance_calculator vehicle_id="' . esc_attr( $post_id ) . '"]' ); ?>
							</div>
						<?php endif; ?>

					</div>

				</div>

				<!-- 5b. Vehicle Reviews & Ratings -->
				<?php if ( shortcode_exists( 'carzuri_vehicle_reviews' ) ) : ?>
				<div style="margin-top: 50px;">
					<?php echo do_shortcode( '[carzuri_vehicle_reviews]' ); ?>
				</div>
				<?php endif; ?>

				<!-- 6. Similar Vehicles Row (Bottom) -->
				<div style="margin-top: 50px;">
					<h3 style="font-size: 18px; font-weight: 800; color: #FFFFFF; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 12px; margin: 0 0 24px 0; text-transform: uppercase; letter-spacing: 0.5px; font-family: var(--cz-font-display, sans-serif);">
						SIMILAR VEHICLES <span style="font-weight:300; opacity:0.5;">—</span>
					</h3>
					
					<?php 
					// Find similar vehicles: same body_type or make, excluding this post
					$similar_args = array(
						'post_type'      => 'vehicle',
						'posts_per_page' => 4,
						'post__not_in'   => array( $post_id ),
						'post_status'    => 'publish',
						'tax_query'      => array(
							'relation' => 'OR',
						),
					);

					// Query shared make terms
					$make_terms = wp_get_post_terms( $post_id, 'vehicle_make', array( 'fields' => 'ids' ) );
					if ( ! empty( $make_terms ) && ! is_wp_error( $make_terms ) ) {
						$similar_args['tax_query'][] = array(
							'taxonomy' => 'vehicle_make',
							'field'    => 'term_id',
							'terms'    => $make_terms,
						);
					}

					// Query shared body_type terms
					$body_type_terms = wp_get_post_terms( $post_id, 'vehicle_body_type', array( 'fields' => 'ids' ) );
					if ( ! empty( $body_type_terms ) && ! is_wp_error( $body_type_terms ) ) {
						$similar_args['tax_query'][] = array(
							'taxonomy' => 'vehicle_body_type',
							'field'    => 'term_id',
							'terms'    => $body_type_terms,
						);
					}

					$similar_query = new WP_Query( $similar_args );
					?>

					<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px;">
						<?php 
						if ( $similar_query->have_posts() ) :
							while ( $similar_query->have_posts() ) :
								$similar_query->the_post();
								include CARZURI_LISTINGS_DIR . 'templates/vehicle-card.php';
							endwhile;
							wp_reset_postdata();
						else :
							echo '<p style="color:#9CA3AF; font-size:13px;">No similar vehicles found.</p>';
						endif;
						?>
					</div>
				</div>

			</div>
		</div>

		<style>
		@media (min-width: 992px) {
			.cz-single-vehicle-grid {
				grid-template-columns: 1.8fr 1.2fr !important;
			}
		}
		.cz-vehicle-message-btn {
			width: 100% !important;
			justify-content: center !important;
		}

		/* Key Specs strip: 3 columns on mobile (set inline above), 7 on
		   wider screens now that Location has been added as a 7th item.
		   This replaces an invalid inline "@media(){}" that was previously
		   embedded directly in the strip's style="" attribute — that is
		   not valid CSS and browsers ignore it silently, so this
		   responsive behavior likely never actually applied before. */
		@media (min-width: 600px) {
			.cz-key-specs-strip {
				grid-template-columns: repeat(7, 1fr) !important;
			}
		}

		/* FIX: on mobile, .cz-single-vehicle-grid is a single-column CSS
		   Grid ("grid-template-columns: 1fr"). Grid columns default to
		   min-width:auto, meaning they won't shrink below the widest
		   min-content of anything inside them. The masked VIN string shown
		   to guests (e.g. "••••••••••567890") has no spaces anywhere in
		   it, so the browser can't wrap it onto multiple lines — that
		   single table cell demanded enough width to show the whole string
		   on one line, which dragged the ENTIRE grid column (and therefore
		   everything else inside it: specs grid, dealer card, buttons)
		   wider than the phone screen, cutting all of it off. min-width: 0
		   lets the column actually shrink to the viewport; table-layout:
		   fixed plus word-break give the VIN cell somewhere to actually
		   wrap instead of demanding extra width in the first place. */
		.cz-single-vehicle-grid > div {
			min-width: 0;
		}
		.cz-detailed-specs-section table {
			table-layout: fixed;
			width: 100%;
		}
		.cz-detailed-specs-section td {
			word-break: break-word;
			overflow-wrap: anywhere;
		}
		</style>

		<script>
		// Light gallery slider logic (swap main display on thumbnail click)
		document.addEventListener('DOMContentLoaded', function() {
			const thumbs = document.querySelectorAll('.cz-thumb-item');
			const mainImg = document.getElementById('cz-gallery-main-view');

			thumbs.forEach(thumb => {
				thumb.addEventListener('click', function() {
					thumbs.forEach(t => {
						t.style.borderColor = 'transparent';
						t.style.opacity = '0.7';
					});

					this.style.borderColor = 'var(--cz-color-gold, #D4AF37)';
					this.style.opacity = '1';

					const newUrl = this.getAttribute('data-large-url');
					if (mainImg && newUrl) {
						mainImg.setAttribute('src', newUrl);
					}
				});
			});
		});
		</script>

		<?php
	endwhile;
endif;

get_footer(); // Load standard theme footer
