<?php
/**
 * Vehicle Grid / Carousel Template.
 * Rendered by [carzuri_vehicle_grid] shortcode.
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$columns       = intval( $args['columns'] );
$featured_only = filter_var( $args['featured_only'], FILTER_VALIDATE_BOOLEAN );

// Determine grid container styles
$grid_style = 'display: grid; gap: 20px;';
if ( $columns === 5 ) {
	$grid_style .= 'grid-template-columns: repeat(5, minmax(200px, 1fr));';
} else {
	$grid_style .= 'grid-template-columns: repeat(4, minmax(220px, 1fr));';
}
?>

<div class="carzuri-vehicle-grid-wrapper" data-featured-only="<?php echo $featured_only ? 'true' : 'false'; ?>" data-columns="<?php echo esc_attr( $columns ); ?>" data-limit="<?php echo esc_attr( $args['limit'] ); ?>">
	
	<!-- Header section (only if featured row or has title) -->
	<?php if ( $featured_only ) : ?>
		<div class="cz-grid-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 12px;">
			<h2 style="font-size: 18px; font-weight: 800; color: #FFFFFF; letter-spacing: 0.5px; text-transform: uppercase; margin: 0; font-family: var(--cz-font-display, sans-serif);">
				FEATURED VEHICLES <span style="font-weight: 300; opacity: 0.5;">—</span>
			</h2>
			
			<div style="display: flex; align-items: center; gap: 16px;">
				<a href="<?php echo esc_url( get_post_type_archive_link( 'vehicle' ) ); ?>" class="cz-view-all-link" style="color: var(--cz-color-gold, #D4AF37); font-size: 11px; font-weight: 700; text-decoration: none; text-transform: uppercase; letter-spacing: 1px; display: flex; align-items: center; gap: 4px;">
					VIEW ALL VEHICLES <span>→</span>
				</a>
				
				<!-- Carousel Navigation Arrows -->
				<div class="cz-carousel-controls" style="display: flex; gap: 8px;">
					<button class="cz-carousel-arrow-prev" aria-label="Previous" style="background: #121A2E; border: 1px solid rgba(255,255,255,0.05); color: #FFFFFF; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: background 0.15s;">
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>
						</svg>
					</button>
					<button class="cz-carousel-arrow-next" aria-label="Next" style="background: #121A2E; border: 1px solid rgba(255,255,255,0.05); color: #FFFFFF; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: background 0.15s;">
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
						</svg>
					</button>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<!-- Vehicles Grid Container -->
	<div class="cz-grid-container" id="carzuri-vehicles-container" style="<?php echo esc_attr( $grid_style ); ?>">
		
		<?php if ( $vehicles_query->have_posts() ) : ?>
			<?php while ( $vehicles_query->have_posts() ) : ?>
				<?php $vehicles_query->the_post(); ?>
				
				<div class="cz-grid-item">
					<?php include CARZURI_LISTINGS_DIR . 'templates/vehicle-card.php'; ?>
				</div>

			<?php endwhile; ?>
		<?php else : ?>
			
			<!-- Empty State -->
			<div class="cz-empty-state" style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; background-color: #121A2E; border-radius: 12px; border: 1px dashed rgba(255,255,255,0.1);">
				<div style="font-size: 36px; margin-bottom: 12px;">🔍</div>
				<h3 style="font-size: 16px; font-weight: 700; color: #FFFFFF; margin: 0 0 8px 0;"><?php esc_html_e( 'No vehicles match your filters', 'carzuri-listings' ); ?></h3>
				<p style="font-size: 13px; color: #9CA3AF; margin: 0 0 20px 0;"><?php esc_html_e( 'Try broadening or resetting your search parameters.', 'carzuri-listings' ); ?></p>
				<button id="cz-reset-filters-btn" style="background-color: var(--cz-color-gold, #D4AF37); color: #0A111F; font-weight: 700; border: none; border-radius: 6px; padding: 10px 20px; font-size: 12px; text-transform: uppercase; cursor: pointer;">
					Reset Filters
				</button>
			</div>

		<?php endif; ?>

	</div>

	<!-- Pagination/Load More (only if NOT featured and limit is not small) -->
	<?php if ( ! $featured_only && $vehicles_query->max_num_pages > 1 ) : ?>
		<div class="cz-pagination-container" style="text-align: center; margin-top: 30px;">
			<button id="cz-load-more-vehicles-btn" data-next-page="2" data-max-pages="<?php echo esc_attr( $vehicles_query->max_num_pages ); ?>" style="background-color: #121A2E; border: 1px solid rgba(255,255,255,0.1); color: #FFFFFF; font-weight: 700; border-radius: 6px; padding: 12px 28px; font-size: 13px; letter-spacing: 0.5px; text-transform: uppercase; cursor: pointer; transition: background 0.2s;">
				Load More Vehicles
			</button>
		</div>
	<?php endif; ?>

</div>

<style>
/* Responsive tweaks */
@media (max-width: 1200px) {
	#carzuri-vehicles-container {
		grid-template-columns: repeat(3, minmax(200px, 1fr)) !important;
	}
}
@media (max-width: 900px) {
	#carzuri-vehicles-container {
		grid-template-columns: repeat(2, minmax(200px, 1fr)) !important;
	}
}
@media (max-width: 550px) {
	#carzuri-vehicles-container {
		grid-template-columns: 1fr !important;
	}
}
</style>
