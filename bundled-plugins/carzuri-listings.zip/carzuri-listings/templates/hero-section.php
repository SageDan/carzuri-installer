<?php
/**
 * Hero Section Template.
 * Rendered by the [carzuri_hero] shortcode.
 * 
 * To override this template in your theme, copy this file to:
 * {your-theme}/templates/hero-section.php
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Dynamically find real page URLs (same pattern already used for Finance/AI Valuation
// below), with safe fallbacks to the confirmed static slugs if a page isn't found.
global $wpdb;

$finance_calc_url = home_url( '/finance-calculator/' );
$finance_calc_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_finance_calculator]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
if ( $finance_calc_page_id ) {
	$finance_calc_url = get_permalink( $finance_calc_page_id );
}

$finance_app_url = home_url( '/finance-application-form/' );
$finance_app_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_finance_application_form]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
if ( $finance_app_page_id ) {
	$finance_app_url = get_permalink( $finance_app_page_id );
}

$ai_valuation_url = home_url( '/ai-valuation/' );
$ai_valuation_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_ai_valuation]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
if ( $ai_valuation_page_id ) {
	$ai_valuation_url = get_permalink( $ai_valuation_page_id );
}

$buy_cars_url = home_url( '/buy-cars/' );

$dealers_directory_url = home_url( '/dealers/' );
$dealers_directory_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_dealers_directory]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
if ( $dealers_directory_page_id ) {
	$dealers_directory_url = get_permalink( $dealers_directory_page_id );
}

$buyer_registration_url = home_url( '/buyer-registration/' );
$buyer_reg_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_buyer_registration]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
if ( $buyer_reg_page_id ) {
	$buyer_registration_url = get_permalink( $buyer_reg_page_id );
}

$dealer_registration_url = home_url( '/dealer-registration/' );
$dealer_reg_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_dealer_registration]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
if ( $dealer_reg_page_id ) {
	$dealer_registration_url = get_permalink( $dealer_reg_page_id );
}

$dealer_login_url = home_url( '/dealer-login/' );
$dealer_login_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_dealer_login]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
if ( $dealer_login_page_id ) {
	$dealer_login_url = get_permalink( $dealer_login_page_id );
}

$logo_url = CARZURI_LISTINGS_URL . 'assets/images/carzuri-logo.png';
$logo_url = apply_filters( 'carzuri_listings_hero_logo', $logo_url );

$hero_bg_url = CARZURI_LISTINGS_URL . 'assets/images/carzuri-hero-dealership.jpg';
$hero_bg_url = apply_filters( 'carzuri_listings_hero_bg', $hero_bg_url );
?>

<div class="carzuri-hero-section" style="background-image: linear-gradient(rgba(10,17,31,0.87), rgba(10,17,31,0.87)), url('<?php echo esc_url( $hero_bg_url ); ?>'); background-size: cover; background-position: center;">

	<!-- Decorative textured background: mirrored hex patterns + soft radial glow -->
	<div class="carzuri-hero-bg-pattern carzuri-hero-bg-pattern-left" aria-hidden="true">
		<svg width="100%" height="100%" viewBox="0 0 400 600" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M-100,50 L50,136.6 L50,310 L-100,396.6 L-250,310 L-250,136.6 Z" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="1.5"/>
			<path d="M50,223.3 L200,310 L200,483.3 L50,570 L-100,483.3 L-100,310 Z" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="1"/>
			<path d="M-150,396.6 L0,483.3 L0,656.6 L-150,743.3 L-300,656.6 L-300,483.3 Z" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="1"/>
			<line x1="50" y1="136.6" x2="200" y2="310" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="0.75" stroke-dasharray="4 4"/>
			<line x1="-100" y1="396.6" x2="50" y2="570" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="0.75" stroke-dasharray="4 4"/>
		</svg>
	</div>
	<div class="carzuri-hero-bg-pattern carzuri-hero-bg-pattern-right" aria-hidden="true">
		<svg width="100%" height="100%" viewBox="0 0 400 600" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M-100,50 L50,136.6 L50,310 L-100,396.6 L-250,310 L-250,136.6 Z" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="1.5"/>
			<path d="M50,223.3 L200,310 L200,483.3 L50,570 L-100,483.3 L-100,310 Z" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="1"/>
			<path d="M-150,396.6 L0,483.3 L0,656.6 L-150,743.3 L-300,656.6 L-300,483.3 Z" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="1"/>
			<line x1="50" y1="136.6" x2="200" y2="310" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="0.75" stroke-dasharray="4 4"/>
			<line x1="-100" y1="396.6" x2="50" y2="570" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="0.75" stroke-dasharray="4 4"/>
		</svg>
	</div>
	<div class="carzuri-hero-glow" aria-hidden="true"></div>

	<div class="carzuri-hero-container">

		<!-- Wordmark Logo -->
		<div class="carzuri-hero-logo">
			<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php esc_attr_e( 'Carzuri Limited', 'carzuri-listings' ); ?>" />
		</div>

		<!-- Principal Slogans -->
		<div class="carzuri-hero-headers">
			<h2 class="carzuri-tagline">
				DRIVEN BY TRUST. <span class="gold-slogan-part">POWERED BY VALUE.</span>
			</h2>
			<p class="carzuri-subtagline">
				Buy Smart. Sell Fast. Drive Your Future with Carzuri.
			</p>
		</div>

		<!-- Trust-Badge Icons -->
		<div class="carzuri-trust-badges-grid">

			<a href="<?php echo esc_url( $ai_valuation_url ); ?>" class="carzuri-trust-badge">
				<div class="cz-badge-icon-wrap">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
					</svg>
				</div>
				<div>
					<h4 class="cz-badge-title">AI SMART VALUATION</h4>
					<p class="cz-badge-desc">Get 85% market accurate value in seconds</p>
				</div>
			</a>

			<a href="<?php echo esc_url( $finance_app_url ); ?>" class="carzuri-trust-badge">
				<div class="cz-badge-icon-wrap">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
						<line x1="16" y1="2" x2="16" y2="6"/>
						<line x1="8" y1="2" x2="8" y2="6"/>
						<line x1="3" y1="10" x2="21" y2="10"/>
					</svg>
				</div>
				<div>
					<h4 class="cz-badge-title">FINANCE MADE EASY</h4>
					<p class="cz-badge-desc">Get pre-qualified &amp; see monthly estimates</p>
				</div>
			</a>

			<a href="<?php echo esc_url( $dealers_directory_url ); ?>" class="carzuri-trust-badge">
				<div class="cz-badge-icon-wrap">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
					</svg>
				</div>
				<div>
					<h4 class="cz-badge-title">TRUSTED DEALERS</h4>
					<p class="cz-badge-desc">Verified dealers. Quality cars.</p>
				</div>
			</a>

			<a href="<?php echo esc_url( $finance_calc_url ); ?>" class="carzuri-trust-badge">
				<div class="cz-badge-icon-wrap">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--cz-color-gold, #D4AF37)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<rect x="4" y="2" width="16" height="20" rx="2"/>
						<line x1="8" y1="6" x2="16" y2="6"/>
						<line x1="8" y1="10" x2="8" y2="10.01"/>
						<line x1="12" y1="10" x2="12" y2="10.01"/>
						<line x1="16" y1="10" x2="16" y2="10.01"/>
						<line x1="8" y1="14" x2="8" y2="14.01"/>
						<line x1="12" y1="14" x2="12" y2="14.01"/>
						<line x1="16" y1="14" x2="16" y2="14.01"/>
						<line x1="8" y1="18" x2="16" y2="18"/>
					</svg>
				</div>
				<div>
					<h4 class="cz-badge-title">ESTIMATE YOUR PAYMENT</h4>
					<p class="cz-badge-desc">Calculate monthly costs instantly</p>
				</div>
			</a>

		</div>

		<!-- CTA Clusters: Buyers and Dealers, side by side -->
		<div class="carzuri-hero-cta-row">

			<div class="carzuri-hero-cta-cluster">
				<span class="carzuri-hero-cta-label">Buying a car?</span>
				<div class="carzuri-hero-cta-buttons">
					<a href="<?php echo esc_url( $buy_cars_url ); ?>" class="carzuri-hero-btn carzuri-hero-btn-primary">Browse Vehicles</a>
					<a href="<?php echo esc_url( $buyer_registration_url ); ?>" class="carzuri-hero-btn carzuri-hero-btn-outline">Create a Buyer Account</a>
				</div>
			</div>

			<div class="carzuri-hero-cta-divider" aria-hidden="true"></div>

			<div class="carzuri-hero-cta-cluster">
				<span class="carzuri-hero-cta-label">Selling as a dealer?</span>
				<div class="carzuri-hero-cta-buttons">
					<a href="<?php echo esc_url( $dealer_registration_url ); ?>" class="carzuri-hero-btn carzuri-hero-btn-primary">List Your Vehicles</a>
					<a href="<?php echo esc_url( $dealer_login_url ); ?>" class="carzuri-hero-btn carzuri-hero-btn-outline">Dealer Login</a>
				</div>
			</div>

		</div>

	</div>
</div>

<style>
.carzuri-hero-section {
	background-color: var(--cz-color-navy, #0A111F);
	background-repeat: no-repeat;
	color: #FFFFFF;
	position: relative;
	overflow: hidden;
	padding: 60px 20px 44px 20px;
	border-radius: 12px;
	margin-bottom: 24px;
}

.carzuri-hero-bg-pattern {
	position: absolute;
	top: 0;
	bottom: 0;
	width: 40%;
	opacity: 0.15;
	pointer-events: none;
}
.carzuri-hero-bg-pattern-left {
	left: 0;
}
.carzuri-hero-bg-pattern-right {
	right: 0;
	transform: scaleX(-1);
}
.carzuri-hero-glow {
	position: absolute;
	top: 50%;
	left: 50%;
	width: 900px;
	height: 900px;
	transform: translate(-50%, -50%);
	background: radial-gradient(circle, rgba(212,175,55,0.10) 0%, rgba(212,175,55,0) 65%);
	pointer-events: none;
}

.carzuri-hero-container {
	max-width: 800px;
	margin: 0 auto;
	width: 100%;
	position: relative;
	z-index: 2;
	text-align: center;
}

.carzuri-hero-logo {
	margin-bottom: 20px;
}
.carzuri-hero-logo img {
	max-height: 90px;
	width: auto;
	display: block;
	margin: 0 auto;
}

.carzuri-hero-headers {
	margin-bottom: 28px;
}
.carzuri-tagline {
	font-size: 30px;
	font-weight: 700;
	letter-spacing: 1px;
	line-height: 1.25;
	margin: 0 0 10px 0;
	color: #FFFFFF;
	font-family: var(--cz-font-display, sans-serif);
}
.gold-slogan-part {
	color: var(--cz-color-gold, #D4AF37);
}
.carzuri-subtagline {
	font-size: 16px;
	color: #D1D5DB;
	margin: 0;
	font-family: var(--cz-font-sans, sans-serif);
}

.carzuri-trust-badges-grid {
	display: grid;
	grid-template-columns: repeat(2, 1fr);
	gap: 18px 24px;
	margin-bottom: 36px;
	text-align: left;
}
.carzuri-trust-badge,
.carzuri-trust-badge:hover,
.carzuri-trust-badge:focus,
.carzuri-trust-badge:visited,
.carzuri-trust-badge * {
	text-decoration: none !important;
}
.carzuri-trust-badge {
	display: flex;
	gap: 12px;
	align-items: flex-start;
}
.cz-badge-icon-wrap {
	flex-shrink: 0;
	width: 36px;
	height: 36px;
	border: 1.5px solid var(--cz-color-gold, #D4AF37);
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
}
.cz-badge-title {
	margin: 0 0 2px 0;
	font-size: 12px;
	font-weight: 700;
	color: #FFFFFF;
}
.cz-badge-desc {
	margin: 0;
	font-size: 11px;
	color: #9CA3AF;
	line-height: 1.3;
}

.carzuri-hero-cta-row {
	display: flex;
	align-items: stretch;
	justify-content: center;
	gap: 28px;
	flex-wrap: wrap;
	padding-top: 24px;
	border-top: 1px solid rgba(255,255,255,0.08);
}
.carzuri-hero-cta-cluster {
	display: flex;
	flex-direction: column;
	align-items: center;
	gap: 12px;
}
.carzuri-hero-cta-label {
	font-size: 12px;
	font-weight: 700;
	color: #9CA3AF;
	text-transform: uppercase;
	letter-spacing: 0.5px;
}
.carzuri-hero-cta-buttons {
	display: flex;
	gap: 10px;
	flex-wrap: wrap;
	justify-content: center;
}
.carzuri-hero-cta-divider {
	width: 1px;
	background: rgba(255,255,255,0.1);
	align-self: stretch;
}
.carzuri-hero-btn {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	padding: 11px 20px;
	border-radius: 6px;
	font-size: 12.5px;
	font-weight: 700;
	text-transform: uppercase;
	letter-spacing: 0.4px;
	text-decoration: none;
	white-space: nowrap;
	transition: background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease;
}
.carzuri-hero-btn-primary {
	background-color: var(--cz-color-gold, #D4AF37);
	color: #0A111F;
	border: 1.5px solid var(--cz-color-gold, #D4AF37);
}
.carzuri-hero-btn-primary:hover {
	background-color: #c19b26;
	border-color: #c19b26;
}
.carzuri-hero-btn-outline {
	background-color: transparent;
	color: #FFFFFF;
	border: 1.5px solid rgba(255,255,255,0.35);
}
.carzuri-hero-btn-outline:hover {
	border-color: var(--cz-color-gold, #D4AF37);
	color: var(--cz-color-gold, #D4AF37);
}

@media (max-width: 768px) {
	.carzuri-hero-section {
		padding: 40px 16px 32px 16px;
	}
	.carzuri-tagline {
		font-size: 23px;
	}
	.carzuri-trust-badges-grid {
		grid-template-columns: 1fr;
	}
	.carzuri-hero-cta-row {
		gap: 20px;
	}
	.carzuri-hero-cta-divider {
		display: none;
	}
}
</style>
