<?php
/**
 * Latest Blog Posts Section Template.
 * Rendered by the [carzuri_latest_blog_posts] shortcode.
 * Only ever included when at least one published post exists —
 * see render_latest_blog_posts() in class-shortcodes.php.
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The Blog page is WordPress's own "Posts page" (Settings → Reading),
// not a shortcode-driven page — so there's no shortcode to look up here,
// unlike other dynamic URLs used elsewhere on this site. /blog/ is the
// real, confirmed slug.
$blog_archive_url = home_url( '/blog/' );
?>

<div class="carzuri-latest-blog-section">
	<div class="cz-blog-section-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 12px;">
		<h2 style="font-size: 18px; font-weight: 800; color: #FFFFFF; letter-spacing: 0.5px; text-transform: uppercase; margin: 0; font-family: var(--cz-font-display, sans-serif);">
			LATEST FROM OUR BLOG <span style="font-weight: 300; opacity: 0.5;">—</span>
		</h2>
		<a href="<?php echo esc_url( $blog_archive_url ); ?>" style="color: var(--cz-color-gold, #D4AF37); font-size: 11px; font-weight: 700; text-decoration: none; text-transform: uppercase; letter-spacing: 1px; display: flex; align-items: center; gap: 4px;">
			VIEW ALL POSTS <span>→</span>
		</a>
	</div>

	<div class="cz-blog-grid-container" style="display: grid; grid-template-columns: repeat(3, minmax(220px, 1fr)); gap: 20px;">
		<?php
		while ( $blog_query->have_posts() ) :
			$blog_query->the_post();
			?>
			<a href="<?php the_permalink(); ?>" class="cz-blog-card" style="background-color: #121A2E; border-radius: 12px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05); display: flex; flex-direction: column; text-decoration: none; transition: transform 0.2s, box-shadow 0.2s;">
				<div style="position: relative; padding-top: 56%; background-color: #0A111F; overflow: hidden;">
					<?php if ( has_post_thumbnail() ) : ?>
						<?php the_post_thumbnail( 'medium_large', array( 'style' => 'position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;' ) ); ?>
					<?php else : ?>
						<div style="position:absolute; top:0; left:0; width:100%; height:100%; display:flex; align-items:center; justify-content:center; color:#4B5563; font-size:12px;">No Image Available</div>
					<?php endif; ?>
				</div>
				<div style="padding: 16px; display: flex; flex-direction: column; flex-grow: 1;">
					<div style="font-size: 11px; color: #9CA3AF; margin-bottom: 6px;"><?php echo esc_html( get_the_date() ); ?></div>
					<h3 style="margin: 0 0 8px 0; font-size: 15px; font-weight: 700; color: #FFFFFF; line-height: 1.4;"><?php the_title(); ?></h3>
					<p style="margin: 0; font-size: 13px; color: #9CA3AF; line-height: 1.5; flex-grow: 1;"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18 ) ); ?></p>
					<span style="margin-top: 12px; color: var(--cz-color-gold, #D4AF37); font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Read More →</span>
				</div>
			</a>
			<?php
		endwhile;
		?>
	</div>
</div>

<style>
.cz-blog-card:hover {
	transform: translateY(-4px);
	box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);
	border-color: rgba(212, 175, 55, 0.3) !important;
}

@media (max-width: 900px) {
	.cz-blog-grid-container {
		grid-template-columns: repeat(2, minmax(200px, 1fr)) !important;
	}
}

@media (max-width: 600px) {
	.cz-blog-grid-container {
		grid-template-columns: 1fr !important;
	}
}
</style>
