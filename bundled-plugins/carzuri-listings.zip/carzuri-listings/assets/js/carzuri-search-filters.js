/**
 * Carzuri Search and Filters - Advanced toggle and sessionStorage state.
 *
 * NOTE: The dependent Make -> Model dropdown logic that used to live here
 * has been removed. It duplicated (and raced against) Core's own global
 * handler in carzuri-core.js, which already listens for changes on any
 * select[name="vehicle_make"] and populates the matching
 * select[name="vehicle_model"] in the same form via the real
 * vehicle_model taxonomy (GET /carzuri/v1/models). This form's Make and
 * Model dropdowns (#cz-make-dropdown / #cz-model-dropdown) already match
 * that pattern exactly, so Core's handler now owns this responsibility
 * on its own — no extra wiring needed here. The old logic here also had
 * its own hardcoded mock model list (Land Cruiser/Prado/Hilux/Vitz etc.)
 * as a silent fallback, which could surface fake data in place of a
 * vehicle's real, taxonomy-backed models.
 *
 * @package CarzuriListings
 */

(function() {
	document.addEventListener('DOMContentLoaded', function() {
		const form = document.getElementById('carzuri-listings-filter-form');
		if (!form) return;

		const makeDropdown = document.getElementById('cz-make-dropdown');
		const advancedToggle = document.getElementById('cz-advanced-search-toggle');
		const advancedDrawer = document.getElementById('cz-advanced-filters-drawer');

		// 1. Setup Advanced Search Toggle
		if (advancedToggle && advancedDrawer) {
			advancedToggle.addEventListener('click', function(e) {
				e.preventDefault();
				if (advancedDrawer.style.display === 'none') {
					advancedDrawer.style.display = 'block';
					advancedToggle.innerHTML = '▲ Close Advanced Search';
				} else {
					advancedDrawer.style.display = 'none';
					advancedToggle.innerHTML = '▼ Advanced Search';
				}
			});
		}

		// 2. Store and Restore filters state in sessionStorage for back-button preservation
		const inputFields = form.querySelectorAll('select, input');

		function saveStateToSession() {
			inputFields.forEach(field => {
				if (field.name) {
					sessionStorage.setItem('cz_filter_' + field.name, field.value);
				}
			});
		}

		function loadStateFromSession() {
			let hasActiveFilters = false;
			inputFields.forEach(field => {
				if (field.name) {
					const storedValue = sessionStorage.getItem('cz_filter_' + field.name);
					if (storedValue !== null && storedValue !== '') {
						field.value = storedValue;
						hasActiveFilters = true;

						// Trigger change event so Core's global Make->Model
						// handler (carzuri-core.js) re-populates the Model
						// dropdown for the restored Make selection.
						if (field.id === 'cz-make-dropdown') {
							const event = new Event('change');
							field.dispatchEvent(event);
						}
					}
				}
			});

			if (hasActiveFilters && advancedDrawer) {
				// Keep advanced options visible if any was set
				const mileage = sessionStorage.getItem('cz_filter_max_mileage');
				const fuel = sessionStorage.getItem('cz_filter_fuel_type');
				const trans = sessionStorage.getItem('cz_filter_transmission');
				if (mileage || fuel || trans) {
					advancedDrawer.style.display = 'block';
					if (advancedToggle) advancedToggle.innerHTML = '▲ Close Advanced Search';
				}
			}
		}

		// Attach change listener to save filters
		inputFields.forEach(field => {
			field.addEventListener('change', saveStateToSession);
			field.addEventListener('input', saveStateToSession);
		});

		// Restore session filters
		loadStateFromSession();

		// Handle Reset button
		document.addEventListener('click', function(e) {
			if (e.target && e.target.id === 'cz-reset-filters-btn') {
				form.reset();
				inputFields.forEach(field => {
					if (field.name) {
						sessionStorage.removeItem('cz_filter_' + field.name);
					}
				});
				sessionStorage.removeItem('cz_filter_vehicle_model');

				if (makeDropdown) {
					const event = new Event('change');
					makeDropdown.dispatchEvent(event);
				}

				// Dispatch search update
				const submitEvent = new Event('submit', { cancelable: true });
				form.dispatchEvent(submitEvent);
			}
		});

	});
})();
