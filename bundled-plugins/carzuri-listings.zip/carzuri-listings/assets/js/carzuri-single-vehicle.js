/**
 * Carzuri Single Vehicle Detail Page - Contact form submission and validation.
 *
 * @package CarzuriListings
 */

(function() {
	document.addEventListener('DOMContentLoaded', function() {
		const form = document.getElementById('cz-listings-contact-form');
		const statusMsg = document.getElementById('cz-form-status-msg');
		const submitBtn = document.getElementById('cz-listings-submit-inquiry');

		if (!form) return;

		form.addEventListener('submit', function(e) {
			e.preventDefault();

			// 1. Client-Side Rate-Limiting: disable submit button immediately
			submitBtn.disabled = true;
			submitBtn.textContent = 'SENDING...';
			submitBtn.style.opacity = '0.7';

			if (statusMsg) {
				statusMsg.style.display = 'none';
				statusMsg.className = '';
			}

			// Gather form parameters
			const formData = new FormData(form);
			const requestPayload = {};
			for (let [key, val] of formData.entries()) {
				requestPayload[key] = val;
			}

			const restUrl = (typeof CarzuriListingsData !== 'undefined')
				? CarzuriListingsData.rest_url + '/inquiries'
				: '/api/carzuri/v1/inquiries';

			const nonce = (typeof CarzuriListingsData !== 'undefined') ? CarzuriListingsData.nonce : '';

			// 2. POST inquiry to WordPress REST API extension
			fetch(restUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': nonce
				},
				body: JSON.stringify(requestPayload)
			})
			.then(response => {
				return response.json().then(data => {
					if (!response.ok) {
						// Return reject with message
						return Promise.reject(data);
					}
					return data;
				});
			})
			.then(data => {
				// Success
				if (statusMsg) {
					statusMsg.style.display = 'block';
					statusMsg.style.backgroundColor = 'rgba(16, 185, 129, 0.1)';
					statusMsg.style.color = '#10B981';
					statusMsg.style.border = '1px solid rgba(16, 185, 129, 0.2)';
					statusMsg.textContent = data.message || 'Your inquiry has been submitted successfully!';
				}
				form.reset();
				submitBtn.textContent = 'SUBMIT INQUIRY';
				submitBtn.disabled = false;
				submitBtn.style.opacity = '1';
			})
			.catch(err => {
				console.error('Inquiry submission error:', err);
				
				// Show Error
				if (statusMsg) {
					statusMsg.style.display = 'block';
					statusMsg.style.backgroundColor = 'rgba(239, 68, 68, 0.1)';
					statusMsg.style.color = '#EF4444';
					statusMsg.style.border = '1px solid rgba(239, 68, 68, 0.2)';
					statusMsg.textContent = err.message || 'There was an error sending your inquiry. Please try again.';
				}

				// Re-enable button after 2.5 seconds to prevent rapid spam clicking but allow correction
				setTimeout(() => {
					submitBtn.textContent = 'SUBMIT INQUIRY';
					submitBtn.disabled = false;
					submitBtn.style.opacity = '1';
				}, 2500);
			});
		});

	});
})();
