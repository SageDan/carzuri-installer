/**
 * Carzuri Vehicle Grid - Live AJAX filtering, pagination, and favorites toggle.
 *
 * @package CarzuriListings
 */

(function() {
	document.addEventListener('DOMContentLoaded', function() {
		const gridWrapper = document.querySelector('.carzuri-vehicle-grid-wrapper');
		const gridContainer = document.getElementById('carzuri-vehicles-container');
		const filterForm = document.getElementById('carzuri-listings-filter-form');
		const loadMoreBtn = document.getElementById('cz-load-more-vehicles-btn');

		if (!gridContainer) return;

		const isFeaturedOnly = gridWrapper ? gridWrapper.getAttribute('data-featured-only') === 'true' : false;

		// 1. AJAX live filtering from Search Filter form
		if (filterForm && !isFeaturedOnly) {
			filterForm.addEventListener('submit', function(e) {
				e.preventDefault();
				fetchAndRenderVehicles(1); // Load page 1
			});
		}

		// Function to load vehicles via WordPress REST API
		function fetchAndRenderVehicles(page = 1, append = false) {
			if (!gridContainer) return;

			if (!append) {
				gridContainer.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px; color:#D1D5DB;">Loading vehicles...</div>';
			}

			// Prepare queries
			let queryParams = new URLSearchParams();
			queryParams.set('page', page);
			queryParams.set('per_page', gridWrapper ? gridWrapper.getAttribute('data-limit') || 8 : 8);

			if (isFeaturedOnly) {
				queryParams.set('featured', '1');
			} else if (filterForm) {
				const formData = new FormData(filterForm);
				const keyMap = {
					'vehicle_make': 'make',
					'vehicle_body_type': 'body_type',
					'vehicle_location': 'location',
					'max_price': 'price_max',
					'max_mileage': 'mileage_max',
					'vehicle_year': 'year_min'
				};
				for (let [key, value] of formData.entries()) {
					if (value) {
						const apiKey = keyMap[key] || key;
						queryParams.set(apiKey, value);
					}
				}
			}

			const restUrl = (typeof CarzuriListingsData !== 'undefined')
				? CarzuriListingsData.rest_url + '/vehicles'
				: '/api/carzuri/v1/vehicles';

			fetch(`${restUrl}?${queryParams.toString()}`)
				.then(response => {
					// Extract pagination headers if available
					const totalPages = response.headers.get('X-WP-TotalPages');
					if (totalPages && loadMoreBtn) {
						loadMoreBtn.setAttribute('data-max-pages', totalPages);
					}
					return response.json();
				})
				.then(data => {
					// Unwrap vehicles if response is an object, otherwise fallback to data itself if it's an array
					let vehicles = [];
					if (data && typeof data === 'object' && !Array.isArray(data)) {
						vehicles = data.vehicles || [];
						if (data.total_pages && loadMoreBtn) {
							loadMoreBtn.setAttribute('data-max-pages', data.total_pages);
						}
					} else if (Array.isArray(data)) {
						vehicles = data;
					}

					// Reflect the active filters in the browser's URL (without triggering a real page reload)
					if (filterForm) {
						const browserParams = new URLSearchParams();
						const formData = new FormData(filterForm);
						for (let [key, value] of formData.entries()) {
							if (value) {
								browserParams.set(key, value);
							}
						}
						const newUrl = browserParams.toString() 
							? window.location.pathname + '?' + browserParams.toString() 
							: window.location.pathname;
						window.history.pushState({ path: newUrl }, '', newUrl);
					}

					// Announce search update to other scripts
					document.dispatchEvent(new CustomEvent('carzuriFiltersUpdated'));

					if (!Array.isArray(vehicles) || vehicles.length === 0) {
						if (!append) {
							renderEmptyState();
						} else if (loadMoreBtn) {
							loadMoreBtn.style.display = 'none';
						}
						return;
					}

					if (!append) {
						gridContainer.innerHTML = '';
					}

					vehicles.forEach(vehicle => {
						const cardHtml = renderVehicleCardHtml(vehicle);
						const col = document.createElement('div');
						col.className = 'cz-grid-item';
						col.innerHTML = cardHtml;
						gridContainer.appendChild(col);
					});

					// Update Pagination Button visibility
					if (loadMoreBtn) {
						const nextPage = page + 1;
						const maxPages = parseInt(loadMoreBtn.getAttribute('data-max-pages') || 1);
						if (nextPage <= maxPages) {
							loadMoreBtn.setAttribute('data-next-page', nextPage);
							loadMoreBtn.style.display = 'inline-block';
						} else {
							loadMoreBtn.style.display = 'none';
						}
					}

					// Bind event listeners on new cards (e.g. Favorite toggles)
					bindCardInteractions();
				})
				.catch(err => {
					console.error('Failed to load vehicles:', err);
					gridContainer.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px; color:#EF4444;">Error loading listings. Please try again.</div>';
				});
		}

		function applyUrlFiltersOnLoad() {
			const urlParams = new URLSearchParams(window.location.search);
			if (!filterForm) return;

			const keyMap = {
				'make': 'vehicle_make',
				'body_type': 'vehicle_body_type',
				'location': 'vehicle_location',
				'price_max': 'max_price',
				'mileage_max': 'max_mileage',
				'year_min': 'vehicle_year'
			};

			let filtersFound = false;

			for (let [key, value] of urlParams.entries()) {
				const fieldName = keyMap[key] || key;
				const field = filterForm.querySelector(`[name="${fieldName}"]`);
				if (field) {
					field.value = value;
					filtersFound = true;
				}
			}

			if (filtersFound) {
				fetchAndRenderVehicles(1, false);
			}
		}
		applyUrlFiltersOnLoad();

		// 2. Render the thumbnail for a vehicle card - always uses the vehicle's real
		// photo when one exists; NEVER falls back to an external stock photo.
		// If no real photo is available, shows a self-contained "No Image Available"
		// placeholder (inline SVG, no external network dependency).
		function renderThumbnailHtml(vehicle) {
			if (vehicle.featured_image_url) {
				const safeTitle = vehicle.title ? vehicle.title.replace(/"/g, '&quot;') : 'Vehicle photo';
				return `<img src="${vehicle.featured_image_url}" alt="${safeTitle}" style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;">`;
			}

			return `
				<div style="position:absolute; top:0; left:0; width:100%; height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center; background-color:#0A111F; color:#4B5563;">
					<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
						<path d="M3 13l1.5-4.5A2 2 0 0 1 6.4 7h11.2a2 2 0 0 1 1.9 1.5L21 13"/>
						<path d="M5 13h14a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1v-1H7v1a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1z"/>
						<circle cx="7.5" cy="16.5" r="1"/>
						<circle cx="16.5" cy="16.5" r="1"/>
					</svg>
					<span style="font-size:11px; margin-top:8px; color:#6B7280;">No Image Available</span>
				</div>
			`;
		}

		// 3. Render Vehicle Card HTML on-the-fly for AJAX calls
		function renderVehicleCardHtml(vehicle) {
			const formattedPrice = (typeof CarzuriListingsData !== 'undefined')
				? CarzuriListingsData.currency_symbol + ' ' + Number(vehicle.price).toLocaleString()
				: 'KSh ' + Number(vehicle.price).toLocaleString();

			const isFav = vehicle.is_favorited;
			const favColor = isFav ? 'var(--cz-color-gold, #D4AF37)' : '#FFFFFF';
			const favFill = isFav ? 'currentColor' : 'none';

			const badgeHtml = `
				<div class="cz-badge-container" style="position: absolute; top: 12px; left: 12px; display: flex; gap: 6px; z-index: 2;">
					${vehicle.featured ? `<span style="background-color:var(--cz-color-gold, #D4AF37); color:#0A111F; font-size:10px; font-weight:800; padding:4px 8px; border-radius:4px; text-transform:uppercase;">FEATURED</span>` : ''}
					${vehicle.is_new ? `<span style="background-color:#EF4444; color:#FFFFFF; font-size:10px; font-weight:800; padding:4px 8px; border-radius:4px; text-transform:uppercase;">NEW</span>` : ''}
				</div>
			`;

			return `
				<div class="carzuri-vehicle-card" data-vehicle-id="${vehicle.id}" style="background-color: #121A2E; border-radius: 12px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05); display: flex; flex-direction: column; position: relative; cursor: pointer; transition: transform 0.2s; box-sizing: border-box; height:100%;">
					<div class="cz-card-thumbnail" style="position: relative; padding-top: 60%; background-color: #0A111F; overflow: hidden;">
						<a href="${vehicle.permalink || `/vehicles/${vehicle.id}`}" class="cz-card-link-overlay" style="position: absolute; top:0; left:0; width:100%; height:100%; z-index:1;">
							${renderThumbnailHtml(vehicle)}
						</a>
						${badgeHtml}
						<button class="cz-favorite-toggle-btn" data-vehicle-id="${vehicle.id}" style="position: absolute; top: 12px; right: 12px; background: rgba(10, 17, 31, 0.6); backdrop-filter: blur(4px); border: none; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 3; color: ${favColor};">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="${favFill}" stroke="currentColor" stroke-width="2">
								<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
							</svg>
						</button>
						<div class="cz-save-prompt" style="display: none; position: absolute; top: 50px; right: 12px; background-color: #EF4444; color: #FFFFFF; padding: 6px 10px; border-radius: 4px; font-size: 11px; z-index: 4; box-shadow: 0 4px 6px rgba(0,0,0,0.1); white-space: nowrap;">
							<a href="${typeof CarzuriListingsData !== 'undefined' ? CarzuriListingsData.login_url : '#'}" style="color: #FFFFFF; font-weight: 700; text-decoration: underline;">Log in</a> to save favorites
						</div>
					</div>
					<div class="cz-card-body" style="padding: 16px; display: flex; flex-direction: column; flex-grow: 1; position: relative;">
						<h3 class="cz-card-title" style="margin: 0 0 6px 0; font-size: 15px; font-weight: 700; color: #FFFFFF;">
							<a href="${vehicle.permalink || `/vehicles/${vehicle.id}`}" style="color: #FFFFFF; text-decoration: none; z-index: 2; position: relative;">${vehicle.title}</a>
						</h3>
						<div class="cz-card-price" style="font-size: 18px; font-weight: 800; color: var(--cz-color-gold, #D4AF37); margin-bottom: 12px;">${formattedPrice}</div>
						
						<div class="cz-card-specs-row" style="display: flex; gap: 12px; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 12px; margin-bottom: 12px; flex-wrap: wrap;">
							<div class="cz-spec-item" style="display: flex; align-items: center; gap: 4px; color: #9CA3AF; font-size: 11px;">
								<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
								<span>${vehicle.year || 'N/A'}</span>
							</div>
							<div class="cz-spec-item" style="display: flex; align-items: center; gap: 4px; color: #9CA3AF; font-size: 11px;">
								<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 22V4a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v18M14 22V4M6 12h3M6 16h3M18 12h3M18 16h3"/></svg>
								<!-- FIX: was vehicle.fuel, which does not exist in
								     carzuri_get_vehicle_data()'s response — the
								     real key is fuel_type (from the
								     carzuri_fuel_type meta field), which is why
								     this always showed "N/A" regardless of the
								     vehicle's actual fuel type. -->
								<span>${vehicle.fuel_type || 'N/A'}</span>
							</div>
							<div class="cz-spec-item" style="display: flex; align-items: center; gap: 4px; color: #9CA3AF; font-size: 11px;">
								<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
								<span>${vehicle.mileage ? Number(vehicle.mileage).toLocaleString() + ' km' : 'N/A'}</span>
							</div>
						</div>
						
						<div class="cz-card-location" style="display: flex; align-items: center; gap: 4px; color: #9CA3AF; font-size: 11px; margin-top: auto; border-top: 1px solid rgba(255,255,255,0.03); padding-top: 8px;">
							<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
							<!-- FIX: was vehicle.location, which read Core's now-removed
							     free-text carzuri_location meta field — a value that
							     could silently differ from the vehicle_location taxonomy
							     term shown on the server-rendered card (vehicle-card.php),
							     causing the same vehicle to show two different locations
							     depending on how the card was rendered. vehicle.location_name
							     is the taxonomy value and is now the single source of truth
							     everywhere, matching what carzuri_get_vehicle_data() returns. -->
							<span>${vehicle.location_name || 'Nairobi'}</span>
						</div>
					</div>
				</div>
			`;
		}

		// Render Empty State Message
		function renderEmptyState() {
			gridContainer.innerHTML = `
				<div class="cz-empty-state" style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; background-color: #121A2E; border-radius: 12px; border: 1px dashed rgba(255,255,255,0.1);">
					<div style="font-size: 36px; margin-bottom: 12px;">🔍</div>
					<h3 style="font-size: 16px; font-weight: 700; color: #FFFFFF; margin: 0 0 8px 0;">No vehicles match your filters</h3>
					<p style="font-size: 13px; color: #9CA3AF; margin: 0 0 20px 0;">Try broadening or resetting your search parameters.</p>
					<button id="cz-reset-filters-btn" style="background-color: var(--cz-color-gold, #D4AF37); color: #0A111F; font-weight: 700; border: none; border-radius: 6px; padding: 10px 20px; font-size: 12px; text-transform: uppercase; cursor: pointer;">
						Reset Filters
					</button>
				</div>
			`;
		}

		// 3. Carousel Navigation Logic (For featured row only)
		const arrowPrev = document.querySelector('.cz-carousel-arrow-prev');
		const arrowNext = document.querySelector('.cz-carousel-arrow-next');
		if (arrowPrev && arrowNext && gridContainer) {
			arrowNext.addEventListener('click', function() {
				gridContainer.scrollBy({ left: 300, behavior: 'smooth' });
			});
			arrowPrev.addEventListener('click', function() {
				gridContainer.scrollBy({ left: -300, behavior: 'smooth' });
			});
		}

		// 4. Pagination (Load More) logic
		if (loadMoreBtn) {
			loadMoreBtn.addEventListener('click', function() {
				const nextPage = parseInt(this.getAttribute('data-next-page') || 1);
				fetchAndRenderVehicles(nextPage, true);
			});
		}

		// 5. Favorite Heart toggling with live validation
		function bindCardInteractions() {
			const cards = document.querySelectorAll('.carzuri-vehicle-card');
			cards.forEach(card => {
				// Prevent card navigation on heart clicking
				card.addEventListener('click', function(e) {
					if (e.target.closest('.cz-favorite-toggle-btn') || e.target.closest('.cz-save-prompt')) {
						e.stopPropagation();
						e.preventDefault();
						return;
					}
					
					const link = card.querySelector('.cz-card-title a');
					if (link) {
						window.location.href = link.getAttribute('href');
					}
				});

				const favBtn = card.querySelector('.cz-favorite-toggle-btn');
				const savePrompt = card.querySelector('.cz-save-prompt');
				
				if (favBtn) {
					favBtn.addEventListener('click', function(e) {
						e.stopPropagation();
						e.preventDefault();

						const isLogged = (typeof CarzuriListingsData !== 'undefined') ? CarzuriListingsData.is_logged_in : false;
						const vehicleId = this.getAttribute('data-vehicle-id');

						if (!isLogged) {
							// Show non-logged in prompt bubble
							if (savePrompt) {
								savePrompt.style.display = 'block';
								setTimeout(() => {
									savePrompt.style.display = 'none';
								}, 3000);
							}
							return;
						}

						// Logged in: Call Core REST API to toggle favorite status
						const restUrl = (typeof CarzuriListingsData !== 'undefined') 
							? CarzuriListingsData.rest_url + '/favorites'
							: '/api/carzuri/v1/favorites';
						
						const nonce = (typeof CarzuriListingsData !== 'undefined') ? CarzuriListingsData.nonce : '';

						// Optimistic UI state toggling
						const svg = favBtn.querySelector('svg');
						const currentlyFavorited = svg.getAttribute('fill') === 'currentColor';
						
						if (currentlyFavorited) {
							svg.setAttribute('fill', 'none');
							favBtn.style.color = '#FFFFFF';
						} else {
							svg.setAttribute('fill', 'currentColor');
							favBtn.style.color = 'var(--cz-color-gold, #D4AF37)';
						}

						fetch(restUrl, {
							method: 'POST',
							headers: {
								'Content-Type': 'application/json',
								'X-WP-Nonce': nonce
							},
							body: JSON.stringify({ vehicle_id: vehicleId })
						})
						.then(res => res.json())
						.then(resData => {
							// If the new state returned by server matches the state BEFORE toggle, it failed.
							if (resData.is_favorite === currentlyFavorited) {
								// Revert state if error occurred
								revertFavState();
							}
						})
						.catch(err => {
							console.error('Favorite error:', err);
							revertFavState();
						});

						function revertFavState() {
							if (currentlyFavorited) {
								svg.setAttribute('fill', 'currentColor');
								favBtn.style.color = 'var(--cz-color-gold, #D4AF37)';
							} else {
								svg.setAttribute('fill', 'none');
								favBtn.style.color = '#FFFFFF';
							}
						}

					});
				}
			});
		}

		// Initial bind
		bindCardInteractions();

	});
})();
