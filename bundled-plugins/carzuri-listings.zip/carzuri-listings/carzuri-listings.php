<?php
/**
 * Plugin Name: Carzuri Listings
 * Plugin URI:  https://github.com/carzuri/carzuri-listings
 * Description: Carzuri Listings WordPress Plugin. Renders the hero section, search/filter bar, vehicle grids, and single-vehicle templates, integrated with Carzuri Core.
 * Version:     1.0.5
 * Author:      Carzuri Limited
 * Author URI:  https://carzuri.com
 * Text Domain: carzuri-listings
 * Domain Path: /languages
 * License:     Apache-2.0
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define Plugin Constants.
define( 'CARZURI_LISTINGS_VERSION', '1.0.5' );
define( 'CARZURI_LISTINGS_FILE', __FILE__ );
define( 'CARZURI_LISTINGS_DIR', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_LISTINGS_URL', plugin_dir_url( __FILE__ ) );

/**
 * Main Carzuri Listings Class.
 */
class Carzuri_Listings {

	/**
	 * Single instance of the class.
	 *
	 * @var Carzuri_Listings
	 */
	private static $instance = null;

	/**
	 * Get active instance.
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		// Register activation hook.
		register_activation_hook( __FILE__, array( $this, 'activate_plugin' ) );

		// Hook into init (priority 20) so Carzuri Core's post type (registered
		// on init at default priority 10) is guaranteed to exist before we
		// check for it. plugins_loaded fires too early for post_type_exists().
		add_action( 'init', array( $this, 'init_plugin' ), 20 );
	}

	/**
	 * Check dependencies during activation.
	 */
	public function activate_plugin() {
		if ( ! $this->check_dependencies() ) {
			// Deactivate self.
			deactivate_plugins( plugin_basename( __FILE__ ) );
			// Store transiet to show admin notice.
			set_transient( 'carzuri_listings_activation_error', true, 30 );
			wp_die( 'Carzuri Listings requires Carzuri Core to be installed and active. <a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">Go back to Plugins page</a>' );
		}
	}

	/**
	 * Validate dependencies.
	 */
	public function check_dependencies() {
		// Check whether Carzuri Core has registered the vehicle post type.
		return post_type_exists( 'vehicle' );
	}

	/**
	 * Initialize plugin components if dependencies are met.
	 */
	public function init_plugin() {
		// Double check dependency at runtime.
		if ( ! $this->check_dependencies() ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_missing_core' ) );
			return;
		}

		// Include files.
		$this->includes();

		// Instantiate modules.
		Carzuri_Listings_Assets::get_instance();
		Carzuri_Listings_Shortcodes::get_instance();
		Carzuri_Listings_Single_Vehicle_Template::get_instance();
		Carzuri_Listings_REST_Extensions::get_instance();
		Carzuri_Listings_Archive_Redirect::get_instance();
	}

	/**
	 * Show admin notice if Core is missing.
	 */
	public function admin_notice_missing_core() {
		?>
		<div class="notice notice-error is-dismissible">
			<p><?php esc_html_e( 'Carzuri Listings requires Carzuri Core to be installed and active.', 'carzuri-listings' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Include required files.
	 */
	private function includes() {
		require_once CARZURI_LISTINGS_DIR . 'includes/class-assets.php';
		require_once CARZURI_LISTINGS_DIR . 'includes/class-shortcodes.php';
		require_once CARZURI_LISTINGS_DIR . 'includes/class-single-vehicle-template.php';
		require_once CARZURI_LISTINGS_DIR . 'includes/class-rest-extensions.php';
		require_once CARZURI_LISTINGS_DIR . 'includes/class-archive-redirect.php';
	}
}

// Start the plugin.
Carzuri_Listings::get_instance();
