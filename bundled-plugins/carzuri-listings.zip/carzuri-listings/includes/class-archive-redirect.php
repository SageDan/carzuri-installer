<?php
/**
 * Vehicle Archive Redirect Class.
 *
 * WordPress automatically generates a public archive page at /vehicle/
 * because Carzuri Core registered the 'vehicle' post type with
 * has_archive => true. Nobody deliberately built or styled that page —
 * it's rendered by the active theme's generic default archive template
 * (plain title/date/author list, no filters, no vehicle cards), and it
 * duplicates exactly what the purpose-built "Buy Cars" page already does
 * properly (styled grid, search/filter bar, favoriting, pagination).
 *
 * Rather than building and maintaining a second, parallel "browse
 * vehicles" experience, this redirects any visit to the raw /vehicle/
 * archive straight to the real Buy Cars page — same dynamic
 * lookup-by-shortcode pattern already used elsewhere on this site
 * (Dealer Dashboard, Dealer Directory, Site Footer) for locating a real
 * page URL without hardcoding a slug that could change.
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Listings_Archive_Redirect {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'template_redirect', array( $this, 'redirect_vehicle_archive_to_buy_cars' ) );
	}

	/**
	 * Redirect the vehicle post type archive to the Buy Cars page.
	 */
	public function redirect_vehicle_archive_to_buy_cars() {
		if ( ! is_post_type_archive( 'vehicle' ) ) {
			return;
		}

		// Never redirect admin, AJAX, or REST requests — this should only
		// ever affect a real visitor hitting the raw archive URL directly.
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		global $wpdb;

		$buy_cars_url = home_url( '/buy-cars/' );
		$page_id      = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_vehicle_grid%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
		if ( $page_id ) {
			$buy_cars_url = get_permalink( $page_id );
		}

		// 301: this is a permanent architectural decision, not a temporary
		// redirect — the raw archive is never meant to be the canonical
		// "browse vehicles" URL, so search engines should update their
		// index to point at Buy Cars instead.
		wp_safe_redirect( $buy_cars_url, 301 );
		exit;
	}
}
