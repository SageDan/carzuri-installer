<?php
/**
 * Single Vehicle Template Override Class.
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Listings_Single_Vehicle_Template {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'template_include', array( $this, 'override_single_vehicle_template' ) );
	}

	/**
	 * Override the template file for single-vehicle posts.
	 */
	public function override_single_vehicle_template( $template ) {
		if ( is_singular( 'vehicle' ) ) {
			// Enqueue asset scripts
			wp_enqueue_script( 'carzuri-single-vehicle' );

			// Check if a template file exists in the theme first (giving child-theme developers priority)
			$theme_template = locate_template( array( 'single-vehicle.php' ) );
			if ( $theme_template ) {
				return $theme_template;
			}

			// Otherwise, return our plugin's template file
			$plugin_template = CARZURI_LISTINGS_DIR . 'templates/single-vehicle.php';
			if ( file_exists( $plugin_template ) ) {
				return $plugin_template;
			}
		}

		return $template;
	}
}
