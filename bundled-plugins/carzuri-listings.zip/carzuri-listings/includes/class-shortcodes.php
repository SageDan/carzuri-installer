<?php
/**
 * Shortcodes for Carzuri Listings.
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Listings_Shortcodes {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'carzuri_hero', array( $this, 'render_hero_section' ) );
		add_shortcode( 'carzuri_search_bar', array( $this, 'render_search_bar' ) );
		add_shortcode( 'carzuri_vehicle_grid', array( $this, 'render_vehicle_grid' ) );
		add_shortcode( 'carzuri_latest_blog_posts', array( $this, 'render_latest_blog_posts' ) );
	}

	/**
	 * Retrieve cached Makes (taxonomy: vehicle_make).
	 */
	public static function get_cached_makes() {
		$makes = get_transient( 'carzuri_vehicle_makes_list' );

		if ( false === $makes ) {
			$makes = get_terms( array(
				'taxonomy'   => 'vehicle_make',
				'hide_empty' => false,
			) );

			if ( ! is_wp_error( $makes ) && ! empty( $makes ) ) {
				set_transient( 'carzuri_vehicle_makes_list', $makes, HOUR_IN_SECONDS );
			} else {
				$makes = array();
			}
		}

		return $makes;
	}

	/**
	 * Render [carzuri_hero]
	 */
	public function render_hero_section( $atts ) {
		ob_start();
		// Include template
		include CARZURI_LISTINGS_DIR . 'templates/hero-section.php';
		$output = ob_get_clean();
		return str_replace( array( "\r\n", "\n", "\r" ), '', $output );
	}

	/**
	 * Render [carzuri_search_bar]
	 */
	public function render_search_bar( $atts ) {
		wp_enqueue_script( 'carzuri-search-filters' );

		// Load makes and locations for dropdown options
		$makes     = self::get_cached_makes();
		$body_types = get_terms( array( 'taxonomy' => 'vehicle_body_type', 'hide_empty' => false ) );
		$locations  = get_terms( array( 'taxonomy' => 'vehicle_location', 'hide_empty' => false ) );

		if ( is_wp_error( $body_types ) ) {
			$body_types = array();
		}
		if ( is_wp_error( $locations ) ) {
			$locations = array();
		}

		ob_start();
		include CARZURI_LISTINGS_DIR . 'templates/search-filter-bar.php';
		$output = ob_get_clean();
		return str_replace( array( "\r\n", "\n", "\r" ), '', $output );
	}

	/**
	 * Render [carzuri_vehicle_grid]
	 */
	public function render_vehicle_grid( $atts ) {
		wp_enqueue_script( 'carzuri-vehicle-grid' );

		$args = shortcode_atts( array(
			'featured_only' => 'false',
			'limit'         => '5',
			'columns'       => '5',
			'page'          => '1',
		), $atts, 'carzuri_vehicle_grid' );

		// Prepare WP_Query
		$query_args = array(
			'post_type'      => 'vehicle',
			'posts_per_page' => intval( $args['limit'] ),
			'post_status'    => 'publish',
			'paged'          => intval( $args['page'] ),
		);

		// If featured_only is true, filter by meta query
		if ( 'true' === $args['featured_only'] ) {
			$query_args['meta_query'] = array(
				array(
					'key'     => 'carzuri_featured',
					'value'   => '1',
					'compare' => '=',
				),
			);
		}

		// Pull vehicles from database
		$vehicles_query = new WP_Query( $query_args );

		ob_start();
		include CARZURI_LISTINGS_DIR . 'templates/vehicle-grid.php';
		wp_reset_postdata();

		$output = ob_get_clean();
		return str_replace( array( "\r\n", "\n", "\r" ), '', $output );
	}

	/**
	 * Render [carzuri_latest_blog_posts]
	 *
	 * Static grid (no carousel/motion — auto-rotating carousels have poor
	 * engagement and are harder to scan than a plain grid) of the most
	 * recently published native WordPress posts. Queried directly via
	 * WP_Query since this renders server-side on normal page load, the
	 * same way the vehicle grid's own initial render already works —
	 * Core's separate GET /carzuri/v1/blog/latest-posts REST endpoint
	 * remains available for any future JS-driven consumer, but isn't
	 * needed for this static section.
	 *
	 * Deliberately renders nothing at all (not even an empty-state box)
	 * when there are zero published posts yet, so this section simply
	 * doesn't appear on the homepage until real content exists.
	 */
	public function render_latest_blog_posts( $atts ) {
		$args = shortcode_atts( array(
			'count' => '3',
		), $atts, 'carzuri_latest_blog_posts' );

		$count = max( 1, min( intval( $args['count'] ), 12 ) );

		$blog_query = new WP_Query( array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => $count,
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );

		// No published posts yet — render nothing rather than an empty
		// placeholder box, so the section is invisible until it has real
		// content to show.
		if ( ! $blog_query->have_posts() ) {
			wp_reset_postdata();
			return '';
		}

		ob_start();
		include CARZURI_LISTINGS_DIR . 'templates/latest-blog-posts.php';
		wp_reset_postdata();

		$output = ob_get_clean();
		return str_replace( array( "\r\n", "\n", "\r" ), '', $output );
	}
}
