<?php
/**
 * REST API Extensions for Carzuri Listings.
 * Registers extra endpoints under the existing carzuri/v1 namespace.
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Listings_REST_Extensions {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_endpoints' ) );
	}

	/**
	 * Register REST API Endpoints.
	 */
	public function register_endpoints() {
		// POST carzuri/v1/inquiries
		register_rest_route( 'carzuri/v1', '/inquiries', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'handle_create_inquiry' ),
			'permission_callback' => '__return_true', // Public endpoint
		) );

		// GET carzuri/v1/vehicles/{id}/similar
		register_rest_route( 'carzuri/v1', '/vehicles/(?P<id>\d+)/similar', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( $this, 'get_similar_vehicles' ),
			'permission_callback' => '__return_true',
		) );
	}

	/**
	 * POST /carzuri/v1/inquiries handler.
	 */
	public function handle_create_inquiry( WP_REST_Request $request ) {
		global $wpdb;

		// 1. Honeypot check for bots
		$honeypot = $request->get_param( 'website_url_hp' );
		if ( ! empty( $honeypot ) ) {
			// Silent fail for bots
			return new WP_REST_Response( array( 'success' => true, 'message' => 'Spam detected.' ), 200 );
		}

		// 2. Extract and sanitize parameters
		$vehicle_id   = intval( $request->get_param( 'vehicle_id' ) );
		$buyer_name   = sanitize_text_field( $request->get_param( 'buyer_name' ) );
		$buyer_email  = sanitize_email( $request->get_param( 'buyer_email' ) );
		$buyer_phone  = sanitize_text_field( $request->get_param( 'buyer_phone' ) );
		$message      = sanitize_textarea_field( $request->get_param( 'message' ) );

		// Validation
		if ( empty( $vehicle_id ) || empty( $buyer_name ) || empty( $buyer_email ) || empty( $message ) ) {
			return new WP_Error( 'missing_fields', __( 'Please fill in all required fields.', 'carzuri-listings' ), array( 'status' => 400 ) );
		}

		if ( ! is_email( $buyer_email ) ) {
			return new WP_Error( 'invalid_email', __( 'Please enter a valid email address.', 'carzuri-listings' ), array( 'status' => 400 ) );
		}

		// 3. 5-minute duplicate check: reject if same email submitted an inquiry for same vehicle in the last 5 minutes
		$table_name = $wpdb->prefix . 'carzuri_inquiries';
		
		// If table doesn't exist, we can fallback to option or let it error, but let's check first
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) === $table_name ) {
			$five_minutes_ago = date( 'Y-m-d H:i:s', current_time( 'timestamp' ) - 300 );
			$duplicate_count  = $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM $table_name WHERE vehicle_id = %d AND buyer_email = %s AND created_at >= %s",
				$vehicle_id,
				$buyer_email,
				$five_minutes_ago
			) );

			if ( $duplicate_count > 0 ) {
				return new WP_Error( 'duplicate_inquiry', __( 'You have already submitted an inquiry for this vehicle recently. Please wait 5 minutes before trying again.', 'carzuri-listings' ), array( 'status' => 429 ) );
			}
		}

		// 4. Extract dealer_id from vehicle meta
		$dealer_id = get_post_meta( $vehicle_id, 'carzuri_dealer_id', true );
		if ( empty( $dealer_id ) ) {
			$dealer_id = 1; // Fallback default dealer
		}

		// 5. Detect buyer user ID if logged in
		$buyer_user_id = is_user_logged_in() ? get_current_user_id() : null;

		// 6. Write into Core's wp_carzuri_inquiries table
		$data = array(
			'vehicle_id'    => $vehicle_id,
			'dealer_id'     => $dealer_id,
			'buyer_user_id' => $buyer_user_id,
			'buyer_name'    => $buyer_name,
			'buyer_email'   => $buyer_email,
			'buyer_phone'   => $buyer_phone,
			'message'       => $message,
			'status'        => 'new',
			'created_at'    => current_time( 'mysql' ),
		);

		$format = array( '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s' );

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) === $table_name ) {
			$inserted = $wpdb->insert( $table_name, $data, $format );
		} else {
			// Save in standard WP options array as a mock storage if Core is not yet configured on DB side
			$inquiries = get_option( 'carzuri_mock_inquiries', array() );
			$data['id'] = count( $inquiries ) + 1;
			$inquiries[] = $data;
			update_option( 'carzuri_mock_inquiries', $inquiries );
			$inserted = true;
		}

		if ( ! $inserted ) {
			return new WP_Error( 'db_error', __( 'Failed to save inquiry to database. Please try again.', 'carzuri-listings' ), array( 'status' => 500 ) );
		}

		$inquiry_id = $wpdb->insert_id ? $wpdb->insert_id : count( get_option( 'carzuri_mock_inquiries', array() ) );

		// 7. Trigger action hook for inquiry created listeners (e.g. Carzuri Inquiry & Lead System)
		do_action( 'carzuri_inquiry_created', $inquiry_id );

		return new WP_REST_Response( array(
			'success' => true,
			'message' => __( 'Your inquiry has been submitted successfully!', 'carzuri-listings' ),
			'data'    => $data,
		), 200 );
	}

	/**
	 * GET /carzuri/v1/vehicles/{id}/similar handler.
	 */
	public function get_similar_vehicles( WP_REST_Request $request ) {
		$vehicle_id = intval( $request->get_param( 'id' ) );

		if ( ! $vehicle_id ) {
			return new WP_Error( 'invalid_id', __( 'Invalid vehicle ID.', 'carzuri-listings' ), array( 'status' => 400 ) );
		}

		// Find shared terms
		$makes      = wp_get_post_terms( $vehicle_id, 'vehicle_make', array( 'fields' => 'ids' ) );
		$body_types = wp_get_post_terms( $vehicle_id, 'vehicle_body_type', array( 'fields' => 'ids' ) );

		$tax_query = array( 'relation' => 'OR' );

		if ( ! empty( $makes ) && ! is_wp_error( $makes ) ) {
			$tax_query[] = array(
				'taxonomy' => 'vehicle_make',
				'field'    => 'term_id',
				'terms'    => $makes,
			);
		}

		if ( ! empty( $body_types ) && ! is_wp_error( $body_types ) ) {
			$tax_query[] = array(
				'taxonomy' => 'vehicle_body_type',
				'field'    => 'term_id',
				'terms'    => $body_types,
			);
		}

		$args = array(
			'post_type'      => 'vehicle',
			'posts_per_page' => 4,
			'post__not_in'   => array( $vehicle_id ),
			'post_status'    => 'publish',
		);

		if ( count( $tax_query ) > 1 ) {
			$args['tax_query'] = $tax_query;
		}

		$similar_query = new WP_Query( $args );
		$similar_posts = array();

		if ( $similar_query->have_posts() ) {
			while ( $similar_query->have_posts() ) {
				$similar_query->the_post();
				
				// Format vehicle data
				$price   = get_post_meta( get_the_ID(), 'carzuri_price', true );
				$year    = get_post_meta( get_the_ID(), 'carzuri_year', true );
				$fuel    = get_post_meta( get_the_ID(), 'carzuri_fuel_type', true );
				$mileage = get_post_meta( get_the_ID(), 'carzuri_mileage', true );
				
				$location_terms = wp_get_post_terms( get_the_ID(), 'vehicle_location', array( 'fields' => 'names' ) );
				$location       = ! empty( $location_terms ) ? $location_terms[0] : '';

				$similar_posts[] = array(
					'id'        => get_the_ID(),
					'title'     => get_the_title(),
					'permalink' => get_permalink(),
					'image'     => get_the_post_thumbnail_url( get_the_ID(), 'medium' ),
					'price'     => $price,
					'year'      => $year,
					'fuel'      => $fuel,
					'mileage'   => $mileage,
					'location'  => $location,
					'featured'  => get_post_meta( get_the_ID(), 'carzuri_featured', true ) === '1',
					'is_new'    => ( ( time() - get_the_time( 'U' ) ) < ( 14 * DAY_IN_SECONDS ) ),
				);
			}
			wp_reset_postdata();
		}

		return new WP_REST_Response( $similar_posts, 200 );
	}
}
