<?php
/**
 * Asset Manager for Carzuri Listings.
 *
 * @package CarzuriListings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Listings_Assets {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Enqueue frontend CSS and Javascript.
	 */
	public function enqueue_assets() {
		// 1. Enqueue CSS with carzuri-design-system as a hard dependency
		wp_enqueue_style(
			'carzuri-listings-styles',
			CARZURI_LISTINGS_URL . 'assets/css/carzuri-listings.css',
			array( 'carzuri-design-system' ), // Enqueue Core's design system style first
			CARZURI_LISTINGS_VERSION
		);

		// 2. Register Javascript files
		// NOTE: 'carzuri-core' is now declared as an explicit dependency —
		// carzuri-search-filters.js no longer runs its own dependent
		// Make -> Model logic (removed as part of the Make/Model handler
		// consolidation) and instead relies entirely on Core's own global
		// handler in carzuri-core.js to populate the Model dropdown.
		// Core happens to already enqueue that script globally on every
		// front-end page regardless of this dependency, but declaring it
		// here makes that reliance explicit and guaranteed rather than
		// incidental — if Core ever changes how/when it loads its script,
		// WordPress will still enforce the correct load order here.
		wp_register_script(
			'carzuri-search-filters',
			CARZURI_LISTINGS_URL . 'assets/js/carzuri-search-filters.js',
			array( 'carzuri-core' ),
			CARZURI_LISTINGS_VERSION,
			true
		);

		wp_register_script(
			'carzuri-vehicle-grid',
			CARZURI_LISTINGS_URL . 'assets/js/carzuri-vehicle-grid.js',
			array( 'carzuri-search-filters' ),
			CARZURI_LISTINGS_VERSION,
			true
		);

		wp_register_script(
			'carzuri-single-vehicle',
			CARZURI_LISTINGS_URL . 'assets/js/carzuri-single-vehicle.js',
			array(),
			CARZURI_LISTINGS_VERSION,
			true
		);

		// Localize parameters for use in Javascript (REST URLs, nonces, etc.)
		$localization_data = array(
			'rest_url'   => esc_url_raw( rest_url( 'carzuri/v1' ) ),
			'nonce'      => wp_create_nonce( 'wp_rest' ),
			'is_logged_in' => is_user_logged_in(),
			'login_url'  => wp_login_url( get_permalink() ),
			'currency_symbol' => 'KSh',
			'texts'      => array(
				'login_prompt' => __( 'Log in to save favorites', 'carzuri-listings' ),
				'no_results'   => __( 'No vehicles match your filters — try broadening your search', 'carzuri-listings' ),
				'inquiry_success' => __( 'Your inquiry has been sent successfully!', 'carzuri-listings' ),
				'inquiry_error' => __( 'There was an error sending your inquiry. Please try again.', 'carzuri-listings' ),
			)
		);

		wp_localize_script( 'carzuri-search-filters', 'CarzuriListingsData', $localization_data );
		wp_localize_script( 'carzuri-vehicle-grid', 'CarzuriListingsData', $localization_data );
		wp_localize_script( 'carzuri-single-vehicle', 'CarzuriListingsData', $localization_data );
	}
}
