<?php
/**
 * Plugin Name: Carzuri Blog Styling
 * Plugin URI:  https://carzuri.co.ke/plugins/carzuri-blog-styling
 * Description: Gives the native WordPress blog (single posts and the blog index/archive) a styled front-end matching the Carzuri design system, without touching theme files. Blog content itself remains plain native WordPress posts, per this project's decision to avoid a custom CPT.
 * Version:     1.0.0
 * Author:      Carzuri Platform Team
 * Author URI:  https://carzuri.co.ke
 * Text Domain: carzuri-blog-styling
 * License:     GPLv2 or later
 *
 * @package CarzuriBlogStyling
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'CARZURI_BLOG_STYLING_VERSION', '1.0.0' );
define( 'CARZURI_BLOG_STYLING_PATH', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_BLOG_STYLING_URL', plugin_dir_url( __FILE__ ) );

/**
 * Enqueue this plugin's stylesheet only on the pages it actually styles —
 * a single native post, or the blog index (WordPress's configured
 * "Posts page", which per this project is the page at /blog/).
 */
function carzuri_blog_styling_enqueue_assets() {
	if ( is_singular( 'post' ) || is_home() ) {
		// Enqueue Core's shared design system first (fonts, base tokens)
		// so this stylesheet loads after it and can build on the same
		// typography — even though colors here are hardcoded per the
		// project's standing rule, not pulled from CSS variables.
		if ( wp_style_is( 'carzuri-design-system', 'registered' ) ) {
			wp_enqueue_style( 'carzuri-design-system' );
		}

		wp_enqueue_style(
			'carzuri-blog-styling',
			CARZURI_BLOG_STYLING_URL . 'assets/css/carzuri-blog-styling.css',
			array(),
			CARZURI_BLOG_STYLING_VERSION
		);
	}
}
add_action( 'wp_enqueue_scripts', 'carzuri_blog_styling_enqueue_assets' );

/**
 * Swap in our own template for a single native post, or for the blog
 * index (the "Posts page" — this project set the page at /blog/ as
 * WordPress's Posts page under Settings > Reading, so is_home() is the
 * correct check here, not is_page( 'blog' )).
 *
 * Both custom templates still call get_header()/get_footer() so the
 * real site header, nav, and footer (Site Header & Footer plugin) are
 * completely unaffected — only the content area in between is replaced.
 */
function carzuri_blog_styling_template_include( $template ) {
	if ( is_singular( 'post' ) ) {
		$custom = CARZURI_BLOG_STYLING_PATH . 'templates/single-post.php';
		if ( file_exists( $custom ) ) {
			return $custom;
		}
	}

	if ( is_home() ) {
		$custom = CARZURI_BLOG_STYLING_PATH . 'templates/archive-post.php';
		if ( file_exists( $custom ) ) {
			return $custom;
		}
	}

	return $template;
}
add_filter( 'template_include', 'carzuri_blog_styling_template_include', 99 );
