<?php
/**
 * Custom blog index template for the Carzuri blog.
 *
 * This renders on is_home() — the page this project set as WordPress's
 * "Posts page" (Settings > Reading), which lives at /blog/. Calls
 * get_header()/get_footer() so the real site nav and footer are
 * untouched; only the post grid below is custom.
 *
 * @package CarzuriBlogStyling
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="cz-blog">
	<div class="cz-blog-index-header">
		<h1 class="cz-blog-index-title"><?php esc_html_e( 'Automotive News & Insights', 'carzuri-blog-styling' ); ?></h1>
		<p class="cz-blog-index-subtitle"><?php esc_html_e( 'Buying guides, market trends, and tips from the Carzuri team.', 'carzuri-blog-styling' ); ?></p>
	</div>

	<?php if ( have_posts() ) : ?>
		<div class="cz-blog-grid">
			<?php
			while ( have_posts() ) :
				the_post();

				$categories = get_the_category();
				$cat_name   = ! empty( $categories ) ? $categories[0]->name : '';
				?>
				<div class="cz-blog-card">
					<a href="<?php the_permalink(); ?>" class="cz-blog-card-img-wrap">
						<?php if ( has_post_thumbnail() ) : ?>
							<?php the_post_thumbnail( 'medium_large' ); ?>
						<?php else : ?>
							<div class="cz-blog-card-noimage"><?php esc_html_e( 'No Image Available', 'carzuri-blog-styling' ); ?></div>
						<?php endif; ?>

						<?php if ( $cat_name ) : ?>
							<span class="cz-blog-card-category"><?php echo esc_html( $cat_name ); ?></span>
						<?php endif; ?>
					</a>

					<div class="cz-blog-card-body">
						<div class="cz-blog-card-date"><?php echo esc_html( get_the_date() ); ?></div>
						<h2 class="cz-blog-card-title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h2>
						<p class="cz-blog-card-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
						<a href="<?php the_permalink(); ?>" class="cz-blog-card-readmore"><?php esc_html_e( 'Read More →', 'carzuri-blog-styling' ); ?></a>
					</div>
				</div>
			<?php endwhile; ?>
		</div>

		<div class="cz-blog-pagination">
			<?php
			echo paginate_links( array(
				'prev_text' => __( '&larr; Prev', 'carzuri-blog-styling' ),
				'next_text' => __( 'Next &rarr;', 'carzuri-blog-styling' ),
			) );
			?>
		</div>

	<?php else : ?>
		<div class="cz-blog-empty">
			<?php esc_html_e( 'No blog posts published yet — check back soon.', 'carzuri-blog-styling' ); ?>
		</div>
	<?php endif; ?>
</div>

<?php
get_footer();
