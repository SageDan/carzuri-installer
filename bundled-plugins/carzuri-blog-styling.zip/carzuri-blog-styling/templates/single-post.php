<?php
/**
 * Custom single-post template for the Carzuri blog.
 *
 * Deliberately calls get_header()/get_footer() so the site's real nav,
 * header, and footer (Site Header & Footer plugin) render exactly as on
 * every other page — only the content area below is replaced.
 *
 * @package CarzuriBlogStyling
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="cz-blog">
	<a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>" class="cz-blog-back-link">
		&larr; <?php esc_html_e( 'Back to Blog', 'carzuri-blog-styling' ); ?>
	</a>

	<?php
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();

			$categories  = get_the_category();
			$cat_name    = ! empty( $categories ) ? $categories[0]->name : '';
			$author_name = get_the_author();
			$post_date   = get_the_date();
			?>

			<div class="cz-blog-single-hero">
				<?php if ( has_post_thumbnail() ) : ?>
					<?php the_post_thumbnail( 'full' ); ?>
				<?php else : ?>
					<div class="cz-blog-single-hero-noimage"><?php esc_html_e( 'No Image Available', 'carzuri-blog-styling' ); ?></div>
				<?php endif; ?>

				<?php if ( $cat_name ) : ?>
					<span class="cz-blog-single-category"><?php echo esc_html( $cat_name ); ?></span>
				<?php endif; ?>
			</div>

			<h1 class="cz-blog-single-title"><?php the_title(); ?></h1>

			<div class="cz-blog-single-meta">
				<span><?php esc_html_e( 'By', 'carzuri-blog-styling' ); ?> <strong><?php echo esc_html( $author_name ); ?></strong></span>
				<span><?php echo esc_html( $post_date ); ?></span>
			</div>

			<div class="cz-blog-single-content">
				<?php the_content(); ?>
			</div>

			<div class="cz-blog-single-footer">
				<a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>" class="cz-blog-back-link">
					&larr; <?php esc_html_e( 'Back to Blog', 'carzuri-blog-styling' ); ?>
				</a>
			</div>

		<?php endwhile; ?>
	<?php endif; ?>
</div>

<?php
get_footer();
