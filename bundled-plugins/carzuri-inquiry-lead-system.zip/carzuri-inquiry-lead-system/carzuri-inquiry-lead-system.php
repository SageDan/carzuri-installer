<?php
/**
 * Plugin Name: Carzuri Inquiry & Lead System
 * Description: Buyer-facing inquiries view, REST endpoints, and notification action triggers.
 * Version: 1.0.0
 * Author: Carzuri
 * Text Domain: carzuri-inquiry-lead-system
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * --------------------------------------------------------------------------
 * 1. ACTION HOOK TRIGGERS (INBOUND LEADS & STATUS UPDATES)
 * --------------------------------------------------------------------------
 */

/**
 * Triggered when a new inquiry is created.
 * Creates an in-app notification for the dealer.
 */
add_action( 'carzuri_inquiry_created', 'carzuri_handle_inquiry_created_notification', 10, 1 );
function carzuri_handle_inquiry_created_notification( $inquiry_id ) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'carzuri_inquiries';
    
    // Fetch inquiry row to get dealer user ID and vehicle ID
    $inquiry = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$table_name} WHERE id = %d",
        $inquiry_id
    ) );
    
    if ( ! $inquiry ) {
        return;
    }
    
    $dealer_id = isset( $inquiry->dealer_id ) ? intval( $inquiry->dealer_id ) : 0;
    if ( ! $dealer_id ) {
        return;
    }
    
    $vehicle_title = get_the_title( $inquiry->vehicle_id );
    $title = __( 'New inquiry received', 'carzuri-inquiry-lead-system' );
    $message = sprintf(
        __( 'You received a new inquiry on vehicle "%s".', 'carzuri-inquiry-lead-system' ),
        $vehicle_title ? $vehicle_title : '#' . $inquiry->vehicle_id
    );
    
    // Link to the dealer's Inbound Leads tab in Dealer Marketplace
    $link = home_url( '/dealer-dashboard/?tab=inbound-leads' );
    
    if ( function_exists( 'carzuri_create_notification' ) ) {
        carzuri_create_notification( $dealer_id, 'new_inquiry', $title, $message, $link );
    }
}

/**
 * Triggered when an inquiry's status is updated.
 * Creates an in-app notification for the buyer.
 */
add_action( 'carzuri_inquiry_status_changed', 'carzuri_handle_inquiry_status_changed_notification', 10, 2 );
function carzuri_handle_inquiry_status_changed_notification( $inquiry_id, $new_status ) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'carzuri_inquiries';
    
    // Fetch inquiry row
    $inquiry = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$table_name} WHERE id = %d",
        $inquiry_id
    ) );
    
    if ( ! $inquiry || empty( $inquiry->buyer_user_id ) ) {
        return; // Skip silently for guest inquiries (null buyer_user_id)
    }
    
    $buyer_id = intval( $inquiry->buyer_user_id );
    $vehicle_title = get_the_title( $inquiry->vehicle_id );
    
    $title = __( 'Inquiry Status Updated', 'carzuri-inquiry-lead-system' );
    $message = sprintf(
        __( 'Your inquiry on "%s" is now "%s".', 'carzuri-inquiry-lead-system' ),
        $vehicle_title ? $vehicle_title : '#' . $inquiry->vehicle_id,
        ucfirst( $new_status )
    );
    
    // Link to the buyer's My Inquiries page
    $link = home_url( '/my-inquiries/' );
    
    if ( function_exists( 'carzuri_create_notification' ) ) {
        carzuri_create_notification( $buyer_id, 'inquiry_status_update', $title, $message, $link );
    }
}


/**
 * --------------------------------------------------------------------------
 * 2. REST API ENDPOINT: GET carzuri/v1/my-inquiries
 * --------------------------------------------------------------------------
 */
add_action( 'rest_api_init', 'carzuri_register_inquiry_routes' );
function carzuri_register_inquiry_routes() {
    register_rest_route( 'carzuri/v1', '/my-inquiries', array(
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => 'carzuri_get_my_inquiries',
        'permission_callback' => 'carzuri_get_my_inquiries_permissions_check',
    ) );
}

/**
 * Ensures the user is logged in before accessing private inquiries.
 */
function carzuri_get_my_inquiries_permissions_check( $request ) {
    return is_user_logged_in();
}

/**
 * Returns only the authenticated user's inquiries, sorted newest first.
 * Conforms to existing /vehicles response pattern (object, not bare array).
 */
function carzuri_get_my_inquiries( $request ) {
    global $wpdb;
    $current_user_id = get_current_user_id();
    $table_name = $wpdb->prefix . 'carzuri_inquiries';
    
    // Retrieve inquiries for current buyer, newest first
    $inquiries = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$table_name} WHERE buyer_user_id = %d ORDER BY created_at DESC",
        $current_user_id
    ) );
    
    $formatted_inquiries = array();
    
    if ( ! empty( $inquiries ) ) {
        foreach ( $inquiries as $inquiry ) {
            $vehicle_id = intval( $inquiry->vehicle_id );
            
            // Vehicle metadata & thumbnail
            $vehicle_title = get_the_title( $vehicle_id );
            $vehicle_permalink = get_permalink( $vehicle_id );
            $thumbnail_id = get_post_thumbnail_id( $vehicle_id );
            $thumbnail_url = $thumbnail_id ? wp_get_attachment_image_url( $thumbnail_id, 'thumbnail' ) : '';
            
            // Dealer Business Name (fallback cascade)
            $dealer_business_name = '';
            if ( isset( $inquiry->dealer_business_name ) && ! empty( $inquiry->dealer_business_name ) ) {
                $dealer_business_name = $inquiry->dealer_business_name;
            } elseif ( isset( $inquiry->dealer_id ) ) {
                $dealer_id = intval( $inquiry->dealer_id );
                $dealer_business_name = get_user_meta( $dealer_id, 'carzuri_dealer_business_name', true );
                if ( empty( $dealer_business_name ) ) {
                    $dealer_info = get_userdata( $dealer_id );
                    $dealer_business_name = $dealer_info ? $dealer_info->display_name : '';
                }
            }
            
            $formatted_inquiries[] = array(
                'id'                   => intval( $inquiry->id ),
                'vehicle_id'           => $vehicle_id,
                'vehicle_title'        => $vehicle_title ? $vehicle_title : sprintf( __( 'Vehicle #%d', 'carzuri-inquiry-lead-system' ), $vehicle_id ),
                'vehicle_thumbnail'    => $thumbnail_url,
                'vehicle_link'         => $vehicle_permalink,
                'date_submitted'       => $inquiry->created_at,
                'status'               => $inquiry->status,
                'dealer_business_name' => $dealer_business_name,
                'message'              => isset( $inquiry->message ) ? $inquiry->message : ''
            );
        }
    }
    
    // Consistent with Core's response shape: { inquiries: [...], total_results }
    return new WP_REST_Response( array(
        'inquiries'     => $formatted_inquiries,
        'total_results' => count( $formatted_inquiries )
    ), 200 );
}


/**
 * --------------------------------------------------------------------------
 * 3. BUYER-FACING FRONTEND SHORTCODE [carzuri_my_inquiries]
 * --------------------------------------------------------------------------
 */
add_shortcode( 'carzuri_my_inquiries', 'carzuri_render_my_inquiries' );
function carzuri_render_my_inquiries( $atts ) {
    // 1. Force authenticated status check
    if ( ! is_user_logged_in() ) {
        return sprintf(
            '<div class="carzuri-login-required" style="background: var(--carzuri-navy-dark, #0a192f); color: #ffffff; padding: 24px; border-radius: 8px; text-align: center; border: 1px solid var(--carzuri-gold, #f5a623); max-width: 500px; margin: 30px auto; font-family: var(--carzuri-font-sans, sans-serif);">
                <p style="margin-bottom: 16px; font-size: 1.1rem; font-weight: 500;">%s</p>
                <a href="%s" class="button" style="background: var(--carzuri-gold, #f5a623); color: var(--carzuri-navy-dark, #0a192f); padding: 12px 24px; border-radius: 4px; text-decoration: none; font-weight: bold; display: inline-block; transition: opacity 0.2s;">%s</a>
             </div>',
            esc_html__( 'Please log in to view your inquiries.', 'carzuri-inquiry-lead-system' ),
            esc_url( wp_login_url( get_permalink() ) ),
            esc_html__( 'Log In', 'carzuri-inquiry-lead-system' )
        );
    }
    
    // 2. Enqueue design system and local styles
    wp_enqueue_style( 'carzuri-design-system' );
    wp_enqueue_style( 'carzuri-my-inquiries-style', plugins_url( 'assets/css/my-inquiries.css', __FILE__ ), array( 'carzuri-design-system' ), '1.0.0' );
    
    // 3. Retrieve inquiries using internal REST logic for data security
    $request = new WP_REST_Request( 'GET', '/carzuri/v1/my-inquiries' );
    $response = carzuri_get_my_inquiries( $request );
    $data = $response->get_data();
    
    $inquiries = isset( $data['inquiries'] ) ? $data['inquiries'] : array();
    
    ob_start();
    ?>
    <div class="carzuri-my-inquiries-container">
        <h2 class="carzuri-section-title"><?php esc_html_e( 'My Submitted Inquiries', 'carzuri-inquiry-lead-system' ); ?></h2>
        
        <?php if ( empty( $inquiries ) ) : ?>
            <p class="carzuri-no-inquiries"><?php esc_html_e( 'You have not submitted any inquiries yet.', 'carzuri-inquiry-lead-system' ); ?></p>
        <?php else : ?>
            <div class="carzuri-inquiries-list">
                <?php foreach ( $inquiries as $inquiry ) : ?>
                    <div class="carzuri-inquiry-card" id="carzuri-inquiry-<?php echo esc_attr( $inquiry['id'] ); ?>">
                        
                        <div class="carzuri-inquiry-image">
                            <?php if ( ! empty( $inquiry['vehicle_thumbnail'] ) ) : ?>
                                <img src="<?php echo esc_url( $inquiry['vehicle_thumbnail'] ); ?>" alt="<?php echo esc_attr( $inquiry['vehicle_title'] ); ?>" referrerPolicy="no-referrer" />
                            <?php else : ?>
                                <div class="carzuri-image-placeholder"></div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="carzuri-inquiry-details">
                            <h3 class="carzuri-vehicle-title">
                                <a href="<?php echo esc_url( $inquiry['vehicle_link'] ); ?>"><?php echo esc_html( $inquiry['vehicle_title'] ); ?></a>
                            </h3>
                            
                            <?php if ( ! empty( $inquiry['dealer_business_name'] ) ) : ?>
                                <p class="carzuri-dealer-name">
                                    <span class="label"><?php esc_html_e( 'Dealer:', 'carzuri-inquiry-lead-system' ); ?></span>
                                    <span class="value"><?php echo esc_html( $inquiry['dealer_business_name'] ); ?></span>
                                </p>
                            <?php endif; ?>
                            
                            <p class="carzuri-inquiry-date">
                                <span class="label"><?php esc_html_e( 'Submitted:', 'carzuri-inquiry-lead-system' ); ?></span>
                                <span class="value"><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $inquiry['date_submitted'] ) ) ); ?></span>
                            </p>
                        </div>
                        
                        <div class="carzuri-inquiry-status-col">
                            <span class="carzuri-status-badge status-<?php echo esc_attr( $inquiry['status'] ); ?>">
                                <?php echo esc_html( ucfirst( $inquiry['status'] ) ); ?>
                            </span>
                        </div>
                        
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
