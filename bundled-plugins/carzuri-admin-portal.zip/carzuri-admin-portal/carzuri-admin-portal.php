<?php
/**
 * Plugin Name: Carzuri Admin Portal
 * Plugin URI:  https://carzuri.co.ke/plugins/carzuri-admin-portal
 * Description: Front-end administrative portal for the carzuri_admin role. Manages dealer approvals, vehicle approvals, and finance queue access without wp-admin.
 * Version:     1.1.4
 * Author:      Carzuri Platform Team
 * Author URI:  https://carzuri.co.ke
 * Text Domain: carzuri-admin-portal
 * Domain Path: /languages
 * License:     GPLv2 or later
 *
 * @package CarzuriAdminPortal
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'CARZURI_ADMIN_PORTAL_VERSION', '1.1.4' );
define( 'CARZURI_ADMIN_PORTAL_PATH', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_ADMIN_PORTAL_URL', plugin_dir_url( __FILE__ ) );

/**
 * Include required core classes.
 */
require_once CARZURI_ADMIN_PORTAL_PATH . 'includes/class-carzuri-admin-roles.php';
require_once CARZURI_ADMIN_PORTAL_PATH . 'includes/class-carzuri-admin-shortcodes.php';
require_once CARZURI_ADMIN_PORTAL_PATH . 'includes/class-carzuri-admin-blog-rest.php';

/**
 * Initialize Plugin Components.
 */
function carzuri_admin_portal_init() {
	// Initialize role & admin-bar / wp-admin access rules
	Carzuri_Admin_Roles::init();

	// Initialize shortcodes
	Carzuri_Admin_Shortcodes::init();

	// Initialize Blog tab REST endpoints
	Carzuri_Admin_Blog_REST::init();
}
add_action( 'plugins_loaded', 'carzuri_admin_portal_init' );

/**
 * Enqueue Frontend Scripts and Styles for Shortcodes.
 */
function carzuri_admin_portal_enqueue_assets() {
	global $post;

	// Always enqueue on singular pages containing our shortcodes, or enqueue globally if required
	$has_login_shortcode     = is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'carzuri_admin_login' );
	$has_dashboard_shortcode = is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'carzuri_admin_dashboard' );

	if ( $has_login_shortcode || $has_dashboard_shortcode || is_page( 'carzuri-admin' ) || is_page( 'admin-portal' ) ) {
		// Enqueue Core's design system handle (registered by Core)
		wp_enqueue_style( 'carzuri-design-system' );

		wp_enqueue_style(
			'carzuri-admin-portal-styles',
			CARZURI_ADMIN_PORTAL_URL . 'assets/css/carzuri-admin-portal.css',
			array( 'carzuri-design-system' ),
			CARZURI_ADMIN_PORTAL_VERSION
		);

		wp_enqueue_script(
			'carzuri-admin-portal-js',
			CARZURI_ADMIN_PORTAL_URL . 'assets/js/carzuri-admin-portal.js',
			array( 'jquery' ),
			CARZURI_ADMIN_PORTAL_VERSION,
			true
		);

		// Pass localized script parameters safely without inline scripts
		wp_localize_script(
			'carzuri-admin-portal-js',
			'carzuriAdminVars',
			array(
				'ajax_url'     => admin_url( 'admin-ajax.php' ),
				'login_nonce'  => wp_create_nonce( 'carzuri_admin_login_action' ),
				'root'         => esc_url_raw( rest_url( 'carzuri/v1/' ) ),
				'nonce'        => wp_create_nonce( 'wp_rest' ),
				'current_user' => array(
					'id'          => get_current_user_id(),
					'display_name'=> wp_get_current_user()->display_name,
					'email'       => wp_get_current_user()->user_email,
					'roles'       => (array) wp_get_current_user()->roles,
					'is_admin'    => current_user_can( 'carzuri_admin' ) || current_user_can( 'manage_options' ),
				),
				'login_url'         => site_url( '/admin-login/' ),
				'dashboard_url'     => site_url( '/carzuri-admin-portal/' ),
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'carzuri_admin_portal_enqueue_assets' );

/**
 * Plugin activation hook: register carzuri_admin role if not existing.
 */
function carzuri_admin_portal_activate() {
	if ( ! get_role( 'carzuri_admin' ) ) {
		add_role(
			'carzuri_admin',
			__( 'Carzuri Administrator', 'carzuri-admin-portal' ),
			array(
				'read'                      => true,
				'carzuri_admin'             => true,
				'approve_dealers'          => true,
				'approve_vehicles'         => true,
				'view_finance_applications' => true,
			)
		);
	}
}
register_activation_hook( __FILE__, 'carzuri_admin_portal_activate' );
