<?php
/**
 * Shortcode Handlers for Carzuri Admin Portal.
 *
 * @package CarzuriAdminPortal
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Admin_Shortcodes {

	/**
	 * Initialize shortcodes and AJAX actions.
	 */
	public static function init() {
		add_shortcode( 'carzuri_admin_login', array( __CLASS__, 'render_admin_login' ) );
		add_shortcode( 'carzuri_admin_dashboard', array( __CLASS__, 'render_admin_dashboard' ) );

		// Register AJAX actions for front-end login
		add_action( 'wp_ajax_carzuri_admin_login', array( __CLASS__, 'handle_admin_login_ajax' ) );
		add_action( 'wp_ajax_nopriv_carzuri_admin_login', array( __CLASS__, 'handle_admin_login_ajax' ) );
	}

	/**
	 * AJAX handler for carzuri_admin_login form submission.
	 */
	public static function handle_admin_login_ajax() {
		// Verify security nonce
		if ( ! isset( $_POST['carzuri_login_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( $_POST['carzuri_login_nonce'] ), 'carzuri_admin_login_action' ) ) {
			wp_send_json_error( array(
				'message' => __( 'Security verification failed. Please refresh the page and try again.', 'carzuri-admin-portal' ),
			) );
		}

		$username = isset( $_POST['log'] ) ? sanitize_text_field( $_POST['log'] ) : '';
		$password = isset( $_POST['pwd'] ) ? $_POST['pwd'] : '';
		$remember = ! empty( $_POST['rememberme'] );

		if ( empty( $username ) || empty( $password ) ) {
			wp_send_json_error( array(
				'message' => __( 'Please enter both username and password.', 'carzuri-admin-portal' ),
			) );
		}

		$creds = array(
			'user_login'    => $username,
			'user_password' => $password,
			'remember'      => $remember,
		);

		$user = wp_signon( $creds, is_ssl() );

		if ( is_wp_error( $user ) ) {
			wp_send_json_error( array(
				'message' => $user->get_error_message(),
			) );
		}

		// Verify role
		if ( in_array( 'carzuri_admin', (array) $user->roles, true ) || user_can( $user, 'manage_options' ) ) {
			// New Device Verification — shared mechanism from Carzuri Core
			// (carzuri_is_known_device() / carzuri_send_device_verification_code()).
			// Admin accounts are the highest-value target on this site, so
			// this check applies here exactly as it does for Dealer and
			// Buyer logins; verifying a device once for an account here is
			// also remembered on the other two login flows, since the
			// check is keyed on user_id alone.
			if ( ! carzuri_is_known_device( $user->ID ) ) {
				wp_logout();
				carzuri_send_device_verification_code( $user->ID );

				wp_send_json_success( array(
					'requires_device_verification' => true,
					'user_id'                      => $user->ID,
					'remember'                     => $remember,
					'redirect_url'                 => site_url( '/carzuri-admin-portal/' ),
					'message'                      => __( 'For your security, we emailed you a verification code. Please enter it below to finish signing in.', 'carzuri-admin-portal' ),
				) );
			}

			wp_send_json_success( array(
				'message'      => __( 'Login successful! Redirecting to admin portal...', 'carzuri-admin-portal' ),
				'redirect_url' => site_url( '/carzuri-admin-portal/' ),
			) );
		} else {
			wp_logout();
			wp_send_json_error( array(
				'message' => __( 'Access Denied. Your account does not have carzuri_admin privileges.', 'carzuri-admin-portal' ),
			) );
		}
	}

	/**
	 * Render [carzuri_admin_login] shortcode.
	 */
	public static function render_admin_login() {
		ob_start();

		// Logged in state view
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			$is_admin     = in_array( 'carzuri_admin', (array) $current_user->roles, true ) || current_user_can( 'manage_options' );
			?>
			<div class="cz-admin-portal cz-card cz-login-profile-card">
				<div class="cz-card-header cz-flex cz-items-center cz-justify-between">
					<div class="cz-flex cz-items-center cz-gap-3">
						<div class="cz-avatar cz-avatar-admin">
							<span><?php echo esc_html( strtoupper( substr( $current_user->display_name, 0, 1 ) ) ); ?></span>
						</div>
						<div>
							<h3 class="cz-text-lg cz-font-bold cz-m-0"><?php echo esc_html( $current_user->display_name ); ?></h3>
							<p class="cz-text-sm cz-text-muted cz-m-0"><?php echo esc_html( $current_user->user_email ); ?></p>
						</div>
					</div>
					<span class="cz-badge <?php echo $is_admin ? 'cz-badge-success' : 'cz-badge-warning'; ?>">
						<?php echo $is_admin ? esc_html__( 'Administrator', 'carzuri-admin-portal' ) : esc_html__( 'Limited Access', 'carzuri-admin-portal' ); ?>
					</span>
				</div>
				<div class="cz-card-body cz-pt-4">
					<?php if ( $is_admin ) : ?>
						<p class="cz-text-sm cz-mb-4"><?php esc_html_e( 'You are logged in with full administrative capabilities for dealer and vehicle approvals.', 'carzuri-admin-portal' ); ?></p>
						<div class="cz-flex cz-gap-3">
							<a href="<?php echo esc_url( site_url( '/carzuri-admin-portal/' ) ); ?>" class="cz-btn cz-btn-primary">
								<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 18px; height: 18px;"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
								<?php esc_html_e( 'Open Admin Dashboard', 'carzuri-admin-portal' ); ?>
							</a>
							<a href="<?php echo esc_url( wp_logout_url( get_permalink() ) ); ?>" class="cz-btn cz-btn-secondary">
								<?php esc_html_e( 'Sign Out', 'carzuri-admin-portal' ); ?>
							</a>
						</div>
					<?php else : ?>
						<div class="cz-alert cz-alert-error cz-mb-4">
							<?php esc_html_e( 'Your account does not have administrator access to this portal.', 'carzuri-admin-portal' ); ?>
						</div>
						<a href="<?php echo esc_url( wp_logout_url( get_permalink() ) ); ?>" class="cz-btn cz-btn-secondary">
							<?php esc_html_e( 'Sign Out and Switch Account', 'carzuri-admin-portal' ); ?>
						</a>
					<?php endif; ?>
				</div>
			</div>
			<?php
			return ob_get_clean();
		}

		// Login Form View (AJAX submission)
		?>
		<div class="cz-admin-portal cz-login-wrapper">
			<div class="cz-login-card cz-card">
				<div class="cz-login-header cz-text-center">
					<div class="cz-brand-logo cz-mb-2">
						<span class="cz-logo-accent">CARZURI</span> ADMIN
					</div>
					<h2 class="cz-login-title"><?php esc_html_e( 'Admin Portal Login', 'carzuri-admin-portal' ); ?></h2>
					<p class="cz-login-subtitle"><?php esc_html_e( 'Administrative credentials required to manage site operations', 'carzuri-admin-portal' ); ?></p>
				</div>

				<div id="cz-login-alert" class="cz-alert-container cz-mb-4" style="display: none;"></div>

				<form class="cz-login-form" id="cz-admin-login-form">
					<?php wp_nonce_field( 'carzuri_admin_login_action', 'carzuri_login_nonce' ); ?>

					<div class="cz-form-group">
						<label for="carzuri_admin_user" class="cz-label"><?php esc_html_e( 'Username or Email Address', 'carzuri-admin-portal' ); ?></label>
						<div class="cz-input-wrapper">
							<input type="text" name="log" id="carzuri_admin_user" class="cz-input" required autocomplete="username" placeholder="admin@carzuri.co.ke">
						</div>
					</div>

					<div class="cz-form-group">
						<label for="carzuri_admin_pass" class="cz-label"><?php esc_html_e( 'Password', 'carzuri-admin-portal' ); ?></label>
						<div class="cz-input-wrapper cz-password-wrapper">
							<input type="password" name="pwd" id="carzuri_admin_pass" class="cz-input" required autocomplete="current-password" placeholder="••••••••••••">
							<button type="button" class="cz-btn-toggle-password" id="cz-toggle-pwd-btn" aria-label="Toggle password visibility">
								<svg class="cz-icon cz-icon-eye" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 18px; height: 18px;"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
							</button>
						</div>
					</div>

					<div class="cz-flex cz-items-center cz-justify-between cz-mb-4">
						<label class="cz-checkbox-label">
							<input type="checkbox" name="rememberme" value="forever" class="cz-checkbox">
							<span><?php esc_html_e( 'Remember Me', 'carzuri-admin-portal' ); ?></span>
						</label>
					</div>

					<button type="submit" name="carzuri_admin_login_submit" class="cz-btn cz-btn-primary cz-btn-block cz-btn-lg">
						<?php esc_html_e( 'Sign In to Portal', 'carzuri-admin-portal' ); ?>
					</button>
				</form>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render [carzuri_admin_dashboard] shortcode.
	 */
	public static function render_admin_dashboard() {
		ob_start();

		// Access permission check
		if ( ! is_user_logged_in() ) {
			?>
			<div class="cz-admin-portal cz-access-denied-wrapper">
				<div class="cz-card cz-text-center cz-p-6">
					<div class="cz-mb-4">
						<svg class="cz-icon cz-text-danger" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 48px; height: 48px; margin: 0 auto;"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
					</div>
					<h3 class="cz-text-xl cz-font-bold cz-mb-2"><?php esc_html_e( 'Authentication Required', 'carzuri-admin-portal' ); ?></h3>
					<p class="cz-text-muted cz-mb-4"><?php esc_html_e( 'You must be logged in as a Carzuri Administrator to access the admin portal.', 'carzuri-admin-portal' ); ?></p>
					<a href="<?php echo esc_url( site_url( '/admin-login/' ) ); ?>" class="cz-btn cz-btn-primary">
						<?php esc_html_e( 'Go to Admin Login', 'carzuri-admin-portal' ); ?>
					</a>
				</div>
			</div>
			<?php
			return ob_get_clean();
		}

		$current_user = wp_get_current_user();
		$is_admin     = in_array( 'carzuri_admin', (array) $current_user->roles, true ) || current_user_can( 'manage_options' );

		if ( ! $is_admin ) {
			?>
			<div class="cz-admin-portal cz-access-denied-wrapper">
				<div class="cz-card cz-p-6">
					<div class="cz-alert cz-alert-error cz-mb-4">
						<h4 class="cz-font-bold cz-m-0 cz-mb-1"><?php esc_html_e( 'Restricted Access', 'carzuri-admin-portal' ); ?></h4>
						<p class="cz-m-0"><?php esc_html_e( 'This portal is reserved for administrator accounts. If you believe you should have access, please contact your site owner.', 'carzuri-admin-portal' ); ?></p>
					</div>
					<a href="<?php echo esc_url( wp_logout_url( site_url( '/admin-login/' ) ) ); ?>" class="cz-btn cz-btn-secondary">
						<?php esc_html_e( 'Log Out & Switch User', 'carzuri-admin-portal' ); ?>
					</a>
				</div>
			</div>
			<?php
			return ob_get_clean();
		}

		// Main Dashboard Shell
		?>
		<div class="cz-admin-portal cz-dashboard-container" id="carzuri-admin-dashboard-app">
			
			<!-- Portal Header -->
			<div class="cz-dashboard-header cz-flex cz-items-center cz-justify-between cz-mb-6">
				<div>
					<div class="cz-flex cz-items-center cz-gap-2">
						<span class="cz-brand-badge">CARZURI</span>
						<h1 class="cz-dashboard-title cz-m-0"><?php esc_html_e( 'Admin Portal', 'carzuri-admin-portal' ); ?></h1>
					</div>
					<p class="cz-text-muted cz-m-0 cz-mt-1"><?php esc_html_e( 'Full management dashboard for dealer approvals, vehicle moderation, and finance queues.', 'carzuri-admin-portal' ); ?></p>
				</div>
				<div class="cz-flex cz-items-center cz-gap-3">
					<div class="cz-user-pill">
						<span class="cz-user-dot"></span>
						<span class="cz-user-name"><?php echo esc_html( $current_user->display_name ); ?></span>
					</div>
					<a href="<?php echo esc_url( wp_logout_url( get_permalink() ) ); ?>" class="cz-btn cz-btn-sm cz-btn-outline-danger">
						<?php esc_html_e( 'Logout', 'carzuri-admin-portal' ); ?>
					</a>
				</div>
			</div>

			<!-- Navigation Tabs -->
			<div class="cz-tabs-nav cz-mb-6">
				<button type="button" class="cz-tab-btn cz-tab-active" data-tab="overview">
					<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 18px; height: 18px;"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
					<span><?php esc_html_e( 'Overview', 'carzuri-admin-portal' ); ?></span>
				</button>
				<button type="button" class="cz-tab-btn" data-tab="dealers">
					<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 18px; height: 18px;"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
					<span><?php esc_html_e( 'Dealer Approvals', 'carzuri-admin-portal' ); ?></span>
					<span class="cz-count-badge" id="cz-dealer-pending-badge">0</span>
				</button>
				<button type="button" class="cz-tab-btn" data-tab="vehicles">
					<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 18px; height: 18px;"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
					<span><?php esc_html_e( 'Vehicle Approvals', 'carzuri-admin-portal' ); ?></span>
					<span class="cz-count-badge" id="cz-vehicle-pending-badge">0</span>
				</button>
				<button type="button" class="cz-tab-btn" data-tab="finance">
					<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 18px; height: 18px;"><rect x="2" y="5" width="20" height="14" rx="2"></rect><line x1="2" y1="10" x2="22" y2="10"></line></svg>
					<span><?php esc_html_e( 'Finance Queue', 'carzuri-admin-portal' ); ?></span>
					<span class="cz-count-badge" id="cz-finance-pending-badge">0</span>
				</button>
				<button type="button" class="cz-tab-btn" data-tab="blog">
					<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 18px; height: 18px;"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
					<span><?php esc_html_e( 'Blog', 'carzuri-admin-portal' ); ?></span>
					<span class="cz-count-badge" id="cz-blog-draft-badge">0</span>
				</button>
			</div>

			<!-- Dynamic Alert Message Container -->
			<div id="cz-portal-alert" class="cz-alert-container cz-mb-4" style="display: none;"></div>

			<!-- TAB 1: OVERVIEW -->
			<div class="cz-tab-content cz-tab-content-active" id="cz-tab-overview">
				<div class="cz-grid cz-grid-3 cz-gap-4 cz-mb-6">
					<div class="cz-stat-card cz-card">
						<div class="cz-stat-header">
							<span class="cz-stat-label"><?php esc_html_e( 'Pending Dealers', 'carzuri-admin-portal' ); ?></span>
							<span class="cz-stat-icon cz-icon-yellow">
								<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 20px; height: 20px;"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
							</span>
						</div>
						<div class="cz-stat-value" id="stat-pending-dealers">--</div>
						<div class="cz-stat-footer">
							<button type="button" class="cz-btn-link" onclick="carzuriAdminApp.switchTab('dealers', 'pending')"><?php esc_html_e( 'Review Applications →', 'carzuri-admin-portal' ); ?></button>
						</div>
					</div>

					<div class="cz-stat-card cz-card">
						<div class="cz-stat-header">
							<span class="cz-stat-label"><?php esc_html_e( 'Pending Vehicles', 'carzuri-admin-portal' ); ?></span>
							<span class="cz-stat-icon cz-icon-blue">
								<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 20px; height: 20px;"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
							</span>
						</div>
						<div class="cz-stat-value" id="stat-pending-vehicles">--</div>
						<div class="cz-stat-footer">
							<button type="button" class="cz-btn-link" onclick="carzuriAdminApp.switchTab('vehicles')"><?php esc_html_e( 'Moderate Listings →', 'carzuri-admin-portal' ); ?></button>
						</div>
					</div>

					<div class="cz-stat-card cz-card">
						<div class="cz-stat-header">
							<span class="cz-stat-label"><?php esc_html_e( 'Pending Finance Apps', 'carzuri-admin-portal' ); ?></span>
							<span class="cz-stat-icon cz-icon-green">
								<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 20px; height: 20px;"><rect x="2" y="5" width="20" height="14" rx="2"></rect><line x1="2" y1="10" x2="22" y2="10"></line></svg>
							</span>
						</div>
						<div class="cz-stat-value" id="stat-pending-finance">--</div>
						<div class="cz-stat-footer">
							<button type="button" class="cz-btn-link" onclick="carzuriAdminApp.switchTab('finance')"><?php esc_html_e( 'Open Finance Queue →', 'carzuri-admin-portal' ); ?></button>
						</div>
					</div>
				</div>

				<div class="cz-card cz-p-6">
					<h3 class="cz-card-title cz-mb-3"><?php esc_html_e( 'Quick Administrative Actions', 'carzuri-admin-portal' ); ?></h3>
					<div class="cz-flex cz-flex-wrap cz-gap-3">
						<button type="button" class="cz-btn cz-btn-secondary" onclick="carzuriAdminApp.reloadAllData()">
							<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 16px; height: 16px;"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
							<?php esc_html_e( 'Refresh Portal Data', 'carzuri-admin-portal' ); ?>
						</button>
						<button type="button" class="cz-btn cz-btn-secondary" onclick="carzuriAdminApp.switchTab('dealers', 'pending')">
							<?php esc_html_e( 'View Pending Dealers', 'carzuri-admin-portal' ); ?>
						</button>
						<button type="button" class="cz-btn cz-btn-secondary" onclick="carzuriAdminApp.switchTab('vehicles')">
							<?php esc_html_e( 'View Pending Vehicles', 'carzuri-admin-portal' ); ?>
						</button>
					</div>
				</div>
			</div>

			<!-- TAB 2: DEALER APPROVALS -->
			<div class="cz-tab-content" id="cz-tab-dealers">
				<div class="cz-card">
					<div class="cz-card-header cz-flex cz-items-center cz-justify-between cz-flex-wrap cz-gap-3">
						<div>
							<h3 class="cz-card-title cz-m-0"><?php esc_html_e( 'Dealer Approvals', 'carzuri-admin-portal' ); ?></h3>
							<p class="cz-text-sm cz-text-muted cz-m-0"><?php esc_html_e( 'Approve or reject registered dealership accounts across the Carzuri Marketplace.', 'carzuri-admin-portal' ); ?></p>
						</div>
						<!-- Status Filter Buttons -->
						<div class="cz-filter-group cz-flex cz-gap-2">
							<button type="button" class="cz-btn-filter cz-active" data-status="all" onclick="carzuriAdminApp.filterDealers('all')"><?php esc_html_e( 'All', 'carzuri-admin-portal' ); ?></button>
							<button type="button" class="cz-btn-filter" data-status="pending" onclick="carzuriAdminApp.filterDealers('pending')"><?php esc_html_e( 'Pending', 'carzuri-admin-portal' ); ?></button>
							<button type="button" class="cz-btn-filter" data-status="approved" onclick="carzuriAdminApp.filterDealers('approved')"><?php esc_html_e( 'Approved', 'carzuri-admin-portal' ); ?></button>
							<button type="button" class="cz-btn-filter" data-status="rejected" onclick="carzuriAdminApp.filterDealers('rejected')"><?php esc_html_e( 'Rejected', 'carzuri-admin-portal' ); ?></button>
						</div>
					</div>

					<!-- Scrollable Table Container for Mobile Responsiveness -->
					<div class="cz-table-responsive">
						<table class="cz-table" id="cz-dealers-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Business / Contact', 'carzuri-admin-portal' ); ?></th>
									<th><?php esc_html_e( 'Email & Phone', 'carzuri-admin-portal' ); ?></th>
									<th><?php esc_html_e( 'Reg Number & Location', 'carzuri-admin-portal' ); ?></th>
									<th><?php esc_html_e( 'Status', 'carzuri-admin-portal' ); ?></th>
									<th class="cz-text-right"><?php esc_html_e( 'Actions', 'carzuri-admin-portal' ); ?></th>
								</tr>
							</thead>
							<tbody id="cz-dealers-tbody">
								<tr>
									<td colspan="5" class="cz-text-center cz-p-6 cz-text-muted">
										<?php esc_html_e( 'Loading dealers...', 'carzuri-admin-portal' ); ?>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>

			<!-- TAB 3: VEHICLE APPROVALS -->
			<div class="cz-tab-content" id="cz-tab-vehicles">
				<div class="cz-card">
					<div class="cz-card-header cz-flex cz-items-center cz-justify-between cz-flex-wrap cz-gap-3">
						<div>
							<h3 class="cz-card-title cz-m-0"><?php esc_html_e( 'Vehicle Approval Queue', 'carzuri-admin-portal' ); ?></h3>
							<p class="cz-text-sm cz-text-muted cz-m-0"><?php esc_html_e( 'Review submitted listings, take a previously-approved vehicle down, or mark it as Featured.', 'carzuri-admin-portal' ); ?></p>
						</div>
						<div class="cz-flex cz-items-center cz-gap-3 cz-flex-wrap">
							<!-- Status Filter Buttons: switches between the pending-review queue and already-live vehicles (the latter needed to offer Unpublish) -->
							<div class="cz-filter-group cz-flex cz-gap-2">
								<button type="button" class="cz-btn-filter cz-active" data-vstatus="pending" onclick="carzuriAdminApp.filterVehicles('pending')"><?php esc_html_e( 'Pending', 'carzuri-admin-portal' ); ?></button>
								<button type="button" class="cz-btn-filter" data-vstatus="publish" onclick="carzuriAdminApp.filterVehicles('publish')"><?php esc_html_e( 'Published', 'carzuri-admin-portal' ); ?></button>
							</div>
							<button type="button" class="cz-btn cz-btn-sm cz-btn-secondary" onclick="carzuriAdminApp.loadVehicles()">
								<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 14px; height: 14px;"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
								<?php esc_html_e( 'Refresh Queue', 'carzuri-admin-portal' ); ?>
							</button>
						</div>
					</div>

					<div id="cz-vehicles-container" class="cz-grid cz-grid-2 cz-gap-4 cz-p-4">
						<div class="cz-col-span-2 cz-text-center cz-p-6 cz-text-muted">
							<?php esc_html_e( 'Loading pending vehicles...', 'carzuri-admin-portal' ); ?>
						</div>
					</div>
				</div>
			</div>

			<!-- TAB 4: FINANCE APPLICATIONS -->
			<div class="cz-tab-content" id="cz-tab-finance">
				<div class="cz-card cz-p-6">
					<div class="cz-flex cz-items-center cz-justify-between cz-mb-4">
						<div>
							<h3 class="cz-card-title cz-m-0"><?php esc_html_e( 'Finance Applications Queue', 'carzuri-admin-portal' ); ?></h3>
							<p class="cz-text-sm cz-text-muted cz-m-0"><?php esc_html_e( 'Review and manage financing applications submitted by customers.', 'carzuri-admin-portal' ); ?></p>
						</div>
					</div>

					<div class="cz-finance-embedded-preview cz-card cz-p-4">
						<?php
						// Reuses the existing shortcode if available on the site
						if ( shortcode_exists( 'carzuri_finance_admin_queue' ) ) {
							echo do_shortcode( '[carzuri_finance_admin_queue]' );
						} else {
							?>
							<div class="cz-alert cz-alert-info">
								<p class="cz-m-0">
									<strong><?php esc_html_e( 'Finance Applications:', 'carzuri-admin-portal' ); ?></strong>
									<?php esc_html_e( 'This section is ready to display submitted applications.', 'carzuri-admin-portal' ); ?>
								</p>
							</div>
							<?php
						}
						?>
					</div>
				</div>
			</div>

			<!-- TAB 5: BLOG -->
			<div class="cz-tab-content" id="cz-tab-blog">
				<div class="cz-card">
					<div class="cz-card-header cz-flex cz-items-center cz-justify-between cz-flex-wrap cz-gap-3">
						<div>
							<h3 class="cz-card-title cz-m-0"><?php esc_html_e( 'Blog / Automotive News', 'carzuri-admin-portal' ); ?></h3>
							<p class="cz-text-sm cz-text-muted cz-m-0"><?php esc_html_e( 'Write, edit, and publish articles for your website. Changes go live on your site automatically once published.', 'carzuri-admin-portal' ); ?></p>
						</div>
						<div class="cz-flex cz-gap-2">
							<button type="button" class="cz-btn cz-btn-sm cz-btn-secondary" onclick="carzuriAdminApp.loadBlogPosts()">
								<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 14px; height: 14px;"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
								<?php esc_html_e( 'Refresh', 'carzuri-admin-portal' ); ?>
							</button>
							<button type="button" class="cz-btn cz-btn-primary cz-btn-sm" onclick="carzuriAdminApp.openBlogEditor()">
								<?php esc_html_e( '+ New Post', 'carzuri-admin-portal' ); ?>
							</button>
						</div>
					</div>

					<div class="cz-table-responsive">
						<table class="cz-table" id="cz-blog-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Post', 'carzuri-admin-portal' ); ?></th>
									<th><?php esc_html_e( 'Category', 'carzuri-admin-portal' ); ?></th>
									<th><?php esc_html_e( 'Status', 'carzuri-admin-portal' ); ?></th>
									<th><?php esc_html_e( 'Date', 'carzuri-admin-portal' ); ?></th>
									<th class="cz-text-right"><?php esc_html_e( 'Actions', 'carzuri-admin-portal' ); ?></th>
								</tr>
							</thead>
							<tbody id="cz-blog-tbody">
								<tr>
									<td colspan="5" class="cz-text-center cz-p-6 cz-text-muted">
										<?php esc_html_e( 'Loading posts...', 'carzuri-admin-portal' ); ?>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>

		</div>

		<!-- Rejection Modal for Vehicles -->
		<div id="cz-rejection-modal" class="cz-modal-overlay" style="display: none;">
			<div class="cz-modal-card cz-card">
				<div class="cz-card-header cz-flex cz-items-center cz-justify-between">
					<h3 class="cz-card-title cz-m-0"><?php esc_html_e( 'Reject Vehicle Listing', 'carzuri-admin-portal' ); ?></h3>
					<button type="button" class="cz-modal-close" onclick="carzuriAdminApp.closeRejectModal()">&times;</button>
				</div>
				<div class="cz-card-body cz-p-4">
					<p class="cz-text-sm cz-mb-3"><?php esc_html_e( 'You are about to reject the following vehicle submission:', 'carzuri-admin-portal' ); ?> <strong id="cz-modal-vehicle-title">--</strong></p>
					
					<div class="cz-form-group cz-mb-4">
						<label for="cz-rejection-reason-input" class="cz-label"><?php esc_html_e( 'Rejection Reason (Optional)', 'carzuri-admin-portal' ); ?></label>
						<textarea id="cz-rejection-reason-input" class="cz-textarea" rows="3" placeholder="<?php esc_attr_e( 'e.g. Invalid VIN, blurred photos, or incorrect pricing info.', 'carzuri-admin-portal' ); ?>"></textarea>
					</div>

					<div class="cz-flex cz-justify-end cz-gap-3">
						<button type="button" class="cz-btn cz-btn-secondary" onclick="carzuriAdminApp.closeRejectModal()"><?php esc_html_e( 'Cancel', 'carzuri-admin-portal' ); ?></button>
						<button type="button" class="cz-btn cz-btn-danger" id="cz-confirm-reject-btn"><?php esc_html_e( 'Confirm Rejection', 'carzuri-admin-portal' ); ?></button>
					</div>
				</div>
			</div>
		</div>

		<!-- Unpublish Modal for Vehicles (previously-approved listings only) -->
		<div id="cz-unpublish-modal" class="cz-modal-overlay" style="display: none;">
			<div class="cz-modal-card cz-card">
				<div class="cz-card-header cz-flex cz-items-center cz-justify-between">
					<h3 class="cz-card-title cz-m-0"><?php esc_html_e( 'Unpublish Vehicle Listing', 'carzuri-admin-portal' ); ?></h3>
					<button type="button" class="cz-modal-close" onclick="carzuriAdminApp.closeUnpublishModal()">&times;</button>
				</div>
				<div class="cz-card-body cz-p-4">
					<p class="cz-text-sm cz-mb-3"><?php esc_html_e( 'You are about to take down the following live listing:', 'carzuri-admin-portal' ); ?> <strong id="cz-unpublish-modal-vehicle-title">--</strong></p>
					<p class="cz-text-sm cz-text-muted cz-mb-3"><?php esc_html_e( 'It will be removed from the public site immediately. The dealer will be notified.', 'carzuri-admin-portal' ); ?></p>

					<div class="cz-form-group cz-mb-4">
						<label for="cz-unpublish-reason-input" class="cz-label"><?php esc_html_e( 'Reason (Optional)', 'carzuri-admin-portal' ); ?></label>
						<textarea id="cz-unpublish-reason-input" class="cz-textarea" rows="3" placeholder="<?php esc_attr_e( 'e.g. Vehicle sold outside the platform, listed in error, dealer request.', 'carzuri-admin-portal' ); ?>"></textarea>
					</div>

					<div class="cz-flex cz-justify-end cz-gap-3">
						<button type="button" class="cz-btn cz-btn-secondary" onclick="carzuriAdminApp.closeUnpublishModal()"><?php esc_html_e( 'Cancel', 'carzuri-admin-portal' ); ?></button>
						<button type="button" class="cz-btn cz-btn-danger" id="cz-confirm-unpublish-btn"><?php esc_html_e( 'Confirm Unpublish', 'carzuri-admin-portal' ); ?></button>
					</div>
				</div>
			</div>
		</div>

		<!-- Blog Post Editor Modal (used for both New Post and Edit Post) -->
		<div id="cz-blog-editor-modal" class="cz-modal-overlay" style="display: none;">
			<div class="cz-modal-card cz-card" style="max-width: 640px;">
				<div class="cz-card-header cz-flex cz-items-center cz-justify-between">
					<h3 class="cz-card-title cz-m-0" id="cz-blog-modal-title"><?php esc_html_e( 'New Blog Post', 'carzuri-admin-portal' ); ?></h3>
					<button type="button" class="cz-modal-close" onclick="carzuriAdminApp.closeBlogEditor()">&times;</button>
				</div>
				<div class="cz-card-body cz-p-4">
					<input type="hidden" id="cz-blog-post-id" value="">

					<div class="cz-form-group">
						<label class="cz-label" for="cz-blog-title-input"><?php esc_html_e( 'Title', 'carzuri-admin-portal' ); ?></label>
						<input type="text" id="cz-blog-title-input" class="cz-input" placeholder="<?php esc_attr_e( 'e.g. 5 Tips for Buying a Used Car in Kenya', 'carzuri-admin-portal' ); ?>">
					</div>

					<div class="cz-form-group">
						<label class="cz-label" for="cz-blog-content-input"><?php esc_html_e( 'Content', 'carzuri-admin-portal' ); ?></label>
						<textarea id="cz-blog-content-input" class="cz-textarea" rows="8" placeholder="<?php esc_attr_e( 'Write your post here. Basic HTML tags are supported.', 'carzuri-admin-portal' ); ?>"></textarea>
					</div>

					<div class="cz-form-group">
						<label class="cz-label" for="cz-blog-excerpt-input"><?php esc_html_e( 'Excerpt (Optional)', 'carzuri-admin-portal' ); ?></label>
						<textarea id="cz-blog-excerpt-input" class="cz-textarea" rows="2" placeholder="<?php esc_attr_e( 'A short summary shown on the blog listing page.', 'carzuri-admin-portal' ); ?>"></textarea>
					</div>

					<div class="cz-grid cz-grid-2 cz-gap-3 cz-mb-3">
						<div class="cz-form-group cz-m-0">
							<label class="cz-label" for="cz-blog-category-select"><?php esc_html_e( 'Category', 'carzuri-admin-portal' ); ?></label>
							<div class="cz-flex cz-gap-2">
								<select id="cz-blog-category-select" class="cz-input"></select>
								<button type="button" class="cz-btn cz-btn-sm cz-btn-secondary" onclick="carzuriAdminApp.promptNewCategory()" style="white-space:nowrap;">
									<?php esc_html_e( '+ New', 'carzuri-admin-portal' ); ?>
								</button>
							</div>
						</div>
						<div class="cz-form-group cz-m-0">
							<label class="cz-label" for="cz-blog-status-select"><?php esc_html_e( 'Status', 'carzuri-admin-portal' ); ?></label>
							<select id="cz-blog-status-select" class="cz-input">
								<option value="draft"><?php esc_html_e( 'Draft', 'carzuri-admin-portal' ); ?></option>
								<option value="publish"><?php esc_html_e( 'Published', 'carzuri-admin-portal' ); ?></option>
							</select>
						</div>
					</div>

					<div class="cz-form-group">
						<label class="cz-label" for="cz-blog-featured-image-input"><?php esc_html_e( 'Featured Image (Optional)', 'carzuri-admin-portal' ); ?></label>
						<input type="file" id="cz-blog-featured-image-input" accept="image/*" class="cz-input">
						<div id="cz-blog-featured-image-preview" class="cz-mt-2" style="display:none;">
							<img src="" style="max-width: 160px; border-radius: 8px;" id="cz-blog-featured-image-preview-img" alt="">
						</div>
						<input type="hidden" id="cz-blog-featured-media-id" value="">
					</div>

					<div class="cz-flex cz-justify-end cz-gap-3">
						<button type="button" class="cz-btn cz-btn-secondary" onclick="carzuriAdminApp.closeBlogEditor()"><?php esc_html_e( 'Cancel', 'carzuri-admin-portal' ); ?></button>
						<button type="button" class="cz-btn cz-btn-primary" id="cz-save-blog-post-btn"><?php esc_html_e( 'Save Post', 'carzuri-admin-portal' ); ?></button>
					</div>
				</div>
			</div>
		</div>

		<?php
		return ob_get_clean();
	}
}
