<?php
/**
 * REST API for the Admin Portal's Blog tab — manages standard WordPress
 * `post` type content (plain native WordPress, per this project's own
 * decision to avoid a custom CPT for the blog) so the carzuri_admin role
 * can write, edit, and publish blog posts without ever touching wp-admin.
 *
 * Reuses WordPress's native category taxonomy and the core /wp/v2/media
 * REST endpoint for featured images — no custom taxonomy or upload
 * handling is built here.
 *
 * @package CarzuriAdminPortal
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Admin_Blog_REST {

	/**
	 * Initialize REST hooks.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register routes under the existing carzuri/v1 namespace.
	 */
	public static function register_routes() {
		$namespace = 'carzuri/v1';

		register_rest_route( $namespace, '/blog/posts', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_posts' ),
				'permission_callback' => array( 'Carzuri_Admin_Roles', 'check_admin_permission' ),
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'create_post' ),
				'permission_callback' => array( 'Carzuri_Admin_Roles', 'check_admin_permission' ),
			),
		) );

		register_rest_route( $namespace, '/blog/posts/(?P<id>\d+)', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_post_single' ),
				'permission_callback' => array( 'Carzuri_Admin_Roles', 'check_admin_permission' ),
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'update_post' ),
				'permission_callback' => array( 'Carzuri_Admin_Roles', 'check_admin_permission' ),
			),
		) );

		register_rest_route( $namespace, '/blog/posts/(?P<id>\d+)/publish', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( __CLASS__, 'publish_post' ),
			'permission_callback' => array( 'Carzuri_Admin_Roles', 'check_admin_permission' ),
		) );

		// Non-destructive: moves the post to Trash rather than permanently
		// deleting it, matching WordPress's own default behavior.
		register_rest_route( $namespace, '/blog/posts/(?P<id>\d+)/delete', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( __CLASS__, 'delete_post_action' ),
			'permission_callback' => array( 'Carzuri_Admin_Roles', 'check_admin_permission' ),
		) );

		register_rest_route( $namespace, '/blog/categories', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_categories' ),
				'permission_callback' => array( 'Carzuri_Admin_Roles', 'check_admin_permission' ),
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'create_category' ),
				'permission_callback' => array( 'Carzuri_Admin_Roles', 'check_admin_permission' ),
			),
		) );
	}

	/**
	 * Flatten a WP_Post into the exact shape the front-end JS expects.
	 */
	private static function format_post( $post ) {
		$thumb_id = get_post_thumbnail_id( $post->ID );
		$cats     = wp_get_post_categories( $post->ID, array( 'fields' => 'ids' ) );

		return array(
			'id'                 => $post->ID,
			'title'              => $post->post_title,
			'content'            => $post->post_content,
			'excerpt'            => $post->post_excerpt,
			'status'             => $post->post_status,
			'date'               => $post->post_date,
			'author_name'        => get_the_author_meta( 'display_name', $post->post_author ),
			'featured_media'     => (int) $thumb_id,
			'featured_image_url' => $thumb_id ? wp_get_attachment_url( $thumb_id ) : '',
			'categories'         => array_map( 'intval', $cats ),
			'permalink'          => get_permalink( $post->ID ),
		);
	}

	/**
	 * GET /blog/posts: list posts of every status the admin needs to see
	 * (published, draft, pending review, scheduled).
	 */
	public static function get_posts( WP_REST_Request $request ) {
		$page     = $request->get_param( 'page' ) ? absint( $request->get_param( 'page' ) ) : 1;
		$per_page = $request->get_param( 'per_page' ) ? absint( $request->get_param( 'per_page' ) ) : 20;

		$query = new WP_Query( array(
			'post_type'      => 'post',
			'post_status'    => array( 'publish', 'draft', 'pending', 'future' ),
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );

		$posts = array();
		foreach ( $query->posts as $post ) {
			$posts[] = self::format_post( $post );
		}

		return new WP_REST_Response( array(
			'posts'         => $posts,
			'total_results' => (int) $query->found_posts,
			'total_pages'   => (int) $query->max_num_pages,
		), 200 );
	}

	/**
	 * GET /blog/posts/{id}: fetch a single post for the edit form.
	 */
	public static function get_post_single( WP_REST_Request $request ) {
		$id   = (int) $request->get_param( 'id' );
		$post = get_post( $id );

		if ( ! $post || $post->post_type !== 'post' ) {
			return new WP_REST_Response( array( 'message' => __( 'Post not found.', 'carzuri-admin-portal' ) ), 404 );
		}

		return new WP_REST_Response( self::format_post( $post ), 200 );
	}

	/**
	 * POST /blog/posts: create a new post.
	 */
	public static function create_post( WP_REST_Request $request ) {
		$title   = sanitize_text_field( (string) $request->get_param( 'title' ) );
		$content = wp_kses_post( (string) $request->get_param( 'content' ) );
		$excerpt = sanitize_textarea_field( (string) $request->get_param( 'excerpt' ) );
		$status  = self::sanitize_status( $request->get_param( 'status' ) );

		if ( empty( $title ) ) {
			return new WP_REST_Response( array( 'message' => __( 'A post title is required.', 'carzuri-admin-portal' ) ), 400 );
		}

		$post_id = wp_insert_post( array(
			'post_title'   => $title,
			'post_content' => $content,
			'post_excerpt' => $excerpt,
			'post_status'  => $status,
			'post_type'    => 'post',
			'post_author'  => get_current_user_id(),
		), true );

		if ( is_wp_error( $post_id ) ) {
			return new WP_REST_Response( array( 'message' => $post_id->get_error_message() ), 500 );
		}

		self::apply_taxonomy_and_media( $post_id, $request );

		return new WP_REST_Response( array(
			'success' => true,
			'message' => __( 'Post saved successfully.', 'carzuri-admin-portal' ),
			'post'    => self::format_post( get_post( $post_id ) ),
		), 200 );
	}

	/**
	 * POST /blog/posts/{id}: update an existing post. Only fields actually
	 * present in the request are changed.
	 */
	public static function update_post( WP_REST_Request $request ) {
		$id   = (int) $request->get_param( 'id' );
		$post = get_post( $id );

		if ( ! $post || $post->post_type !== 'post' ) {
			return new WP_REST_Response( array( 'message' => __( 'Post not found.', 'carzuri-admin-portal' ) ), 404 );
		}

		$update = array( 'ID' => $id );

		if ( $request->get_param( 'title' ) !== null ) {
			$update['post_title'] = sanitize_text_field( (string) $request->get_param( 'title' ) );
		}
		if ( $request->get_param( 'content' ) !== null ) {
			$update['post_content'] = wp_kses_post( (string) $request->get_param( 'content' ) );
		}
		if ( $request->get_param( 'excerpt' ) !== null ) {
			$update['post_excerpt'] = sanitize_textarea_field( (string) $request->get_param( 'excerpt' ) );
		}
		if ( $request->get_param( 'status' ) !== null ) {
			$update['post_status'] = self::sanitize_status( $request->get_param( 'status' ) );
		}

		$result = wp_update_post( $update, true );

		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response( array( 'message' => $result->get_error_message() ), 500 );
		}

		self::apply_taxonomy_and_media( $id, $request );

		return new WP_REST_Response( array(
			'success' => true,
			'message' => __( 'Post updated successfully.', 'carzuri-admin-portal' ),
			'post'    => self::format_post( get_post( $id ) ),
		), 200 );
	}

	/**
	 * POST /blog/posts/{id}/publish: convenience action to publish a draft,
	 * matching the dedicated-action pattern already used for vehicles
	 * (approve/reject/unpublish) rather than requiring a full update call.
	 */
	public static function publish_post( WP_REST_Request $request ) {
		$id   = (int) $request->get_param( 'id' );
		$post = get_post( $id );

		if ( ! $post || $post->post_type !== 'post' ) {
			return new WP_REST_Response( array( 'message' => __( 'Post not found.', 'carzuri-admin-portal' ) ), 404 );
		}

		$result = wp_update_post( array(
			'ID'          => $id,
			'post_status' => 'publish',
		), true );

		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response( array( 'message' => $result->get_error_message() ), 500 );
		}

		return new WP_REST_Response( array(
			'success' => true,
			'message' => __( 'Post published.', 'carzuri-admin-portal' ),
		), 200 );
	}

	/**
	 * POST /blog/posts/{id}/delete: move a post to Trash (non-destructive).
	 */
	public static function delete_post_action( WP_REST_Request $request ) {
		$id   = (int) $request->get_param( 'id' );
		$post = get_post( $id );

		if ( ! $post || $post->post_type !== 'post' ) {
			return new WP_REST_Response( array( 'message' => __( 'Post not found.', 'carzuri-admin-portal' ) ), 404 );
		}

		$result = wp_trash_post( $id );

		if ( ! $result ) {
			return new WP_REST_Response( array( 'message' => __( 'Failed to delete post.', 'carzuri-admin-portal' ) ), 500 );
		}

		return new WP_REST_Response( array(
			'success' => true,
			'message' => __( 'Post moved to Trash.', 'carzuri-admin-portal' ),
		), 200 );
	}

	/**
	 * GET /blog/categories: list WordPress's native categories.
	 */
	public static function get_categories() {
		$cats     = get_categories( array( 'hide_empty' => false ) );
		$response = array();

		foreach ( $cats as $cat ) {
			$response[] = array(
				'id'   => $cat->term_id,
				'name' => $cat->name,
			);
		}

		return new WP_REST_Response( $response, 200 );
	}

	/**
	 * POST /blog/categories: create a new native WordPress category term,
	 * so the admin isn't limited to "Uncategorized" from the Blog tab.
	 */
	public static function create_category( WP_REST_Request $request ) {
		$name = sanitize_text_field( (string) $request->get_param( 'name' ) );

		if ( empty( $name ) ) {
			return new WP_REST_Response( array( 'message' => __( 'A category name is required.', 'carzuri-admin-portal' ) ), 400 );
		}

		$existing = get_term_by( 'name', $name, 'category' );
		if ( $existing && ! is_wp_error( $existing ) ) {
			return new WP_REST_Response( array(
				'success'  => true,
				'message'  => __( 'Category already exists — selected it instead.', 'carzuri-admin-portal' ),
				'category' => array( 'id' => $existing->term_id, 'name' => $existing->name ),
			), 200 );
		}

		$result = wp_insert_term( $name, 'category' );

		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response( array( 'message' => $result->get_error_message() ), 500 );
		}

		return new WP_REST_Response( array(
			'success'  => true,
			'message'  => __( 'Category created.', 'carzuri-admin-portal' ),
			'category' => array( 'id' => $result['term_id'], 'name' => $name ),
		), 200 );
	}

	/**
	 * Restrict incoming status values to a known-safe set, defaulting to
	 * 'draft' for anything unrecognized rather than trusting arbitrary
	 * input straight into wp_insert_post()/wp_update_post().
	 */
	private static function sanitize_status( $status ) {
		$allowed = array( 'publish', 'draft', 'pending' );
		$status  = sanitize_text_field( (string) $status );
		return in_array( $status, $allowed, true ) ? $status : 'draft';
	}

	/**
	 * Shared logic for setting featured image and category on create/update.
	 * `featured_media` is expected to be an attachment ID already uploaded
	 * via WordPress's own /wp/v2/media endpoint on the front-end.
	 */
	private static function apply_taxonomy_and_media( $post_id, WP_REST_Request $request ) {
		$featured_media = $request->get_param( 'featured_media' );
		if ( $featured_media !== null ) {
			$featured_media = absint( $featured_media );
			if ( $featured_media > 0 ) {
				set_post_thumbnail( $post_id, $featured_media );
			} else {
				delete_post_thumbnail( $post_id );
			}
		}

		$categories = $request->get_param( 'categories' );
		if ( is_array( $categories ) ) {
			$categories = array_map( 'absint', $categories );
			wp_set_post_categories( $post_id, $categories );
		}
	}
}
