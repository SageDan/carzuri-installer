<?php
/**
 * Role & Security Management for Carzuri Admin Portal.
 *
 * @package CarzuriAdminPortal
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Admin_Roles {

	/**
	 * Initialize hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'ensure_role_capabilities' ) );
		add_action( 'after_setup_theme', array( __CLASS__, 'hide_admin_bar' ) );
		add_action( 'admin_init', array( __CLASS__, 'redirect_wp_admin_access' ) );
	}

	/**
	 * Ensure the carzuri_admin role exists with appropriate capabilities.
	 */
	public static function ensure_role_capabilities() {
		$role = get_role( 'carzuri_admin' );
		if ( ! $role ) {
			add_role(
				'carzuri_admin',
				__( 'Carzuri Administrator', 'carzuri-admin-portal' ),
				array(
					'read'                      => true,
					'carzuri_admin'             => true,
					'approve_dealers'          => true,
					'approve_vehicles'         => true,
					'view_finance_applications' => true,
				)
			);
		} else {
			// Grant core portal capabilities
			$role->add_cap( 'carzuri_admin' );
			$role->add_cap( 'approve_dealers' );
			$role->add_cap( 'approve_vehicles' );
			$role->add_cap( 'view_finance_applications' );
		}
	}

	/**
	 * Hide admin bar for carzuri_admin users unless manage_options is present.
	 */
	public static function hide_admin_bar() {
		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
			if ( in_array( 'carzuri_admin', (array) $user->roles, true ) && ! current_user_can( 'manage_options' ) ) {
				show_admin_bar( false );
			}
		}
	}

	/**
	 * Redirect /wp-admin/ attempts for carzuri_admin role to the front-end dashboard.
	 * Includes bypass guards for AJAX and REST API requests!
	 */
	public static function redirect_wp_admin_access() {
		// Bypass guard 1: AJAX requests must never be redirected
		if ( wp_doing_ajax() ) {
			return;
		}

		// Bypass guard 2: REST API requests must never be redirected
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}

		if ( function_exists( 'wp_is_json_request' ) && wp_is_json_request() ) {
			return;
		}

		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
			if ( in_array( 'carzuri_admin', (array) $user->roles, true ) && ! current_user_can( 'manage_options' ) ) {
				// Safe redirect to front-end dashboard page
				$dashboard_url = site_url( '/carzuri-admin-portal/' );
				wp_safe_redirect( $dashboard_url );
				exit;
			}
		}
	}

	/**
	 * Permission check helper for REST API handlers.
	 * Returns true if current user has carzuri_admin role or manage_options capability.
	 *
	 * @return bool|WP_Error
	 */
	public static function check_admin_permission() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'rest_not_logged_in',
				__( 'You must be logged in to access administrative tools.', 'carzuri-admin-portal' ),
				array( 'status' => 401 )
			);
		}

		if ( current_user_can( 'manage_options' ) || current_user_can( 'carzuri_admin' ) ) {
			return true;
		}

		$user = wp_get_current_user();
		if ( in_array( 'carzuri_admin', (array) $user->roles, true ) ) {
			return true;
		}

		return new WP_Error(
			'rest_forbidden',
			__( 'You do not have permission to access this resource. Carzuri Admin privileges required.', 'carzuri-admin-portal' ),
			array( 'status' => 403 )
		);
	}
}
