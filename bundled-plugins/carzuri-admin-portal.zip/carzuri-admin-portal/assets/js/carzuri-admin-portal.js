/**
 * Carzuri Admin Portal Frontend JavaScript Application.
 * Consumes existing endpoints via fetch() API calls with REST nonce.
 * Version 1.1.2
 */

(function ($) {
	'use strict';

	window.carzuriAdminApp = {
		dealers: [],
		vehicles: [],
		financeCount: 0,
		blogPosts: [],
		blogCategories: [],
		currentDealerFilter: 'all',
		currentVehicleFilter: 'pending',
		activeVehicleRejectId: null,
		activeVehicleUnpublishId: null,

		init: function () {
			this.bindEvents();

			if ($('#carzuri-admin-dashboard-app').length) {
				this.reloadAllData();
			}
		},

		bindEvents: function () {
			var self = this;

			/* Password Visibility Toggle */
			$(document).on('click', '#cz-toggle-pwd-btn', function (e) {
				e.preventDefault();
				var $input = $('#carzuri_admin_pass');
				if ($input.length) {
					var type = $input.attr('type') === 'password' ? 'text' : 'password';
					$input.attr('type', type);
				}
			});

			/* AJAX Login Form Submission */
			$(document).on('submit', '#cz-admin-login-form', function (e) {
				e.preventDefault();
				self.handleAdminLogin($(this));
			});

			/* Tab Switching */
			$(document).on('click', '.cz-tab-btn', function (e) {
				e.preventDefault();
				var targetTab = $(this).data('tab');
				self.switchTab(targetTab);
			});

			/* Rejection Modal Submit */
			$(document).on('click', '#cz-confirm-reject-btn', function (e) {
				e.preventDefault();
				self.submitVehicleRejection();
			});

			/* Unpublish Modal Submit */
			$(document).on('click', '#cz-confirm-unpublish-btn', function (e) {
				e.preventDefault();
				self.submitVehicleUnpublish();
			});

			/* Blog Post Editor Save */
			$(document).on('click', '#cz-save-blog-post-btn', function (e) {
				e.preventDefault();
				self.saveBlogPost();
			});

			/* Blog Featured Image Selection */
			$(document).on('change', '#cz-blog-featured-image-input', function (e) {
				self.handleBlogImageSelect(e.target.files[0]);
			});
		},

		handleAdminLogin: function ($form) {
			var self = this;
			var $btn = $form.find('button[type="submit"]');
			var originalBtnText = $btn.html();

			var ajaxUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.ajax_url) ? carzuriAdminVars.ajax_url : '/wp-admin/admin-ajax.php';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.login_nonce) ? carzuriAdminVars.login_nonce : $form.find('[name="carzuri_login_nonce"]').val();

			var username = $form.find('[name="log"]').val();
			var password = $form.find('[name="pwd"]').val();
			var remember = $form.find('[name="rememberme"]').is(':checked') ? 'forever' : '';

			var formData = new FormData();
			formData.append('action', 'carzuri_admin_login');
			formData.append('carzuri_login_nonce', nonce);
			formData.append('log', username);
			formData.append('pwd', password);
			if (remember) {
				formData.append('rememberme', remember);
			}

			$btn.prop('disabled', true).html('Signing In...');
			self.hideLoginAlert();

			fetch(ajaxUrl, {
				method: 'POST',
				body: formData
			})
			.then(function (res) {
				return res.json();
			})
			.then(function (res) {
				if (res && res.success && res.data && res.data.requires_device_verification) {
					self.showLoginAlert(res.data.message || 'Please verify your device to continue.', 'success');
					self.showDeviceVerificationStep($form, res.data.user_id, res.data.remember, res.data.redirect_url);
					return;
				}

				if (res && res.success) {
					self.showLoginAlert((res.data && res.data.message) ? res.data.message : 'Login successful! Redirecting...', 'success');
					var redirectUrl = (res.data && res.data.redirect_url) ? res.data.redirect_url : ((typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.dashboard_url) ? carzuriAdminVars.dashboard_url : '/carzuri-admin-portal/');
					setTimeout(function () {
						window.location.href = redirectUrl;
					}, 500);
				} else {
					$btn.prop('disabled', false).html(originalBtnText);
					var errorMsg = (res && res.data && res.data.message) ? res.data.message : 'Invalid login credentials. Please try again.';
					self.showLoginAlert(errorMsg, 'error');
				}
			})
			.catch(function (err) {
				$btn.prop('disabled', false).html(originalBtnText);
				self.showLoginAlert('An error occurred during sign in. Please try again.', 'error');
			});
		},

		/**
		 * New Device Verification: builds and shows a one-time-code entry
		 * step in place of the login form, calling Carzuri Core's shared
		 * /carzuri/v1/verify-device endpoint.
		 */
		showDeviceVerificationStep: function ($form, userId, remember, redirectUrl) {
			var self = this;
			$form.hide();

			var restRoot = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var restNonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';
			var fallbackRedirect = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.dashboard_url) ? carzuriAdminVars.dashboard_url : '/carzuri-admin-portal/';

			var $verifyBlock = $(
				'<div id="cz-device-verify-block">' +
					'<div class="cz-form-group">' +
						'<label for="cz_device_code" class="cz-label">Verification Code</label>' +
						'<div class="cz-input-wrapper">' +
							'<input type="text" id="cz_device_code" inputmode="numeric" maxlength="6" placeholder="6-digit code" class="cz-input" style="letter-spacing: 2px;">' +
						'</div>' +
					'</div>' +
					'<button type="button" id="cz-verify-code-btn" class="cz-btn cz-btn-primary cz-btn-block cz-btn-lg">Verify & Continue</button>' +
					'<div class="cz-text-center cz-mt-3">' +
						'<span class="cz-text-sm cz-text-muted">Didn\'t get a code?</span> ' +
						'<button type="button" id="cz-resend-code-btn" class="cz-btn-link">Resend it</button>' +
					'</div>' +
				'</div>'
			);

			$form.after($verifyBlock);

			$('#cz-verify-code-btn').on('click', function () {
				var code = $('#cz_device_code').val().trim();
				if (!code) {
					self.showLoginAlert('Please enter the code we emailed you.', 'error');
					return;
				}

				var $btn = $(this);
				$btn.prop('disabled', true).text('Verifying...');

				fetch(restRoot + 'verify-device', {
					method: 'POST',
					headers: {
						'X-WP-Nonce': restNonce,
						'Content-Type': 'application/json'
					},
					body: JSON.stringify({ user_id: userId, code: code, remember: remember })
				})
				.then(function (res) { return res.json(); })
				.then(function (res) {
					if (res.success) {
						self.showLoginAlert(res.message || 'Verified! Redirecting...', 'success');
						setTimeout(function () {
							window.location.href = redirectUrl || fallbackRedirect;
						}, 600);
					} else {
						$btn.prop('disabled', false).text('Verify & Continue');
						self.showLoginAlert(res.message || 'Incorrect code. Please try again.', 'error');
					}
				})
				.catch(function () {
					$btn.prop('disabled', false).text('Verify & Continue');
					self.showLoginAlert('Could not verify the code. Please try again.', 'error');
				});
			});

			$('#cz-resend-code-btn').on('click', function () {
				var $btn = $(this);
				$btn.prop('disabled', true).text('Sending...');

				fetch(restRoot + 'verify-device/resend', {
					method: 'POST',
					headers: {
						'X-WP-Nonce': restNonce,
						'Content-Type': 'application/json'
					},
					body: JSON.stringify({ user_id: userId })
				})
				.then(function (res) { return res.json(); })
				.then(function (res) {
					$btn.prop('disabled', false).text('Resend it');
					self.showLoginAlert(res.message || 'A new code has been sent.', res.success ? 'success' : 'error');
				})
				.catch(function () {
					$btn.prop('disabled', false).text('Resend it');
					self.showLoginAlert('Could not resend the code. Please try again.', 'error');
				});
			});
		},

		showLoginAlert: function (msg, type) {
			var alertClass = type === 'error' ? 'cz-alert-error' : 'cz-alert-success';
			var html = '<div class="cz-alert ' + alertClass + '">' +
				'<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:18px;height:18px;"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>' +
				'<span>' + msg + '</span>' +
				'</div>';
			$('#cz-login-alert').html(html).slideDown(200);
		},

		hideLoginAlert: function () {
			$('#cz-login-alert').slideUp(200).empty();
		},

		switchTab: function (tabName, filterParam) {
			$('.cz-tab-btn').removeClass('cz-tab-active');
			$('.cz-tab-btn[data-tab="' + tabName + '"]').addClass('cz-tab-active');

			$('.cz-tab-content').removeClass('cz-tab-content-active');
			$('#cz-tab-' + tabName).addClass('cz-tab-content-active');

			if (tabName === 'dealers' && filterParam) {
				this.filterDealers(filterParam);
			}
		},

		showAlert: function (message, type) {
			var alertClass = type === 'error' ? 'cz-alert-error' : 'cz-alert-success';
			var $container = $('#cz-portal-alert');

			var html = '<div class="cz-alert ' + alertClass + '">' +
				'<svg class="cz-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:18px;height:18px;"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>' +
				'<span>' + message + '</span>' +
				'</div>';

			$container.html(html).slideDown(200);

			setTimeout(function () {
				$container.slideUp(200);
			}, 5000);
		},

		escapeHtml: function (str) {
			if (str === null || str === undefined) return '';
			return String(str)
				.replace(/&/g, '&amp;')
				.replace(/</g, '&lt;')
				.replace(/>/g, '&gt;')
				.replace(/"/g, '&quot;')
				.replace(/'/g, '&#039;');
		},

		reloadAllData: function () {
			this.loadDealers();
			this.loadVehicles();
			this.loadFinanceCount();
			this.loadBlogCategories();
			this.loadBlogPosts();
		},

		/* 1. DEALER APPROVALS (Consumes GET /wp-json/carzuri/v1/dealers) */
		loadDealers: function () {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'dealers?status=all', {
				method: 'GET',
				headers: {
					'X-WP-Nonce': nonce
				}
			})
			.then(function (res) {
				if (!res.ok) {
					throw new Error('HTTP ' + res.status + ' ' + res.statusText);
				}
				return res.json();
			})
			.then(function (data) {
				self.dealers = Array.isArray(data) ? data : [];
				self.renderDealersTable();
				self.updateCounts();
			})
			.catch(function (err) {
				var msg = err.message || 'Failed to load dealers list.';
				self.showAlert(msg, 'error');
				$('#cz-dealers-tbody').html('<tr><td colspan="5" class="cz-text-center cz-text-danger cz-p-4">' + msg + '</td></tr>');
			});
		},

		filterDealers: function (status) {
			this.currentDealerFilter = status;
			$('.cz-btn-filter[data-status]').removeClass('cz-active');
			$('.cz-btn-filter[data-status="' + status + '"]').addClass('cz-active');
			this.renderDealersTable();
		},

		renderDealersTable: function () {
			var self = this;
			var $tbody = $('#cz-dealers-tbody');
			var filtered = this.dealers;

			if (this.currentDealerFilter !== 'all') {
				filtered = this.dealers.filter(function (item) {
					return item.status === self.currentDealerFilter || (self.currentDealerFilter === 'pending' && item.carzuri_dealer_approved === '0');
				});
			}

			if (!filtered || filtered.length === 0) {
				$tbody.html('<tr><td colspan="5" class="cz-text-center cz-p-6 cz-text-muted">No dealers found matching this status filter.</td></tr>');
				return;
			}

			var rowsHtml = '';
			filtered.forEach(function (d) {
				var badgeClass = 'cz-badge-pending';
				var statusLabel = 'Pending';

				if (d.carzuri_dealer_approved === '1' || d.status === 'approved') {
					badgeClass = 'cz-badge-approved';
					statusLabel = 'Approved';
				} else if (d.carzuri_dealer_approved === 'rejected' || d.status === 'rejected') {
					badgeClass = 'cz-badge-rejected';
					statusLabel = 'Rejected';
				}

				rowsHtml += '<tr data-dealer-id="' + d.id + '">' +
					'<td>' +
						'<div class="cz-font-bold">' + (d.business_name || 'Dealer #' + d.id) + '</div>' +
						'<div class="cz-text-sm cz-text-muted">' + (d.contact_name || '') + '</div>' +
					'</td>' +
					'<td>' +
						'<div>' + (d.user_email || '') + '</div>' +
						'<div class="cz-text-sm cz-text-muted">' + (d.phone || 'N/A') + '</div>' +
					'</td>' +
					'<td>' +
						'<div>Reg: ' + (d.registration_number || 'N/A') + '</div>' +
						'<div class="cz-text-sm cz-text-muted">' + (d.location || 'Nairobi') + '</div>' +
					'</td>' +
					'<td><span class="cz-badge ' + badgeClass + '">' + statusLabel + '</span></td>' +
					'<td class="cz-text-right">' +
						'<div class="cz-flex cz-justify-end cz-gap-2">';

				if (d.carzuri_dealer_approved !== '1') {
					rowsHtml += '<button type="button" class="cz-btn cz-btn-sm cz-btn-success" onclick="carzuriAdminApp.approveDealer(' + d.id + ')">Approve</button>';
				}
				if (d.carzuri_dealer_approved !== 'rejected') {
					rowsHtml += '<button type="button" class="cz-btn cz-btn-sm cz-btn-danger" onclick="carzuriAdminApp.rejectDealer(' + d.id + ')">Reject</button>';
				}
				if (d.carzuri_dealer_approved === '1') {
					rowsHtml += '<button type="button" class="cz-btn cz-btn-sm cz-btn-secondary" onclick="carzuriAdminApp.resendApprovalEmail(' + d.id + ')">Resend Email</button>';
				}

				rowsHtml += '</div></td></tr>';
			});

			$tbody.html(rowsHtml);
		},

		approveDealer: function (id) {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'dealers/' + id + '/approve', {
				method: 'POST',
				headers: {
					'X-WP-Nonce': nonce,
					'Content-Type': 'application/json'
				}
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) {
						throw new Error(errData.message || 'Error approving dealer.');
					});
				}
				return res.json();
			})
			.then(function (res) {
				self.showAlert(res.message || 'Dealer approved successfully!', 'success');
				self.loadDealers();
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Error approving dealer.', 'error');
			});
		},

		rejectDealer: function (id) {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'dealers/' + id + '/reject', {
				method: 'POST',
				headers: {
					'X-WP-Nonce': nonce,
					'Content-Type': 'application/json'
				}
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) {
						throw new Error(errData.message || 'Error rejecting dealer.');
					});
				}
				return res.json();
			})
			.then(function (res) {
				self.showAlert(res.message || 'Dealer status set to rejected.', 'success');
				self.loadDealers();
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Error rejecting dealer.', 'error');
			});
		},

		resendApprovalEmail: function (id) {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'dealers/' + id + '/resend-approval-email', {
				method: 'POST',
				headers: {
					'X-WP-Nonce': nonce,
					'Content-Type': 'application/json'
				}
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) {
						throw new Error(errData.message || 'Failed to resend email.');
					});
				}
				return res.json();
			})
			.then(function (res) {
				self.showAlert(res.message || 'Email resent successfully.', 'success');
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Failed to resend email.', 'error');
			});
		},

		/* 2. VEHICLE APPROVALS (Consumes GET /wp-json/carzuri/v1/vehicles-pending) */
		loadVehicles: function () {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			var statusQuery = (this.currentVehicleFilter === 'publish') ? '?status=publish' : '?status=pending';

			fetch(rootUrl + 'vehicles-pending' + statusQuery, {
				method: 'GET',
				headers: {
					'X-WP-Nonce': nonce
				}
			})
			.then(function (res) {
				if (!res.ok) {
					throw new Error('HTTP ' + res.status + ' ' + res.statusText);
				}
				return res.json();
			})
			.then(function (data) {
				self.vehicles = Array.isArray(data) ? data : [];
				self.renderVehiclesGrid();
				self.updateCounts();
			})
			.catch(function (err) {
				var msg = err.message || 'Failed to load vehicles.';
				self.showAlert(msg, 'error');
				$('#cz-vehicles-container').html('<div class="cz-col-span-2 cz-alert cz-alert-error">' + msg + '</div>');
			});
		},

		filterVehicles: function (status) {
			this.currentVehicleFilter = status;
			$('.cz-btn-filter[data-vstatus]').removeClass('cz-active');
			$('.cz-btn-filter[data-vstatus="' + status + '"]').addClass('cz-active');
			this.loadVehicles();
		},

		renderVehiclesGrid: function () {
			var isPublishedView = (this.currentVehicleFilter === 'publish');
			var $container = $('#cz-vehicles-container');

			if (!this.vehicles || this.vehicles.length === 0) {
				var emptyMsg = isPublishedView
					? 'No published vehicles found.'
					: 'No pending vehicles requiring review at this time.';
				$container.html('<div class="cz-col-span-2 cz-card cz-p-6 cz-text-center cz-text-muted">' + emptyMsg + '</div>');
				return;
			}

			var html = '';
			this.vehicles.forEach(function (v) {
				var priceFormatted = 'KSh ' + Number(v.price || 0).toLocaleString();
				var isFeatured = !!v.featured;

				html += '<div class="cz-vehicle-card">' +
					'<div style="position: relative;">' +
					'<img src="' + (v.featured_image_url || 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80') + '" class="cz-vehicle-img" alt="' + v.title + '">' +
					(isFeatured ? '<span class="cz-badge cz-badge-approved" style="position:absolute; top:8px; left:8px;">★ Featured</span>' : '') +
					'</div>' +
					'<div class="cz-vehicle-details">' +
						'<div class="cz-text-sm cz-text-muted cz-mb-1">' + (v.dealer_business_name || 'Dealer #' + v.dealer_id) + '</div>' +
						'<h4 class="cz-vehicle-title">' + v.title + '</h4>' +
						'<div class="cz-vehicle-price">' + priceFormatted + '</div>' +
						'<div class="cz-vehicle-specs">' +
							'<span class="cz-spec-item">' + (v.year || '2023') + '</span>' +
							'<span class="cz-spec-item">' + Number(v.mileage || 0).toLocaleString() + ' km</span>' +
							'<span class="cz-spec-item">' + (v.fuel_type || 'Petrol') + '</span>' +
							'<span class="cz-spec-item">' + (v.transmission || 'Automatic') + '</span>' +
						'</div>' +
						'<div class="cz-text-sm cz-text-muted cz-mb-3">VIN: ' + (v.vin || 'N/A') + ' | Reg: ' + (v.registration_number || 'N/A') + '</div>' +
						'<div class="cz-flex cz-gap-2 cz-mt-auto">';

				if (isPublishedView) {
					html += '<button type="button" class="cz-btn cz-btn-sm cz-btn-danger cz-btn-block" onclick="carzuriAdminApp.openUnpublishModal(' + v.id + ')">Unpublish</button>';
				} else {
					html += '<button type="button" class="cz-btn cz-btn-sm cz-btn-success cz-btn-block" onclick="carzuriAdminApp.approveVehicle(' + v.id + ')">Approve Listing</button>' +
						'<button type="button" class="cz-btn cz-btn-sm cz-btn-danger cz-btn-block" onclick="carzuriAdminApp.openRejectModal(' + v.id + ')">Reject</button>';
				}

				html += '</div>' +
					'<div class="cz-flex cz-gap-2 cz-mt-2">' +
						'<button type="button" class="cz-btn cz-btn-sm cz-btn-secondary cz-btn-block" onclick="carzuriAdminApp.toggleFeatured(' + v.id + ')">' +
							(isFeatured ? '★ Remove from Featured' : '☆ Mark as Featured') +
						'</button>' +
					'</div>' +
					'</div>' +
				'</div>';
			});

			$container.html(html);
		},

		approveVehicle: function (id) {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'vehicles/' + id + '/approve', {
				method: 'POST',
				headers: {
					'X-WP-Nonce': nonce,
					'Content-Type': 'application/json'
				}
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) {
						throw new Error(errData.message || 'Failed to approve vehicle.');
					});
				}
				return res.json();
			})
			.then(function (res) {
				self.showAlert(res.message || 'Vehicle approved and published!', 'success');
				self.loadVehicles();
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Failed to approve vehicle.', 'error');
			});
		},

		toggleFeatured: function (id) {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'vehicles/' + id + '/toggle-featured', {
				method: 'POST',
				headers: {
					'X-WP-Nonce': nonce,
					'Content-Type': 'application/json'
				}
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) {
						throw new Error(errData.message || 'Failed to update Featured status.');
					});
				}
				return res.json();
			})
			.then(function (res) {
				self.showAlert(res.message || 'Featured status updated.', 'success');
				self.loadVehicles();
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Failed to update Featured status.', 'error');
			});
		},

		openRejectModal: function (id) {
			this.activeVehicleRejectId = id;
			var vehicle = this.vehicles.find(function (item) { return item.id === id; });
			var title = vehicle ? vehicle.title : 'Vehicle #' + id;

			$('#cz-modal-vehicle-title').text(title);
			$('#cz-rejection-reason-input').val('');
			$('#cz-rejection-modal').fadeIn(150);
		},

		closeRejectModal: function () {
			this.activeVehicleRejectId = null;
			$('#cz-rejection-modal').fadeOut(150);
		},

		submitVehicleRejection: function () {
			if (!this.activeVehicleRejectId) {
				return;
			}

			var self = this;
			var id = this.activeVehicleRejectId;
			var reason = $('#cz-rejection-reason-input').val().trim();
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'vehicles/' + id + '/reject', {
				method: 'POST',
				headers: {
					'X-WP-Nonce': nonce,
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({ reason: reason })
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) {
						throw new Error(errData.message || 'Failed to reject vehicle.');
					});
				}
				return res.json();
			})
			.then(function (res) {
				self.closeRejectModal();
				self.showAlert(res.message || 'Vehicle listing rejected.', 'success');
				self.loadVehicles();
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Failed to reject vehicle.', 'error');
			});
		},

		openUnpublishModal: function (id) {
			this.activeVehicleUnpublishId = id;
			var vehicle = this.vehicles.find(function (item) { return item.id === id; });
			var title = vehicle ? vehicle.title : 'Vehicle #' + id;

			$('#cz-unpublish-modal-vehicle-title').text(title);
			$('#cz-unpublish-reason-input').val('');
			$('#cz-unpublish-modal').fadeIn(150);
		},

		closeUnpublishModal: function () {
			this.activeVehicleUnpublishId = null;
			$('#cz-unpublish-modal').fadeOut(150);
		},

		submitVehicleUnpublish: function () {
			if (!this.activeVehicleUnpublishId) {
				return;
			}

			var self = this;
			var id = this.activeVehicleUnpublishId;
			var reason = $('#cz-unpublish-reason-input').val().trim();
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'vehicles/' + id + '/unpublish', {
				method: 'POST',
				headers: {
					'X-WP-Nonce': nonce,
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({ reason: reason })
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) {
						throw new Error(errData.message || 'Failed to unpublish vehicle.');
					});
				}
				return res.json();
			})
			.then(function (res) {
				self.closeUnpublishModal();
				self.showAlert(res.message || 'Vehicle unpublished successfully.', 'success');
				self.loadVehicles();
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Failed to unpublish vehicle.', 'error');
			});
		},

		/* 3. FINANCE APPLICATIONS COUNT (Consumes GET /wp-json/carzuri/v1/finance-applications) */
		loadFinanceCount: function () {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'finance-applications', {
				method: 'GET',
				headers: {
					'X-WP-Nonce': nonce
				}
			})
			.then(function (res) {
				if (!res.ok) {
					throw new Error('HTTP ' + res.status);
				}
				return res.json();
			})
			.then(function (res) {
				var apps = (res && res.success && Array.isArray(res.data)) ? res.data : [];
				self.financeCount = apps.length;
				self.updateCounts();
			})
			.catch(function () {
				self.financeCount = 0;
				self.updateCounts();
			});
		},

		/* 4. BLOG / AUTOMOTIVE NEWS (Consumes carzuri/v1/blog/* endpoints, native WP posts) */
		loadBlogCategories: function () {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'blog/categories', {
				method: 'GET',
				headers: { 'X-WP-Nonce': nonce }
			})
			.then(function (res) {
				if (!res.ok) { throw new Error('HTTP ' + res.status); }
				return res.json();
			})
			.then(function (data) {
				self.blogCategories = Array.isArray(data) ? data : [];
				var $select = $('#cz-blog-category-select');
				$select.empty();
				self.blogCategories.forEach(function (cat) {
					$select.append('<option value="' + cat.id + '">' + self.escapeHtml(cat.name) + '</option>');
				});
			})
			.catch(function () {
				self.blogCategories = [];
			});
		},

		loadBlogPosts: function () {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'blog/posts?per_page=50', {
				method: 'GET',
				headers: { 'X-WP-Nonce': nonce }
			})
			.then(function (res) {
				if (!res.ok) { throw new Error('HTTP ' + res.status); }
				return res.json();
			})
			.then(function (data) {
				self.blogPosts = (data && Array.isArray(data.posts)) ? data.posts : [];
				self.renderBlogTable();
				self.updateBlogBadge();
			})
			.catch(function (err) {
				var msg = err.message || 'Failed to load blog posts.';
				self.showAlert(msg, 'error');
				$('#cz-blog-tbody').html('<tr><td colspan="5" class="cz-text-center cz-text-danger cz-p-4">' + msg + '</td></tr>');
			});
		},

		renderBlogTable: function () {
			var self = this;
			var $tbody = $('#cz-blog-tbody');

			if (!this.blogPosts || this.blogPosts.length === 0) {
				$tbody.html('<tr><td colspan="5" class="cz-text-center cz-p-6 cz-text-muted">No blog posts yet. Click "+ New Post" to write your first one.</td></tr>');
				return;
			}

			var rowsHtml = '';
			this.blogPosts.forEach(function (p) {
				var badgeClass = 'cz-badge-pending';
				var statusLabel = 'Draft';
				if (p.status === 'publish') {
					badgeClass = 'cz-badge-approved';
					statusLabel = 'Published';
				} else if (p.status === 'pending') {
					statusLabel = 'Pending Review';
				}

				var catNames = (self.blogCategories || [])
					.filter(function (c) { return p.categories && p.categories.indexOf(c.id) !== -1; })
					.map(function (c) { return c.name; })
					.join(', ') || 'Uncategorized';

				var dateFormatted = p.date ? new Date(p.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '';

				rowsHtml += '<tr data-post-id="' + p.id + '">' +
					'<td><div class="cz-font-bold">' + self.escapeHtml(p.title || '(untitled)') + '</div></td>' +
					'<td>' + self.escapeHtml(catNames) + '</td>' +
					'<td><span class="cz-badge ' + badgeClass + '">' + statusLabel + '</span></td>' +
					'<td class="cz-text-sm cz-text-muted">' + dateFormatted + '</td>' +
					'<td class="cz-text-right">' +
						'<div class="cz-flex cz-justify-end cz-gap-2">' +
						'<button type="button" class="cz-btn cz-btn-sm cz-btn-secondary" onclick="carzuriAdminApp.openBlogEditor(' + p.id + ')">Edit</button>';

				if (p.status !== 'publish') {
					rowsHtml += '<button type="button" class="cz-btn cz-btn-sm cz-btn-success" onclick="carzuriAdminApp.publishBlogPost(' + p.id + ')">Publish</button>';
				}

				rowsHtml += '<button type="button" class="cz-btn cz-btn-sm cz-btn-danger" onclick="carzuriAdminApp.deleteBlogPost(' + p.id + ')">Delete</button>' +
						'</div></td></tr>';
			});

			$tbody.html(rowsHtml);
		},

		updateBlogBadge: function () {
			var draftCount = (this.blogPosts || []).filter(function (p) { return p.status !== 'publish'; }).length;
			$('#cz-blog-draft-badge').text(draftCount);
		},

		promptNewCategory: function () {
			var self = this;
			var name = window.prompt('New category name:');
			if (!name || !name.trim()) { return; }
			name = name.trim();

			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'blog/categories', {
				method: 'POST',
				headers: {
					'X-WP-Nonce': nonce,
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({ name: name })
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) { throw new Error(errData.message || 'Failed to create category.'); });
				}
				return res.json();
			})
			.then(function (res) {
				self.showAlert(res.message || 'Category created.', 'success');
				var newCat = res.category;
				if (newCat && !self.blogCategories.some(function (c) { return c.id === newCat.id; })) {
					self.blogCategories.push(newCat);
				}
				var $select = $('#cz-blog-category-select');
				$select.empty();
				self.blogCategories.forEach(function (cat) {
					$select.append('<option value="' + cat.id + '">' + self.escapeHtml(cat.name) + '</option>');
				});
				if (newCat) {
					$select.val(newCat.id);
				}
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Failed to create category.', 'error');
			});
		},

		openBlogEditor: function (id) {
			$('#cz-blog-post-id').val(id || '');
			$('#cz-blog-featured-media-id').val('');
			$('#cz-blog-featured-image-preview').hide();

			if (id) {
				$('#cz-blog-modal-title').text('Edit Blog Post');
				var post = this.blogPosts.find(function (item) { return item.id === id; });
				if (post) {
					$('#cz-blog-title-input').val(post.title);
					$('#cz-blog-content-input').val(post.content);
					$('#cz-blog-excerpt-input').val(post.excerpt);
					$('#cz-blog-status-select').val(post.status === 'publish' ? 'publish' : 'draft');
					if (post.categories && post.categories.length) {
						$('#cz-blog-category-select').val(post.categories[0]);
					}
					if (post.featured_image_url) {
						$('#cz-blog-featured-media-id').val(post.featured_media);
						$('#cz-blog-featured-image-preview-img').attr('src', post.featured_image_url);
						$('#cz-blog-featured-image-preview').show();
					}
				}
			} else {
				$('#cz-blog-modal-title').text('New Blog Post');
				$('#cz-blog-title-input').val('');
				$('#cz-blog-content-input').val('');
				$('#cz-blog-excerpt-input').val('');
				$('#cz-blog-status-select').val('draft');
			}

			$('#cz-blog-editor-modal').fadeIn(150);
		},

		closeBlogEditor: function () {
			$('#cz-blog-editor-modal').fadeOut(150);
		},

		handleBlogImageSelect: function (file) {
			var self = this;
			if (!file) { return; }

			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var mediaUrl = rootUrl.replace('carzuri/v1/', 'wp/v2/') + 'media';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			var formData = new FormData();
			formData.append('file', file);

			self.showAlert('Uploading image...', 'success');

			fetch(mediaUrl, {
				method: 'POST',
				headers: { 'X-WP-Nonce': nonce },
				body: formData
			})
			.then(function (res) {
				if (!res.ok) { throw new Error('Image upload failed.'); }
				return res.json();
			})
			.then(function (media) {
				$('#cz-blog-featured-media-id').val(media.id);
				$('#cz-blog-featured-image-preview-img').attr('src', media.source_url);
				$('#cz-blog-featured-image-preview').show();
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Image upload failed.', 'error');
			});
		},

		saveBlogPost: function () {
			var self = this;
			var id = $('#cz-blog-post-id').val();
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			var title = $('#cz-blog-title-input').val().trim();
			if (!title) {
				self.showAlert('Please enter a post title.', 'error');
				return;
			}

			var catId = parseInt($('#cz-blog-category-select').val(), 10);
			var featuredMediaId = parseInt($('#cz-blog-featured-media-id').val(), 10);

			var payload = {
				title: title,
				content: $('#cz-blog-content-input').val(),
				excerpt: $('#cz-blog-excerpt-input').val(),
				status: $('#cz-blog-status-select').val(),
				categories: isNaN(catId) ? [] : [catId],
				featured_media: isNaN(featuredMediaId) ? 0 : featuredMediaId
			};

			var url = id ? (rootUrl + 'blog/posts/' + id) : (rootUrl + 'blog/posts');

			fetch(url, {
				method: 'POST',
				headers: {
					'X-WP-Nonce': nonce,
					'Content-Type': 'application/json'
				},
				body: JSON.stringify(payload)
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) {
						throw new Error(errData.message || 'Failed to save post.');
					});
				}
				return res.json();
			})
			.then(function (res) {
				self.closeBlogEditor();
				self.showAlert(res.message || 'Post saved.', 'success');
				self.loadBlogPosts();
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Failed to save post.', 'error');
			});
		},

		publishBlogPost: function (id) {
			var self = this;
			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'blog/posts/' + id + '/publish', {
				method: 'POST',
				headers: { 'X-WP-Nonce': nonce, 'Content-Type': 'application/json' }
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) { throw new Error(errData.message || 'Failed to publish post.'); });
				}
				return res.json();
			})
			.then(function (res) {
				self.showAlert(res.message || 'Post published.', 'success');
				self.loadBlogPosts();
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Failed to publish post.', 'error');
			});
		},

		deleteBlogPost: function (id) {
			var self = this;
			if (!window.confirm('Move this post to Trash?')) { return; }

			var rootUrl = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.root) ? carzuriAdminVars.root : '/wp-json/carzuri/v1/';
			var nonce = (typeof carzuriAdminVars !== 'undefined' && carzuriAdminVars.nonce) ? carzuriAdminVars.nonce : '';

			fetch(rootUrl + 'blog/posts/' + id + '/delete', {
				method: 'POST',
				headers: { 'X-WP-Nonce': nonce, 'Content-Type': 'application/json' }
			})
			.then(function (res) {
				if (!res.ok) {
					return res.json().then(function (errData) { throw new Error(errData.message || 'Failed to delete post.'); });
				}
				return res.json();
			})
			.then(function (res) {
				self.showAlert(res.message || 'Post moved to Trash.', 'success');
				self.loadBlogPosts();
			})
			.catch(function (err) {
				self.showAlert(err.message || 'Failed to delete post.', 'error');
			});
		},

		updateCounts: function () {
			var pendingDealers = this.dealers.filter(function (d) {
				return d.carzuri_dealer_approved === '0' || d.status === 'pending';
			}).length;

			if (this.currentVehicleFilter === 'pending') {
				var pendingVehicles = this.vehicles.length;
				$('#stat-pending-vehicles').text(pendingVehicles);
				$('#cz-vehicle-pending-badge').text(pendingVehicles);
			}

			$('#stat-pending-dealers').text(pendingDealers);
			$('#cz-dealer-pending-badge').text(pendingDealers);

			$('#stat-pending-finance').text(this.financeCount);
			$('#cz-finance-pending-badge').text(this.financeCount);
		}
	};

	$(document).ready(function () {
		window.carzuriAdminApp.init();
	});

})(jQuery);
