/**
 * Carzuri Messaging Frontend Client
 *
 * Handles REST API synchronization, active conversation streaming,
 * message posting, 15s polling, read-marking, search, and mobile views.
 *
 * @package Carzuri_Messaging
 */

(function() {
	'use strict';

	/* Verify data object exists */
	if (typeof window.carzuriMessagingData === 'undefined') {
		return;
	}

	const config = window.carzuriMessagingData;
	const restUrl = config.restUrl;
	const nonce = config.nonce;
	const currentUserId = parseInt(config.currentUserId, 10);
	const pollIntervalMs = config.pollInterval || 15000;

	/* State */
	let state = {
		conversations: [],
		activeConversationId: null,
		activeConversation: null,
		messages: [],
		filter: 'all',
		searchQuery: '',
		isSending: false,
		isLoadingMessages: false,
		pollTimer: null
	};

	/* DOM Elements */
	let dom = {};

	/* Initialize once DOM is ready */
	function init() {
		cacheDom();
		if (!dom.container) {
			return;
		}

		bindEvents();
		handleInitialParams();
		loadConversations();
		startPolling();
	}

	/* Cache DOM references */
	function cacheDom() {
		dom.container = document.getElementById('carzuri-messaging-app');
		if (!dom.container) {
			return;
		}

		dom.panels = document.getElementById('carzuri-msg-panels');
		dom.searchInput = document.getElementById('carzuri-conv-search-input');
		dom.filterButtons = document.querySelectorAll('.carzuri-filter-btn');
		dom.unreadTotalBadge = document.getElementById('carzuri-unread-total-badge');
		dom.convLoading = document.getElementById('carzuri-conv-loading');
		dom.convList = document.getElementById('carzuri-conversations-list');
		dom.noConversations = document.getElementById('carzuri-no-conversations');
		
		/* Thread elements */
		dom.threadPanel = document.getElementById('carzuri-thread-panel');
		dom.backBtn = document.getElementById('carzuri-mobile-back-btn');
		dom.threadAvatar = document.getElementById('carzuri-thread-avatar');
		dom.threadUserName = document.getElementById('carzuri-thread-user-name');
		dom.threadRoleBadge = document.getElementById('carzuri-thread-role-badge');
		dom.threadStatus = document.getElementById('carzuri-thread-status');
		dom.threadStatusText = document.getElementById('carzuri-thread-status-text');
		dom.vehicleCard = document.getElementById('carzuri-thread-vehicle-card');
		dom.vehicleThumb = document.getElementById('carzuri-vehicle-thumb-img');
		dom.vehicleLink = document.getElementById('carzuri-vehicle-link');
		dom.emptyPlaceholder = document.getElementById('carzuri-thread-empty-state');
		dom.messagesStreamWrap = document.getElementById('carzuri-messages-stream-wrap');
		dom.messagesScroll = document.getElementById('carzuri-messages-scroll');
		dom.messagesList = document.getElementById('carzuri-messages-list');
		dom.scrollAnchor = document.getElementById('carzuri-scroll-anchor');
		dom.composerPanel = document.getElementById('carzuri-composer-panel');
		dom.messageForm = document.getElementById('carzuri-message-form');
		dom.messageInput = document.getElementById('carzuri-message-input');
		dom.sendBtn = document.getElementById('carzuri-send-btn');
		dom.sendBtnText = document.getElementById('carzuri-send-btn-text');
		dom.sendIcon = document.getElementById('carzuri-send-icon');
		dom.sendSpinner = document.getElementById('carzuri-send-spinner');
		dom.charCount = document.getElementById('carzuri-char-count');
	}

	/* Event listeners */
	function bindEvents() {
		/* Search input */
		if (dom.searchInput) {
			dom.searchInput.addEventListener('input', function(e) {
				state.searchQuery = e.target.value.toLowerCase().trim();
				renderConversationList();
			});
		}

		/* Filter buttons */
		if (dom.filterButtons) {
			dom.filterButtons.forEach(function(btn) {
				btn.addEventListener('click', function() {
					dom.filterButtons.forEach(function(b) { b.classList.remove('is-active'); });
					btn.classList.add('is-active');
					state.filter = btn.getAttribute('data-filter') || 'all';
					renderConversationList();
				});
			});
		}

		/* Mobile Back button */
		if (dom.backBtn) {
			dom.backBtn.addEventListener('click', function() {
				setMobileView('list');
			});
		}

		/* Message Composer Form */
		if (dom.messageForm) {
			dom.messageForm.addEventListener('submit', function(e) {
				e.preventDefault();
				sendMessage();
			});
		}

		/* Message input auto-resize & keyboard shortcuts */
		if (dom.messageInput) {
			dom.messageInput.addEventListener('keydown', function(e) {
				if (e.key === 'Enter' && !e.shiftKey) {
					e.preventDefault();
					sendMessage();
				}
			});

			dom.messageInput.addEventListener('input', function() {
				this.style.height = 'auto';
				this.style.height = Math.min(this.scrollHeight, 140) + 'px';
				if (dom.charCount) {
					dom.charCount.textContent = this.value.length + ' / 3000';
				}
			});
		}

		/* Visibility change handler to manage polling efficiency */
		document.addEventListener('visibilitychange', function() {
			if (document.hidden) {
				stopPolling();
			} else {
				startPolling();
				if (state.activeConversationId) {
					fetchMessages(state.activeConversationId, true);
				}
				loadConversations(true);
			}
		});
	}

	/* Check for URL query params like dealer_id, vehicle_id or conversation_id */
	function handleInitialParams() {
		if (config.targetDealerId && config.targetDealerId > 0) {
			startNewConversation(config.targetDealerId, config.targetVehicleId || 0);
		} else if (config.initialConversation && config.initialConversation > 0) {
			state.activeConversationId = parseInt(config.initialConversation, 10);
		}
	}

	/* REST Fetch Helper */
	function apiFetch(endpoint, options) {
		options = options || {};
		const url = restUrl + endpoint.replace(/^\//, '');
		const headers = options.headers || {};
		
		headers['X-WP-Nonce'] = nonce;
		headers['Content-Type'] = 'application/json';
		options.headers = headers;
		options.credentials = 'same-origin';

		return fetch(url, options).then(function(response) {
			return response.json().then(function(data) {
				if (!response.ok) {
					const errorMsg = data && data.message ? data.message : 'HTTP ' + response.status;
					return Promise.reject(new Error(errorMsg));
				}
				return data;
			});
		});
	}

	/* Load Conversations List from REST */
	function loadConversations(isBackground) {
		if (!isBackground && dom.convLoading) {
			dom.convLoading.style.display = 'flex';
		}

		apiFetch('conversations')
			.then(function(data) {
				if (dom.convLoading) {
					dom.convLoading.style.display = 'none';
				}

				if (data && data.conversations) {
					state.conversations = data.conversations;
					updateUnreadTotalBadge();
					renderConversationList();

					/* If an initial conversation was requested or is active */
					if (state.activeConversationId) {
						const found = state.conversations.find(function(c) {
							return c.id === state.activeConversationId;
						});
						if (found && !state.activeConversation) {
							selectConversation(found.id, false);
						}
					}
				}
			})
			.catch(function(err) {
				if (dom.convLoading) {
					dom.convLoading.style.display = 'none';
				}
				console.error('[Carzuri Messaging] Error loading conversations:', err);
			});
	}

	/* Start or find conversation with dealer */
	function startNewConversation(dealerId, vehicleId) {
		apiFetch('conversations/start', {
			method: 'POST',
			body: JSON.stringify({
				dealer_id: dealerId,
				vehicle_id: vehicleId
			})
		})
		.then(function(res) {
			if (res && res.conversation_id) {
				state.activeConversationId = res.conversation_id;
				loadConversations();
				selectConversation(res.conversation_id);
			}
		})
		.catch(function(err) {
			console.error('[Carzuri Messaging] Error initiating conversation:', err);
		});
	}

	/* Update global unread badge */
	function updateUnreadTotalBadge() {
		const totalUnread = state.conversations.reduce(function(acc, item) {
			return acc + (item.unread_count || 0);
		}, 0);

		if (dom.unreadTotalBadge) {
			if (totalUnread > 0) {
				dom.unreadTotalBadge.textContent = totalUnread;
				dom.unreadTotalBadge.style.display = 'inline-block';
			} else {
				dom.unreadTotalBadge.style.display = 'none';
			}
		}
	}

	/* Filter and Render Conversations */
	function renderConversationList() {
		if (!dom.convList) {
			return;
		}

		let items = state.conversations.slice();

		/* Apply Search Filter */
		if (state.searchQuery) {
			items = items.filter(function(item) {
				const nameMatch = item.other_user && item.other_user.name && item.other_user.name.toLowerCase().includes(state.searchQuery);
				const vehicleMatch = item.vehicle && item.vehicle.title && item.vehicle.title.toLowerCase().includes(state.searchQuery);
				const snippetMatch = item.last_message && item.last_message.text && item.last_message.text.toLowerCase().includes(state.searchQuery);
				return nameMatch || vehicleMatch || snippetMatch;
			});
		}

		/* Apply Category Filter */
		if (state.filter === 'unread') {
			items = items.filter(function(item) {
				return (item.unread_count || 0) > 0;
			});
		} else if (state.filter === 'vehicles') {
			items = items.filter(function(item) {
				return item.vehicle_id && item.vehicle_id > 0;
			});
		}

		dom.convList.innerHTML = '';

		if (items.length === 0) {
			if (dom.noConversations) {
				dom.noConversations.style.display = 'flex';
			}
			return;
		}

		if (dom.noConversations) {
			dom.noConversations.style.display = 'none';
		}

		items.forEach(function(conv) {
			const el = createConversationItemElement(conv);
			dom.convList.appendChild(el);
		});
	}

	/* Create single conversation list DOM element */
	function createConversationItemElement(conv) {
		const div = document.createElement('div');
		div.className = 'carzuri-conv-item' + 
			(conv.id === state.activeConversationId ? ' is-active' : '') +
			(conv.unread_count > 0 ? ' has-unread' : '');
		div.setAttribute('data-conv-id', conv.id);

		const otherUser = conv.other_user || {};
		const initialLetter = otherUser.name ? otherUser.name.charAt(0).toUpperCase() : 'C';
		const relativeTime = formatRelativeTime(conv.last_message ? conv.last_message.created_at : conv.last_message_at);

		let avatarHtml = '';
		if (otherUser.avatar_url) {
			avatarHtml = '<img src="' + escapeHtml(otherUser.avatar_url) + '" alt="' + escapeHtml(otherUser.name) + '" class="carzuri-avatar-img" />';
		} else {
			avatarHtml = '<div class="carzuri-avatar-fallback">' + initialLetter + '</div>';
		}

		let vehicleBadgeHtml = '';
		if (conv.vehicle && conv.vehicle.title) {
			vehicleBadgeHtml = '<div class="carzuri-conv-vehicle-tag">' +
				'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:12px!important;height:12px!important;min-width:12px!important;"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>' +
				'<span>' + escapeHtml(conv.vehicle.title) + '</span>' +
			'</div>';
		}

		let unreadDotHtml = '';
		if (conv.unread_count > 0) {
			unreadDotHtml = '<span class="carzuri-unread-dot-badge">' + conv.unread_count + '</span>';
		}

		const snippet = conv.last_message && conv.last_message.text ? conv.last_message.text : 'No messages yet';

		div.innerHTML = 
			'<div class="carzuri-conv-avatar-box">' + avatarHtml + '</div>' +
			'<div class="carzuri-conv-body">' +
				'<div class="carzuri-conv-row-top">' +
					'<h4 class="carzuri-conv-name">' + escapeHtml(otherUser.name || 'Carzuri User') + '</h4>' +
					'<span class="carzuri-conv-time">' + relativeTime + '</span>' +
				'</div>' +
				vehicleBadgeHtml +
				'<div class="carzuri-conv-preview-row">' +
					'<p class="carzuri-conv-snippet">' + escapeHtml(snippet) + '</p>' +
					unreadDotHtml +
				'</div>' +
			'</div>';

		div.addEventListener('click', function() {
			selectConversation(conv.id, true);
		});

		return div;
	}

	/* Select an active conversation */
	function selectConversation(convId, switchToThreadMobile) {
		state.activeConversationId = convId;
		
		/* Update active class in list */
		const allItems = dom.convList.querySelectorAll('.carzuri-conv-item');
		allItems.forEach(function(item) {
			if (parseInt(item.getAttribute('data-conv-id'), 10) === convId) {
				item.classList.add('is-active');
				item.classList.remove('has-unread');
				const badge = item.querySelector('.carzuri-unread-dot-badge');
				if (badge) {
					badge.remove();
				}
			} else {
				item.classList.remove('is-active');
			}
		});

		if (switchToThreadMobile !== false) {
			setMobileView('thread');
		}

		fetchMessages(convId, false);
		markConversationAsRead(convId);
	}

	/* Fetch messages for a specific conversation */
	function fetchMessages(convId, isBackground) {
		if (!isBackground) {
			state.isLoadingMessages = true;
		}

		apiFetch('conversations/' + convId + '/messages')
			.then(function(data) {
				state.isLoadingMessages = false;
				if (data && data.success) {
					state.activeConversation = data.conversation;
					state.messages = data.messages || [];
					updateThreadHeader(data.conversation);
					renderMessagesList();
					if (dom.emptyPlaceholder) {
						dom.emptyPlaceholder.style.display = 'none';
					}
					if (dom.messagesStreamWrap) {
						dom.messagesStreamWrap.style.display = 'flex';
					}
					if (dom.composerPanel) {
						dom.composerPanel.style.display = 'block';
					}
					if (!isBackground) {
						scrollToBottom(true);
					}
				}
			})
			.catch(function(err) {
				state.isLoadingMessages = false;
				console.error('[Carzuri Messaging] Error fetching messages:', err);
			});
	}

	/* Update Thread Header details */
	function updateThreadHeader(conv) {
		if (!conv) {
			return;
		}

		const otherParty = conv.other_party || {};
		if (dom.threadUserName) {
			dom.threadUserName.textContent = otherParty.name || 'Carzuri User';
		}

		if (dom.threadRoleBadge) {
			if (otherParty.role_label) {
				dom.threadRoleBadge.textContent = otherParty.role_label;
				dom.threadRoleBadge.style.display = 'inline-block';
			} else {
				dom.threadRoleBadge.style.display = 'none';
			}
		}

		if (dom.threadAvatar) {
			if (otherParty.avatar_url) {
				dom.threadAvatar.innerHTML = '<img src="' + escapeHtml(otherParty.avatar_url) + '" alt="" class="carzuri-avatar-img" />';
			} else {
				const letter = otherParty.name ? otherParty.name.charAt(0).toUpperCase() : 'C';
				dom.threadAvatar.innerHTML = '<span>' + letter + '</span>';
			}
		}

		/* Vehicle Card */
		if (dom.vehicleCard && dom.vehicleLink && dom.vehicleThumb) {
			if (conv.vehicle && conv.vehicle.title) {
				dom.vehicleLink.textContent = conv.vehicle.title;
				dom.vehicleLink.href = conv.vehicle.permalink || '#';
				if (conv.vehicle.thumbnail) {
					dom.vehicleThumb.src = conv.vehicle.thumbnail;
					dom.vehicleThumb.parentElement.style.display = 'block';
				} else {
					dom.vehicleThumb.parentElement.style.display = 'none';
				}
				dom.vehicleCard.style.display = 'flex';
			} else {
				dom.vehicleCard.style.display = 'none';
			}
		}
	}

	/* Render messages list */
	function renderMessagesList() {
		if (!dom.messagesList) {
			return;
		}

		dom.messagesList.innerHTML = '';
		let lastDate = '';

		state.messages.forEach(function(msg) {
			const msgDate = new Date(msg.created_at.replace(/-/g, '/'));
			const dateStr = formatDateSeparator(msgDate);

			if (dateStr !== lastDate) {
				const dateDivider = document.createElement('div');
				dateDivider.className = 'carzuri-date-divider';
				dateDivider.innerHTML = '<span class="carzuri-date-divider-text">' + dateStr + '</span>';
				dom.messagesList.appendChild(dateDivider);
				lastDate = dateStr;
			}

			const row = document.createElement('div');
			row.className = 'carzuri-msg-row ' + (msg.is_mine ? 'is-mine' : 'is-other');

			const timeStr = formatMessageTime(msgDate);
			const readStatusHtml = msg.is_mine ? 
				(msg.is_read ? '<span class="carzuri-read-status">✓✓</span>' : '<span class="carzuri-read-status">✓</span>') : '';

			row.innerHTML = 
				'<div class="carzuri-msg-bubble">' + formatMessageBody(msg.message_text) + '</div>' +
				'<div class="carzuri-msg-footer">' +
					'<span class="carzuri-msg-time">' + timeStr + '</span>' +
					readStatusHtml +
				'</div>';

			dom.messagesList.appendChild(row);
		});
	}

	/* Send a new message */
	function sendMessage() {
		if (state.isSending || !state.activeConversationId || !dom.messageInput) {
			return;
		}

		const text = dom.messageInput.value.trim();
		if (!text) {
			return;
		}

		setSendingState(true);

		apiFetch('conversations/' + state.activeConversationId + '/messages', {
			method: 'POST',
			body: JSON.stringify({
				message_text: text
			})
		})
		.then(function(res) {
			setSendingState(false);
			if (res && res.success && res.message) {
				dom.messageInput.value = '';
				dom.messageInput.style.height = 'auto';
				if (dom.charCount) {
					dom.charCount.textContent = '0 / 3000';
				}

				state.messages.push(res.message);
				renderMessagesList();
				scrollToBottom(true);
				loadConversations(true);
			}
		})
		.catch(function(err) {
			setSendingState(false);
			alert(err.message || 'Failed to send message. Please try again.');
		});
	}

	/* Mark conversation as read */
	function markConversationAsRead(convId) {
		apiFetch('conversations/' + convId + '/mark-read', {
			method: 'POST'
		})
		.then(function(res) {
			/* Update local unread counts */
			const conv = state.conversations.find(function(c) { return c.id === convId; });
			if (conv) {
				conv.unread_count = 0;
				updateUnreadTotalBadge();
			}
		})
		.catch(function(err) {
			console.warn('[Carzuri Messaging] mark-read error:', err);
		});
	}

	/* Set sending state for button */
	function setSendingState(sending) {
		state.isSending = sending;
		if (!dom.sendBtn) {
			return;
		}

		dom.sendBtn.disabled = sending;
		if (dom.sendSpinner && dom.sendIcon && dom.sendBtnText) {
			if (sending) {
				dom.sendSpinner.style.display = 'inline-block';
				dom.sendIcon.style.display = 'none';
				dom.sendBtnText.textContent = config.i18n.sending || 'Sending...';
			} else {
				dom.sendSpinner.style.display = 'none';
				dom.sendIcon.style.display = 'inline-block';
				dom.sendBtnText.textContent = config.i18n.send || 'Send';
			}
		}
	}

	/* Scroll message stream to bottom */
	function scrollToBottom(smooth) {
		if (dom.messagesScroll) {
			setTimeout(function() {
				dom.messagesScroll.scrollTo({
					top: dom.messagesScroll.scrollHeight,
					behavior: smooth ? 'smooth' : 'auto'
				});
			}, 30);
		}
	}

	/* Mobile view switcher */
	function setMobileView(view) {
		if (!dom.panels) {
			return;
		}
		if (view === 'thread') {
			dom.panels.classList.remove('carzuri-view-list');
			dom.panels.classList.add('carzuri-view-thread');
		} else {
			dom.panels.classList.remove('carzuri-view-thread');
			dom.panels.classList.add('carzuri-view-list');
		}
	}

	/* Polling Mechanism (every 15s) */
	function startPolling() {
		stopPolling();
		state.pollTimer = setInterval(function() {
			loadConversations(true);
			if (state.activeConversationId) {
				fetchMessages(state.activeConversationId, true);
			}
		}, pollIntervalMs);
	}

	function stopPolling() {
		if (state.pollTimer) {
			clearInterval(state.pollTimer);
			state.pollTimer = null;
		}
	}

	/* Helper: Format Relative Time */
	function formatRelativeTime(dateStr) {
		if (!dateStr) return '';
		const d = new Date(dateStr.replace(/-/g, '/'));
		const now = new Date();
		const diffSeconds = Math.floor((now - d) / 1000);

		if (diffSeconds < 60) return config.i18n.now || 'Just now';
		if (diffSeconds < 3600) return Math.floor(diffSeconds / 60) + 'm ago';
		if (diffSeconds < 86400) return Math.floor(diffSeconds / 3600) + 'h ago';
		if (diffSeconds < 604800) return Math.floor(diffSeconds / 86400) + 'd ago';
		return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
	}

	/* Helper: Format Date Separator */
	function formatDateSeparator(d) {
		const today = new Date();
		if (d.toDateString() === today.toDateString()) {
			return 'Today';
		}
		const yesterday = new Date();
		yesterday.setDate(today.getDate() - 1);
		if (d.toDateString() === yesterday.toDateString()) {
			return 'Yesterday';
		}
		return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
	}

	/* Helper: Format Message Time */
	function formatMessageTime(d) {
		return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
	}

	/* Helper: Format Message Text safely with line breaks */
	function formatMessageBody(raw) {
		if (!raw) return '';
		const escaped = escapeHtml(raw);
		return escaped.replace(/\n/g, '<br>');
	}

	/* Helper: HTML Escape */
	function escapeHtml(str) {
		if (!str) return '';
		return String(str)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}

	/* Boot up on DOMContentLoaded */
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

})();
