<?php
/**
 * Uninstall handler for Carzuri Messaging
 *
 * WordPress only executes this file when the plugin is deleted from the
 * Plugins screen (not on a simple deactivate), so it's safe to drop these
 * tables here — this never runs during normal use.
 *
 * @package Carzuri_Messaging
 */

// If uninstall not called from WordPress, exit (standard WP safeguard —
// prevents this file from being run directly or by anything other than
// WordPress's own uninstall process).
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

$conversations_table = $wpdb->prefix . 'carzuri_conversations';
$messages_table       = $wpdb->prefix . 'carzuri_messages';

// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table names cannot be parameterized; not user input.
$wpdb->query( "DROP TABLE IF EXISTS {$messages_table}" );
// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table names cannot be parameterized; not user input.
$wpdb->query( "DROP TABLE IF EXISTS {$conversations_table}" );
