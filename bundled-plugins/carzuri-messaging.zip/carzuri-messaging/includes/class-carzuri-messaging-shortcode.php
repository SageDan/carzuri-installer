<?php
/**
 * Shortcode & Asset Management for Carzuri Messaging.
 *
 * @package Carzuri_Messaging
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Messaging_Shortcode {

	/**
	 * Initialize hooks.
	 */
	public static function init() {
		add_shortcode( 'carzuri_my_messages', array( __CLASS__, 'render_my_messages_shortcode' ) );
		add_shortcode( 'carzuri_message_dealer_button', array( __CLASS__, 'render_contact_dealer_button_shortcode' ) );

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}

	/**
	 * Register frontend scripts and styles.
	 */
	public static function register_assets() {
		wp_register_style(
			'carzuri-messaging-css',
			CARZURI_MESSAGING_PLUGIN_URL . 'assets/css/carzuri-messaging.css',
			array(),
			CARZURI_MESSAGING_VERSION
		);

		wp_register_script(
			'carzuri-messaging-js',
			CARZURI_MESSAGING_PLUGIN_URL . 'assets/js/carzuri-messaging.js',
			array(),
			CARZURI_MESSAGING_VERSION,
			true
		);
	}

	/**
	 * Render the primary [carzuri_my_messages] shortcode.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string HTML output.
	 */
	public static function render_my_messages_shortcode( $atts = array() ) {
		if ( ! is_user_logged_in() ) {
			return self::render_login_required();
		}

		// Enqueue scripts and styles.
		wp_enqueue_style( 'carzuri-messaging-css' );
		wp_enqueue_script( 'carzuri-messaging-js' );

		$current_user           = wp_get_current_user();
		$initial_conversation_id = isset( $_GET['conversation_id'] ) ? absint( $_GET['conversation_id'] ) : 0;
		$target_dealer_id       = isset( $_GET['dealer_id'] ) ? absint( $_GET['dealer_id'] ) : 0;
		$target_vehicle_id      = isset( $_GET['vehicle_id'] ) ? absint( $_GET['vehicle_id'] ) : 0;

		$roles = (array) $current_user->roles;
		$is_dealer = in_array( 'carzuri_dealer', $roles, true );
		$role_name = $is_dealer ? __( 'Dealer Account', 'carzuri-messaging' ) : __( 'Buyer Account', 'carzuri-messaging' );

		// Localize script data for REST communication.
		wp_localize_script(
			'carzuri-messaging-js',
			'carzuriMessagingData',
			array(
				'restUrl'             => esc_url_raw( rest_url( 'carzuri/v1/' ) ),
				'nonce'               => wp_create_nonce( 'wp_rest' ),
				'currentUserId'       => $current_user->ID,
				'currentUserName'     => $current_user->display_name,
				'userRoles'           => $roles,
				'isDealer'            => $is_dealer,
				'initialConversation' => $initial_conversation_id,
				'targetDealerId'      => $target_dealer_id,
				'targetVehicleId'     => $target_vehicle_id,
				'pollInterval'        => 15000, // 15 seconds polling.
				'i18n'                => array(
					'noConversations'  => __( 'No conversations yet.', 'carzuri-messaging' ),
					'selectToRead'     => __( 'Select a conversation from the left to start messaging.', 'carzuri-messaging' ),
					'typeMessage'      => __( 'Type your message...', 'carzuri-messaging' ),
					'send'             => __( 'Send', 'carzuri-messaging' ),
					'sending'          => __( 'Sending...', 'carzuri-messaging' ),
					'loadFailed'       => __( 'Unable to load messages. Please check your connection.', 'carzuri-messaging' ),
					'verifiedDealer'   => __( 'Verified Dealer', 'carzuri-messaging' ),
					'buyer'            => __( 'Buyer', 'carzuri-messaging' ),
					'vehicleInquiry'   => __( 'Vehicle Inquiry', 'carzuri-messaging' ),
					'generalInquiry'   => __( 'General Chat', 'carzuri-messaging' ),
					'unreadBadge'      => __( 'unread', 'carzuri-messaging' ),
					'online'           => __( 'Active on Carzuri', 'carzuri-messaging' ),
					'now'              => __( 'Just now', 'carzuri-messaging' ),
					'startNew'         => __( 'Start Conversation', 'carzuri-messaging' ),
					'backToChatList'   => __( 'All Messages', 'carzuri-messaging' ),
				),
			)
		);

		ob_start();
		?>
		<div id="carzuri-messaging-app" class="carzuri-msg-container" data-user-id="<?php echo esc_attr( $current_user->ID ); ?>" data-initial-conv="<?php echo esc_attr( $initial_conversation_id ); ?>">
			
			<!-- Top Header Bar -->
			<div class="carzuri-msg-topbar">
				<div class="carzuri-msg-topbar-left">
					<div class="carzuri-msg-brand-mark">
						<svg class="carzuri-icon-gold" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
						</svg>
						<span class="carzuri-msg-brand-title"><?php esc_html_e( 'Carzuri Messages', 'carzuri-messaging' ); ?></span>
					</div>
					<span class="carzuri-badge-role"><?php echo esc_html( $role_name ); ?></span>
				</div>
				<div class="carzuri-msg-topbar-right">
					<span id="carzuri-connection-status" class="carzuri-connection-pill">
						<span class="carzuri-status-dot"></span>
						<span class="carzuri-status-label"><?php esc_html_e( 'Live', 'carzuri-messaging' ); ?></span>
					</span>
				</div>
			</div>

			<!-- Main Two-Panel Layout -->
			<div id="carzuri-msg-panels" class="carzuri-msg-panels carzuri-view-list">

				<!-- Left Panel: Conversation List -->
				<aside id="carzuri-conv-list-panel" class="carzuri-conv-panel" aria-label="<?php esc_attr_e( 'Conversations List', 'carzuri-messaging' ); ?>">
					
					<!-- Search and Filter Bar -->
					<div class="carzuri-search-wrapper">
						<div class="carzuri-input-with-icon">
							<svg class="carzuri-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
								<circle cx="11" cy="11" r="8"></circle>
								<line x1="21" y1="21" x2="16.65" y2="16.65"></line>
							</svg>
							<input type="text" id="carzuri-conv-search-input" class="carzuri-search-input" placeholder="<?php esc_attr_e( 'Search by dealer, buyer, or vehicle...', 'carzuri-messaging' ); ?>" />
						</div>
						<div class="carzuri-filter-pills">
							<button type="button" id="carzuri-filter-all" class="carzuri-filter-btn is-active" data-filter="all">
								<?php esc_html_e( 'All', 'carzuri-messaging' ); ?>
							</button>
							<button type="button" id="carzuri-filter-unread" class="carzuri-filter-btn" data-filter="unread">
								<?php esc_html_e( 'Unread', 'carzuri-messaging' ); ?>
								<span id="carzuri-unread-total-badge" class="carzuri-pill-badge" style="display:none;">0</span>
							</button>
							<button type="button" id="carzuri-filter-vehicles" class="carzuri-filter-btn" data-filter="vehicles">
								<?php esc_html_e( 'Vehicles', 'carzuri-messaging' ); ?>
							</button>
						</div>
					</div>

					<!-- Conversation List Scroll View -->
					<div id="carzuri-conv-scroll-container" class="carzuri-conv-scroll">
						<div id="carzuri-conv-loading" class="carzuri-loading-skeleton">
							<div class="carzuri-skeleton-item"></div>
							<div class="carzuri-skeleton-item"></div>
							<div class="carzuri-skeleton-item"></div>
						</div>
						<div id="carzuri-conversations-list" class="carzuri-conversations-list" role="list"></div>
						<div id="carzuri-no-conversations" class="carzuri-empty-notice" style="display: none;">
							<svg class="carzuri-empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
								<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
							</svg>
							<p class="carzuri-empty-title"><?php esc_html_e( 'No conversations yet', 'carzuri-messaging' ); ?></p>
							<p class="carzuri-empty-subtitle"><?php esc_html_e( 'Inquiries from buyers or replies from dealers will appear here.', 'carzuri-messaging' ); ?></p>
						</div>
					</div>
				</aside>

				<!-- Right Panel: Active Message Thread -->
				<section id="carzuri-thread-panel" class="carzuri-thread-panel" aria-label="<?php esc_attr_e( 'Active Chat Thread', 'carzuri-messaging' ); ?>">
					
					<!-- Mobile Back Button and Thread Header -->
					<div id="carzuri-thread-header" class="carzuri-thread-header">
						<div class="carzuri-header-inner">
							<button type="button" id="carzuri-mobile-back-btn" class="carzuri-back-btn" aria-label="<?php esc_attr_e( 'Back to conversation list', 'carzuri-messaging' ); ?>">
								<svg class="carzuri-back-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
									<line x1="19" y1="12" x2="5" y2="12"></line>
									<polyline points="12 19 5 12 12 5"></polyline>
								</svg>
								<span><?php esc_html_e( 'Back', 'carzuri-messaging' ); ?></span>
							</button>

							<div class="carzuri-thread-user-info">
								<div id="carzuri-thread-avatar" class="carzuri-thread-avatar">
									<span id="carzuri-thread-avatar-fallback">C</span>
								</div>
								<div class="carzuri-thread-user-meta">
									<div class="carzuri-user-title-row">
										<h3 id="carzuri-thread-user-name" class="carzuri-thread-title"><?php esc_html_e( 'Select a conversation', 'carzuri-messaging' ); ?></h3>
										<span id="carzuri-thread-role-badge" class="carzuri-role-tag" style="display:none;"></span>
									</div>
									<p id="carzuri-thread-status" class="carzuri-thread-sub">
										<span class="carzuri-indicator-online"></span>
										<span id="carzuri-thread-status-text"><?php esc_html_e( 'Carzuri Direct Messaging', 'carzuri-messaging' ); ?></span>
									</p>
								</div>
							</div>

							<!-- Attached Vehicle Quick View -->
							<div id="carzuri-thread-vehicle-card" class="carzuri-thread-vehicle-card" style="display: none;">
								<div class="carzuri-vehicle-thumb-box">
									<img id="carzuri-vehicle-thumb-img" src="" alt="<?php esc_attr_e( 'Vehicle', 'carzuri-messaging' ); ?>" class="carzuri-vehicle-thumb" />
								</div>
								<div class="carzuri-vehicle-meta">
									<span class="carzuri-vehicle-badge-label"><?php esc_html_e( 'Regarding Vehicle', 'carzuri-messaging' ); ?></span>
									<a id="carzuri-vehicle-link" href="#" target="_blank" rel="noopener noreferrer" class="carzuri-vehicle-title-link"></a>
								</div>
							</div>
						</div>
					</div>

					<!-- Empty Thread Placeholder (When none selected) -->
					<div id="carzuri-thread-empty-state" class="carzuri-thread-placeholder">
						<div class="carzuri-placeholder-card">
							<div class="carzuri-placeholder-icon-wrap">
								<svg class="carzuri-placeholder-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
									<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
								</svg>
							</div>
							<h3 class="carzuri-placeholder-title"><?php esc_html_e( 'Carzuri Marketplace Chat', 'carzuri-messaging' ); ?></h3>
							<p class="carzuri-placeholder-desc"><?php esc_html_e( 'Select any conversation from the list to view chat history and reply to buyers or dealers.', 'carzuri-messaging' ); ?></p>
						</div>
					</div>

					<!-- Active Messages Stream Container -->
					<div id="carzuri-messages-stream-wrap" class="carzuri-messages-stream-wrap" style="display: none;">
						<div id="carzuri-messages-scroll" class="carzuri-messages-scroll">
							<div id="carzuri-messages-list" class="carzuri-messages-list"></div>
							<div id="carzuri-scroll-anchor"></div>
						</div>
					</div>

					<!-- Message Composer Form -->
					<div id="carzuri-composer-panel" class="carzuri-composer-panel" style="display: none;">
						<form id="carzuri-message-form" class="carzuri-message-form">
							<div class="carzuri-composer-input-row">
								<textarea
									id="carzuri-message-input"
									class="carzuri-message-input"
									rows="1"
									placeholder="<?php esc_attr_e( 'Type your message... (Enter to send, Shift+Enter for newline)', 'carzuri-messaging' ); ?>"
									maxlength="3000"
									required
								></textarea>
								<button type="submit" id="carzuri-send-btn" class="carzuri-send-button" aria-label="<?php esc_attr_e( 'Send message', 'carzuri-messaging' ); ?>">
									<span id="carzuri-send-btn-text" class="carzuri-send-btn-label"><?php esc_html_e( 'Send', 'carzuri-messaging' ); ?></span>
									<svg id="carzuri-send-icon" class="carzuri-send-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
										<line x1="22" y1="2" x2="11" y2="13"></line>
										<polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
									</svg>
									<span id="carzuri-send-spinner" class="carzuri-spinner" style="display: none;"></span>
								</button>
							</div>
							<div class="carzuri-composer-footer">
								<span class="carzuri-composer-hint"><?php esc_html_e( 'Safe & encrypted communication on Carzuri.co.ke', 'carzuri-messaging' ); ?></span>
								<span id="carzuri-char-count" class="carzuri-char-count">0 / 3000</span>
							</div>
						</form>
					</div>

				</section>
			</div>
		</div>
		<?php
		$output = ob_get_clean();
		// CRITICAL LESSON: Strip line breaks to prevent wpautop corruption of nested HTML,
		// matching the defensive pattern used by every other shortcode-rendering plugin
		// on this site.
		return str_replace( array( "\r\n", "\n", "\r" ), '', $output );
	}

	/**
	 * Render login required card when guest visits.
	 *
	 * @return string HTML.
	 */
	public static function render_login_required() {
		wp_enqueue_style( 'carzuri-messaging-css' );

		$login_url = wp_login_url( get_permalink() );
		ob_start();
		?>
		<div class="carzuri-msg-container carzuri-auth-notice-card">
			<div class="carzuri-auth-card-inner">
				<div class="carzuri-auth-icon-wrap">
					<svg class="carzuri-auth-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
						<path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
					</svg>
				</div>
				<h3 class="carzuri-auth-title"><?php esc_html_e( 'Login Required to Access Messages', 'carzuri-messaging' ); ?></h3>
				<p class="carzuri-auth-text"><?php esc_html_e( 'Please sign in to your Carzuri buyer or dealer account to view and reply to your vehicle inquiries.', 'carzuri-messaging' ); ?></p>
				<div class="carzuri-auth-actions">
					<a href="<?php echo esc_url( $login_url ); ?>" class="carzuri-btn-primary">
						<?php esc_html_e( 'Log In to Carzuri', 'carzuri-messaging' ); ?>
					</a>
				</div>
			</div>
		</div>
		<?php
		$output = ob_get_clean();
		// CRITICAL LESSON: Strip line breaks to prevent wpautop corruption.
		return str_replace( array( "\r\n", "\n", "\r" ), '', $output );
	}

	/**
	 * Optional button shortcode: [carzuri_message_dealer_button dealer_id="123" vehicle_id="456"]
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string HTML button.
	 */
	public static function render_contact_dealer_button_shortcode( $atts = array() ) {
		wp_enqueue_style( 'carzuri-messaging-css' );

		$atts = shortcode_atts(
			array(
				'dealer_id'  => 0,
				'vehicle_id' => 0,
				'label'      => __( 'Message Dealer', 'carzuri-messaging' ),
				'class'      => '',
			),
			$atts,
			'carzuri_message_dealer_button'
		);

		$dealer_id  = absint( $atts['dealer_id'] );
		$vehicle_id = absint( $atts['vehicle_id'] );
		$label      = sanitize_text_field( $atts['label'] );

		if ( ! $dealer_id ) {
			return '';
		}

		$messages_page = home_url( '/my-messages/' );
		$url = add_query_arg(
			array(
				'dealer_id'  => $dealer_id,
				'vehicle_id' => $vehicle_id,
			),
			$messages_page
		);

		return sprintf(
			'<a href="%s" class="carzuri-btn-message-dealer %s" data-dealer-id="%d" data-vehicle-id="%d">' .
				'<svg class="carzuri-btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>' .
				'<span>%s</span>' .
			'</a>',
			esc_url( $url ),
			esc_attr( $atts['class'] ),
			$dealer_id,
			$vehicle_id,
			esc_html( $label )
		);
	}
}
