<?php
/**
 * REST API Controller for Carzuri Messaging.
 *
 * @package Carzuri_Messaging
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Messaging_REST {

	/**
	 * REST namespace.
	 *
	 * @var string
	 */
	const NAMESPACE = 'carzuri/v1';

	/**
	 * Register all REST API routes under carzuri/v1/.
	 */
	public static function register_routes() {
		// Start or get a conversation (Buyers & Logged-in users).
		register_rest_route(
			self::NAMESPACE,
			'/conversations/start',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'start_conversation' ),
				'permission_callback' => array( __CLASS__, 'check_logged_in_permission' ),
				'args'                => array(
					'dealer_id'  => array(
						'required'          => true,
						'type'              => 'integer',
						'validate_callback' => function( $param ) {
							return is_numeric( $param ) && (int) $param > 0;
						},
						'sanitize_callback' => 'absint',
					),
					'vehicle_id' => array(
						'required'          => false,
						'type'              => 'integer',
						'default'           => 0,
						'sanitize_callback' => 'absint',
					),
					'initial_message' => array(
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_textarea_field',
					),
				),
			)
		);

		// Get all conversations for the current user.
		register_rest_route(
			self::NAMESPACE,
			'/conversations',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_conversations' ),
				'permission_callback' => array( __CLASS__, 'check_logged_in_permission' ),
			)
		);

		// Get all messages in a specific conversation.
		register_rest_route(
			self::NAMESPACE,
			'/conversations/(?P<id>\d+)/messages',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_messages' ),
				'permission_callback' => array( __CLASS__, 'check_logged_in_permission' ),
				'args'                => array(
					'id' => array(
						'validate_callback' => function( $param ) {
							return is_numeric( $param ) && (int) $param > 0;
						},
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// Post a new message into a conversation.
		register_rest_route(
			self::NAMESPACE,
			'/conversations/(?P<id>\d+)/messages',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'send_message' ),
				'permission_callback' => array( __CLASS__, 'check_logged_in_permission' ),
				'args'                => array(
					'id'           => array(
						'validate_callback' => function( $param ) {
							return is_numeric( $param ) && (int) $param > 0;
						},
						'sanitize_callback' => 'absint',
					),
					'message_text' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_textarea_field',
					),
				),
			)
		);

		// Mark all messages in a conversation as read for current user.
		register_rest_route(
			self::NAMESPACE,
			'/conversations/(?P<id>\d+)/mark-read',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'mark_read' ),
				'permission_callback' => array( __CLASS__, 'check_logged_in_permission' ),
				'args'                => array(
					'id' => array(
						'validate_callback' => function( $param ) {
							return is_numeric( $param ) && (int) $param > 0;
						},
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	/**
	 * Permission check: Logged-in user.
	 *
	 * @return bool|WP_Error
	 */
	public static function check_logged_in_permission() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'rest_not_logged_in',
				__( 'You must be logged in to access Carzuri Messaging.', 'carzuri-messaging' ),
				array( 'status' => 401 )
			);
		}
		return true;
	}

	/**
	 * Verify that the current user is a valid participant (buyer or dealer) in the conversation.
	 *
	 * @param int $conversation_id Conversation ID.
	 * @param int $current_user_id Current user ID.
	 * @return object|WP_Error Conversation row or error.
	 */
	private static function get_authorized_conversation( $conversation_id, $current_user_id ) {
		global $wpdb;

		$table_conversations = $wpdb->prefix . 'carzuri_conversations';

		$conversation = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table_conversations} WHERE id = %d",
				$conversation_id
			)
		);

		if ( ! $conversation ) {
			return new WP_Error(
				'rest_conversation_not_found',
				__( 'Conversation not found.', 'carzuri-messaging' ),
				array( 'status' => 404 )
			);
		}

		$is_buyer = ( (int) $conversation->buyer_id === (int) $current_user_id );
		$is_dealer = ( (int) $conversation->dealer_id === (int) $current_user_id );
		$is_admin  = current_user_can( 'manage_options' );

		if ( ! $is_buyer && ! $is_dealer && ! $is_admin ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'You do not have permission to access this conversation.', 'carzuri-messaging' ),
				array( 'status' => 403 )
			);
		}

		return $conversation;
	}

	/**
	 * POST /conversations/start
	 *
	 * Accepts dealer_id and optional vehicle_id (default 0).
	 * Finds existing or inserts a new row.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function start_conversation( $request ) {
		global $wpdb;

		$current_user_id = get_current_user_id();
		$dealer_id       = (int) $request->get_param( 'dealer_id' );
		$vehicle_id      = (int) $request->get_param( 'vehicle_id' );
		$initial_message = trim( (string) $request->get_param( 'initial_message' ) );

		if ( $dealer_id === $current_user_id ) {
			return new WP_Error(
				'rest_invalid_participant',
				__( 'You cannot start a conversation with yourself.', 'carzuri-messaging' ),
				array( 'status' => 400 )
			);
		}

		// Verify target dealer user exists AND genuinely holds the carzuri_dealer role,
		// so this endpoint can't be used to start a "conversation" between two buyers.
		$dealer_user = get_userdata( $dealer_id );
		if ( ! $dealer_user || ! in_array( 'carzuri_dealer', (array) $dealer_user->roles, true ) ) {
			return new WP_Error(
				'rest_user_not_found',
				__( 'Dealer not found.', 'carzuri-messaging' ),
				array( 'status' => 404 )
			);
		}

		$table_conversations = $wpdb->prefix . 'carzuri_conversations';
		$table_messages      = $wpdb->prefix . 'carzuri_messages';

		// Check for existing conversation with unique key (buyer_id, dealer_id, vehicle_id).
		$existing = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table_conversations} WHERE buyer_id = %d AND dealer_id = %d AND vehicle_id = %d",
				$current_user_id,
				$dealer_id,
				$vehicle_id
			)
		);

		$now             = current_time( 'mysql' );
		$conversation_id = 0;
		$is_new          = false;

		if ( $existing ) {
			$conversation_id = (int) $existing->id;
		} else {
			$inserted = $wpdb->insert(
				$table_conversations,
				array(
					'vehicle_id'      => $vehicle_id,
					'buyer_id'        => $current_user_id,
					'dealer_id'       => $dealer_id,
					'created_at'      => $now,
					'last_message_at' => $now,
				),
				array( '%d', '%d', '%d', '%s', '%s' )
			);

			if ( false === $inserted ) {
				return new WP_Error(
					'rest_db_error',
					__( 'Failed to create conversation.', 'carzuri-messaging' ),
					array( 'status' => 500 )
				);
			}

			$conversation_id = (int) $wpdb->insert_id;
			$is_new          = true;
		}

		// If an initial message was provided, insert it immediately.
		if ( ! empty( $initial_message ) && $conversation_id > 0 ) {
			$wpdb->insert(
				$table_messages,
				array(
					'conversation_id' => $conversation_id,
					'sender_id'       => $current_user_id,
					'message_text'    => $initial_message,
					'is_read'         => 0,
					'created_at'      => $now,
				),
				array( '%d', '%d', '%s', '%d', '%s' )
			);

			$wpdb->update(
				$table_conversations,
				array( 'last_message_at' => $now ),
				array( 'id' => $conversation_id ),
				array( '%s' ),
				array( '%d' )
			);

			// Notify dealer about initial message.
			self::trigger_notification(
				$dealer_id,
				$current_user_id,
				$initial_message,
				$conversation_id,
				$vehicle_id
			);
		}

		return rest_ensure_response(
			array(
				'success'         => true,
				'conversation_id' => $conversation_id,
				'is_new'          => $is_new,
			)
		);
	}

	/**
	 * GET /conversations
	 *
	 * Returns all conversations where current user is buyer_id or dealer_id,
	 * ordered by last_message_at DESC.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public static function get_conversations( $request ) {
		global $wpdb;

		$current_user_id     = get_current_user_id();
		$table_conversations = $wpdb->prefix . 'carzuri_conversations';
		$table_messages      = $wpdb->prefix . 'carzuri_messages';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT c.*, 
					(SELECT COUNT(*) FROM {$table_messages} m WHERE m.conversation_id = c.id AND m.sender_id != %d AND m.is_read = 0) AS unread_count,
					(SELECT m2.message_text FROM {$table_messages} m2 WHERE m2.conversation_id = c.id ORDER BY m2.created_at DESC, m2.id DESC LIMIT 1) AS last_message_text,
					(SELECT m2.created_at FROM {$table_messages} m2 WHERE m2.conversation_id = c.id ORDER BY m2.created_at DESC, m2.id DESC LIMIT 1) AS last_message_time,
					(SELECT m2.sender_id FROM {$table_messages} m2 WHERE m2.conversation_id = c.id ORDER BY m2.created_at DESC, m2.id DESC LIMIT 1) AS last_message_sender_id
				FROM {$table_conversations} c
				WHERE c.buyer_id = %d OR c.dealer_id = %d
				ORDER BY c.last_message_at DESC, c.id DESC",
				$current_user_id,
				$current_user_id,
				$current_user_id
			)
		);

		$conversations = array();

		foreach ( $rows as $row ) {
			$is_current_user_buyer = ( (int) $row->buyer_id === $current_user_id );
			$other_user_id         = $is_current_user_buyer ? (int) $row->dealer_id : (int) $row->buyer_id;
			$other_user            = get_userdata( $other_user_id );

			$other_display_name = $other_user ? $other_user->display_name : __( 'Carzuri User', 'carzuri-messaging' );
			$other_roles        = $other_user ? (array) $other_user->roles : array();
			$other_role_label   = in_array( 'carzuri_dealer', $other_roles, true ) ? __( 'Verified Dealer', 'carzuri-messaging' ) : __( 'Buyer', 'carzuri-messaging' );

			// Vehicle details if attached.
			$vehicle_data = null;
			$vehicle_id   = (int) $row->vehicle_id;

			if ( $vehicle_id > 0 ) {
				$post = get_post( $vehicle_id );
				if ( $post && 'trash' !== $post->post_status ) {
					$thumb_url = get_the_post_thumbnail_url( $vehicle_id, 'medium' );
					$vehicle_data = array(
						'id'        => $vehicle_id,
						'title'     => get_the_title( $vehicle_id ),
						'permalink' => get_permalink( $vehicle_id ),
						'thumbnail' => $thumb_url ? $thumb_url : '',
					);
				}
			}

			$conversations[] = array(
				'id'                  => (int) $row->id,
				'vehicle_id'          => $vehicle_id,
				'buyer_id'            => (int) $row->buyer_id,
				'dealer_id'           => (int) $row->dealer_id,
				'created_at'          => $row->created_at,
				'last_message_at'     => $row->last_message_at,
				'unread_count'        => (int) $row->unread_count,
				'other_user'          => array(
					'id'           => $other_user_id,
					'name'         => $other_display_name,
					'role'         => ! empty( $other_roles ) ? reset( $other_roles ) : 'user',
					'role_label'   => $other_role_label,
					'avatar_url'   => get_avatar_url( $other_user_id, array( 'size' => 80 ) ),
					'is_dealer'    => in_array( 'carzuri_dealer', $other_roles, true ),
				),
				'vehicle'             => $vehicle_data,
				'last_message'        => array(
					'text'       => $row->last_message_text ? wp_trim_words( $row->last_message_text, 15, '...' ) : __( 'No messages yet', 'carzuri-messaging' ),
					'raw_text'   => $row->last_message_text ? $row->last_message_text : '',
					'created_at' => $row->last_message_time ? $row->last_message_time : $row->last_message_at,
					'sender_id'  => (int) $row->last_message_sender_id,
					'is_mine'    => ( (int) $row->last_message_sender_id === $current_user_id ),
				),
			);
		}

		return rest_ensure_response(
			array(
				'success'       => true,
				'conversations' => $conversations,
			)
		);
	}

	/**
	 * GET /conversations/{id}/messages
	 *
	 * Returns all messages in that conversation, ordered oldest to newest.
	 * Must verify server-side ownership.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function get_messages( $request ) {
		global $wpdb;

		$current_user_id = get_current_user_id();
		$conv_id         = (int) $request->get_param( 'id' );

		$conversation = self::get_authorized_conversation( $conv_id, $current_user_id );
		if ( is_wp_error( $conversation ) ) {
			return $conversation;
		}

		$table_messages = $wpdb->prefix . 'carzuri_messages';

		$raw_messages = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table_messages} WHERE conversation_id = %d ORDER BY created_at ASC, id ASC",
				$conv_id
			)
		);

		$messages = array();
		foreach ( $raw_messages as $m ) {
			$is_mine     = ( (int) $m->sender_id === $current_user_id );
			$sender_user = get_userdata( (int) $m->sender_id );

			$messages[] = array(
				'id'              => (int) $m->id,
				'conversation_id' => (int) $m->conversation_id,
				'sender_id'       => (int) $m->sender_id,
				'sender_name'     => $sender_user ? $sender_user->display_name : __( 'Carzuri User', 'carzuri-messaging' ),
				'message_text'    => $m->message_text,
				'is_read'         => (int) $m->is_read === 1,
				'created_at'      => $m->created_at,
				'is_mine'         => $is_mine,
			);
		}

		// Other party details.
		$is_buyer      = ( (int) $conversation->buyer_id === $current_user_id );
		$other_user_id = $is_buyer ? (int) $conversation->dealer_id : (int) $conversation->buyer_id;
		$other_user    = get_userdata( $other_user_id );

		$other_party = array(
			'id'         => $other_user_id,
			'name'       => $other_user ? $other_user->display_name : __( 'Carzuri User', 'carzuri-messaging' ),
			'role_label' => ( $other_user && in_array( 'carzuri_dealer', (array) $other_user->roles, true ) ) ? __( 'Verified Dealer', 'carzuri-messaging' ) : __( 'Buyer', 'carzuri-messaging' ),
			'avatar_url' => get_avatar_url( $other_user_id, array( 'size' => 80 ) ),
			'is_dealer'  => ( $other_user && in_array( 'carzuri_dealer', (array) $other_user->roles, true ) ),
		);

		// Vehicle details.
		$vehicle_data = null;
		$vehicle_id   = (int) $conversation->vehicle_id;
		if ( $vehicle_id > 0 ) {
			$post = get_post( $vehicle_id );
			if ( $post && 'trash' !== $post->post_status ) {
				$vehicle_data = array(
					'id'        => $vehicle_id,
					'title'     => get_the_title( $vehicle_id ),
					'permalink' => get_permalink( $vehicle_id ),
					'thumbnail' => get_the_post_thumbnail_url( $vehicle_id, 'medium' ) ?: '',
				);
			}
		}

		return rest_ensure_response(
			array(
				'success'         => true,
				'conversation_id' => $conv_id,
				'conversation'    => array(
					'id'              => (int) $conversation->id,
					'vehicle_id'      => $vehicle_id,
					'buyer_id'        => (int) $conversation->buyer_id,
					'dealer_id'       => (int) $conversation->dealer_id,
					'created_at'      => $conversation->created_at,
					'last_message_at' => $conversation->last_message_at,
					'other_party'     => $other_party,
					'vehicle'         => $vehicle_data,
				),
				'messages'        => $messages,
			)
		);
	}

	/**
	 * POST /conversations/{id}/messages
	 *
	 * Accepts message_text. Inserts message, updates conversation last_message_at,
	 * and calls carzuri_create_notification() to notify the other party.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function send_message( $request ) {
		global $wpdb;

		$current_user_id = get_current_user_id();
		$conv_id         = (int) $request->get_param( 'id' );
		$message_text    = trim( (string) $request->get_param( 'message_text' ) );

		if ( empty( $message_text ) ) {
			return new WP_Error(
				'rest_empty_message',
				__( 'Message cannot be empty.', 'carzuri-messaging' ),
				array( 'status' => 400 )
			);
		}

		// Server-side ownership verification.
		$conversation = self::get_authorized_conversation( $conv_id, $current_user_id );
		if ( is_wp_error( $conversation ) ) {
			return $conversation;
		}

		$table_conversations = $wpdb->prefix . 'carzuri_conversations';
		$table_messages      = $wpdb->prefix . 'carzuri_messages';
		$now                 = current_time( 'mysql' );

		// Insert message row.
		$inserted = $wpdb->insert(
			$table_messages,
			array(
				'conversation_id' => $conv_id,
				'sender_id'       => $current_user_id,
				'message_text'    => $message_text,
				'is_read'         => 0,
				'created_at'      => $now,
			),
			array( '%d', '%d', '%s', '%d', '%s' )
		);

		if ( false === $inserted ) {
			return new WP_Error(
				'rest_insert_failed',
				__( 'Could not send message. Please try again.', 'carzuri-messaging' ),
				array( 'status' => 500 )
			);
		}

		$message_id = (int) $wpdb->insert_id;

		// Update conversation last_message_at.
		$wpdb->update(
			$table_conversations,
			array( 'last_message_at' => $now ),
			array( 'id' => $conv_id ),
			array( '%s' ),
			array( '%d' )
		);

		// Determine recipient.
		$recipient_id = ( (int) $conversation->buyer_id === $current_user_id )
			? (int) $conversation->dealer_id
			: (int) $conversation->buyer_id;

		// Trigger Carzuri notification helper.
		self::trigger_notification(
			$recipient_id,
			$current_user_id,
			$message_text,
			$conv_id,
			(int) $conversation->vehicle_id
		);

		$current_user = wp_get_current_user();

		return rest_ensure_response(
			array(
				'success' => true,
				'message' => array(
					'id'              => $message_id,
					'conversation_id' => $conv_id,
					'sender_id'       => $current_user_id,
					'sender_name'     => $current_user ? $current_user->display_name : __( 'Me', 'carzuri-messaging' ),
					'message_text'    => $message_text,
					'is_read'         => false,
					'created_at'      => $now,
					'is_mine'         => true,
				),
			)
		);
	}

	/**
	 * POST /conversations/{id}/mark-read
	 *
	 * Marks all messages in conversation not sent by current user as read.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function mark_read( $request ) {
		global $wpdb;

		$current_user_id = get_current_user_id();
		$conv_id         = (int) $request->get_param( 'id' );

		// Server-side ownership verification.
		$conversation = self::get_authorized_conversation( $conv_id, $current_user_id );
		if ( is_wp_error( $conversation ) ) {
			return $conversation;
		}

		$table_messages = $wpdb->prefix . 'carzuri_messages';

		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table_messages} SET is_read = 1 WHERE conversation_id = %d AND sender_id != %d AND is_read = 0",
				$conv_id,
				$current_user_id
			)
		);

		return rest_ensure_response(
			array(
				'success' => true,
				'updated' => (int) $updated,
			)
		);
	}

	/**
	 * Helper to trigger Carzuri notification.
	 *
	 * @param int    $recipient_id    User ID receiving the notification.
	 * @param int    $sender_id       User ID sending the message.
	 * @param string $message_text    Body of the message.
	 * @param int    $conversation_id Conversation ID.
	 * @param int    $vehicle_id      Optional vehicle ID.
	 */
	private static function trigger_notification( $recipient_id, $sender_id, $message_text, $conversation_id, $vehicle_id = 0 ) {
		if ( ! function_exists( 'carzuri_create_notification' ) ) {
			return;
		}

		$sender_user   = get_userdata( $sender_id );
		$sender_name   = $sender_user ? $sender_user->display_name : __( 'Someone', 'carzuri-messaging' );
		$preview       = wp_trim_words( $message_text, 12, '...' );
		$title         = sprintf( __( 'New message from %s', 'carzuri-messaging' ), $sender_name );

		if ( $vehicle_id > 0 ) {
			$vehicle_title = get_the_title( $vehicle_id );
			if ( ! empty( $vehicle_title ) ) {
				$title = sprintf( __( 'New message about %s from %s', 'carzuri-messaging' ), $vehicle_title, $sender_name );
			}
		}

		// Construct link to messages page with conversation selected.
		$messages_page_url = home_url( '/my-messages/' );
		$link = add_query_arg( 'conversation_id', $conversation_id, $messages_page_url );

		/**
		 * Global helper signature:
		 * carzuri_create_notification( $user_id, $type, $title, $message, $link = '' )
		 * 4 required arguments minimum + optional link.
		 */
		carzuri_create_notification(
			$recipient_id,
			'message_received',
			$title,
			$preview,
			$link
		);
	}
}
