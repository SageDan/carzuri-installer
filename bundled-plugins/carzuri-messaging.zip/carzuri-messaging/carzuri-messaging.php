<?php
/**
 * Plugin Name:       Carzuri Messaging
 * Plugin URI:        https://carzuri.co.ke
 * Description:       Threaded buyer-dealer messaging system for Carzuri.co.ke Kenyan automotive marketplace.
 * Version:           1.0.0
 * Author:            Carzuri Engineering
 * Author URI:        https://carzuri.co.ke
 * Text Domain:       carzuri-messaging
 * Requires at least: 6.0
 * Requires PHP:      7.4
 *
 * @package Carzuri_Messaging
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'CARZURI_MESSAGING_VERSION', '1.0.0' );
define( 'CARZURI_MESSAGING_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_MESSAGING_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Include required class files.
 */
require_once CARZURI_MESSAGING_PLUGIN_DIR . 'includes/class-carzuri-messaging-rest.php';
require_once CARZURI_MESSAGING_PLUGIN_DIR . 'includes/class-carzuri-messaging-shortcode.php';

/**
 * Register REST API routes strictly on rest_api_init.
 *
 * CRITICAL SITE REQUIREMENT:
 * REST route registration MUST be hooked via add_action('rest_api_init', ...)
 * on its own, separate from any shortcode/asset registration on plugins_loaded or init.
 * Registering REST routes too early on this site has previously caused a fatal
 * Elementor conflict that took the whole site down.
 */
add_action( 'rest_api_init', array( 'Carzuri_Messaging_REST', 'register_routes' ) );

/**
 * Initialize shortcodes and frontend assets on init.
 */
add_action( 'init', array( 'Carzuri_Messaging_Shortcode', 'init' ) );
