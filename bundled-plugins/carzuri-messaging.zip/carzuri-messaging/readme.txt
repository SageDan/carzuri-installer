=== Carzuri Messaging ===
Contributors: carzuri
Tags: messaging, chat, automotive, marketplace, kenya, buyers, dealers
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Direct buyer and dealer threaded messaging system for Carzuri.co.ke Kenyan automotive marketplace.

== Description ==

Carzuri Messaging is a purpose-built WordPress plugin for Carzuri.co.ke that enables seamless, real-time threaded communications between logged-in buyers and verified automotive dealers.

Key Features:
* Fully responsive 2-panel interface via `[carzuri_my_messages]` shortcode.
* Dedicated REST API endpoints registered strictly under `carzuri/v1/` on `rest_api_init`.
* Integrated with Carzuri database tables (`{$wpdb->prefix}carzuri_conversations` and `{$wpdb->prefix}carzuri_messages`).
* Real-time notifications dispatched to recipients via `carzuri_create_notification()`.
* Vehicle context cards embedded inside message threads.
* 15-second background polling for new incoming messages without WebSockets.
* Mobile-first sliding view with fast back navigation down to 375px screens.
* Strict Kenyan automotive marketplace design language (Dark Navy `#0b192c` + Gold `#d4af37`).

== Installation ==

1. Upload the `carzuri-messaging.zip` file via WordPress Admin > Plugins > Add New > Upload Plugin.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Add the `[carzuri_my_messages]` shortcode to your designated Messages page (e.g. `/my-messages/`).

== Shortcodes ==

* `[carzuri_my_messages]` - Main chat interface for logged-in buyers and dealers.
* `[carzuri_message_dealer_button dealer_id="123" vehicle_id="456" label="Message Dealer"]` - Inquiry button for vehicle single templates.

== Changelog ==

= 1.0.0 =
* Initial release for Carzuri.co.ke.
