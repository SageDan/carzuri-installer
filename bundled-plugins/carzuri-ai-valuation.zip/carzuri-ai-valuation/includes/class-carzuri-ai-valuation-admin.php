<?php
if (!defined('ABSPATH')) {
    exit;
}

class Carzuri_AI_Valuation_Admin {

    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu_tab'), 20);
    }

    public function add_admin_menu_tab() {
        // Core already registers top-level "carzuri-settings" menu.
        // We add a sub-menu / tab "AI Valuation"
        add_submenu_page(
            'carzuri-settings',
            __('Carzuri AI Smart Valuation Log', 'carzuri-ai-valuation'),
            __('AI Valuation', 'carzuri-ai-valuation'),
            'manage_options',
            'carzuri-ai-valuation-settings',
            array($this, 'render_admin_page')
        );
    }

    public function render_admin_page() {
        $api_key = get_option('carzuri_gemini_api_key', '');
        $valuations = Carzuri_AI_Valuation_DB::get_valuations(50);
        ?>
        <div class="wrap carzuri-admin-wrap">
            <h1 class="wp-heading-inline">Carzuri AI Smart Valuation &mdash; Valuation Log</h1>
            <hr class="wp-header-end">

            <div class="notice notice-info">
                <p>
                    <strong>Carzuri AI Smart Valuation v1.0.0</strong> &mdash; Vehicle valuations are powered by Google Gemini AI.
                    The Gemini API key is configured centrally under <strong>Carzuri Settings &rarr; API Keys &amp; Secrets</strong> (option: <code>carzuri_gemini_api_key</code>).
                    <?php if (!empty($api_key)): ?>
                        <span style="color: #10B981; font-weight: 600; display: inline-block; margin-left: 8px;">
                            &#10003; Gemini Key Configured (••••••••<?php echo esc_html(substr($api_key, -4)); ?>)
                        </span>
                    <?php else: ?>
                        <span style="color: #EF4444; font-weight: 600; display: inline-block; margin-left: 8px;">
                            &#9888; No Gemini API key found in Carzuri Settings.
                        </span>
                    <?php endif; ?>
                </p>
            </div>

            <div style="margin-top: 20px;">
                <h3>Recent Valuation Database Entries (wp_carzuri_valuations)</h3>
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Vehicle</th>
                            <th>Year</th>
                            <th>Mileage</th>
                            <th>Condition</th>
                            <th>Est. Market Value</th>
                            <th>Trade-In Offer</th>
                            <th>Confidence</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($valuations)): ?>
                            <tr>
                                <td colspan="9">No valuations recorded yet.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($valuations as $val): ?>
                                <tr>
                                    <td>#<?php echo esc_html($val->id); ?></td>
                                    <td><strong><?php echo esc_html($val->make . ' ' . $val->model); ?></strong></td>
                                    <td><?php echo esc_html($val->year); ?></td>
                                    <td><?php echo esc_html(number_format($val->mileage)); ?> km</td>
                                    <td><span class="badge"><?php echo esc_html($val->condition); ?></span></td>
                                    <td><strong>KSh <?php echo esc_html(number_format($val->estimated_market_value)); ?></strong></td>
                                    <td style="color: #D97706;">KSh <?php echo esc_html(number_format($val->dealer_purchase_value)); ?></td>
                                    <td><?php echo esc_html($val->confidence_score); ?>%</td>
                                    <td><?php echo esc_html($val->created_at); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }
}