<?php
if (!defined('ABSPATH')) {
    exit;
}

class Carzuri_AI_Valuation_DB {

    public static function get_table_name() {
        global $wpdb;
        return $wpdb->prefix . 'carzuri_valuations';
    }

    public static function insert_valuation($data) {
        global $wpdb;
        $table_name = self::get_table_name();

        $inserted = $wpdb->insert(
            $table_name,
            array(
                'user_id'                => isset($data['user_id']) ? $data['user_id'] : null,
                'make'                   => sanitize_text_field($data['make']),
                'model'                  => sanitize_text_field($data['model']),
                'year'                   => intval($data['year']),
                'mileage'                => intval($data['mileage']),
                'condition'              => sanitize_text_field($data['condition']),
                'accident_history'       => sanitize_text_field($data['accident_history']),
                'service_history'        => sanitize_text_field($data['service_history']),
                'estimated_market_value' => intval($data['estimated_market_value']),
                'dealer_purchase_value'  => intval($data['dealer_purchase_value']),
                'private_sale_estimate'  => intval($data['private_sale_estimate']),
                'confidence_score'       => intval($data['confidence_score']),
                'estimated_time_to_sell' => sanitize_text_field($data['estimated_time_to_sell']),
                'raw_ai_response'        => $data['raw_ai_response'],
                'created_at'             => current_time('mysql')
            ),
            array(
                '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s',
                '%d', '%d', '%d', '%d', '%s', '%s', '%s'
            )
        );

        return $inserted ? $wpdb->insert_id : false;
    }

    public static function get_valuations($limit = 50) {
        global $wpdb;
        $table_name = self::get_table_name();
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT %d", $limit)
        );
    }

    public static function get_valuations_by_user($user_id, $limit = 50) {
        global $wpdb;
        $table_name = self::get_table_name();
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d ORDER BY created_at DESC LIMIT %d", intval($user_id), $limit)
        );
    }

    public static function delete_valuation($id) {
        global $wpdb;
        $table_name = self::get_table_name();
        return $wpdb->delete($table_name, array('id' => intval($id)), array('%d'));
    }
}