<?php
if (!defined('ABSPATH')) {
    exit;
}

class Carzuri_AI_Valuation_Shortcode {

    public function __construct() {
        add_shortcode('carzuri_ai_valuation', array($this, 'render_shortcode'));
    }

    public function render_shortcode($atts = array()) {
        $atts = shortcode_atts(array(
            'style' => 'default',
        ), $atts, 'carzuri_ai_valuation');

        // Enqueue styles and scripts using Carzuri Design System handles
        wp_enqueue_style('carzuri-design-system');
        wp_enqueue_style(
            'carzuri-ai-valuation-style',
            CARZURI_AI_VALUATION_URL . 'assets/css/carzuri-ai-valuation.css',
            array('carzuri-design-system'),
            CARZURI_AI_VALUATION_VERSION
        );

        wp_enqueue_script(
            'carzuri-ai-valuation-script',
            CARZURI_AI_VALUATION_URL . 'assets/js/carzuri-ai-valuation.js',
            array('jquery'),
            CARZURI_AI_VALUATION_VERSION,
            true
        );

        wp_localize_script('carzuri-ai-valuation-script', 'carzuriValuationVars', array(
            'rest_url' => esc_url_raw(rest_url('carzuri/v1/valuations')),
            'nonce'    => wp_create_nonce('wp_rest'),
        ));

        ob_start();
        ?>
        <div class="cz-valuation-wrapper" id="carzuri-valuation-app">
            <div class="cz-valuation-card">
                <div class="cz-valuation-header">
                    <div class="cz-badge">AI SMART VALUATION</div>
                    <h2 class="cz-valuation-title">Calculate Instant Vehicle Market Value</h2>
                    <p class="cz-valuation-subtitle">Get real-time market value estimates powered by Gemini AI, trade-in offers, and private sale metrics in seconds.</p>
                </div>

                <form id="cz-valuation-form" class="cz-valuation-form">
                    <div class="cz-form-grid">
                        <div class="cz-form-group">
                            <label for="cz_make">Vehicle Make <span class="required">*</span></label>
                            <input type="text" id="cz_make" name="make" placeholder="e.g. BMW, Toyota, Porsche" required>
                        </div>

                        <div class="cz-form-group">
                            <label for="cz_model">Vehicle Model <span class="required">*</span></label>
                            <input type="text" id="cz_model" name="model" placeholder="e.g. M3, RAV4, 911" required>
                        </div>

                        <div class="cz-form-group">
                            <label for="cz_year">Year <span class="required">*</span></label>
                            <input type="number" id="cz_year" name="year" min="1990" max="<?php echo date('Y') + 1; ?>" placeholder="2022" required>
                        </div>

                        <div class="cz-form-group">
                            <label for="cz_mileage">Current Mileage (KM) <span class="required">*</span></label>
                            <input type="number" id="cz_mileage" name="mileage" min="0" placeholder="25000" required>
                        </div>

                        <div class="cz-form-group">
                            <label for="cz_condition">Overall Condition <span class="required">*</span></label>
                            <select id="cz_condition" name="condition" required>
                                <option value="Excellent">Excellent &mdash; Like new, pristine interior/exterior</option>
                                <option value="Good" selected>Good &mdash; Clean, minor wear, fully operational</option>
                                <option value="Fair">Fair &mdash; Visible cosmetic wear, mechanically sound</option>
                                <option value="Poor">Poor &mdash; Needs mechanical or body repair</option>
                            </select>
                        </div>

                        <div class="cz-form-group">
                            <label for="cz_accident_history">Accident History</label>
                            <select id="cz_accident_history" name="accident_history">
                                <option value="None" selected>No Accidents Reported</option>
                                <option value="Minor Cosmetic">Minor Cosmetic Damage (Repaired)</option>
                                <option value="Moderate">Moderate Repair Record</option>
                                <option value="Major Structural">Major Structural Repair</option>
                            </select>
                        </div>

                        <div class="cz-form-group cz-full-width">
                            <label for="cz_service_history">Service & Maintenance Records</label>
                            <select id="cz_service_history" name="service_history">
                                <option value="Full Dealer Service" selected>Full Authorized Dealer Service History</option>
                                <option value="Partial History">Partial Service Records Available</option>
                                <option value="Independent Shop">Serviced at Independent Mechanics</option>
                                <option value="Self Maintained">Self Maintained / Minimal Records</option>
                            </select>
                        </div>
                    </div>

                    <div id="cz-valuation-error" class="cz-alert cz-alert-danger" style="display: none;"></div>

                    <div class="cz-form-actions">
                        <button type="submit" id="cz-submit-btn" class="cz-btn cz-btn-gold">
                            <span class="cz-btn-text">Generate AI Market Valuation</span>
                            <span class="cz-spinner" style="display: none;"></span>
                        </button>
                    </div>
                </form>

                <!-- Valuation Results View -->
                <div id="cz-valuation-results" class="cz-valuation-results" style="display: none;">
                    <div class="cz-result-headline-box">
                        <span class="cz-result-tag">ESTIMATED FAIR MARKET VALUE</span>
                        <div id="cz-res-market-value" class="cz-headline-price">KSh 0</div>
                        <div class="cz-confidence-badge">
                            <span id="cz-res-confidence">92%</span> AI Confidence Score
                        </div>
                    </div>

                    <div class="cz-breakdown-grid">
                        <div class="cz-breakdown-card cz-dealer-card">
                            <div class="cz-breakdown-label">DEALER TRADE-IN OFFER</div>
                            <div id="cz-res-dealer-value" class="cz-breakdown-price">KSh 0</div>
                            <div class="cz-breakdown-sub">Estimated instant dealer purchase price</div>
                        </div>

                        <div class="cz-breakdown-card">
                            <div class="cz-breakdown-label">PRIVATE SALE ESTIMATE</div>
                            <div id="cz-res-private-value" class="cz-breakdown-price">KSh 0</div>
                            <div class="cz-breakdown-sub">Estimated direct buyer list price</div>
                        </div>

                        <div class="cz-breakdown-card">
                            <div class="cz-breakdown-label">ESTIMATED TIME TO SELL</div>
                            <div id="cz-res-time-to-sell" class="cz-breakdown-price">--</div>
                            <div class="cz-breakdown-sub">Based on current market liquidity</div>
                        </div>
                    </div>

                    <div class="cz-analysis-box">
                        <h4>AI Market Insights & Analysis</h4>
                        <p id="cz-res-analysis-text">Evaluating vehicle market dynamics...</p>
                        <ul id="cz-res-key-factors" class="cz-factors-list"></ul>
                    </div>

                    <!-- Request Trade-In CTA re-using Finance Applications -->
                    <div class="cz-tradein-cta-box">
                        <div class="cz-tradein-info">
                            <h3>Ready to Upgrade Your Vehicle?</h3>
                            <p>Apply your estimated <strong><span id="cz-tradein-vehicle-name">Vehicle</span></strong> trade-in value of <strong><span id="cz-tradein-amount">KSh 0</span></strong> towards a new purchase using Carzuri Finance Applications.</p>
                        </div>
                        <a id="cz-tradein-link" href="/finance-application-form?trade_in=1" class="cz-btn cz-btn-navy">
                            Request Trade-In & Apply for Finance &rarr;
                        </a>
                    </div>

                    <div class="cz-results-reset">
                        <button type="button" id="cz-recalculate-btn" class="cz-btn-link">&larr; Calculate Another Vehicle</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
