<?php
if (!defined('ABSPATH')) {
    exit;
}

class Carzuri_AI_Valuation_REST {

    public static function register_routes() {
        register_rest_route('carzuri/v1', '/valuations', array(
            array(
                'methods'             => WP_REST_Server::CREATABLE, // POST
                'callback'            => array(__CLASS__, 'handle_valuation_submission'),
                'permission_callback' => '__return_true', // Public form access
                'args'                => array(
                    'make' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'model' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'year' => array(
                        'required'          => true,
                        'sanitize_callback' => 'absint',
                    ),
                    'mileage' => array(
                        'required'          => true,
                        'sanitize_callback' => 'absint',
                    ),
                    'condition' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'accident_history' => array(
                        'required'          => false,
                        'default'           => 'None',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'service_history' => array(
                        'required'          => false,
                        'default'           => 'Full Dealer Service',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            ),
            array(
                'methods'             => WP_REST_Server::READABLE, // GET
                'callback'            => array(__CLASS__, 'get_valuations_list'),
                'permission_callback' => array(__CLASS__, 'admin_permissions_check'),
            )
        ));

        register_rest_route('carzuri/v1', '/my-valuations', array(
            'methods'             => WP_REST_Server::READABLE, // GET
            'callback'            => array(__CLASS__, 'get_my_valuations'),
            'permission_callback' => array(__CLASS__, 'user_permissions_check'),
        ));
    }

    public static function admin_permissions_check() {
        return current_user_can('manage_options');
    }

    public static function user_permissions_check() {
        return is_user_logged_in();
    }

    public static function get_valuations_list() {
        $rows = Carzuri_AI_Valuation_DB::get_valuations(50);
        return rest_ensure_response(array('success' => true, 'valuations' => $rows));
    }

    public static function get_my_valuations() {
        $user_id = get_current_user_id();
        $rows = Carzuri_AI_Valuation_DB::get_valuations_by_user($user_id, 50);

        // Decode each row's raw_ai_response (the original AI JSON text saved
        // at submission time) to surface market_analysis and key_factors —
        // matching the same field names already used in the POST submission
        // response, so the front-end can render history items the same way
        // it renders a fresh valuation. Guard against empty/corrupted rows
        // so one bad record doesn't break the whole list.
        $data = array();
        foreach ($rows as $row) {
            $row_array = (array) $row;

            if (!empty($row->raw_ai_response)) {
                $decoded = json_decode($row->raw_ai_response, true);
                if (is_array($decoded)) {
                    if (isset($decoded['market_analysis'])) {
                        $row_array['market_analysis'] = $decoded['market_analysis'];
                    }
                    if (isset($decoded['key_factors'])) {
                        $row_array['key_factors'] = $decoded['key_factors'];
                    }
                }
            }

            // Never send the raw JSON text itself to the front-end — only
            // the decoded fields above.
            unset($row_array['raw_ai_response']);

            $data[] = $row_array;
        }

        return rest_ensure_response(array('success' => true, 'data' => $data));
    }

    public static function handle_valuation_submission($request) {
        $params = $request->get_params();

        $make             = $params['make'];
        $model            = $params['model'];
        $year             = intval($params['year']);
        $mileage          = intval($params['mileage']);
        $condition        = $params['condition'];
        $accident_history = !empty($params['accident_history']) ? $params['accident_history'] : 'None';
        $service_history  = !empty($params['service_history']) ? $params['service_history'] : 'Full Dealer Service';

        // Retrieve stored API Key from WordPress Core Settings API option
        $api_key = get_option('carzuri_gemini_api_key', '');

        if (empty($api_key)) {
            error_log('[Carzuri AI Valuation] Blocked valuation request: no Gemini API key configured in Carzuri Settings.');
            return new WP_Error(
                'valuation_unavailable',
                __('Sorry, vehicle valuations aren\'t available right now. Please try again shortly.', 'carzuri-ai-valuation'),
                array('status' => 503)
            );
        }

        // Construct Gemini REST API prompt asking for strict structured JSON
        $prompt = "You are an expert automotive appraiser for Carzuri Valuation Services.
Evaluate the following pre-owned vehicle and output an accurate market valuation breakdown based on current vehicle valuation algorithms, depreciation trends, and dealer wholesale margins.

Vehicle Specs:
- Make: {$make}
- Model: {$model}
- Year: {$year}
- Mileage: {$mileage} miles
- Condition: {$condition}
- Accident History: {$accident_history}
- Service History: {$service_history}

Currency: KES (Kenyan Shillings / KSh)

Return a STRICT JSON object with these EXACT keys:
{
  \"estimated_market_value\": integer,
  \"dealer_purchase_value\": integer,
  \"private_sale_estimate\": integer,
  \"confidence_score\": integer (70-99),
  \"estimated_time_to_sell\": string (e.g. \"10-18 days\"),
  \"market_analysis\": string,
  \"key_factors\": [string]
}";

        // Use the admin-selected Gemini model version (Carzuri Settings ->
        // API Keys & Secrets). This lets the model be switched instantly
        // (e.g. to an older/lighter version during high-demand outages on
        // the latest model) without needing a code change or deployment.
        $gemini_model = get_option('carzuri_gemini_model', 'gemini-3.6-flash');
        if (empty($gemini_model)) {
            $gemini_model = 'gemini-3.6-flash';
        }

        $endpoint_url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($gemini_model) . ':generateContent?key=' . urlencode($api_key);

        $body = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array('text' => $prompt)
                    )
                )
            ),
            'generationConfig' => array(
                'responseMimeType' => 'application/json',
                'temperature'      => 0.2
            )
        );

        $response = wp_remote_post($endpoint_url, array(
            'headers'     => array('Content-Type' => 'application/json'),
            'body'        => wp_json_encode($body),
            'timeout'     => 25,
        ));

        if (is_wp_error($response)) {
            error_log('[Carzuri AI Valuation] Gemini API connection failed (model: ' . $gemini_model . '): ' . $response->get_error_message());
            return new WP_Error(
                'valuation_unavailable',
                __('Sorry, we couldn\'t complete your vehicle valuation right now. Please try again in a few minutes.', 'carzuri-ai-valuation'),
                array('status' => 503)
            );
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw_response = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            error_log('[Carzuri AI Valuation] Gemini API returned HTTP ' . $code . ' (model: ' . $gemini_model . '). Response body: ' . $raw_response);
            return new WP_Error(
                'valuation_unavailable',
                __('Sorry, we couldn\'t complete your vehicle valuation right now. Please try again in a few minutes.', 'carzuri-ai-valuation'),
                array('status' => 503)
            );
        }

        $decoded_api = json_decode($raw_response, true);
        $candidate_text = isset($decoded_api['candidates'][0]['content']['parts'][0]['text']) 
            ? $decoded_api['candidates'][0]['content']['parts'][0]['text'] 
            : '';

        if (empty($candidate_text)) {
            error_log('[Carzuri AI Valuation] Gemini API (model: ' . $gemini_model . ') returned an empty output. Raw response: ' . $raw_response);
            return new WP_Error(
                'valuation_unavailable',
                __('Sorry, we couldn\'t complete your vehicle valuation right now. Please try again in a few minutes.', 'carzuri-ai-valuation'),
                array('status' => 503)
            );
        }

        // Parse AI generated JSON payload
        $parsed_valuation = json_decode($candidate_text, true);

        if (!$parsed_valuation || !isset($parsed_valuation['estimated_market_value']) || !isset($parsed_valuation['dealer_purchase_value'])) {
            // CRITICAL: If JSON is invalid, DO NOT write a malformed row to DB
            error_log('[Carzuri AI Valuation] Failed to parse valid JSON from Gemini (model: ' . $gemini_model . '). Raw AI text: ' . $candidate_text);
            return new WP_Error(
                'valuation_unavailable',
                __('Sorry, we couldn\'t complete your vehicle valuation right now. Please try again in a few minutes.', 'carzuri-ai-valuation'),
                array('status' => 503)
            );
        }

        // Set user_id if logged in, null for guests (same pattern as Finance Applications)
        $user_id = is_user_logged_in() ? get_current_user_id() : null;

        // Prepare row for wp_carzuri_valuations table
        $db_data = array(
            'user_id'                => $user_id,
            'make'                   => $make,
            'model'                  => $model,
            'year'                   => $year,
            'mileage'                => $mileage,
            'condition'              => $condition,
            'accident_history'       => $accident_history,
            'service_history'        => $service_history,
            'estimated_market_value' => intval($parsed_valuation['estimated_market_value']),
            'dealer_purchase_value'  => intval($parsed_valuation['dealer_purchase_value']),
            'private_sale_estimate'  => intval($parsed_valuation['private_sale_estimate']),
            'confidence_score'       => intval($parsed_valuation['confidence_score']),
            'estimated_time_to_sell' => sanitize_text_field($parsed_valuation['estimated_time_to_sell']),
            'raw_ai_response'        => $candidate_text,
        );

        $inserted_id = Carzuri_AI_Valuation_DB::insert_valuation($db_data);

        if (!$inserted_id) {
            error_log('[Carzuri AI Valuation] Failed to insert valuation row into database for a successfully parsed Gemini response.');
            return new WP_Error(
                'valuation_unavailable',
                __('Sorry, we couldn\'t save your vehicle valuation right now. Please try again in a few minutes.', 'carzuri-ai-valuation'),
                array('status' => 503)
            );
        }

        return rest_ensure_response(array(
            'success'                => true,
            'id'                     => $inserted_id,
            'user_id'                => $user_id,
            'make'                   => $make,
            'model'                  => $model,
            'year'                   => $year,
            'mileage'                => $mileage,
            'condition'              => $condition,
            'accident_history'       => $accident_history,
            'service_history'        => $service_history,
            'estimated_market_value' => $db_data['estimated_market_value'],
            'dealer_purchase_value'  => $db_data['dealer_purchase_value'],
            'private_sale_estimate'  => $db_data['private_sale_estimate'],
            'confidence_score'       => $db_data['confidence_score'],
            'estimated_time_to_sell' => $db_data['estimated_time_to_sell'],
            'market_analysis'        => isset($parsed_valuation['market_analysis']) ? $parsed_valuation['market_analysis'] : '',
            'key_factors'            => isset($parsed_valuation['key_factors']) ? $parsed_valuation['key_factors'] : array(),
            'raw_ai_response'        => $candidate_text
        ));
    }
}