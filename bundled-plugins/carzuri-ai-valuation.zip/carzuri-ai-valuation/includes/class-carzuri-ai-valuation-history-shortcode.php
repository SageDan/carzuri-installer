<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Renders [carzuri_valuation_history] — a logged-in buyer's own past
 * AI valuations, pulled from the existing GET /carzuri/v1/my-valuations
 * endpoint (already built, already permission-checked, previously unused
 * by any front-end code).
 */
class Carzuri_AI_Valuation_History_Shortcode {

    public function __construct() {
        add_shortcode('carzuri_valuation_history', array($this, 'render_shortcode'));
    }

    /**
     * Look up a published page's permalink by the shortcode it contains.
     * Returns null if no matching page is found, so callers can fall
     * back gracefully instead of linking to a broken URL.
     */
    private function find_page_url_by_shortcode($shortcode_tag) {
        $pages = get_posts(array(
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ));

        foreach ($pages as $page_id) {
            $content = get_post_field('post_content', $page_id);
            if ($content && has_shortcode($content, $shortcode_tag)) {
                return get_permalink($page_id);
            }
        }

        return null;
    }

    public function render_shortcode($atts = array()) {
        wp_enqueue_style('carzuri-design-system');
        wp_enqueue_style(
            'carzuri-ai-valuation-style',
            CARZURI_AI_VALUATION_URL . 'assets/css/carzuri-ai-valuation.css',
            array('carzuri-design-system'),
            CARZURI_AI_VALUATION_VERSION
        );

        // The "get another valuation" page is found dynamically by the
        // shortcode it actually contains — this tag is confirmed from
        // this plugin's own existing shortcode class, so no guessing
        // is involved here.
        $valuation_page_url = $this->find_page_url_by_shortcode('carzuri_ai_valuation');

        if (!is_user_logged_in()) {
            ob_start();
            // Confirmed against class-carzuri-buyer-login.php: the real
            // Buyer Login shortcode is 'carzuri_buyer_login', and that
            // plugin's own lost-password link confirms the real Buyer
            // Login page lives at a fixed URL: /buyer-login/. Try the
            // dynamic page-lookup first (in case that page ever moves),
            // falling back to the known real URL rather than a generic
            // WordPress default if the lookup doesn't find it.
            $login_url = $this->find_page_url_by_shortcode('carzuri_buyer_login');
            if (!$login_url) {
                $login_url = home_url('/buyer-login/');
            }
            ?>
            <div class="cz-valuation-wrapper">
                <div class="cz-valuation-card cz-history-login-prompt">
                    <div class="cz-valuation-header">
                        <div class="cz-badge">MY VALUATIONS</div>
                        <h2 class="cz-valuation-title">Please Log In</h2>
                        <p class="cz-valuation-subtitle">
                            Log in to your Carzuri account to view your past AI vehicle valuations.
                        </p>
                    </div>
                    <div class="cz-form-actions">
                        <a href="<?php echo esc_url($login_url); ?>" class="cz-btn cz-btn-gold">Log In</a>
                    </div>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }

        wp_enqueue_script(
            'carzuri-ai-valuation-history-script',
            CARZURI_AI_VALUATION_URL . 'assets/js/carzuri-ai-valuation-history.js',
            array('jquery'),
            CARZURI_AI_VALUATION_VERSION,
            true
        );

        wp_localize_script('carzuri-ai-valuation-history-script', 'carzuriValuationHistoryVars', array(
            'rest_url'          => esc_url_raw(rest_url('carzuri/v1/my-valuations')),
            'nonce'             => wp_create_nonce('wp_rest'),
            'valuation_page_url'=> $valuation_page_url ? esc_url($valuation_page_url) : '',
        ));

        ob_start();
        ?>
        <div class="cz-valuation-wrapper" id="carzuri-valuation-history-app">
            <div class="cz-valuation-card">
                <div class="cz-valuation-header">
                    <div class="cz-badge">MY VALUATIONS</div>
                    <h2 class="cz-valuation-title">Your Valuation History</h2>
                    <p class="cz-valuation-subtitle">All the AI market valuations you've previously requested, most recent first.</p>
                </div>

                <div id="cz-history-loading" style="text-align:center; padding: 20px 0; color: var(--carzuri-gray-text, #64748B);">
                    Loading your valuation history...
                </div>

                <div id="cz-history-error" class="cz-alert cz-alert-danger" style="display:none;"></div>

                <div id="cz-history-empty" class="cz-history-empty-state" style="display:none;">
                    <p>You haven't requested any vehicle valuations yet.</p>
                    <a href="#" id="cz-history-empty-cta" class="cz-btn cz-btn-gold">Get Your First Valuation</a>
                </div>

                <div id="cz-history-grid" class="cz-history-grid"></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
