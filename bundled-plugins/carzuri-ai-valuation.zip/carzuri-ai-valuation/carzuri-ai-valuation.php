<?php
/**
 * Plugin Name: Carzuri AI Smart Valuation
 * Plugin URI:  https://carzuri.com/plugins/ai-smart-valuation
 * Description: AI-powered vehicle valuation tool using Google Gemini API for Carzuri Core ecosystem.
 * Version:     1.1.1
 * Author:      Carzuri Suite
 * Author URI:  https://carzuri.com
 * License:     GPLv2 or later
 * Text Domain: carzuri-ai-valuation
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('CARZURI_AI_VALUATION_VERSION', '1.1.1');
define('CARZURI_AI_VALUATION_PATH', plugin_dir_path(__FILE__));
define('CARZURI_AI_VALUATION_URL', plugin_dir_url(__FILE__));

// Load required class files
require_once CARZURI_AI_VALUATION_PATH . 'includes/class-carzuri-ai-valuation-db.php';
require_once CARZURI_AI_VALUATION_PATH . 'includes/class-carzuri-ai-valuation-admin.php';
require_once CARZURI_AI_VALUATION_PATH . 'includes/class-carzuri-ai-valuation-rest.php';
require_once CARZURI_AI_VALUATION_PATH . 'includes/class-carzuri-ai-valuation-shortcode.php';
require_once CARZURI_AI_VALUATION_PATH . 'includes/class-carzuri-ai-valuation-history-shortcode.php';

/**
 * Main Plugin Initialization Class
 */
class Carzuri_AI_Valuation {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Initialize modules on plugins_loaded
        add_action('plugins_loaded', array($this, 'init_plugin'));

        // CRITICAL: REST routes registered via rest_api_init hook ONLY
        add_action('rest_api_init', array('Carzuri_AI_Valuation_REST', 'register_routes'));
    }

    public function init_plugin() {
        // Initialize Admin Settings tab
        if (is_admin()) {
            new Carzuri_AI_Valuation_Admin();
        }

        // Initialize Shortcode handler
        new Carzuri_AI_Valuation_Shortcode();

        // Initialize Valuation History shortcode handler
        new Carzuri_AI_Valuation_History_Shortcode();
    }
}

// Instantiate plugin
Carzuri_AI_Valuation::get_instance();
