/* Carzuri AI Smart Valuation - History Page JS */
(function($) {
  'use strict';

  $(document).ready(function() {
    var $loading = $('#cz-history-loading');
    var $errorBox = $('#cz-history-error');
    var $emptyState = $('#cz-history-empty');
    var $grid = $('#cz-history-grid');

    if (!$grid.length || typeof carzuriValuationHistoryVars === 'undefined') return;

    if (carzuriValuationHistoryVars.valuation_page_url) {
      $('#cz-history-empty-cta').attr('href', carzuriValuationHistoryVars.valuation_page_url);
    }

    $.ajax({
      url: carzuriValuationHistoryVars.rest_url,
      method: 'GET',
      beforeSend: function(xhr) {
        xhr.setRequestHeader('X-WP-Nonce', carzuriValuationHistoryVars.nonce);
      },
      success: function(response) {
        $loading.hide();

        if (!response || !response.success || !Array.isArray(response.data) || response.data.length === 0) {
          $emptyState.show();
          return;
        }

        response.data.forEach(function(item) {
          $grid.append(renderHistoryCard(item));
        });
      },
      error: function(xhr) {
        $loading.hide();
        var errText = 'Unable to load your valuation history. Please try again.';
        if (xhr.responseJSON && xhr.responseJSON.message) {
          errText = xhr.responseJSON.message;
        }
        $errorBox.text(errText).show();
      }
    });

    function formatCurrency(amount) {
      return 'KSh ' + Number(amount || 0).toLocaleString();
    }

    function escapeHtml(str) {
      return $('<div>').text(str == null ? '' : str).html();
    }

    function renderHistoryCard(item) {
      var vehicleName = escapeHtml(item.year) + ' ' + escapeHtml(item.make) + ' ' + escapeHtml(item.model);
      var createdDate = item.created_at ? escapeHtml(item.created_at) : '';

      var factorsHtml = '';
      if (item.key_factors && Array.isArray(item.key_factors) && item.key_factors.length) {
        factorsHtml = '<ul class="cz-factors-list">' +
          item.key_factors.map(function(f) { return '<li>' + escapeHtml(f) + '</li>'; }).join('') +
          '</ul>';
      }

      var analysisHtml = '';
      if (item.market_analysis) {
        analysisHtml = '<p>' + escapeHtml(item.market_analysis) + '</p>';
      }

      var analysisBox = '';
      if (analysisHtml || factorsHtml) {
        analysisBox = '<div class="cz-analysis-box">' +
          '<h4>AI Market Insights</h4>' +
          analysisHtml + factorsHtml +
          '</div>';
      }

      return $(
        '<div class="cz-history-card">' +
          '<div class="cz-history-card-header">' +
            '<h3>' + vehicleName + '</h3>' +
            '<span class="cz-history-date">' + createdDate + '</span>' +
          '</div>' +
          '<div class="cz-breakdown-grid">' +
            '<div class="cz-breakdown-card cz-dealer-card">' +
              '<div class="cz-breakdown-label">DEALER TRADE-IN OFFER</div>' +
              '<div class="cz-breakdown-price">' + formatCurrency(item.dealer_purchase_value) + '</div>' +
            '</div>' +
            '<div class="cz-breakdown-card">' +
              '<div class="cz-breakdown-label">PRIVATE SALE ESTIMATE</div>' +
              '<div class="cz-breakdown-price">' + formatCurrency(item.private_sale_estimate) + '</div>' +
            '</div>' +
            '<div class="cz-breakdown-card">' +
              '<div class="cz-breakdown-label">ESTIMATED MARKET VALUE</div>' +
              '<div class="cz-breakdown-price">' + formatCurrency(item.estimated_market_value) + '</div>' +
            '</div>' +
          '</div>' +
          '<div class="cz-history-meta">' +
            '<span>' + escapeHtml(item.mileage ? Number(item.mileage).toLocaleString() + ' km' : 'N/A') + '</span>' +
            '<span>' + escapeHtml(item.condition) + '</span>' +
            '<span>Accident: ' + escapeHtml(item.accident_history) + '</span>' +
            '<span>Service: ' + escapeHtml(item.service_history) + '</span>' +
            '<span>' + escapeHtml(item.confidence_score) + '% Confidence</span>' +
          '</div>' +
          analysisBox +
        '</div>'
      );
    }
  });

})(jQuery);
