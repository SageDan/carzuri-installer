/* Carzuri AI Smart Valuation External Enqueued JS */
(function($) {
  'use strict';

  $(document).ready(function() {
    var $form = $('#cz-valuation-form');
    var $submitBtn = $('#cz-submit-btn');
    var $errorBox = $('#cz-valuation-error');
    var $resultsBox = $('#cz-valuation-results');

    if (!$form.length) return;

    $form.on('submit', function(e) {
      e.preventDefault();

      $errorBox.hide().text('');
      $submitBtn.prop('disabled', true).find('.cz-btn-text').text('Analyzing Market Data...');

      var formData = {
        make: $('#cz_make').val(),
        model: $('#cz_model').val(),
        year: parseInt($('#cz_year').val(), 10),
        mileage: parseInt($('#cz_mileage').val(), 10),
        condition: $('#cz_condition').val(),
        accident_history: $('#cz_accident_history').val(),
        service_history: $('#cz_service_history').val()
      };

      $.ajax({
        url: carzuriValuationVars.rest_url,
        method: 'POST',
        beforeSend: function(xhr) {
          xhr.setRequestHeader('X-WP-Nonce', carzuriValuationVars.nonce);
        },
        contentType: 'application/json',
        data: JSON.stringify(formData),
        success: function(response) {
          $submitBtn.prop('disabled', false).find('.cz-btn-text').text('Generate AI Market Valuation');

          if (response && response.success) {
            $form.hide();
            
            // Populate results with Kenyan Shilling (KSh) formatting
            $('#cz-res-market-value').text('KSh ' + Number(response.estimated_market_value).toLocaleString());
            $('#cz-res-dealer-value').text('KSh ' + Number(response.dealer_purchase_value).toLocaleString());
            $('#cz-res-private-value').text('KSh ' + Number(response.private_sale_estimate).toLocaleString());
            $('#cz-res-confidence').text(response.confidence_score + '%');
            $('#cz-res-time-to-sell').text(response.estimated_time_to_sell || '10-20 days');

            if (response.market_analysis) {
              $('#cz-res-analysis-text').text(response.market_analysis);
            }

            var $factorsList = $('#cz-res-key-factors').empty();
            if (response.key_factors && response.key_factors.length) {
              response.key_factors.forEach(function(factor) {
                $factorsList.append('<li>' + factor + '</li>');
              });
            }

            // Populate Trade-In CTA
            var vehicleFull = response.year + ' ' + response.make + ' ' + response.model;
            $('#cz-tradein-vehicle-name').text(vehicleFull);
            $('#cz-tradein-amount').text('KSh ' + Number(response.dealer_purchase_value).toLocaleString());
            
            var tradeinUrl = '/finance-application-form?trade_in_make=' + encodeURIComponent(response.make) +
                             '&trade_in_model=' + encodeURIComponent(response.model) +
                             '&trade_in_year=' + response.year +
                             '&trade_in_value=' + response.dealer_purchase_value;
            $('#cz-tradein-link').attr('href', tradeinUrl);

            $resultsBox.fadeIn();
          } else {
            var errMsg = (response && response.message) ? response.message : 'Unable to complete vehicle valuation.';
            $errorBox.text(errMsg).show();
          }
        },
        error: function(xhr) {
          $submitBtn.prop('disabled', false).find('.cz-btn-text').text('Generate AI Market Valuation');
          var errText = 'An error occurred while calculating valuation.';
          if (xhr.responseJSON && xhr.responseJSON.message) {
            errText = xhr.responseJSON.message;
          }
          $errorBox.text(errText).show();
        }
      });
    });

    $('#cz-recalculate-btn').on('click', function() {
      $resultsBox.hide();
      $form.fadeIn();
    });
  });

})(jQuery);
