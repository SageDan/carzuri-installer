=== Carzuri AI Smart Valuation ===
Contributors: carzuri
Tags: valuation, vehicle valuation, gemini ai, trade-in, carzuri
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later

AI-powered vehicle valuation tool using Google Gemini API for the Carzuri ecosystem.

== Description ==

Carzuri AI Smart Valuation is a WordPress plugin that provides instant, data-backed pre-owned vehicle valuations powered by Google Gemini AI.

Features:
* Shortcode [carzuri_ai_valuation] for instant front-end valuation submission.
* REST API route POST carzuri/v1/valuations registered on rest_api_init.
* Stores parsed valuation records in Core's wp_carzuri_valuations database table.
* Secure Settings API integration for Gemini API key configuration under Carzuri Admin.
* Integrated "Request Trade-In" Call-to-Action leading directly into Finance Application Form.

== Installation ==

1. Upload `carzuri-ai-valuation` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to 'Carzuri' -> 'AI Valuation' tab in WordPress Admin.
4. Enter your Google Gemini API Key and save settings.
5. Embed shortcode `[carzuri_ai_valuation]` on any page or post.
