<?php
/**
 * Plugin Name: Carzuri Dealer Marketplace
 * Plugin URI: https://carzuri.com/dealer-marketplace
 * Description: Extends Carzuri Core with dealer registration, admin approvals, a front-end inventory and leads dashboard, and analytics.
 * Version: 1.1.2
 * Author: Carzuri Team
 * Author URI: https://carzuri.com
 * Text Domain: carzuri-dealer-marketplace
 * Domain Path: /languages
 * Requires PHP: 7.4
 * Requires at least: 5.8
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define Constants.
define( 'CARZURI_DEALER_VERSION', '1.1.2' );
define( 'CARZURI_DEALER_DIR', plugin_dir_path( __FILE__ ) );
define( 'CARZURI_DEALER_URL', plugin_dir_url( __FILE__ ) );

/**
 * Initialize Carzuri Dealer Marketplace after all Carzuri plugins have initialized.
 * We use priority 40 to ensure this runs after Core (default priority), Listings (20), and Favorites (30).
 */
add_action( 'init', 'carzuri_dealer_init_plugin', 40 );

function carzuri_dealer_init_plugin() {
	// CRITICAL LESSON: Check if Core is active by verifying the 'vehicle' custom post type.
	if ( ! post_type_exists( 'vehicle' ) ) {
		// If Core is not active, render admin notice and do not load the rest of the plugin.
		add_action( 'admin_notices', 'carzuri_dealer_missing_core_notice' );
		return;
	}

	// Load Includes.
	require_once CARZURI_DEALER_DIR . 'includes/class-assets.php';
	require_once CARZURI_DEALER_DIR . 'includes/class-dealer-registration.php';
	require_once CARZURI_DEALER_DIR . 'includes/class-admin-approvals.php';
	require_once CARZURI_DEALER_DIR . 'includes/class-shortcodes.php';
	require_once CARZURI_DEALER_DIR . 'includes/class-rest-extensions.php';

	// Instantiate the classes.
	Carzuri_Dealer_Assets::get_instance();
	Carzuri_Dealer_Registration::get_instance();
	Carzuri_Dealer_Admin_Approvals::get_instance();
	Carzuri_Dealer_Shortcodes::get_instance();
	Carzuri_Dealer_Rest_Extensions::get_instance();
}

/**
 * Render admin notice when Carzuri Core is missing.
 */
function carzuri_dealer_missing_core_notice() {
	?>
	<div class="notice notice-error is-dismissible">
		<p><?php esc_html_e( 'Carzuri Dealer Marketplace requires Carzuri Core to be installed and active.', 'carzuri-dealer-marketplace' ); ?></p>
	</div>
	<?php
}

/**
 * Hide WordPress admin toolbar for users with the carzuri_dealer role.
 */
add_action( 'init', 'carzuri_dealer_hide_admin_bar', 10 );
function carzuri_dealer_hide_admin_bar() {
	if ( is_user_logged_in() ) {
		$user = wp_get_current_user();
		if ( in_array( 'carzuri_dealer', $user->roles ) && ! in_array( 'administrator', $user->roles ) && ! in_array( 'carzuri_admin', $user->roles ) ) {
			show_admin_bar( false );
		}
	}
}

/**
 * Redirect dealers away from /wp-admin/ if they try to access it directly.
 */
add_action( 'admin_init', 'carzuri_dealer_restrict_admin_access' );
function carzuri_dealer_restrict_admin_access() {
	// Skip if AJAX or REST API request
	if ( wp_doing_ajax() ) {
		return;
	}
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return;
	}

	if ( is_user_logged_in() ) {
		$user = wp_get_current_user();
		if ( in_array( 'carzuri_dealer', $user->roles ) && ! in_array( 'administrator', $user->roles ) && ! in_array( 'carzuri_admin', $user->roles ) ) {
			// Find dashboard URL
			$dashboard_url = home_url( '/dealer-dashboard/' );
			global $wpdb;
			$page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_dealer_dashboard]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
			if ( $page_id ) {
				$dashboard_url = get_permalink( $page_id );
			}
			
			wp_safe_redirect( $dashboard_url );
			exit;
		}
	}
}
