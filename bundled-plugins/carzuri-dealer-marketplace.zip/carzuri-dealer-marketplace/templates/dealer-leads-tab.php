<?php
/**
 * Dealer Leads Tab Template
 *
 * @package Carzuri_Dealer_Marketplace
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
	<h2 style="font-size: 18px; font-weight: 700; margin-top: 0; margin-bottom: 20px; color: #111827;"><?php esc_html_e( 'Customer Inbound Leads', 'carzuri-dealer-marketplace' ); ?></h2>
	<?php if ( empty( $leads ) ) : ?>
		<div style="text-align: center; padding: 48px 24px; border: 2px dashed #e5e7eb; border-radius: 6px;">
			<p style="color: #6b7280; font-size: 15px; margin: 0;"><?php esc_html_e( 'No buyer inquiries received yet.', 'carzuri-dealer-marketplace' ); ?></p>
		</div>
	<?php else : ?>
		<!-- Mobile-safe scroll container: table scrolls independently instead of dragging the whole page sideways -->
		<div style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
		<table class="carzuri-table" style="min-width: 800px; width: 100%;">
			<thead>
				<tr>
					<th style="width: 140px;"><?php esc_html_e( 'Date Received', 'carzuri-dealer-marketplace' ); ?></th>
					<th style="width: 180px;"><?php esc_html_e( 'Buyer Contact', 'carzuri-dealer-marketplace' ); ?></th>
					<th><?php esc_html_e( 'Vehicle of Interest', 'carzuri-dealer-marketplace' ); ?></th>
					<th><?php esc_html_e( 'Message Details', 'carzuri-dealer-marketplace' ); ?></th>
					<th style="width: 120px;"><?php esc_html_e( 'Status Badge', 'carzuri-dealer-marketplace' ); ?></th>
					<th style="width: 150px;"><?php esc_html_e( 'Change Status', 'carzuri-dealer-marketplace' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $leads as $lead ) : ?>
					<?php
					$lead_id    = intval( $lead['id'] );
					$vehicle_id = intval( $lead['vehicle_id'] );
					$created_at = isset( $lead['created_at'] ) ? date( 'M d, Y', strtotime( $lead['created_at'] ) ) : 'Recently';
					$status     = isset( $lead['status'] ) ? sanitize_text_field( $lead['status'] ) : 'new';
					?>
					<tr>
						<td style="font-size: 13px; color: #6b7280;"><?php echo esc_html( $created_at ); ?></td>
						<td>
							<strong style="font-size: 14px; color: #111827;"><?php echo esc_html( $lead['buyer_name'] ); ?></strong><br>
							<span style="font-size: 12px; color: #4b5563;"><a href="mailto:<?php echo esc_attr( $lead['buyer_email'] ); ?>"><?php echo esc_html( $lead['buyer_email'] ); ?></a></span><br>
							<span style="font-size: 12px; color: #4b5563;"><?php echo esc_html( $lead['buyer_phone'] ); ?></span>
						</td>
						<td>
							<?php if ( $vehicle_id ) : ?>
								<a href="<?php echo esc_url( get_permalink( $vehicle_id ) ); ?>" target="_blank" style="font-weight: 500; text-decoration: none; color: #3b82f6;">
									<?php echo esc_html( get_the_title( $vehicle_id ) ); ?>
								</a>
							<?php else : ?>
								<em><?php esc_html_e( 'General inquiry', 'carzuri-dealer-marketplace' ); ?></em>
							<?php endif; ?>
						</td>
						<td style="font-size: 13px; color: #4b5563; line-height: 1.4;">
							<?php echo esc_html( $lead['message'] ); ?>
						</td>
						<td>
							<span id="carzuri-lead-badge-<?php echo esc_attr( $lead_id ); ?>" class="carzuri-badge <?php echo esc_attr( $status ); ?>">
								<?php echo esc_html( ucfirst( $status ) ); ?>
							</span>
						</td>
						<td>
							<select class="carzuri-form-control carzuri-lead-status-select" data-id="<?php echo esc_attr( $lead_id ); ?>" style="padding: 6px 8px; font-size: 12px; height: auto;">
								<option value="new" <?php selected( $status, 'new' ); ?>><?php esc_html_e( 'New', 'carzuri-dealer-marketplace' ); ?></option>
								<option value="contacted" <?php selected( $status, 'contacted' ); ?>><?php esc_html_e( 'Contacted', 'carzuri-dealer-marketplace' ); ?></option>
								<option value="converted" <?php selected( $status, 'converted' ); ?>><?php esc_html_e( 'Converted', 'carzuri-dealer-marketplace' ); ?></option>
								<option value="closed" <?php selected( $status, 'closed' ); ?>><?php esc_html_e( 'Closed', 'carzuri-dealer-marketplace' ); ?></option>
							</select>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		</div>
	<?php endif; ?>
</div>