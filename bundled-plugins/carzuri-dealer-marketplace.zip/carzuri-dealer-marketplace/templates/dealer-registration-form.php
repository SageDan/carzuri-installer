<?php
/**
 * Dealer Registration Form Template
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="carzuri-dealer-registration-container" style="max-width: 600px; margin: 40px auto; background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 36px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
	<h2 style="font-size: 24px; font-weight: 700; margin-top: 0; margin-bottom: 8px; color: #111827;">
		<?php esc_html_e( 'Register as a Carzuri Dealer', 'carzuri-dealer-marketplace' ); ?>
	</h2>
	<p style="color: #6b7280; font-size: 14px; margin-bottom: 28px; line-height: 1.5;">
		<?php esc_html_e( 'Join our partner network to manage listings, connect with local car buyers, and access leads performance tools.', 'carzuri-dealer-marketplace' ); ?>
	</p>

	<!-- Message Box -->
	<div id="carzuri-registration-message" class="carzuri-alert" style="display: none;"></div>

	<form id="carzuri-dealer-registration-form" method="post" novalidate>
		<div class="carzuri-form-group">
			<label for="dealer_business_name"><?php esc_html_e( 'Business / Dealership Name *', 'carzuri-dealer-marketplace' ); ?></label>
			<input type="text" id="dealer_business_name" name="business_name" class="carzuri-form-control" required placeholder="e.g. Prestige Motors Ltd">
		</div>

		<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
			<div class="carzuri-form-group">
				<label for="dealer_contact_name"><?php esc_html_e( 'Contact Person Name *', 'carzuri-dealer-marketplace' ); ?></label>
				<input type="text" id="dealer_contact_name" name="contact_name" class="carzuri-form-control" required placeholder="e.g. John Doe">
			</div>
			<div class="carzuri-form-group">
				<label for="dealer_email"><?php esc_html_e( 'Business Email Address *', 'carzuri-dealer-marketplace' ); ?></label>
				<input type="email" id="dealer_email" name="email" class="carzuri-form-control" required placeholder="e.g. contact@prestigemotors.com">
			</div>
		</div>

		<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
			<div class="carzuri-form-group">
				<label for="dealer_phone"><?php esc_html_e( 'Phone Number *', 'carzuri-dealer-marketplace' ); ?></label>
				<input type="tel" id="dealer_phone" name="phone" class="carzuri-form-control" required placeholder="e.g. +1 555-0199">
			</div>
			<div class="carzuri-form-group">
				<label for="dealer_whatsapp"><?php esc_html_e( 'WhatsApp Number (Optional)', 'carzuri-dealer-marketplace' ); ?></label>
				<input type="tel" id="dealer_whatsapp" name="whatsapp" class="carzuri-form-control" placeholder="e.g. +254712345678">
			</div>
		</div>

		<div class="carzuri-form-group">
			<label for="dealer_reg_number"><?php esc_html_e( 'Business Reg Number (Optional)', 'carzuri-dealer-marketplace' ); ?></label>
			<input type="text" id="dealer_reg_number" name="reg_number" class="carzuri-form-control" placeholder="e.g. REG-773912">
		</div>

		<div class="carzuri-form-group">
			<label for="dealer_location"><?php esc_html_e( 'Dealership Physical Address *', 'carzuri-dealer-marketplace' ); ?></label>
			<input type="text" id="dealer_location" name="location" class="carzuri-form-control" required placeholder="e.g. 104 West Boulevard, Los Angeles, CA">
		</div>

		<div class="carzuri-form-group">
			<label for="dealer_description"><?php esc_html_e( 'Short Business Description', 'carzuri-dealer-marketplace' ); ?></label>
			<textarea id="dealer_description" name="description" class="carzuri-form-control" rows="4" placeholder="Briefly introduce your specialty, inventory style, or credentials..."></textarea>
		</div>

		<div style="margin-top: 28px;">
			<button type="submit" class="carzuri-btn carzuri-btn-primary" style="width: 100%; font-size: 15px; font-weight: 600; padding: 12px;">
				<?php esc_html_e( 'Submit Partnership Application', 'carzuri-dealer-marketplace' ); ?>
			</button>
		</div>
	</form>
</div>
