<?php
/**
 * Dealer Login Form Template
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="carzuri-dealer-login-container" style="max-width: 480px; margin: 40px auto; background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 36px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
	<h2 style="font-size: 24px; font-weight: 700; margin-top: 0; margin-bottom: 8px; color: #111827; text-align: center;">
		<?php esc_html_e( 'Dealer Partner Login', 'carzuri-dealer-marketplace' ); ?>
	</h2>
	<p style="color: #6b7280; font-size: 14px; margin-bottom: 28px; line-height: 1.5; text-align: center;">
		<?php esc_html_e( 'Log in to manage your inventory, view leads, and see performance analytics.', 'carzuri-dealer-marketplace' ); ?>
	</p>

	<!-- Message Box -->
	<div id="carzuri-login-message" class="carzuri-alert" style="display: none; padding: 12px 16px; border-radius: 6px; margin-bottom: 20px; font-size: 14px;"></div>

	<form id="carzuri-dealer-login-form" method="post" novalidate>
		<div class="carzuri-form-group" style="margin-bottom: 18px;">
			<label for="dealer_username" style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 6px;"><?php esc_html_e( 'Username or Email Address *', 'carzuri-dealer-marketplace' ); ?></label>
			<input type="text" id="dealer_username" name="username" class="carzuri-form-control" required placeholder="e.g. contact@prestigemotors.com" style="width: 100%; border: 1px solid #d1d5db; border-radius: 6px; padding: 10px 14px; font-size: 14px;">
		</div>

		<div class="carzuri-form-group" style="margin-bottom: 18px;">
			<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
				<label for="dealer_password" style="font-size: 13px; font-weight: 600; color: #374151; margin: 0;"><?php esc_html_e( 'Password *', 'carzuri-dealer-marketplace' ); ?></label>
				<a href="<?php echo esc_url( $lost_password_url ); ?>" style="font-size: 12px; color: #3b82f6; text-decoration: none; font-weight: 500;"><?php esc_html_e( 'Forgot password?', 'carzuri-dealer-marketplace' ); ?></a>
			</div>
			<div style="position: relative;">
				<input type="password" id="dealer_password" name="password" class="carzuri-form-control" required placeholder="••••••••" style="width: 100%; border: 1px solid #d1d5db; border-radius: 6px; padding: 10px 40px 10px 14px; font-size: 14px;">
				<button type="button" class="carzuri-toggle-password" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); background: none; border: none; padding: 0; cursor: pointer; color: #9ca3af; display: flex; align-items: center; justify-content: center;" aria-label="Toggle password visibility">
					<svg class="eye-icon" style="width: 18px; height: 18px;" fill="none" viewBox="0 0 24 24" stroke="currentColor">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
					</svg>
					<svg class="eye-off-icon" style="width: 18px; height: 18px; display: none;" fill="none" viewBox="0 0 24 24" stroke="currentColor">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18" />
					</svg>
				</button>
			</div>
		</div>

		<div class="carzuri-form-group" style="margin-bottom: 24px; display: flex; align-items: center; gap: 8px;">
			<input type="checkbox" id="dealer_remember" name="remember" style="margin: 0; cursor: pointer;">
			<label for="dealer_remember" style="font-size: 13px; color: #4b5563; margin: 0; cursor: pointer;"><?php esc_html_e( 'Remember me', 'carzuri-dealer-marketplace' ); ?></label>
		</div>

		<div>
			<button type="submit" class="carzuri-btn carzuri-btn-primary" style="width: 100%; font-size: 15px; font-weight: 600; padding: 12px; border-radius: 6px; border: none; cursor: pointer;">
				<?php esc_html_e( 'Log In', 'carzuri-dealer-marketplace' ); ?>
			</button>
		</div>
	</form>

	<div style="margin-top: 24px; border-top: 1px solid #e5e7eb; padding-top: 20px; text-align: center;">
		<span style="font-size: 13px; color: #6b7280;"><?php esc_html_e( 'Not a partner yet?', 'carzuri-dealer-marketplace' ); ?></span>
		<a href="<?php echo esc_url( $registration_url ); ?>" style="font-size: 13px; font-weight: 600; color: #3b82f6; text-decoration: none; margin-left: 4px;"><?php esc_html_e( 'Register here', 'carzuri-dealer-marketplace' ); ?></a>
	</div>
</div>
