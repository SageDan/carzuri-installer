<?php
/**
 * Dealer Dashboard Main Template
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$business_name = get_user_meta( $dealer->ID, 'carzuri_dealer_business_name', true );
$contact_name  = $dealer->first_name;
$location      = get_user_meta( $dealer->ID, 'carzuri_dealer_location', true );

// Find Dealer Login page URL for logout redirect.
$login_url = home_url( '/dealer-login/' );
global $wpdb;
$login_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_dealer_login]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
if ( $login_page_id ) {
	$login_url = get_permalink( $login_page_id );
}
$logout_url = wp_logout_url( $login_url );

// Find the real Messages page URL (Carzuri Messaging plugin), dynamic lookup with
// a safe fallback to the confirmed slug, matching this project's established pattern.
$messages_url = home_url( '/my-messages/' );
$messages_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_my_messages]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
if ( $messages_page_id ) {
	$messages_url = get_permalink( $messages_page_id );
}
?>
<div class="carzuri-dealer-dashboard-wrap" style="padding: 16px;">
	
	<!-- Header Panel -->
	<div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; margin-bottom: 30px; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 16px;">
		<div>
			<h1 style="font-size: 22px; font-weight: 700; color: #111827; margin: 0 0 4px;">
				<?php echo esc_html( $business_name ? $business_name : $dealer->display_name ); ?>
			</h1>
			<p style="color: #6b7280; font-size: 13px; margin: 0;">
				<span><?php printf( esc_html__( 'Dealer Partner ID: #%d', 'carzuri-dealer-marketplace' ), esc_html( $dealer->ID ) ); ?></span>
				<?php if ( $location ) : ?>
					<span style="margin-left: 12px; border-left: 1px solid #e5e7eb; padding-left: 12px;"><?php echo esc_html( $location ); ?></span>
				<?php endif; ?>
			</p>
		</div>
		<div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap; justify-content: flex-end;">
			<?php if ( shortcode_exists( 'carzuri_my_messages' ) ) : ?>
				<a href="<?php echo esc_url( $messages_url ); ?>" class="carzuri-btn carzuri-btn-secondary" style="font-size: 13px; font-weight: 600;">
					<svg style="width: 16px; height: 16px; margin-right: 6px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
					<?php esc_html_e( 'Messages', 'carzuri-dealer-marketplace' ); ?>
				</a>
			<?php endif; ?>
			<a href="<?php echo esc_url( add_query_arg( 'dealer_id', $dealer->ID, home_url( '/dealer-profile' ) ) ); ?>" class="carzuri-btn carzuri-btn-secondary" target="_blank" style="font-size: 13px; font-weight: 600;">
				<svg style="width: 16px; height: 16px; margin-right: 6px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
				<?php esc_html_e( 'View Storefront', 'carzuri-dealer-marketplace' ); ?>
			</a>
			<span style="font-size: 13px; color: #6b7280;">
				<?php printf( esc_html__( 'Logged in as %s', 'carzuri-dealer-marketplace' ), esc_html( $contact_name ? $contact_name : $dealer->user_login ) ); ?>
				<span style="margin: 0 6px; color: #e5e7eb;">|</span>
				<a href="<?php echo esc_url( $logout_url ); ?>" style="color: #dc2626; text-decoration: none; font-weight: 600;"><?php esc_html_e( 'Log Out', 'carzuri-dealer-marketplace' ); ?></a>
			</span>
		</div>
	</div>

	<!-- Tabs Header -->
	<div class="carzuri-dealer-tabs">
		<button class="carzuri-dealer-tab-trigger active" data-tab="inventory"><?php esc_html_e( 'Inventory Management', 'carzuri-dealer-marketplace' ); ?></button>
		<button class="carzuri-dealer-tab-trigger" data-tab="leads"><?php esc_html_e( 'Inbound Leads', 'carzuri-dealer-marketplace' ); ?></button>
		<button class="carzuri-dealer-tab-trigger" data-tab="analytics"><?php esc_html_e( 'Performance Insights', 'carzuri-dealer-marketplace' ); ?></button>
	</div>

	<!-- Tab Panels -->
	<div id="carzuri-tab-inventory" class="carzuri-dealer-tab-content active">
		<?php echo $inventory_html; ?>
	</div>

	<div id="carzuri-tab-leads" class="carzuri-dealer-tab-content">
		<?php echo $leads_html; ?>
	</div>

	<div id="carzuri-tab-analytics" class="carzuri-dealer-tab-content">
		<?php echo $analytics_html; ?>
	</div>
</div>
