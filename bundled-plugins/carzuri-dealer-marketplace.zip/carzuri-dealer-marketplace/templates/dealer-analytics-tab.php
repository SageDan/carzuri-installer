<?php
/**
 * Dealer Analytics Tab Template
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$conversion_rate = $total_leads > 0 ? round( ( $converted_leads / $total_leads ) * 100, 1 ) : 0;
?>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 30px;">
	
	<!-- Active listings card -->
	<div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
		<div style="font-size: 12px; font-weight: 600; text-transform: uppercase; color: #6b7280; letter-spacing: 0.05em; margin-bottom: 8px;">
			<?php esc_html_e( 'Active Inventory', 'carzuri-dealer-marketplace' ); ?>
		</div>
		<div style="font-size: 32px; font-weight: 800; color: #111827; line-height: 1;">
			<?php echo esc_html( $active_count ); ?>
		</div>
		<div style="font-size: 12px; color: #10b981; margin-top: 8px; font-weight: 500;">
			<?php esc_html_e( 'Live & visible to buyers', 'carzuri-dealer-marketplace' ); ?>
		</div>
	</div>

	<!-- Sold listings card -->
	<div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
		<div style="font-size: 12px; font-weight: 600; text-transform: uppercase; color: #6b7280; letter-spacing: 0.05em; margin-bottom: 8px;">
			<?php esc_html_e( 'Vehicles Sold', 'carzuri-dealer-marketplace' ); ?>
		</div>
		<div style="font-size: 32px; font-weight: 800; color: #d97706; line-height: 1;">
			<?php echo esc_html( $sold_count ); ?>
		</div>
		<div style="font-size: 12px; color: #6b7280; margin-top: 8px;">
			<?php esc_html_e( 'Removed from catalog', 'carzuri-dealer-marketplace' ); ?>
		</div>
	</div>

	<!-- Leads received card -->
	<div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
		<div style="font-size: 12px; font-weight: 600; text-transform: uppercase; color: #6b7280; letter-spacing: 0.05em; margin-bottom: 8px;">
			<?php esc_html_e( 'Total Leads', 'carzuri-dealer-marketplace' ); ?>
		</div>
		<div style="font-size: 32px; font-weight: 800; color: #2563eb; line-height: 1;">
			<?php echo esc_html( $total_leads ); ?>
		</div>
		<div style="font-size: 12px; color: #4b5563; margin-top: 8px; font-weight: 500;">
			<?php printf( esc_html__( '%s%% Conversion rate', 'carzuri-dealer-marketplace' ), esc_html( $conversion_rate ) ); ?>
		</div>
	</div>

	<!-- Views count card -->
	<div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
		<div style="font-size: 12px; font-weight: 600; text-transform: uppercase; color: #6b7280; letter-spacing: 0.05em; margin-bottom: 8px;">
			<?php esc_html_e( 'Listing Page Views', 'carzuri-dealer-marketplace' ); ?>
		</div>
		<div style="font-size: 32px; font-weight: 800; color: #7c3aed; line-height: 1;">
			<?php echo esc_html( number_format( $total_views ) ); ?>
		</div>
		<div style="font-size: 12px; color: #6b7280; margin-top: 8px;">
			<?php esc_html_e( 'Total exposure across store', 'carzuri-dealer-marketplace' ); ?>
		</div>
	</div>
</div>
