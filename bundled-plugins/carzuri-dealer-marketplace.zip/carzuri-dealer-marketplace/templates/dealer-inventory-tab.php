<?php
/**
 * Dealer Inventory Tab Template
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Query all listings for this dealer.
$vehicles_query = new WP_Query(
	array(
		'post_type'      => 'vehicle',
		'post_status'    => array( 'publish', 'pending', 'draft' ),
		'posts_per_page' => -1,
		'meta_key'       => 'carzuri_dealer_id',
		'meta_value'     => $dealer_id,
	)
);

// Fetch terms for core taxonomies.
$makes      = get_terms( array( 'taxonomy' => 'vehicle_make', 'hide_empty' => false ) );
$body_types = get_terms( array( 'taxonomy' => 'vehicle_body_type', 'hide_empty' => false ) );
$locations  = get_terms( array( 'taxonomy' => 'vehicle_location', 'hide_empty' => false ) );
?>
<div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 24px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
	<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
		<h2 style="font-size: 18px; font-weight: 700; margin: 0; color: #111827;"><?php esc_html_e( 'Vehicle Listings', 'carzuri-dealer-marketplace' ); ?></h2>
		<button id="carzuri-add-vehicle-btn" class="carzuri-btn carzuri-btn-primary" style="font-size: 13px; font-weight: 600;">
			<svg style="width: 16px; height: 16px; margin-right: 6px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
			<?php esc_html_e( 'Add New Vehicle', 'carzuri-dealer-marketplace' ); ?>
		</button>
	</div>

	<?php if ( ! $vehicles_query->have_posts() ) : ?>
		<div style="text-align: center; padding: 48px 24px; border: 2px dashed #e5e7eb; border-radius: 6px;">
			<p style="color: #6b7280; font-size: 15px; margin: 0;"><?php esc_html_e( 'You have not uploaded any vehicle listings yet.', 'carzuri-dealer-marketplace' ); ?></p>
		</div>
	<?php else : ?>
		<!-- Mobile-safe scroll container: table scrolls independently instead of dragging the whole page sideways -->
		<div style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
		<table class="carzuri-table" style="min-width: 700px; width: 100%;">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Vehicle Name', 'carzuri-dealer-marketplace' ); ?></th>
					<th><?php esc_html_e( 'Price', 'carzuri-dealer-marketplace' ); ?></th>
					<th><?php esc_html_e( 'Specs (Year/Miles)', 'carzuri-dealer-marketplace' ); ?></th>
					<th><?php esc_html_e( 'Listing Status', 'carzuri-dealer-marketplace' ); ?></th>
					<th style="width: 200px; text-align: right;"><?php esc_html_e( 'Actions', 'carzuri-dealer-marketplace' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php while ( $vehicles_query->have_posts() ) : $vehicles_query->the_post(); ?>
					<?php
					$vehicle_id   = get_the_ID();
					$price        = get_post_meta( $vehicle_id, 'carzuri_price', true );
					$year         = get_post_meta( $vehicle_id, 'carzuri_year', true );
					$mileage      = get_post_meta( $vehicle_id, 'carzuri_mileage', true );
					$status       = get_post_meta( $vehicle_id, 'carzuri_status', true );
					$post_status  = get_post_status( $vehicle_id );
					$condition    = get_post_meta( $vehicle_id, 'carzuri_condition', true );
					$transmission = get_post_meta( $vehicle_id, 'carzuri_transmission', true );
					$fuel_type    = get_post_meta( $vehicle_id, 'carzuri_fuel_type', true );
					$engine_size  = get_post_meta( $vehicle_id, 'carzuri_engine_size', true );
					$vin          = get_post_meta( $vehicle_id, 'carzuri_vin', true );
					$reg_number   = get_post_meta( $vehicle_id, 'carzuri_registration_number', true );

					// Plain-text version of the current description, used to
					// pre-fill the Edit modal's textarea. wp_strip_all_tags()
					// keeps this readable even if the post was originally
					// created via wp-admin's block editor (which stores
					// block-comment markup alongside the actual text).
					$description_plain = wp_strip_all_tags( get_the_content() );

					// Taxonomies terms
					$vehicle_makes = wp_get_object_terms( $vehicle_id, 'vehicle_make' );
					$make_slug     = ! empty( $vehicle_makes ) && ! is_wp_error( $vehicle_makes ) ? $vehicle_makes[0]->slug : '';
					$make_name     = ! empty( $vehicle_makes ) && ! is_wp_error( $vehicle_makes ) ? $vehicle_makes[0]->name : '';

					$vehicle_bodies = wp_get_object_terms( $vehicle_id, 'vehicle_body_type' );
					$body_slug      = ! empty( $vehicle_bodies ) && ! is_wp_error( $vehicle_bodies ) ? $vehicle_bodies[0]->slug : '';
					$body_name      = ! empty( $vehicle_bodies ) && ! is_wp_error( $vehicle_bodies ) ? $vehicle_bodies[0]->name : '';

					// Location — now sourced solely from the vehicle_location
					// taxonomy. The separate free-text "location meta" field
					// (and its data-location_meta attribute below) was removed
					// as part of the Location field consolidation: it was
					// captured from every dealer but never displayed or used
					// anywhere, and could silently disagree with this value.
					$vehicle_locs = wp_get_object_terms( $vehicle_id, 'vehicle_location' );
					$location_slug = ! empty( $vehicle_locs ) && ! is_wp_error( $vehicle_locs ) ? $vehicle_locs[0]->slug : '';
					$location_name = ! empty( $vehicle_locs ) && ! is_wp_error( $vehicle_locs ) ? $vehicle_locs[0]->name : '';
					?>
					<tr>
						<td>
							<strong><?php the_title(); ?></strong><br>
							<span style="font-size: 11px; color: #9ca3af;"><?php printf( esc_html__( 'ID: #%d', 'carzuri-dealer-marketplace' ), esc_html( $vehicle_id ) ); ?></span>
						</td>
						<td style="font-weight: 600; color: #10b981;">
							<?php echo $price ? carzuri_format_price( $price ) : '—'; ?>
						</td>
						<td style="font-size: 13px; color: #4b5563;">
							<?php printf( esc_html__( '%1$s • %2$s mi', 'carzuri-dealer-marketplace' ), esc_html( $year ? $year : '—' ), esc_html( $mileage ? number_format( $mileage ) : '—' ) ); ?>
						</td>
						<td>
							<?php if ( 'sold' === $status ) : ?>
								<span class="carzuri-badge closed"><?php esc_html_e( 'Sold', 'carzuri-dealer-marketplace' ); ?></span>
							<?php elseif ( 'publish' === $post_status ) : ?>
								<span class="carzuri-badge converted"><?php esc_html_e( 'Live', 'carzuri-dealer-marketplace' ); ?></span>
							<?php elseif ( 'pending' === $post_status ) : ?>
								<span class="carzuri-badge contacted"><?php esc_html_e( 'Pending Review', 'carzuri-dealer-marketplace' ); ?></span>
							<?php else : ?>
								<span class="carzuri-badge new"><?php echo esc_html( ucfirst( $post_status ) ); ?></span>
							<?php endif; ?>
						</td>
						<td style="text-align: right;">
							<div style="display: flex; gap: 8px; justify-content: flex-end;">
								<button class="carzuri-btn carzuri-btn-secondary carzuri-edit-vehicle-btn" style="padding: 6px 12px; font-size: 12px;"
									data-id="<?php echo esc_attr( $vehicle_id ); ?>"
									data-title="<?php echo esc_attr( get_the_title() ); ?>"
									data-description="<?php echo esc_attr( $description_plain ); ?>"
									data-price="<?php echo esc_attr( $price ); ?>"
									data-year="<?php echo esc_attr( $year ); ?>"
									data-mileage="<?php echo esc_attr( $mileage ); ?>"
									data-condition="<?php echo esc_attr( $condition ); ?>"
									data-transmission="<?php echo esc_attr( $transmission ); ?>"
									data-fuel_type="<?php echo esc_attr( $fuel_type ); ?>"
									data-engine_size="<?php echo esc_attr( $engine_size ); ?>"
									data-vin="<?php echo esc_attr( $vin ); ?>"
									data-registration_number="<?php echo esc_attr( $reg_number ); ?>"
									data-make_slug="<?php echo esc_attr( $make_slug ); ?>"
									data-make_name="<?php echo esc_attr( $make_name ); ?>"
									data-body_type_slug="<?php echo esc_attr( $body_slug ); ?>"
									data-body_type_name="<?php echo esc_attr( $body_name ); ?>"
									data-location_slug="<?php echo esc_attr( $location_slug ); ?>"
									data-location_name="<?php echo esc_attr( $location_name ); ?>">
									<?php esc_html_e( 'Edit', 'carzuri-dealer-marketplace' ); ?>
								</button>
								
								<?php if ( 'sold' !== $status ) : ?>
									<button class="carzuri-btn carzuri-btn-secondary carzuri-sold-vehicle-btn" style="padding: 6px 12px; font-size: 12px; color: #d97706; border-color: #f59e0b;"
										data-id="<?php echo esc_attr( $vehicle_id ); ?>">
										<?php esc_html_e( 'Mark Sold', 'carzuri-dealer-marketplace' ); ?>
									</button>
								<?php endif; ?>
							</div>
						</td>
					</tr>
				<?php endwhile; wp_reset_postdata(); ?>
			</tbody>
		</table>
		</div>
	<?php endif; ?>
</div>

<!-- Add/Edit Vehicle Modal Dialog -->
<div id="carzuri-vehicle-modal" style="display: none; position: fixed; z-index: 9999; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.5); backdrop-filter: blur(4px);">
	<div style="background-color: #f9fafb; margin: 5% auto; width: 90%; max-width: 750px; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);">
		
		<!-- Modal Header -->
		<div style="background: #fff; border-bottom: 1px solid #e5e7eb; padding: 20px 24px; display: flex; justify-content: space-between; align-items: center;">
			<h3 id="carzuri-vehicle-modal-title" style="font-size: 18px; font-weight: 700; color: #111827; margin: 0;">Add New Vehicle</h3>
			<button class="carzuri-close-modal" style="background: transparent; border: none; font-size: 24px; font-weight: 700; line-height: 1; cursor: pointer; color: #9ca3af; hover:color:#4b5563;">&times;</button>
		</div>

		<!-- Modal Body Form -->
		<form id="carzuri-vehicle-form" style="padding: 24px; max-height: calc(100vh - 200px); overflow-y: auto;">
			<input type="hidden" id="vehicle_id" name="vehicle_id" value="">

			<!-- Form Grid -->
			<div class="carzuri-form-group">
				<label for="vehicle_title"><?php esc_html_e( 'Listing Title / Vehicle Name *', 'carzuri-dealer-marketplace' ); ?></label>
				<input type="text" id="vehicle_title" name="title" class="carzuri-form-control" required placeholder="e.g. 2018 Toyota Land Cruiser Prado">
			</div>

			<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;">
				<div class="carzuri-form-group">
					<label for="vehicle_price"><?php esc_html_e( 'Price (KSh) *', 'carzuri-dealer-marketplace' ); ?></label>
					<input type="number" id="vehicle_price" name="price" class="carzuri-form-control" required placeholder="e.g. 4500000">
				</div>
				<div class="carzuri-form-group">
					<label for="vehicle_year"><?php esc_html_e( 'Model Year *', 'carzuri-dealer-marketplace' ); ?></label>
					<input type="number" id="vehicle_year" name="year" class="carzuri-form-control" required placeholder="e.g. 2018">
				</div>
				<div class="carzuri-form-group">
					<label for="vehicle_mileage"><?php esc_html_e( 'Mileage (km) *', 'carzuri-dealer-marketplace' ); ?></label>
					<input type="number" id="vehicle_mileage" name="mileage" class="carzuri-form-control" required placeholder="e.g. 45000">
				</div>
			</div>

			<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;">
				<div class="carzuri-form-group">
					<label for="vehicle_condition"><?php esc_html_e( 'Condition *', 'carzuri-dealer-marketplace' ); ?></label>
					<select id="vehicle_condition" name="condition" class="carzuri-form-control">
						<option value="used"><?php esc_html_e( 'Used', 'carzuri-dealer-marketplace' ); ?></option>
						<option value="new"><?php esc_html_e( 'New', 'carzuri-dealer-marketplace' ); ?></option>
						<!-- FIX: was value="cpo", which never matched wp-admin's
						     'certified-pre-owned' — meaning a dealer-added
						     "Certified Pre-Owned" vehicle stored a value no
						     Condition filter (or anything else reading this
						     meta) could ever recognize as certified-pre-owned.
						     Aligned to the same canonical value Core's own
						     wp-admin metabox already uses. -->
						<option value="certified-pre-owned"><?php esc_html_e( 'Certified Pre-Owned', 'carzuri-dealer-marketplace' ); ?></option>
					</select>
				</div>
				<div class="carzuri-form-group">
					<label for="vehicle_transmission"><?php esc_html_e( 'Transmission *', 'carzuri-dealer-marketplace' ); ?></label>
					<select id="vehicle_transmission" name="transmission" class="carzuri-form-control">
						<option value="Automatic"><?php esc_html_e( 'Automatic', 'carzuri-dealer-marketplace' ); ?></option>
						<option value="Manual"><?php esc_html_e( 'Manual', 'carzuri-dealer-marketplace' ); ?></option>
					</select>
				</div>
				<div class="carzuri-form-group">
					<label for="vehicle_fuel_type"><?php esc_html_e( 'Fuel Type *', 'carzuri-dealer-marketplace' ); ?></label>
					<select id="vehicle_fuel_type" name="fuel_type" class="carzuri-form-control">
						<option value="Petrol"><?php esc_html_e( 'Petrol', 'carzuri-dealer-marketplace' ); ?></option>
						<option value="Diesel"><?php esc_html_e( 'Diesel', 'carzuri-dealer-marketplace' ); ?></option>
						<option value="Electric"><?php esc_html_e( 'Electric', 'carzuri-dealer-marketplace' ); ?></option>
						<option value="Hybrid"><?php esc_html_e( 'Hybrid', 'carzuri-dealer-marketplace' ); ?></option>
					</select>
				</div>
			</div>

			<!-- Taxonomies (Populated with existing Core taxonomies) -->
			<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;">
				<div class="carzuri-form-group">
					<label for="vehicle_make"><?php esc_html_e( 'Make / Brand', 'carzuri-dealer-marketplace' ); ?></label>
					<input type="text" list="vehicle_make_options" id="vehicle_make" name="vehicle_make" class="carzuri-form-control" placeholder="<?php esc_attr_e( 'e.g. Toyota', 'carzuri-dealer-marketplace' ); ?>">
					<datalist id="vehicle_make_options">
						<?php if ( ! empty( $makes ) && ! is_wp_error( $makes ) ) : ?>
							<?php foreach ( $makes as $term ) : ?>
								<option value="<?php echo esc_attr( $term->name ); ?>"></option>
							<?php endforeach; ?>
						<?php else : ?>
							<option value="Toyota"></option>
							<option value="Nissan"></option>
							<option value="Mazda"></option>
							<option value="Subaru"></option>
							<option value="Mercedes-Benz"></option>
						<?php endif; ?>
					</datalist>
				</div>
				<div class="carzuri-form-group">
					<label for="vehicle_body_type"><?php esc_html_e( 'Body Type', 'carzuri-dealer-marketplace' ); ?></label>
					<input type="text" list="vehicle_body_type_options" id="vehicle_body_type" name="vehicle_body_type" class="carzuri-form-control" placeholder="<?php esc_attr_e( 'e.g. SUV', 'carzuri-dealer-marketplace' ); ?>">
					<datalist id="vehicle_body_type_options">
						<?php if ( ! empty( $body_types ) && ! is_wp_error( $body_types ) ) : ?>
							<?php foreach ( $body_types as $term ) : ?>
								<option value="<?php echo esc_attr( $term->name ); ?>"></option>
							<?php endforeach; ?>
						<?php else : ?>
							<option value="Sedan"></option>
							<option value="SUV"></option>
							<option value="Coupe"></option>
							<option value="Hatchback"></option>
						<?php endif; ?>
					</datalist>
				</div>
				<div class="carzuri-form-group">
					<label for="vehicle_location_tax"><?php esc_html_e( 'Location', 'carzuri-dealer-marketplace' ); ?></label>
					<input type="text" list="vehicle_location_options" id="vehicle_location_tax" name="vehicle_location_tax" class="carzuri-form-control" placeholder="<?php esc_attr_e( 'e.g. Nairobi', 'carzuri-dealer-marketplace' ); ?>">
					<datalist id="vehicle_location_options">
						<?php if ( ! empty( $locations ) && ! is_wp_error( $locations ) ) : ?>
							<?php foreach ( $locations as $term ) : ?>
								<option value="<?php echo esc_attr( $term->name ); ?>"></option>
							<?php endforeach; ?>
						<?php else : ?>
							<option value="Nairobi"></option>
							<option value="Mombasa"></option>
							<option value="Kisumu"></option>
							<option value="Nakuru"></option>
							<option value="Eldoret"></option>
						<?php endif; ?>
					</datalist>
				</div>
			</div>

			<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;">
				<div class="carzuri-form-group">
					<label for="vehicle_engine_size"><?php esc_html_e( 'Engine Size', 'carzuri-dealer-marketplace' ); ?></label>
					<input type="text" id="vehicle_engine_size" name="engine_size" class="carzuri-form-control" placeholder="e.g. 3000cc">
				</div>
				<div class="carzuri-form-group">
					<label for="vehicle_vin"><?php esc_html_e( 'VIN / Chassis Code', 'carzuri-dealer-marketplace' ); ?></label>
					<input type="text" id="vehicle_vin" name="vin" class="carzuri-form-control" placeholder="17-digit VIN code">
				</div>
				<div class="carzuri-form-group">
					<label for="vehicle_reg_number"><?php esc_html_e( 'Registration License No.', 'carzuri-dealer-marketplace' ); ?></label>
					<input type="text" id="vehicle_reg_number" name="registration_number" class="carzuri-form-control" placeholder="e.g. KDL 123A">
				</div>
			</div>

			<div class="carzuri-form-group">
				<label for="vehicle_description"><?php esc_html_e( 'Vehicle Description', 'carzuri-dealer-marketplace' ); ?></label>
				<textarea id="vehicle_description" name="description" class="carzuri-form-control" rows="5" placeholder="<?php esc_attr_e( 'Describe the vehicle\'s condition, features, history, or anything a buyer should know...', 'carzuri-dealer-marketplace' ); ?>"></textarea>
			</div>

			<!-- Featured Image Upload -->
			<div class="carzuri-form-group" style="margin-top: 16px;">
				<label for="vehicle_featured_image"><?php esc_html_e( 'Featured Image * (Max 5MB, JPG/PNG/WEBP)', 'carzuri-dealer-marketplace' ); ?></label>
				<input type="file" id="vehicle_featured_image" name="featured_image" accept="image/jpeg,image/png,image/webp" class="carzuri-form-control" style="padding: 6px 12px; height: auto;">
				<div id="featured-image-preview" style="margin-top: 10px; display: none;">
					<img id="featured-preview-img" src="" alt="Featured Preview" style="max-width: 150px; max-height: 150px; border-radius: 4px; border: 1px solid #ddd; object-fit: cover;">
				</div>
			</div>

			<!-- Gallery Images Upload -->
			<div class="carzuri-form-group" style="margin-top: 16px;">
				<label for="vehicle_gallery_images"><?php esc_html_e( 'Gallery Images (Max 5MB per image, JPG/PNG/WEBP)', 'carzuri-dealer-marketplace' ); ?></label>
				<input type="file" id="vehicle_gallery_images" name="gallery_images[]" accept="image/jpeg,image/png,image/webp" class="carzuri-form-control" multiple style="padding: 6px 12px; height: auto;">
				<div id="gallery-images-preview" style="margin-top: 10px; display: flex; flex-wrap: wrap; gap: 10px;"></div>
			</div>

			<!-- Modal Footer -->
			<div style="border-top: 1px solid #e5e7eb; padding: 18px 0 0; display: flex; justify-content: flex-end; gap: 12px; background: transparent;">
				<button type="button" class="carzuri-btn carzuri-btn-secondary carzuri-close-modal"><?php esc_html_e( 'Cancel', 'carzuri-dealer-marketplace' ); ?></button>
				<button type="submit" class="carzuri-btn carzuri-btn-primary"><?php esc_html_e( 'Save Listing Details', 'carzuri-dealer-marketplace' ); ?></button>
			</div>
		</form>
	</div>
</div>
