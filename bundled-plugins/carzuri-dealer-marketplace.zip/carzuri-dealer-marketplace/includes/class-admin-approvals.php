<?php
/**
 * Admin Approvals class for handling dealer review actions.
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Dealer_Admin_Approvals {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Users list columns.
		add_filter( 'manage_users_columns', array( $this, 'add_dealer_status_column' ) );
		add_filter( 'manage_users_custom_column', array( $this, 'render_dealer_status_column' ), 10, 3 );
		add_filter( 'user_row_actions', array( $this, 'add_dealer_row_actions' ), 10, 2 );

		// Register submenu under Settings -> Dealer Approvals.
		add_action( 'admin_menu', array( $this, 'register_admin_page' ) );

		// Listen to action triggers.
		add_action( 'admin_init', array( $this, 'handle_approval_actions' ) );
	}

	/**
	 * Register the sub-menu under Settings (options-general.php).
	 */
	public function register_admin_page() {
		add_submenu_page(
			'options-general.php',
			__( 'Dealer Approvals', 'carzuri-dealer-marketplace' ),
			__( 'Dealer Approvals', 'carzuri-dealer-marketplace' ),
			'manage_options',
			'dealer-approvals',
			array( $this, 'render_approvals_page' )
		);
	}

	/**
	 * Add custom column for dealer approval status to Users list.
	 */
	public function add_dealer_status_column( $columns ) {
		$columns['dealer_status'] = __( 'Dealer Status', 'carzuri-dealer-marketplace' );
		return $columns;
	}

	/**
	 * Render value for dealer approval status column.
	 */
	public function render_dealer_status_column( $val, $column_name, $user_id ) {
		if ( 'dealer_status' !== $column_name ) {
			return $val;
		}

		$user = get_userdata( $user_id );
		if ( ! $user || ! in_array( 'carzuri_dealer', $user->roles ) ) {
			return '<em>' . __( 'N/A (Not Dealer)', 'carzuri-dealer-marketplace' ) . '</em>';
		}

		$status = get_user_meta( $user_id, 'carzuri_dealer_approved', true );

		if ( '1' === $status ) {
			return '<span style="color: #46b450; font-weight: bold;">' . __( 'Approved', 'carzuri-dealer-marketplace' ) . '</span>';
		} elseif ( 'rejected' === $status ) {
			return '<span style="color: #dc3232; font-weight: bold;">' . __( 'Rejected', 'carzuri-dealer-marketplace' ) . '</span>';
		} else {
			return '<span style="color: #ffb900; font-weight: bold;">' . __( 'Pending Review', 'carzuri-dealer-marketplace' ) . '</span>';
		}
	}

	/**
	 * Add direct row actions (Approve / Reject) in the Users table.
	 */
	public function add_dealer_row_actions( $actions, $user_object ) {
		if ( ! in_array( 'carzuri_dealer', $user_object->roles ) ) {
			return $actions;
		}

		$status = get_user_meta( $user_object->ID, 'carzuri_dealer_approved', true );

		if ( '1' !== $status ) {
			$approve_url = wp_nonce_url(
				add_query_arg(
					array(
						'action'  => 'approve_dealer',
						'user_id' => $user_object->ID,
					),
					admin_url( 'users.php' )
				),
				'carzuri_dealer_approve_action'
			);
			$actions['approve_dealer'] = '<a href="' . esc_url( $approve_url ) . '" style="color: #46b450; font-weight: 500;">' . __( 'Approve Dealer', 'carzuri-dealer-marketplace' ) . '</a>';
		}

		if ( 'rejected' !== $status ) {
			$reject_url = wp_nonce_url(
				add_query_arg(
					array(
						'action'  => 'reject_dealer',
						'user_id' => $user_object->ID,
					),
					admin_url( 'users.php' )
				),
				'carzuri_dealer_reject_action'
			);
			$actions['reject_dealer'] = '<a href="' . esc_url( $reject_url ) . '" style="color: #dc3232; font-weight: 500;">' . __( 'Reject Dealer', 'carzuri-dealer-marketplace' ) . '</a>';
		}

		return $actions;
	}

	/**
	 * Handle approval / rejection actions from query parameters.
	 */
	public function handle_approval_actions() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$action  = isset( $_GET['action'] ) ? sanitize_text_field( $_GET['action'] ) : '';
		$user_id = isset( $_GET['user_id'] ) ? intval( $_GET['user_id'] ) : 0;

		if ( ! $user_id ) {
			return;
		}

		if ( 'approve_dealer' === $action ) {
			check_admin_referer( 'carzuri_dealer_approve_action' );
			$this->approve_dealer( $user_id );
			wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'users.php' ) );
			exit;
		}

		if ( 'reject_dealer' === $action ) {
			check_admin_referer( 'carzuri_dealer_reject_action' );
			$this->reject_dealer( $user_id );
			wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'users.php' ) );
			exit;
		}
	}

	/**
	 * Approve a dealer.
	 */
	public function approve_dealer( $user_id ) {
		update_user_meta( $user_id, 'carzuri_dealer_approved', '1' );

		// CRITICAL LESSON: Call carzuri_create_notification with minimum 4 arguments.
		if ( function_exists( 'carzuri_create_notification' ) ) {
			carzuri_create_notification(
				$user_id,
				'dealer_approved',
				'Account Approved!',
				'Congratulations! Your dealer registration has been approved. You can now access your dashboard.',
				home_url( '/dealer-dashboard' )
			);
		}

		// Send email notification to the dealer.
		$user = get_userdata( $user_id );
		if ( $user && ! empty( $user->user_email ) ) {
			$to            = $user->user_email;
			$subject       = sprintf( __( '[%s] Dealer Account Approved', 'carzuri-dealer-marketplace' ), get_bloginfo( 'name' ) );
			$dashboard_url = home_url( '/dealer-dashboard' );
			$biz_name      = get_user_meta( $user_id, 'carzuri_dealer_business_name', true );
			$name          = $biz_name ? $biz_name : ( $user->first_name ? $user->first_name : $user->display_name );

			$message = sprintf(
				__( "Hello %s,\n\nGreat news! Your dealer registration has been approved.\n\nYou can now log in and access your dealer dashboard here:\n%s\n\nThank you for partnering with us!", 'carzuri-dealer-marketplace' ),
				$name,
				$dashboard_url
			);

			wp_mail( $to, $subject, $message );
		}
	}

	/**
	 * Reject a dealer.
	 */
	public function reject_dealer( $user_id ) {
		update_user_meta( $user_id, 'carzuri_dealer_approved', 'rejected' );

		// CRITICAL LESSON: Call carzuri_create_notification with minimum 4 arguments.
		if ( function_exists( 'carzuri_create_notification' ) ) {
			carzuri_create_notification(
				$user_id,
				'dealer_rejected',
				'Application Update',
				'Your dealer registration application was not approved. Please contact support for more details.',
				''
			);
		}

		// Send email notification to the dealer.
		$user = get_userdata( $user_id );
		if ( $user && ! empty( $user->user_email ) ) {
			$to       = $user->user_email;
			$subject  = sprintf( __( '[%s] Dealer Registration Update', 'carzuri-dealer-marketplace' ), get_bloginfo( 'name' ) );
			$biz_name = get_user_meta( $user_id, 'carzuri_dealer_business_name', true );
			$name     = $biz_name ? $biz_name : ( $user->first_name ? $user->first_name : $user->display_name );

			$message = sprintf(
				__( "Hello %s,\n\nThank you for your interest in registering as a dealer.\n\nRegrettably, your dealer registration application was not approved at this time. If you have questions or believe this was an error, please feel free to contact our support team.\n\nThank you.", 'carzuri-dealer-marketplace' ),
				$name
			);

			wp_mail( $to, $subject, $message );
		}
	}

	/**
	 * Render the dedicated Settings -> Dealer Approvals admin page.
	 */
	public function render_approvals_page() {
		// Fetch pending dealers.
		$pending_dealers = get_users(
			array(
				'role'       => 'carzuri_dealer',
				'meta_key'   => 'carzuri_dealer_approved',
				'meta_value' => '0',
			)
		);

		// Handle inner page actions.
		if ( isset( $_POST['action_dealer'] ) && isset( $_POST['dealer_id'] ) ) {
			check_admin_referer( 'dealer_approval_nonce' );
			$target_id = intval( $_POST['dealer_id'] );
			$act       = sanitize_text_field( $_POST['action_dealer'] );

			if ( 'approve' === $act ) {
				$this->approve_dealer( $target_id );
				echo '<div class="updated"><p>' . esc_html__( 'Dealer approved successfully.', 'carzuri-dealer-marketplace' ) . '</p></div>';
			} elseif ( 'reject' === $act ) {
				$this->reject_dealer( $target_id );
				echo '<div class="updated"><p>' . esc_html__( 'Dealer application rejected.', 'carzuri-dealer-marketplace' ) . '</p></div>';
			}

			// Re-fetch.
			$pending_dealers = get_users(
				array(
					'role'       => 'carzuri_dealer',
					'meta_key'   => 'carzuri_dealer_approved',
					'meta_value' => '0',
				)
			);
		}

		?>
		<div class="wrap" style="max-width: 900px; margin-top: 20px;">
			<h1 style="margin-bottom: 20px;"><?php esc_html_e( 'Dealer Registration Approvals', 'carzuri-dealer-marketplace' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Review and manage registration applications from automotive dealers.', 'carzuri-dealer-marketplace' ); ?></p>
			
			<?php if ( empty( $pending_dealers ) ) : ?>
				<div class="card" style="padding: 24px; margin-top: 20px; background: #fff; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
					<h2><?php esc_html_e( 'No Pending Applications', 'carzuri-dealer-marketplace' ); ?></h2>
					<p><?php esc_html_e( 'All dealer accounts have been processed.', 'carzuri-dealer-marketplace' ); ?></p>
				</div>
			<?php else : ?>
				<table class="wp-list-table widefat fixed striped table-view-list" style="margin-top: 20px;">
					<thead>
						<tr>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Business / Dealer Info', 'carzuri-dealer-marketplace' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Contact Information', 'carzuri-dealer-marketplace' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Location', 'carzuri-dealer-marketplace' ); ?></th>
							<th scope="col" class="manage-column" style="width: 220px;"><?php esc_html_e( 'Actions', 'carzuri-dealer-marketplace' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $pending_dealers as $dealer ) : ?>
							<?php
							$biz_name = get_user_meta( $dealer->ID, 'carzuri_dealer_business_name', true );
							$phone    = get_user_meta( $dealer->ID, 'carzuri_dealer_phone', true );
							$loc      = get_user_meta( $dealer->ID, 'carzuri_dealer_location', true );
							$reg_no   = get_user_meta( $dealer->ID, 'carzuri_dealer_reg_number', true );
							$desc     = get_user_meta( $dealer->ID, 'carzuri_dealer_description', true );
							?>
							<tr>
								<td>
									<strong><?php echo esc_html( $biz_name ? $biz_name : $dealer->display_name ); ?></strong>
									<?php if ( $reg_no ) : ?>
										<br><span class="description"><?php printf( esc_html__( 'Reg No: %s', 'carzuri-dealer-marketplace' ), esc_html( $reg_no ) ); ?></span>
									<?php endif; ?>
									<?php if ( $desc ) : ?>
										<p style="font-style: italic; margin: 4px 0 0; font-size: 12px; color: #666;"><?php echo esc_html( $desc ); ?></p>
									<?php endif; ?>
								</td>
								<td>
									<?php echo esc_html( $dealer->first_name ); ?><br>
									<a href="mailto:<?php echo esc_attr( $dealer->user_email ); ?>"><?php echo esc_html( $dealer->user_email ); ?></a><br>
									<span><?php echo esc_html( $phone ); ?></span>
								</td>
								<td><?php echo esc_html( $loc ); ?></td>
								<td>
									<form method="post" style="display:inline-block; margin: 0;">
										<?php wp_nonce_field( 'dealer_approval_nonce' ); ?>
										<input type="hidden" name="dealer_id" value="<?php echo esc_attr( $dealer->ID ); ?>">
										
										<button type="submit" name="action_dealer" value="approve" class="button button-primary" style="background: #46b450; border-color: #3ca246; box-shadow: none; text-shadow: none; margin-right: 6px;">
											<?php esc_html_e( 'Approve', 'carzuri-dealer-marketplace' ); ?>
										</button>
										<button type="submit" name="action_dealer" value="reject" class="button button-secondary" style="color: #dc3232; border-color: #dc3232;">
											<?php esc_html_e( 'Reject', 'carzuri-dealer-marketplace' ); ?>
										</button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}
}
