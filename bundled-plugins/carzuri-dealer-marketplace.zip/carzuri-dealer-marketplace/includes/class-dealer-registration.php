<?php
/**
 * Dealer Registration class for handling registration logic.
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Dealer_Registration {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	/**
	 * Register a new dealer user.
	 *
	 * @param array $data Input data from registration request.
	 * @return WP_Error|int User ID on success, WP_Error on failure.
	 */
	public function register_dealer( $data ) {
		$email           = sanitize_email( $data['email'] );
		$username        = sanitize_user( isset( $data['username'] ) && $data['username'] ? $data['username'] : $email );
		$business_name   = sanitize_text_field( $data['business_name'] );
		$contact_name    = sanitize_text_field( $data['contact_name'] );
		$phone           = sanitize_text_field( $data['phone'] );
		$whatsapp        = isset( $data['whatsapp'] ) ? sanitize_text_field( $data['whatsapp'] ) : '';
		$location        = sanitize_text_field( $data['location'] );
		$reg_number      = isset( $data['reg_number'] ) ? sanitize_text_field( $data['reg_number'] ) : '';
		$description     = sanitize_textarea_field( $data['description'] );

		// Validate email.
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'invalid_email', __( 'Please provide a valid email address.', 'carzuri-dealer-marketplace' ) );
		}

		// Check if user exists.
		if ( email_exists( $email ) ) {
			return new WP_Error( 'email_exists', __( 'An account with this email already exists — please log in instead.', 'carzuri-dealer-marketplace' ) );
		}

		if ( username_exists( $username ) ) {
			// Generate fallback username if email or username matches.
			$username = 'dealer_' . wp_generate_password( 6, false, false );
		}

		// Generate random temporary password since we will send a password reset/set link.
		$password = wp_generate_password( 12, true, false );

		// Create user with carzuri_dealer role.
		$user_data = array(
			'user_login'   => $username,
			'user_email'   => $email,
			'user_pass'    => $password,
			'role'         => 'carzuri_dealer',
			'first_name'   => $contact_name,
			'display_name' => $business_name ? $business_name : $contact_name,
		);

		$user_id = wp_insert_user( $user_data );

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		// Store business fields as user meta.
		update_user_meta( $user_id, 'carzuri_dealer_business_name', $business_name );
		update_user_meta( $user_id, 'carzuri_dealer_phone', $phone );
		update_user_meta( $user_id, 'carzuri_dealer_whatsapp', $whatsapp );
		update_user_meta( $user_id, 'carzuri_dealer_location', $location );
		update_user_meta( $user_id, 'carzuri_dealer_reg_number', $reg_number );
		update_user_meta( $user_id, 'carzuri_dealer_description', $description );

		// Set pending approval flag ('0').
		update_user_meta( $user_id, 'carzuri_dealer_approved', '0' );

		// Send WordPress "welcome" style email with password-set link using wp_new_user_notification.
		wp_new_user_notification( $user_id, null, 'both' );

		// CRITICAL LESSON: Call carzuri_create_notification with minimum 4 arguments.
		// Notify all administrators.
		if ( function_exists( 'carzuri_create_notification' ) ) {
			$admin_users = get_users( array( 'role' => 'carzuri_admin' ) );
			// Fallback to administrator role if carzuri_admin users don't exist yet
			if ( empty( $admin_users ) ) {
				$admin_users = get_users( array( 'role' => 'administrator' ) );
			}

			foreach ( $admin_users as $admin ) {
				carzuri_create_notification(
					$admin->ID,
					'dealer_pending_approval',
					'New Dealer Registration',
					sprintf( 'Dealer "%s" has registered and is pending approval.', $business_name ),
					home_url( '/carzuri-admin-portal/' )
				);
			}
		}

		return $user_id;
	}
}
