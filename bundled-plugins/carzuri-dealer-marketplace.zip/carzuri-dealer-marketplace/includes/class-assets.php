<?php
/**
 * Assets class for enqueuing CSS and JS files.
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Dealer_Assets {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	public function enqueue_frontend_assets() {
		// Enqueue CSS with 'carzuri-design-system' as a dependency as required.
		wp_enqueue_style(
			'carzuri-dealer-style',
			CARZURI_DEALER_URL . 'assets/css/carzuri-dealer.css',
			array( 'carzuri-design-system' ),
			CARZURI_DEALER_VERSION
		);

		// Register Scripts (will be enqueued in shortcode handlers or conditionally).
		wp_register_script(
			'carzuri-dealer-registration',
			CARZURI_DEALER_URL . 'assets/js/carzuri-dealer-registration.js',
			array( 'jquery' ),
			CARZURI_DEALER_VERSION,
			true
		);

		wp_register_script(
			'carzuri-dealer-inventory',
			CARZURI_DEALER_URL . 'assets/js/carzuri-dealer-inventory.js',
			array( 'jquery' ),
			CARZURI_DEALER_VERSION,
			true
		);

		wp_register_script(
			'carzuri-dealer-leads',
			CARZURI_DEALER_URL . 'assets/js/carzuri-dealer-leads.js',
			array( 'jquery' ),
			CARZURI_DEALER_VERSION,
			true
		);

		wp_register_script(
			'carzuri-dealer-login',
			CARZURI_DEALER_URL . 'assets/js/carzuri-dealer-login.js',
			array( 'jquery' ),
			CARZURI_DEALER_VERSION,
			true
		);

		// Localize with API endpoints and nonce.
		$localize_data = array(
			'root_url'  => esc_url_raw( rest_url() ),
			'nonce'     => wp_create_nonce( 'wp_rest' ),
			'login_url' => wp_login_url(),
		);

		wp_localize_script( 'carzuri-dealer-registration', 'carzuriDealerData', $localize_data );
		wp_localize_script( 'carzuri-dealer-inventory', 'carzuriDealerData', $localize_data );
		wp_localize_script( 'carzuri-dealer-leads', 'carzuriDealerData', $localize_data );
		wp_localize_script( 'carzuri-dealer-login', 'carzuriDealerLogin', $localize_data );
	}

	public function enqueue_admin_assets( $hook ) {
		// Only enqueue on relevant user list or settings page
		if ( 'users.php' === $hook || strpos( $hook, 'dealer-approvals' ) !== false ) {
			wp_enqueue_style(
				'carzuri-dealer-admin-style',
				CARZURI_DEALER_URL . 'assets/css/carzuri-dealer.css',
				array(),
				CARZURI_DEALER_VERSION
			);
		}
	}
}
