<?php
/**
 * REST API Extensions class.
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Dealer_Rest_Extensions {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register custom REST API routes.
	 */
	public function register_routes() {
		$namespace = 'carzuri/v1';

		// POST /carzuri/v1/dealer-registration
		register_rest_route(
			$namespace,
			'/dealer-registration',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_dealer_registration' ),
				'permission_callback' => '__return_true', // Publicly accessible.
			)
		);

		// POST /carzuri/v1/dealer-login
		register_rest_route(
			$namespace,
			'/dealer-login',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_dealer_login' ),
				'permission_callback' => '__return_true', // Publicly accessible.
			)
		);

		// PATCH /carzuri/v1/inquiries/{id}
		register_rest_route(
			$namespace,
			'/inquiries/(?P<id>\d+)',
			array(
				'methods'             => 'PATCH', // Or WP_REST_Server::EDITABLE
				'callback'            => array( $this, 'handle_update_inquiry' ),
				'permission_callback' => array( $this, 'check_dealer_auth' ),
			)
		);

		// POST /carzuri/v1/dealer-vehicles
		register_rest_route(
			$namespace,
			'/dealer-vehicles',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_dealer_vehicle' ),
				'permission_callback' => array( $this, 'check_approved_dealer_auth' ),
			)
		);

		// GET /carzuri/v1/taxonomy-terms
		register_rest_route(
			$namespace,
			'/taxonomy-terms',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_taxonomy_terms' ),
				'permission_callback' => '__return_true',
			)
		);

		// GET /carzuri/v1/dealers
		register_rest_route(
			$namespace,
			'/dealers',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_dealers' ),
				'permission_callback' => array( $this, 'check_admin_auth' ),
			)
		);

		// POST /carzuri/v1/dealers/{id}/approve
		register_rest_route(
			$namespace,
			'/dealers/(?P<id>\d+)/approve',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'approve_dealer' ),
				'permission_callback' => array( $this, 'check_admin_auth' ),
			)
		);

		// POST /carzuri/v1/dealers/{id}/reject
		register_rest_route(
			$namespace,
			'/dealers/(?P<id>\d+)/reject',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'reject_dealer' ),
				'permission_callback' => array( $this, 'check_admin_auth' ),
			)
		);

		// POST /carzuri/v1/dealers/{id}/resend-approval-email
		register_rest_route(
			$namespace,
			'/dealers/(?P<id>\d+)/resend-approval-email',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'resend_dealer_approval_email' ),
				'permission_callback' => array( $this, 'check_admin_auth' ),
			)
		);

		// GET /carzuri/v1/vehicles-pending
		// NOTE: despite the route name (kept as-is for backward compatibility
		// with existing callers), this now also accepts an optional ?status=
		// query param so Admin Portal can browse already-published vehicles
		// too, not just ones awaiting first-time approval. Defaults to
		// 'pending' when the param is omitted, so all existing behavior for
		// current callers is unchanged.
		register_rest_route(
			$namespace,
			'/vehicles-pending',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_vehicles_pending' ),
				'permission_callback' => array( $this, 'check_admin_auth' ),
			)
		);

		// POST /carzuri/v1/vehicles/{id}/approve
		register_rest_route(
			$namespace,
			'/vehicles/(?P<id>\d+)/approve',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'approve_vehicle' ),
				'permission_callback' => array( $this, 'check_admin_auth' ),
			)
		);

		// POST /carzuri/v1/vehicles/{id}/reject
		register_rest_route(
			$namespace,
			'/vehicles/(?P<id>\d+)/reject',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'reject_vehicle' ),
				'permission_callback' => array( $this, 'check_admin_auth' ),
			)
		);

		// POST /carzuri/v1/vehicles/{id}/unpublish
		// Takes a previously-approved (currently live/published) vehicle
		// down. Distinct from reject: reject is for a submission that was
		// never good enough to go live in the first place; unpublish is for
		// a vehicle that WAS live and needs to come down (sold outside the
		// platform, listed in error, dealer request, etc). Uses the same
		// underlying mechanism as reject (post_status -> draft), which is
		// already proven to correctly hide a vehicle from the public site.
		register_rest_route(
			$namespace,
			'/vehicles/(?P<id>\d+)/unpublish',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'unpublish_vehicle' ),
				'permission_callback' => array( $this, 'check_admin_auth' ),
			)
		);

		// POST /carzuri/v1/vehicles/{id}/toggle-featured
		// Lets a carzuri_admin flag/unflag a vehicle as Featured from the
		// front-end Admin Portal. Previously the only way to do this was
		// via wp-admin's post editor checkbox — this was never exposed
		// anywhere in the admin's actual day-to-day tool.
		register_rest_route(
			$namespace,
			'/vehicles/(?P<id>\d+)/toggle-featured',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'toggle_vehicle_featured' ),
				'permission_callback' => array( $this, 'check_admin_auth' ),
			)
		);
	}

	/**
	 * Permission check: User must have carzuri_admin role or manage_options capability.
	 */
	public function check_admin_auth() {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		$user = wp_get_current_user();
		if ( in_array( 'carzuri_admin', (array) $user->roles, true ) || current_user_can( 'manage_options' ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Permission check: User must be a logged-in dealer or administrator.
	 */
	public function check_dealer_auth() {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		$user = wp_get_current_user();
		return in_array( 'carzuri_dealer', $user->roles ) || in_array( 'administrator', $user->roles );
	}

	/**
	 * Permission check: User must be a logged-in APPROVED dealer or administrator.
	 */
	public function check_approved_dealer_auth() {
		if ( ! $this->check_dealer_auth() ) {
			return false;
		}
		$user = wp_get_current_user();
		if ( in_array( 'administrator', $user->roles ) ) {
			return true;
		}
		$approved = get_user_meta( $user->ID, 'carzuri_dealer_approved', true );
		return '1' === $approved;
	}

	/**
	 * Handler: POST /carzuri/v1/dealer-registration
	 */
	public function handle_dealer_registration( WP_REST_Request $request ) {
		$params = $request->get_params();

		// Check required fields.
		$required = array( 'email', 'business_name', 'contact_name', 'phone', 'location' );
		foreach ( $required as $field ) {
			if ( empty( $params[ $field ] ) ) {
				return new WP_Error(
					'missing_fields',
					sprintf( __( 'The "%s" field is required.', 'carzuri-dealer-marketplace' ), $field ),
					array( 'status' => 400 )
				);
			}
		}

		$registration = Carzuri_Dealer_Registration::get_instance();
		$result       = $registration->register_dealer( $params );

		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => $result->get_error_message(),
				),
				400
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Your application has been received and is currently under review.', 'carzuri-dealer-marketplace' ),
				'user_id' => $result,
			),
			200
		);
	}

	/**
	 * Handler: PATCH /carzuri/v1/inquiries/{id}
	 */
	public function handle_update_inquiry( WP_REST_Request $request ) {
		global $wpdb;
		$inquiry_id = intval( $request->get_param( 'id' ) );
		$status     = sanitize_text_field( $request->get_param( 'status' ) );
		$user_id    = get_current_user_id();

		// Validate status.
		$allowed_statuses = array( 'new', 'contacted', 'converted', 'closed' );
		if ( ! in_array( $status, $allowed_statuses ) ) {
			return new WP_Error( 'invalid_status', __( 'Invalid inquiry status.', 'carzuri-dealer-marketplace' ), array( 'status' => 400 ) );
		}

		$table = $wpdb->prefix . 'carzuri_inquiries';

		// Fetch the inquiry first to verify ownership.
		$inquiry = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $inquiry_id ), ARRAY_A );

		if ( ! $inquiry ) {
			return new WP_Error( 'not_found', __( 'Inquiry not found.', 'carzuri-dealer-marketplace' ), array( 'status' => 404 ) );
		}

		// CRITICAL LESSON: Ownership checked server-side.
		// Check that the current dealer is indeed the owner of the inquiry.
		$is_admin = current_user_can( 'manage_options' );
		if ( ! $is_admin && intval( $inquiry['dealer_id'] ) !== $user_id ) {
			return new WP_Error( 'unauthorized_lead', __( 'You do not have permission to update this lead.', 'carzuri-dealer-marketplace' ), array( 'status' => 403 ) );
		}

		// Update database.
		$updated = $wpdb->update(
			$table,
			array( 'status' => $status ),
			array( 'id' => $inquiry_id ),
			array( '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error( 'db_error', __( 'Could not update inquiry status.', 'carzuri-dealer-marketplace' ), array( 'status' => 500 ) );
		}

		// Optionally create a notification for the dealer about status updates.
		if ( function_exists( 'carzuri_create_notification' ) ) {
			carzuri_create_notification(
				$user_id,
				'lead_status_updated',
				'Lead Updated',
				sprintf( 'Inquiry from %s updated to "%s".', $inquiry['buyer_name'], $status ),
				''
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Lead status updated successfully.', 'carzuri-dealer-marketplace' ),
				'status'  => $status,
			),
			200
		);
	}

	/**
	 * Handler: POST /carzuri/v1/dealer-vehicles
	 */
	public function handle_dealer_vehicle( WP_REST_Request $request ) {
		$params    = $request->get_params();
		$dealer_id = get_current_user_id();

		$vehicle_id = isset( $params['vehicle_id'] ) ? intval( $params['vehicle_id'] ) : 0;
		$title      = sanitize_text_field( $params['title'] );

		// 1. If updating an existing vehicle, verify ownership server-side.
		if ( $vehicle_id ) {
			$post_owner = intval( get_post_meta( $vehicle_id, 'carzuri_dealer_id', true ) );
			$is_admin   = current_user_can( 'manage_options' );
			if ( ! $is_admin && $post_owner !== $dealer_id ) {
				return new WP_Error( 'unauthorized_vehicle', __( 'You do not have permission to edit this vehicle.', 'carzuri-dealer-marketplace' ), array( 'status' => 403 ) );
			}
		}

		// Ensure title is present on creation.
		if ( ! $vehicle_id && empty( $title ) ) {
			return new WP_Error( 'missing_title', __( 'Vehicle title is required.', 'carzuri-dealer-marketplace' ), array( 'status' => 400 ) );
		}

		// 2. Insert or update the 'vehicle' custom post type.
		$post_data = array(
			'post_type'  => 'vehicle',
			// DESIGN DECISION: Set to 'pending' on creation for admin moderation.
			'post_status' => $vehicle_id ? get_post_status( $vehicle_id ) : 'pending',
		);

		if ( ! empty( $title ) ) {
			$post_data['post_title'] = $title;
		}

		// Vehicle Description -> saved as the post's actual post_content,
		// the same field the single vehicle page template already reads
		// into its "Vehicle Description" section. Previously this field
		// simply didn't exist anywhere in the dealer's Add/Edit Vehicle
		// form, so a dealer-submitted vehicle always had an empty
		// description — only vehicles added directly via wp-admin (which
		// exposes the real content editor) ever had one. sanitize_textarea_field()
		// strips tags but preserves line breaks/paragraphs; WordPress's own
		// 'the_content' filter (wpautop) turns those into <p> tags at
		// display time, so no HTML needs to be stored here.
		if ( isset( $params['description'] ) ) {
			$post_data['post_content'] = sanitize_textarea_field( $params['description'] );
		}

		if ( $vehicle_id ) {
			$post_data['ID'] = $vehicle_id;
			$result_id       = wp_update_post( $post_data, true );
		} else {
			$result_id = wp_insert_post( $post_data, true );
		}

		if ( is_wp_error( $result_id ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => $result_id->get_error_message(),
				),
				400
			);
		}

		// 3. Save all Core vehicle post meta keys.
		// CRITICAL LESSON: Always set 'carzuri_dealer_id' to the currently logged in dealer!
		update_post_meta( $result_id, 'carzuri_dealer_id', $dealer_id );

		// Save price, year, mileage, conditions, specs.
		if ( isset( $params['price'] ) ) {
			update_post_meta( $result_id, 'carzuri_price', floatval( $params['price'] ) );
		}
		if ( isset( $params['year'] ) ) {
			update_post_meta( $result_id, 'carzuri_year', intval( $params['year'] ) );
		}
		if ( isset( $params['mileage'] ) ) {
			update_post_meta( $result_id, 'carzuri_mileage', intval( $params['mileage'] ) );
		}
		if ( isset( $params['condition'] ) ) {
			update_post_meta( $result_id, 'carzuri_condition', sanitize_text_field( $params['condition'] ) );
		}
		if ( isset( $params['transmission'] ) ) {
			update_post_meta( $result_id, 'carzuri_transmission', sanitize_text_field( $params['transmission'] ) );
		}
		if ( isset( $params['fuel_type'] ) ) {
			update_post_meta( $result_id, 'carzuri_fuel_type', sanitize_text_field( $params['fuel_type'] ) );
		}
		if ( isset( $params['engine_size'] ) ) {
			update_post_meta( $result_id, 'carzuri_engine_size', sanitize_text_field( $params['engine_size'] ) );
		}
		if ( isset( $params['vin'] ) ) {
			update_post_meta( $result_id, 'carzuri_vin', sanitize_text_field( $params['vin'] ) );
		}
		if ( isset( $params['registration_number'] ) ) {
			update_post_meta( $result_id, 'carzuri_registration_number', sanitize_text_field( $params['registration_number'] ) );
		}
		// NOTE: 'carzuri_location' free-text meta write removed as part of
		// the Location field consolidation — the dealer form no longer
		// sends a 'location' param at all (only the real vehicle_location
		// taxonomy term below), so there is nothing to save here anymore.
		if ( isset( $params['status'] ) ) {
			update_post_meta( $result_id, 'carzuri_status', sanitize_text_field( $params['status'] ) );
		}
		if ( isset( $params['featured'] ) ) {
			update_post_meta( $result_id, 'carzuri_featured', sanitize_text_field( $params['featured'] ) );
		}
		if ( isset( $params['accident_history'] ) ) {
			update_post_meta( $result_id, 'carzuri_accident_history', sanitize_text_field( $params['accident_history'] ) );
		}
		if ( isset( $params['service_history'] ) ) {
			update_post_meta( $result_id, 'carzuri_service_history', sanitize_text_field( $params['service_history'] ) );
		}
		if ( isset( $params['gallery_ids'] ) ) {
			update_post_meta( $result_id, 'carzuri_gallery_ids', sanitize_text_field( $params['gallery_ids'] ) );
		}

		// Initialize views count if not set.
		$views = get_post_meta( $result_id, 'carzuri_views_count', true );
		if ( '' === $views ) {
			update_post_meta( $result_id, 'carzuri_views_count', '0' );
		}

		// 4. Save Core taxonomies (Make, Body Type, Location).
		// We expect input as taxonomy terms or slugs and we reuse existing core taxonomies:
		// 'vehicle_make', 'vehicle_body_type', 'vehicle_location'
		if ( isset( $params['vehicle_make'] ) ) {
			wp_set_object_terms( $result_id, $params['vehicle_make'], 'vehicle_make' );
		}
		if ( isset( $params['vehicle_body_type'] ) ) {
			wp_set_object_terms( $result_id, $params['vehicle_body_type'], 'vehicle_body_type' );
		}
		if ( isset( $params['vehicle_location'] ) ) {
			wp_set_object_terms( $result_id, $params['vehicle_location'], 'vehicle_location' );
		}

		// Handle featured image if media attachment ID is passed.
		if ( isset( $params['featured_image_id'] ) ) {
			set_post_thumbnail( $result_id, intval( $params['featured_image_id'] ) );
		}

		// Handle file uploads using WordPress standard media functions.
		if ( ! empty( $_FILES ) ) {
			if ( ! function_exists( 'media_handle_upload' ) ) {
				require_once ABSPATH . 'wp-admin/includes/image.php';
				require_once ABSPATH . 'wp-admin/includes/file.php';
				require_once ABSPATH . 'wp-admin/includes/media.php';
			}

			// Handle featured image upload.
			if ( isset( $_FILES['featured_image'] ) && 0 === $_FILES['featured_image']['error'] ) {
				$featured_id = media_handle_upload( 'featured_image', $result_id );
				if ( ! is_wp_error( $featured_id ) ) {
					set_post_thumbnail( $result_id, intval( $featured_id ) );
				}
			}

			// Handle gallery images upload.
			if ( isset( $_FILES['gallery_images'] ) && is_array( $_FILES['gallery_images']['name'] ) ) {
				$gallery_ids = array();
				
				// Retain existing gallery IDs if they exist.
				$existing_gallery = get_post_meta( $result_id, 'carzuri_gallery_ids', true );
				if ( is_array( $existing_gallery ) ) {
					$gallery_ids = $existing_gallery;
				} elseif ( ! empty( $existing_gallery ) ) {
					if ( is_string( $existing_gallery ) ) {
						$decoded = json_decode( $existing_gallery, true );
						if ( is_array( $decoded ) ) {
							$gallery_ids = $decoded;
						} else {
							$gallery_ids = array_filter( array_map( 'intval', explode( ',', $existing_gallery ) ) );
						}
					}
				}

				$files = $_FILES['gallery_images'];
				$count = count( $files['name'] );
				
				for ( $i = 0; $i < $count; $i++ ) {
					if ( empty( $files['name'][$i] ) || $files['error'][$i] !== 0 ) {
						continue;
					}
					
					$temp_key = 'temp_gallery_upload_' . $i;
					$_FILES[ $temp_key ] = array(
						'name'     => $files['name'][ $i ],
						'type'     => $files['type'][ $i ],
						'tmp_name' => $files['tmp_name'][ $i ],
						'error'    => $files['error'][ $i ],
						'size'     => $files['size'][ $i ],
					);
					
					$attach_id = media_handle_upload( $temp_key, $result_id );
					if ( ! is_wp_error( $attach_id ) ) {
						$gallery_ids[] = intval( $attach_id );
					}
					unset( $_FILES[ $temp_key ] );
				}
				
				if ( ! empty( $gallery_ids ) ) {
					update_post_meta( $result_id, 'carzuri_gallery_ids', $gallery_ids );
				}
			}
		}

		// Notify admins on new submission.
		if ( ! $vehicle_id && function_exists( 'carzuri_create_notification' ) ) {
			$admin_users = get_users( array( 'role' => 'carzuri_admin' ) );
			if ( empty( $admin_users ) ) {
				$admin_users = get_users( array( 'role' => 'administrator' ) );
			}
			foreach ( $admin_users as $admin ) {
				carzuri_create_notification(
					$admin->ID,
					'vehicle_submitted_for_review',
					'New Listing Submitted',
					sprintf( 'Dealer "%s" has submitted vehicle "%s" for review.', get_user_meta( $dealer_id, 'carzuri_dealer_business_name', true ), $title ),
					admin_url( 'edit.php?post_type=vehicle' )
				);
			}
		}

		return new WP_REST_Response(
			array(
				'success'    => true,
				'message'    => $vehicle_id ? __( 'Vehicle updated successfully.', 'carzuri-dealer-marketplace' ) : __( 'Vehicle submitted for review.', 'carzuri-dealer-marketplace' ),
				'vehicle_id' => $result_id,
			),
			200
		);
	}

	/**
	 * Handler: POST /carzuri/v1/dealer-login
	 */
	public function handle_dealer_login( WP_REST_Request $request ) {
		$params = $request->get_params();

		$username = isset( $params['username'] ) ? sanitize_text_field( $params['username'] ) : '';
		$password = isset( $params['password'] ) ? $params['password'] : '';
		$remember = isset( $params['remember'] ) ? (bool) $params['remember'] : false;

		if ( empty( $username ) || empty( $password ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Please enter both username/email and password.', 'carzuri-dealer-marketplace' ),
				),
				400
			);
		}

		// Authenticate via wp_signon.
		$creds = array(
			'user_login'    => $username,
			'user_password' => $password,
			'remember'      => $remember,
		);

		// If user entered email, let's find the username first, as wp_signon can sometimes be strict depending on config.
		if ( is_email( $username ) ) {
			$user = get_user_by( 'email', $username );
			if ( $user ) {
				$creds['user_login'] = $user->user_login;
			}
		}

		$user = wp_signon( $creds, is_ssl() );

		if ( is_wp_error( $user ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Incorrect email or password.', 'carzuri-dealer-marketplace' ),
				),
				401
			);
		}

		// Look up the dashboard URL (needed for both the normal success
		// response below and the device-verification response, so a
		// resumed login after entering the code redirects to the same
		// place a known-device login always has).
		$dashboard_url = home_url( '/dealer-dashboard/' );
		global $wpdb;
		$page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_dealer_dashboard]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
		if ( $page_id ) {
			$dashboard_url = get_permalink( $page_id );
		}

		// New Device Verification: if this browser/device hasn't completed
		// email verification before, don't grant the session yet — undo the
		// auth cookies wp_signon() just set, email a one-time code (via
		// Carzuri Core's shared helper), and ask the front end to collect
		// it. A device verified once for this account here is remembered
		// across Admin and Buyer logins too, since the check is keyed on
		// user_id alone.
		if ( ! carzuri_is_known_device( $user->ID ) ) {
			wp_logout();
			carzuri_send_device_verification_code( $user->ID );

			return new WP_REST_Response(
				array(
					'success'                      => true,
					'requires_device_verification' => true,
					'user_id'                      => $user->ID,
					'remember'                     => $remember,
					'redirect_url'                 => $dashboard_url,
					'message'                      => __( 'For your security, we emailed you a verification code. Please enter it below to finish signing in.', 'carzuri-dealer-marketplace' ),
				),
				200
			);
		}

		return new WP_REST_Response(
			array(
				'success'      => true,
				'message'      => __( 'Login successful! Redirecting...', 'carzuri-dealer-marketplace' ),
				'redirect_url' => $dashboard_url,
			),
			200
		);
	}

	/**
	 * Handler: GET /carzuri/v1/taxonomy-terms
	 */
	public function get_taxonomy_terms( WP_REST_Request $request ) {
		$makes = get_terms(
			array(
				'taxonomy'   => 'vehicle_make',
				'hide_empty' => false,
			)
		);
		$bodies = get_terms(
			array(
				'taxonomy'   => 'vehicle_body_type',
				'hide_empty' => false,
			)
		);

		$makes_data = array();
		if ( ! is_wp_error( $makes ) && ! empty( $makes ) ) {
			foreach ( $makes as $term ) {
				$makes_data[] = array(
					'id'   => $term->term_id,
					'name' => $term->name,
					'slug' => $term->slug,
				);
			}
		}

		$bodies_data = array();
		if ( ! is_wp_error( $bodies ) && ! empty( $bodies ) ) {
			foreach ( $bodies as $term ) {
				$bodies_data[] = array(
					'id'   => $term->term_id,
					'name' => $term->name,
					'slug' => $term->slug,
				);
			}
		}

		// Fallback defaults if empty on first use.
		if ( empty( $makes_data ) ) {
			$default_makes = array( 'BMW', 'Audi', 'Toyota', 'Tesla', 'Porsche', 'Mercedes-Benz' );
			foreach ( $default_makes as $idx => $m ) {
				$makes_data[] = array( 'id' => $idx + 1, 'name' => $m, 'slug' => sanitize_title( $m ) );
			}
		}
		if ( empty( $bodies_data ) ) {
			$default_bodies = array( 'Coupe', 'Sedan', 'SUV', 'Hatchback' );
			foreach ( $default_bodies as $idx => $b ) {
				$bodies_data[] = array( 'id' => $idx + 1, 'name' => $b, 'slug' => sanitize_title( $b ) );
			}
		}

		return new WP_REST_Response(
			array(
				'makes'  => $makes_data,
				'bodies' => $bodies_data,
			),
			200
		);
	}

	/**
	 * Handler: GET /carzuri/v1/dealers
	 */
	public function get_dealers( WP_REST_Request $request ) {
		$status_param = $request->get_param( 'status' );
		$status_param = $status_param ? sanitize_text_field( $status_param ) : 'all';

		$args = array(
			'role'    => 'carzuri_dealer',
			'orderby' => 'ID',
			'order'   => 'ASC',
		);

		$dealers = get_users( $args );
		$data    = array();

		foreach ( $dealers as $dealer ) {
			$approved_status = get_user_meta( $dealer->ID, 'carzuri_dealer_approved', true );
			if ( '' === $approved_status || false === $approved_status ) {
				$approved_status = '0';
			}

			if ( 'pending' === $status_param && '0' !== $approved_status ) {
				continue;
			}
			if ( 'approved' === $status_param && '1' !== $approved_status ) {
				continue;
			}
			if ( 'rejected' === $status_param && 'rejected' !== $approved_status ) {
				continue;
			}

			$biz_name = get_user_meta( $dealer->ID, 'carzuri_dealer_business_name', true );
			$phone    = get_user_meta( $dealer->ID, 'carzuri_dealer_phone', true );
			$loc      = get_user_meta( $dealer->ID, 'carzuri_dealer_location', true );
			$reg_no   = get_user_meta( $dealer->ID, 'carzuri_dealer_reg_number', true );
			$desc     = get_user_meta( $dealer->ID, 'carzuri_dealer_description', true );

			$data[] = array(
				'id'                     => $dealer->ID,
				'user_email'             => $dealer->user_email,
				'contact_name'           => $dealer->first_name ? $dealer->first_name : $dealer->display_name,
				'business_name'          => $biz_name ? $biz_name : $dealer->display_name,
				'phone'                  => $phone ? $phone : '',
				'location'               => $loc ? $loc : '',
				'registration_number'    => $reg_no ? $reg_no : '',
				'description'            => $desc ? $desc : '',
				'carzuri_dealer_approved' => $approved_status,
				'status'                 => $approved_status,
			);
		}

		return new WP_REST_Response( $data, 200 );
	}

	/**
	 * Handler: POST /carzuri/v1/dealers/{id}/approve
	 */
	public function approve_dealer( WP_REST_Request $request ) {
		$dealer_id = intval( $request->get_param( 'id' ) );
		$user      = get_userdata( $dealer_id );

		if ( ! $user ) {
			return new WP_Error( 'not_found', __( 'Dealer not found.', 'carzuri-dealer-marketplace' ), array( 'status' => 404 ) );
		}

		Carzuri_Dealer_Admin_Approvals::get_instance()->approve_dealer( $dealer_id );

		return new WP_REST_Response(
			array(
				'success'               => true,
				'message'               => __( 'Dealer approved successfully.', 'carzuri-dealer-marketplace' ),
				'dealer_id'             => $dealer_id,
				'carzuri_dealer_approved' => '1',
			),
			200
		);
	}

	/**
	 * Handler: POST /carzuri/v1/dealers/{id}/reject
	 */
	public function reject_dealer( WP_REST_Request $request ) {
		$dealer_id = intval( $request->get_param( 'id' ) );
		$user      = get_userdata( $dealer_id );

		if ( ! $user ) {
			return new WP_Error( 'not_found', __( 'Dealer not found.', 'carzuri-dealer-marketplace' ), array( 'status' => 404 ) );
		}

		Carzuri_Dealer_Admin_Approvals::get_instance()->reject_dealer( $dealer_id );

		return new WP_REST_Response(
			array(
				'success'               => true,
				'message'               => __( 'Dealer application rejected.', 'carzuri-dealer-marketplace' ),
				'dealer_id'             => $dealer_id,
				'carzuri_dealer_approved' => 'rejected',
			),
			200
		);
	}

	/**
	 * Handler: POST /carzuri/v1/dealers/{id}/resend-approval-email
	 */
	public function resend_dealer_approval_email( WP_REST_Request $request ) {
		$dealer_id = intval( $request->get_param( 'id' ) );
		$user      = get_userdata( $dealer_id );

		if ( ! $user || ! in_array( 'carzuri_dealer', (array) $user->roles, true ) ) {
			return new WP_Error( 'not_found', __( 'Dealer not found.', 'carzuri-dealer-marketplace' ), array( 'status' => 404 ) );
		}

		$approved = get_user_meta( $dealer_id, 'carzuri_dealer_approved', true );
		if ( '1' !== $approved ) {
			return new WP_Error( 'not_approved', __( 'This dealer has not been approved yet.', 'carzuri-dealer-marketplace' ), array( 'status' => 400 ) );
		}

		wp_new_user_notification( $dealer_id, null, 'user' );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => sprintf( __( 'Password setup email resent to %s.', 'carzuri-dealer-marketplace' ), $user->user_email ),
			),
			200
		);
	}

	/**
	 * Handler: GET /carzuri/v1/vehicles-pending
	 *
	 * Accepts an optional ?status= param: 'pending' (default, unchanged
	 * behavior) or 'publish' (to browse already-live vehicles so Admin
	 * Portal can offer an Unpublish action on them).
	 */
	public function get_vehicles_pending( WP_REST_Request $request ) {
		$status_param    = $request->get_param( 'status' );
		$queried_status  = ( 'publish' === $status_param ) ? 'publish' : 'pending';

		$args = array(
			'post_type'      => 'vehicle',
			'post_status'    => $queried_status,
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		$vehicles = get_posts( $args );
		$data     = array();

		foreach ( $vehicles as $vehicle ) {
			$dealer_id = intval( get_post_meta( $vehicle->ID, 'carzuri_dealer_id', true ) );
			$biz_name  = get_user_meta( $dealer_id, 'carzuri_dealer_business_name', true );
			if ( ! $biz_name ) {
				$dealer_user = get_userdata( $dealer_id );
				$biz_name    = $dealer_user ? $dealer_user->display_name : '';
			}

			$makes     = wp_get_object_terms( $vehicle->ID, 'vehicle_make' );
			$make_name = ! empty( $makes ) && ! is_wp_error( $makes ) ? $makes[0]->name : '';

			$bodies    = wp_get_object_terms( $vehicle->ID, 'vehicle_body_type' );
			$body_name = ! empty( $bodies ) && ! is_wp_error( $bodies ) ? $bodies[0]->name : '';

			$locs      = wp_get_object_terms( $vehicle->ID, 'vehicle_location' );
			$loc_name  = ! empty( $locs ) && ! is_wp_error( $locs ) ? $locs[0]->name : '';

			$thumb_url = get_the_post_thumbnail_url( $vehicle->ID, 'medium' );

			$data[] = array(
				'id'                   => $vehicle->ID,
				'title'                => $vehicle->post_title,
				'post_status'          => $vehicle->post_status,
				'dealer_id'            => $dealer_id,
				'dealer_business_name' => $biz_name,
				'price'                => floatval( get_post_meta( $vehicle->ID, 'carzuri_price', true ) ),
				'year'                 => intval( get_post_meta( $vehicle->ID, 'carzuri_year', true ) ),
				'mileage'              => intval( get_post_meta( $vehicle->ID, 'carzuri_mileage', true ) ),
				'condition'            => get_post_meta( $vehicle->ID, 'carzuri_condition', true ),
				'transmission'         => get_post_meta( $vehicle->ID, 'carzuri_transmission', true ),
				'fuel_type'            => get_post_meta( $vehicle->ID, 'carzuri_fuel_type', true ),
				'engine_size'          => get_post_meta( $vehicle->ID, 'carzuri_engine_size', true ),
				'vin'                  => get_post_meta( $vehicle->ID, 'carzuri_vin', true ),
				'registration_number'  => get_post_meta( $vehicle->ID, 'carzuri_registration_number', true ),
				// NOTE: the plain 'location' key (free-text meta) was
				// removed from this response as part of the Location field
				// consolidation. 'location_tax' below (the real taxonomy
				// term) is now the only location value returned here.
				'make'                 => $make_name,
				'body_type'            => $body_name,
				'location_tax'         => $loc_name,
				'featured_image_url'   => $thumb_url ? $thumb_url : '',
				// Previously absent from this response entirely, so the
				// Admin Portal had no way to know or display a vehicle's
				// current Featured status. Normalized to a real boolean
				// here regardless of how the raw meta value was originally
				// stored (wp-admin's checkbox handler saves PHP true/false,
				// which WordPress persists as '1'/'' — not the '1'/'0'
				// pair Core's own REST filter expects — so a loose truthy
				// check is used rather than a strict string comparison).
				'featured'             => (bool) get_post_meta( $vehicle->ID, 'carzuri_featured', true ),
				'created_at'           => $vehicle->post_date,
			);
		}

		return new WP_REST_Response( $data, 200 );
	}

	/**
	 * Handler: POST /carzuri/v1/vehicles/{id}/approve
	 */
	public function approve_vehicle( WP_REST_Request $request ) {
		$vehicle_id = intval( $request->get_param( 'id' ) );
		$post       = get_post( $vehicle_id );

		if ( ! $post || 'vehicle' !== $post->post_type ) {
			return new WP_Error( 'not_found', __( 'Vehicle not found.', 'carzuri-dealer-marketplace' ), array( 'status' => 404 ) );
		}

		$updated = wp_update_post(
			array(
				'ID'          => $vehicle_id,
				'post_status' => 'publish',
			),
			true
		);

		if ( is_wp_error( $updated ) ) {
			return new WP_Error( 'update_failed', $updated->get_error_message(), array( 'status' => 500 ) );
		}

		$dealer_id = intval( get_post_meta( $vehicle_id, 'carzuri_dealer_id', true ) );
		if ( $dealer_id && function_exists( 'carzuri_create_notification' ) ) {
			carzuri_create_notification(
				$dealer_id,
				'vehicle_approved',
				'Vehicle Listing Approved!',
				sprintf( __( 'Your vehicle listing "%s" has been approved and published.', 'carzuri-dealer-marketplace' ), $post->post_title ),
				get_permalink( $vehicle_id )
			);
		}

		return new WP_REST_Response(
			array(
				'success'     => true,
				'message'     => __( 'Vehicle approved and published successfully.', 'carzuri-dealer-marketplace' ),
				'vehicle_id'  => $vehicle_id,
				'post_status' => 'publish',
			),
			200
		);
	}

	/**
	 * Handler: POST /carzuri/v1/vehicles/{id}/reject
	 */
	public function reject_vehicle( WP_REST_Request $request ) {
		$vehicle_id = intval( $request->get_param( 'id' ) );
		$reason     = $request->get_param( 'reason' );
		$post       = get_post( $vehicle_id );

		if ( ! $post || 'vehicle' !== $post->post_type ) {
			return new WP_Error( 'not_found', __( 'Vehicle not found.', 'carzuri-dealer-marketplace' ), array( 'status' => 404 ) );
		}

		$updated = wp_update_post(
			array(
				'ID'          => $vehicle_id,
				'post_status' => 'draft',
			),
			true
		);

		if ( is_wp_error( $updated ) ) {
			return new WP_Error( 'update_failed', $updated->get_error_message(), array( 'status' => 500 ) );
		}

		$sanitized_reason = '';
		if ( null !== $reason && '' !== $reason ) {
			$sanitized_reason = sanitize_textarea_field( $reason );
			update_post_meta( $vehicle_id, 'carzuri_rejection_reason', $sanitized_reason );
		}

		$dealer_id = intval( get_post_meta( $vehicle_id, 'carzuri_dealer_id', true ) );
		if ( $dealer_id && function_exists( 'carzuri_create_notification' ) ) {
			$msg = sprintf( __( 'Your vehicle listing "%s" was rejected.', 'carzuri-dealer-marketplace' ), $post->post_title );
			if ( ! empty( $sanitized_reason ) ) {
				$msg .= ' ' . sprintf( __( 'Reason: %s', 'carzuri-dealer-marketplace' ), $sanitized_reason );
			}
			carzuri_create_notification(
				$dealer_id,
				'vehicle_rejected',
				'Vehicle Listing Rejected',
				$msg,
				''
			);
		}

		return new WP_REST_Response(
			array(
				'success'               => true,
				'message'               => __( 'Vehicle listing rejected.', 'carzuri-dealer-marketplace' ),
				'vehicle_id'            => $vehicle_id,
				'post_status'           => 'draft',
				'carzuri_rejection_reason' => $sanitized_reason,
			),
			200
		);
	}

	/**
	 * Handler: POST /carzuri/v1/vehicles/{id}/unpublish
	 *
	 * Takes a previously-approved (currently published) vehicle down. Reuses
	 * the same post_status -> 'draft' mechanism reject_vehicle() already uses
	 * (proven to correctly hide a vehicle from the public site), but is a
	 * semantically distinct admin action from rejection, with its own
	 * notification type and its own optional reason meta key so the two
	 * cases stay distinguishable if ever inspected later.
	 */
	public function unpublish_vehicle( WP_REST_Request $request ) {
		$vehicle_id = intval( $request->get_param( 'id' ) );
		$reason     = $request->get_param( 'reason' );
		$post       = get_post( $vehicle_id );

		if ( ! $post || 'vehicle' !== $post->post_type ) {
			return new WP_Error( 'not_found', __( 'Vehicle not found.', 'carzuri-dealer-marketplace' ), array( 'status' => 404 ) );
		}

		if ( 'publish' !== $post->post_status ) {
			return new WP_Error(
				'not_published',
				__( 'This vehicle is not currently published, so it cannot be unpublished.', 'carzuri-dealer-marketplace' ),
				array( 'status' => 400 )
			);
		}

		$updated = wp_update_post(
			array(
				'ID'          => $vehicle_id,
				'post_status' => 'draft',
			),
			true
		);

		if ( is_wp_error( $updated ) ) {
			return new WP_Error( 'update_failed', $updated->get_error_message(), array( 'status' => 500 ) );
		}

		$sanitized_reason = '';
		if ( null !== $reason && '' !== $reason ) {
			$sanitized_reason = sanitize_textarea_field( $reason );
			update_post_meta( $vehicle_id, 'carzuri_unpublish_reason', $sanitized_reason );
		}

		$dealer_id = intval( get_post_meta( $vehicle_id, 'carzuri_dealer_id', true ) );
		if ( $dealer_id && function_exists( 'carzuri_create_notification' ) ) {
			$msg = sprintf( __( 'Your vehicle listing "%s" has been taken down by an administrator.', 'carzuri-dealer-marketplace' ), $post->post_title );
			if ( ! empty( $sanitized_reason ) ) {
				$msg .= ' ' . sprintf( __( 'Reason: %s', 'carzuri-dealer-marketplace' ), $sanitized_reason );
			}
			carzuri_create_notification(
				$dealer_id,
				'vehicle_unpublished',
				'Vehicle Listing Unpublished',
				$msg,
				''
			);
		}

		return new WP_REST_Response(
			array(
				'success'                  => true,
				'message'                  => __( 'Vehicle unpublished successfully.', 'carzuri-dealer-marketplace' ),
				'vehicle_id'               => $vehicle_id,
				'post_status'              => 'draft',
				'carzuri_unpublish_reason' => $sanitized_reason,
			),
			200
		);
	}

	/**
	 * Handler: POST /carzuri/v1/vehicles/{id}/toggle-featured
	 *
	 * Flips a vehicle's Featured status. Previously only settable via
	 * wp-admin's post editor checkbox — this exposes the same toggle to
	 * carzuri_admin users in the front-end Admin Portal, where they
	 * actually manage vehicles day-to-day. Normalizes the stored value to
	 * a plain '1'/'0' string on every write, matching what Core's own
	 * /vehicles REST filter (`carzuri_featured` meta_query) expects,
	 * regardless of how the value happened to be stored previously.
	 */
	public function toggle_vehicle_featured( WP_REST_Request $request ) {
		$vehicle_id = intval( $request->get_param( 'id' ) );
		$post       = get_post( $vehicle_id );

		if ( ! $post || 'vehicle' !== $post->post_type ) {
			return new WP_Error( 'not_found', __( 'Vehicle not found.', 'carzuri-dealer-marketplace' ), array( 'status' => 404 ) );
		}

		$currently_featured = (bool) get_post_meta( $vehicle_id, 'carzuri_featured', true );
		$new_featured_state  = ! $currently_featured;

		update_post_meta( $vehicle_id, 'carzuri_featured', $new_featured_state ? '1' : '0' );

		return new WP_REST_Response(
			array(
				'success'    => true,
				'message'    => $new_featured_state
					? __( 'Vehicle marked as Featured.', 'carzuri-dealer-marketplace' )
					: __( 'Vehicle removed from Featured.', 'carzuri-dealer-marketplace' ),
				'vehicle_id' => $vehicle_id,
				'featured'   => $new_featured_state,
			),
			200
		);
	}
}
