<?php
/**
 * Shortcodes class for rendering dealer views.
 *
 * @package Carzuri_Dealer_Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Carzuri_Dealer_Shortcodes {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'carzuri_dealer_registration', array( $this, 'render_registration_form' ) );
		add_shortcode( 'carzuri_dealer_dashboard', array( $this, 'render_dashboard' ) );
		add_shortcode( 'carzuri_dealer_profile', array( $this, 'render_dealer_profile' ) );
		add_shortcode( 'carzuri_dealer_login', array( $this, 'render_login_form' ) );
		add_shortcode( 'carzuri_dealers_directory', array( $this, 'render_dealers_directory' ) );
	}

	/**
	 * Helper function to safely load templates and strip line breaks to defeat wpautop.
	 */
	private function get_template_output( $template_name, $args = array() ) {
		ob_start();
		// Extract arguments so they are available as variables in the template.
		if ( ! empty( $args ) ) {
			extract( $args );
		}

		$template_path = CARZURI_DEALER_DIR . 'templates/' . $template_name . '.php';
		if ( file_exists( $template_path ) ) {
			include $template_path;
		} else {
			echo '<p>Template ' . esc_html( $template_name ) . ' not found.</p>';
		}

		$output = ob_get_clean();
		// CRITICAL LESSON: Strip line breaks to prevent wpautop corruption of JS/HTML.
		return str_replace( array( "\r\n", "\n", "\r" ), '', $output );
	}

	/**
	 * Render Dealer Registration Form shortcode: [carzuri_dealer_registration]
	 */
	public function render_registration_form() {
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			if ( in_array( 'carzuri_dealer', $current_user->roles ) ) {
				return '<div class="carzuri-alert info">' . sprintf( __( 'You are already registered and logged in as a dealer. Access your <a href="%s">Dealer Dashboard</a>.', 'carzuri-dealer-marketplace' ), esc_url( home_url( '/dealer-dashboard' ) ) ) . '</div>';
			} else {
				return '<div class="carzuri-alert info">' . __( 'You are currently logged in with a non-dealer account.', 'carzuri-dealer-marketplace' ) . '</div>';
			}
		}

		// Enqueue JS for registration.
		wp_enqueue_script( 'carzuri-dealer-registration' );

		return $this->get_template_output( 'dealer-registration-form' );
	}

	/**
	 * Render Dealer Login Form shortcode: [carzuri_dealer_login]
	 */
	public function render_login_form() {
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			if ( in_array( 'carzuri_dealer', $current_user->roles ) || in_array( 'administrator', $current_user->roles ) || in_array( 'carzuri_admin', $current_user->roles ) ) {
				$dashboard_url = home_url( '/dealer-dashboard/' );
				global $wpdb;
				$page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_dealer_dashboard]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
				if ( $page_id ) {
					$dashboard_url = get_permalink( $page_id );
				}
				return '<div class="carzuri-alert info" style="padding: 16px; background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; border-radius: 6px; text-align: center; margin: 20px auto; max-width: 600px;">' . sprintf( __( 'You are already logged in. Access your <a href="%s" style="font-weight: 600; color: inherit; text-decoration: underline;">Dealer Dashboard</a>.', 'carzuri-dealer-marketplace' ), esc_url( $dashboard_url ) ) . '</div>';
			} else {
				return '<div class="carzuri-alert info" style="padding: 16px; background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; border-radius: 6px; text-align: center; margin: 20px auto; max-width: 600px;">' . __( 'You are currently logged in with a non-dealer account.', 'carzuri-dealer-marketplace' ) . '</div>';
			}
		}

		// Find registration page URL
		$registration_url = home_url( '/dealer-registration/' );
		global $wpdb;
		$reg_page_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_dealer_registration]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
		if ( $reg_page_id ) {
			$registration_url = get_permalink( $reg_page_id );
		}

		$lost_password_url = wp_lostpassword_url();

		// Enqueue JS for login.
		wp_enqueue_script( 'carzuri-dealer-login' );

		return $this->get_template_output(
			'dealer-login-form',
			array(
				'registration_url'  => $registration_url,
				'lost_password_url' => $lost_password_url,
			)
		);
	}

	/**
	 * Render Dealer Dashboard shortcode: [carzuri_dealer_dashboard]
	 */
	public function render_dashboard() {
		// 1. If not logged in: show a login prompt.
		if ( ! is_user_logged_in() ) {
			$login_url = wp_login_url( get_permalink() );
			return '<div class="carzuri-dashboard-login-gate" style="text-align: center; padding: 48px 24px; border: 1px dashed #ccc; border-radius: 8px;">
				<h3 style="margin-bottom: 12px;">' . esc_html__( 'Dealer Access Required', 'carzuri-dealer-marketplace' ) . '</h3>
				<p style="margin-bottom: 24px; color: #666;">' . esc_html__( 'Please log in to manage your inventory, view leads, and see performance analytics.', 'carzuri-dealer-marketplace' ) . '</p>
				<a href="' . esc_url( $login_url ) . '" class="btn btn-primary" style="background-color: #000; color: #fff; padding: 10px 24px; text-decoration: none; border-radius: 4px; font-weight: 500;">' . esc_html__( 'Log In as Dealer', 'carzuri-dealer-marketplace' ) . '</a>
			</div>';
		}

		$current_user = wp_get_current_user();

		// 2. If logged in but not a carzuri_dealer role: show "This dashboard is for registered dealers only".
		if ( ! in_array( 'carzuri_dealer', $current_user->roles ) && ! in_array( 'administrator', $current_user->roles ) ) {
			return '<div class="carzuri-alert warning" style="padding: 24px; background: #fff3cd; color: #856404; border: 1px solid #ffeeba; border-radius: 6px;">' . esc_html__( 'This dashboard is for registered dealers only.', 'carzuri-dealer-marketplace' ) . '</div>';
		}

		// 3. If pending approval: show pending notice.
		$approval_status = get_user_meta( $current_user->ID, 'carzuri_dealer_approved', true );

		// Admins bypass pending check.
		$is_admin = in_array( 'administrator', $current_user->roles );
		if ( ! $is_admin ) {
			if ( '0' === $approval_status || empty( $approval_status ) ) {
				return '<div class="carzuri-alert pending" style="padding: 32px 24px; background: #fffcf0; border: 1px solid #ffe8a1; border-radius: 6px; text-align: center;">
					<h3 style="color: #b08100; margin-top: 0; margin-bottom: 12px;">' . esc_html__( 'Application Under Review', 'carzuri-dealer-marketplace' ) . '</h3>
					<p style="margin: 0; color: #555;">' . esc_html__( 'Your dealer account is pending admin approval. You will be notified by email once your application has been verified.', 'carzuri-dealer-marketplace' ) . '</p>
				</div>';
			} elseif ( 'rejected' === $approval_status ) {
				return '<div class="carzuri-alert rejected" style="padding: 32px 24px; background: #fdf2f2; border: 1px solid #f8b4b4; border-radius: 6px; text-align: center;">
					<h3 style="color: #9b1c1c; margin-top: 0; margin-bottom: 12px;">' . esc_html__( 'Application Not Approved', 'carzuri-dealer-marketplace' ) . '</h3>
					<p style="margin: 0; color: #7f1d1d;">' . esc_html__( 'Your dealer registration application was not approved. Please contact support for assistance.', 'carzuri-dealer-marketplace' ) . '</p>
				</div>';
			}
		}

		// Enqueue Dashboard assets.
		wp_enqueue_script( 'carzuri-dealer-inventory' );
		wp_enqueue_script( 'carzuri-dealer-leads' );

		// Fetch Analytics Data.
		$dealer_id = $current_user->ID;

		// Active and Sold Vehicle Counts.
		$active_vehicles_query = new WP_Query(
			array(
				'post_type'      => 'vehicle',
				'post_status'    => array( 'publish', 'pending', 'draft' ),
				'posts_per_page' => -1,
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => 'carzuri_dealer_id',
						'value' => $dealer_id,
					),
					array(
						'key'     => 'carzuri_status',
						'value'   => 'sold',
						'compare' => '!=',
					),
				),
			)
		);
		$active_count = $active_vehicles_query->found_posts;

		$sold_vehicles_query = new WP_Query(
			array(
				'post_type'      => 'vehicle',
				'post_status'    => array( 'publish', 'pending', 'draft' ),
				'posts_per_page' => -1,
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => 'carzuri_dealer_id',
						'value' => $dealer_id,
					),
					array(
						'key'   => 'carzuri_status',
						'value' => 'sold',
					),
				),
			)
		);
		$sold_count = $sold_vehicles_query->found_posts;

		// Inquiries from custom table wp_carzuri_inquiries.
		global $wpdb;
		$inquiries_table = $wpdb->prefix . 'carzuri_inquiries';
		
		$total_leads     = 0;
		$converted_leads = 0;
		$leads_data      = array();

		// Check if inquiries table exists.
		$table_check = $wpdb->get_var( "SHOW TABLES LIKE '$inquiries_table'" );
		if ( $table_check ) {
			// Query leads.
			$leads_data = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM $inquiries_table WHERE dealer_id = %d ORDER BY created_at DESC",
					$dealer_id
				),
				ARRAY_A
			);
			$total_leads = count( $leads_data );

			// Filter converted.
			foreach ( $leads_data as $lead ) {
				if ( isset( $lead['status'] ) && 'converted' === $lead['status'] ) {
					$converted_leads++;
				}
			}
		}

		// Pull total views count from carzuri_views_count meta fields.
		$all_dealer_vehicles = new WP_Query(
			array(
				'post_type'      => 'vehicle',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'meta_key'       => 'carzuri_dealer_id',
				'meta_value'     => $dealer_id,
			)
		);

		$total_views = 0;
		if ( $all_dealer_vehicles->have_posts() ) {
			while ( $all_dealer_vehicles->have_posts() ) {
				$all_dealer_vehicles->the_post();
				$views       = get_post_meta( get_the_ID(), 'carzuri_views_count', true );
				$total_views += intval( $views );
			}
			wp_reset_postdata();
		}

		$analytics_args = array(
			'active_count'    => $active_count,
			'sold_count'      => $sold_count,
			'total_leads'     => $total_leads,
			'converted_leads' => $converted_leads,
			'total_views'     => $total_views,
		);

		return $this->get_template_output(
			'dealer-dashboard',
			array(
				'dealer'         => $current_user,
				'analytics'      => $analytics_args,
				'leads'          => $leads_data,
				'inventory_html' => $this->get_template_output( 'dealer-inventory-tab', array( 'dealer_id' => $dealer_id ) ),
				'leads_html'     => $this->get_template_output( 'dealer-leads-tab', array( 'leads' => $leads_data ) ),
				'analytics_html' => $this->get_template_output( 'dealer-analytics-tab', $analytics_args ),
			)
		);
	}

	/**
	 * Render public-facing Dealer Profile shortcode: [carzuri_dealer_profile]
	 */
	public function render_dealer_profile() {
		$dealer_id = isset( $_GET['dealer_id'] ) ? intval( $_GET['dealer_id'] ) : 0;
		if ( ! $dealer_id ) {
			return '<p class="carzuri-error">' . esc_html__( 'No dealer specified.', 'carzuri-dealer-marketplace' ) . '</p>';
		}

		$dealer = get_userdata( $dealer_id );
		if ( ! $dealer || ! in_array( 'carzuri_dealer', $dealer->roles ) ) {
			return '<p class="carzuri-error">' . esc_html__( 'Dealer profile not found.', 'carzuri-dealer-marketplace' ) . '</p>';
		}

		$biz_name = get_user_meta( $dealer_id, 'carzuri_dealer_business_name', true );
		$desc     = get_user_meta( $dealer_id, 'carzuri_dealer_description', true );
		$loc      = get_user_meta( $dealer_id, 'carzuri_dealer_location', true );
		$phone    = get_user_meta( $dealer_id, 'carzuri_dealer_phone', true );
		$whatsapp = get_user_meta( $dealer_id, 'carzuri_dealer_whatsapp', true );

		// Query published vehicles for this dealer.
		$vehicles_query = new WP_Query(
			array(
				'post_type'      => 'vehicle',
				'post_status'    => 'publish',
				'posts_per_page' => 12,
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => 'carzuri_dealer_id',
						'value' => $dealer_id,
					),
					array(
						'key'     => 'carzuri_status',
						'value'     => 'sold',
						'compare' => '!=',
					),
				),
			)
		);

		ob_start();
		?>
		<div class="carzuri-dealer-profile-container" style="max-width: 1200px; margin: 0 auto; padding: 24px 16px; font-family: var(--carzuri-font-sans, 'Inter', sans-serif);">
			<!-- Profile Header Card -->
			<div class="carzuri-profile-header-card" style="background: var(--carzuri-navy-dark, #0b192c); border: 1px solid rgba(212,175,55,0.25); border-radius: 12px; padding: 32px; margin-bottom: 32px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.2);">
				<div class="carzuri-profile-header-grid" style="display: grid; grid-template-columns: 1fr; gap: 24px; align-items: start;">
					<div>
						<h1 style="font-size: 28px; font-weight: 700; margin: 0 0 8px; color: var(--carzuri-white, #ffffff);">
							<?php echo esc_html( $biz_name ? $biz_name : $dealer->display_name ); ?>
						</h1>
						<?php if ( $loc ) : ?>
							<div style="font-size: 14px; color: var(--carzuri-gray-400, #94a3b8); margin-bottom: 12px; display: flex; align-items: center; gap: 6px;">
								<svg style="width: 16px; height: 16px; flex-shrink: 0;" fill="none" stroke="#d4af37" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
								<?php echo esc_html( $loc ); ?>
							</div>
						<?php endif; ?>

						<?php if ( $desc ) : ?>
							<p style="font-size: 15px; line-height: 1.6; color: var(--carzuri-gray-200, #e2e8f0); margin: 16px 0 0;">
								<?php echo esc_html( $desc ); ?>
							</p>
						<?php endif; ?>
					</div>

					<div style="display: flex; flex-direction: column; gap: 10px; align-self: start;">
						<?php if ( $phone ) : ?>
							<div style="background: rgba(255,255,255,0.04); border-radius: 8px; padding: 16px; border: 1px solid rgba(255,255,255,0.08);">
								<div style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--carzuri-gray-400, #94a3b8); font-weight: 600; margin-bottom: 4px;"><?php esc_html_e( 'Contact Dealer', 'carzuri-dealer-marketplace' ); ?></div>
								<a href="tel:<?php echo esc_attr( $phone ); ?>" style="font-size: 18px; font-weight: 700; color: #d4af37 !important; text-decoration: none; display: flex; align-items: center; gap: 8px;">
									<svg style="width: 18px; height: 18px; flex-shrink: 0;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.94.725l.548 2.2a1 1 0 01-.321.988l-1.305.98a10.582 10.582 0 004.872 4.872l.98-1.305a1 1 0 01.988-.321l2.2.548a1 1 0 01.725.94V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
									<?php echo esc_html( $phone ); ?>
								</a>
							</div>
						<?php endif; ?>
						<?php if ( $whatsapp ) : ?>
							<?php $whatsapp_digits = preg_replace( '/[^0-9]/', '', $whatsapp ); ?>
							<a href="https://wa.me/<?php echo esc_attr( $whatsapp_digits ); ?>" target="_blank" rel="noopener noreferrer" style="background: #25D366 !important; border-radius: 8px; padding: 12px 16px; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 14px; font-weight: 700; color: #FFFFFF !important;">
								<svg style="width: 18px; height: 18px; flex-shrink: 0;" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"></path><path d="M12.001 2C6.478 2 2 6.478 2 12c0 1.82.487 3.53 1.334 5.001L2 22l5.152-1.312A9.958 9.958 0 0012.001 22C17.523 22 22 17.523 22 12S17.523 2 12.001 2zm0 18.062a8.049 8.049 0 01-4.108-1.13l-.294-.176-3.06.78.816-2.984-.192-.306a8.043 8.043 0 01-1.235-4.246c0-4.453 3.622-8.075 8.075-8.075 4.452 0 8.074 3.622 8.074 8.075 0 4.452-3.622 8.062-8.076 8.062z"></path></svg>
								<?php esc_html_e( 'Chat on WhatsApp', 'carzuri-dealer-marketplace' ); ?>
							</a>
						<?php endif; ?>
						<?php
						// Message Dealer button, always available regardless of phone/WhatsApp,
						// since it only depends on the dealer's Carzuri account existing.
						// Reuses the Carzuri Messaging plugin's own shortcode rather than
						// duplicating its markup or logic here.
						echo do_shortcode( '[carzuri_message_dealer_button dealer_id="' . intval( $dealer_id ) . '" label="Message Dealer" class="carzuri-profile-message-btn"]' );
						?>
					</div>
				</div>
			</div>

			<!-- Ratings & Reviews Section (reuses the existing, fully-tested Reviews & Dealer Ratings module) -->
			<div class="carzuri-profile-reviews-section" style="margin-bottom: 40px;">
				<?php echo do_shortcode( '[carzuri_dealer_reviews dealer_id="' . intval( $dealer_id ) . '"]' ); ?>
			</div>

			<!-- Inventory Section -->
			<h2 style="font-size: 20px; font-weight: 600; color: var(--carzuri-white, #ffffff); margin-bottom: 24px; border-bottom: 2px solid rgba(212,175,55,0.25); padding-bottom: 12px;">
				<?php esc_html_e( 'Current Inventory', 'carzuri-dealer-marketplace' ); ?>
				<span style="font-size: 14px; font-weight: 400; color: var(--carzuri-gray-400, #94a3b8); margin-left: 8px;">
					(<?php echo esc_html( $vehicles_query->found_posts ); ?> <?php esc_html_e( 'listings', 'carzuri-dealer-marketplace' ); ?>)
				</span>
			</h2>

			<?php if ( $vehicles_query->have_posts() ) : ?>
				<div class="carzuri-vehicles-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 24px;">
					<?php while ( $vehicles_query->have_posts() ) : $vehicles_query->the_post(); ?>
						<!-- Standard vehicle card, styled to match the site's dark navy/gold design system -->
						<div class="vehicle-card" style="background: var(--carzuri-navy-dark, #0b192c); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; overflow: hidden; box-shadow: 0 1px 2px rgba(0,0,0,0.2); transition: transform 0.2s, box-shadow 0.2s;">
							<div class="vehicle-thumbnail" style="height: 180px; background: rgba(255,255,255,0.04); position: relative;">
								<?php if ( has_post_thumbnail() ) : ?>
									<?php the_post_thumbnail( 'medium', array( 'style' => 'width: 100%; height: 100%; object-fit: cover;' ) ); ?>
								<?php else : ?>
									<div style="display: flex; align-items: center; justify-content: center; height: 100%; color: var(--carzuri-gray-400, #94a3b8); font-size: 14px;">No Image</div>
								<?php endif; ?>

								<!-- Year Tag -->
								<?php $year = get_post_meta( get_the_ID(), 'carzuri_year', true ); ?>
								<?php if ( $year ) : ?>
									<span style="position: absolute; top: 12px; left: 12px; background: #d4af37 !important; color: #0b192c !important; font-size: 12px; font-weight: 700; padding: 4px 8px; border-radius: 4px;">
										<?php echo esc_html( $year ); ?>
									</span>
								<?php endif; ?>
							</div>
							<div class="vehicle-details" style="padding: 16px;">
								<h3 style="font-size: 16px; font-weight: 600; margin: 0 0 8px; color: var(--carzuri-white, #ffffff);">
									<a href="<?php the_permalink(); ?>" style="color: inherit; text-decoration: none;"><?php the_title(); ?></a>
								</h3>

								<!-- Specs list -->
								<div style="display: flex; flex-wrap: wrap; gap: 8px; font-size: 12px; color: var(--carzuri-gray-400, #94a3b8); margin-bottom: 12px;">
									<?php 
									$mileage = get_post_meta( get_the_ID(), 'carzuri_mileage', true );
									$transmission = get_post_meta( get_the_ID(), 'carzuri_transmission', true );
									$fuel = get_post_meta( get_the_ID(), 'carzuri_fuel_type', true );
									
									if ( $mileage ) echo '<span>' . esc_html( number_format( $mileage ) ) . ' mi</span> •';
									if ( $transmission ) echo '<span>' . esc_html( $transmission ) . '</span> •';
									if ( $fuel ) echo '<span>' . esc_html( $fuel ) . '</span>';
									?>
								</div>

								<!-- Price -->
								<?php $price = get_post_meta( get_the_ID(), 'carzuri_price', true ); ?>
								<div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid rgba(255,255,255,0.08); padding-top: 12px; margin-top: 12px;">
									<span style="font-size: 18px; font-weight: 700; color: #d4af37 !important;">
										<?php echo $price ? carzuri_format_price( $price ) : 'Contact for Price'; ?>
									</span>
									<a href="<?php the_permalink(); ?>" style="font-size: 13px; font-weight: 600; color: #d4af37 !important; text-decoration: none;">View Details →</a>
								</div>
							</div>
						</div>
					<?php endwhile; wp_reset_postdata(); ?>
				</div>
			<?php else : ?>
				<p style="padding: 40px; text-align: center; color: var(--carzuri-gray-400, #94a3b8); border: 1px dashed rgba(255,255,255,0.1); border-radius: 8px; background: rgba(255,255,255,0.02);">
					<?php esc_html_e( 'This dealer has no active vehicle listings.', 'carzuri-dealer-marketplace' ); ?>
				</p>
			<?php endif; ?>
		</div>
		<?php
		$output = ob_get_clean();
		// CRITICAL LESSON: Strip line breaks to prevent wpautop corruption of JS/HTML.
		return str_replace( array( "\r\n", "\n", "\r" ), '', $output );
	}

	/**
	 * Render public-facing Dealers Directory shortcode: [carzuri_dealers_directory]
	 *
	 * Lists every approved dealer with their vehicle count and aggregate rating
	 * (read directly from wp_carzuri_reviews, same source Reviews & Dealer Ratings
	 * already populates and tests — no new rating logic here), linking each card
	 * into the now-restyled [carzuri_dealer_profile] page.
	 */
	public function render_dealers_directory() {
		global $wpdb;

		// Only ever show dealers the admin has actually approved.
		$dealers = get_users(
			array(
				'role'       => 'carzuri_dealer',
				'meta_key'   => 'carzuri_dealer_approved',
				'meta_value' => '1',
				'orderby'    => 'display_name',
				'order'      => 'ASC',
			)
		);

		// Find the real Dealer Profile page URL (same dynamic-lookup pattern used
		// throughout this project, with a safe fallback to the confirmed slug).
		$profile_base_url = home_url( '/dealer-profile/' );
		$profile_page_id  = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%[carzuri_dealer_profile]%' AND post_status = 'publish' AND post_type = 'page' LIMIT 1" );
		if ( $profile_page_id ) {
			$profile_base_url = get_permalink( $profile_page_id );
		}

		$reviews_table = $wpdb->prefix . 'carzuri_reviews';

		ob_start();
		?>
		<div class="carzuri-dealers-directory-container" style="max-width: 1200px; margin: 0 auto; padding: 24px 16px; font-family: var(--carzuri-font-sans, 'Inter', sans-serif);">

			<div style="margin-bottom: 32px; text-align: center;">
				<h1 style="font-size: 26px; font-weight: 700; color: var(--carzuri-white, #ffffff); margin: 0 0 8px;">
					<?php esc_html_e( 'Our Trusted Dealers', 'carzuri-dealer-marketplace' ); ?>
				</h1>
				<p style="font-size: 14.5px; color: var(--carzuri-gray-400, #94a3b8); margin: 0;">
					<?php esc_html_e( 'Every dealer listed here has been verified and approved by Carzuri.', 'carzuri-dealer-marketplace' ); ?>
				</p>
			</div>

			<?php if ( empty( $dealers ) ) : ?>
				<p style="padding: 40px; text-align: center; color: var(--carzuri-gray-400, #94a3b8); border: 1px dashed rgba(255,255,255,0.1); border-radius: 8px; background: rgba(255,255,255,0.02);">
					<?php esc_html_e( 'No approved dealers to show yet. Check back soon.', 'carzuri-dealer-marketplace' ); ?>
				</p>
			<?php else : ?>
				<div class="carzuri-dealers-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 24px;">
					<?php foreach ( $dealers as $dealer ) : ?>
						<?php
						$dealer_id = $dealer->ID;
						$biz_name  = get_user_meta( $dealer_id, 'carzuri_dealer_business_name', true );
						$loc       = get_user_meta( $dealer_id, 'carzuri_dealer_location', true );

						// Live vehicle count (excludes sold, same rule used on the profile page).
						$vehicle_count_query = new WP_Query(
							array(
								'post_type'      => 'vehicle',
								'post_status'    => 'publish',
								'posts_per_page' => 1,
								'fields'         => 'ids',
								'meta_query'     => array(
									'relation' => 'AND',
									array(
										'key'   => 'carzuri_dealer_id',
										'value' => $dealer_id,
									),
									array(
										'key'     => 'carzuri_status',
										'value'   => 'sold',
										'compare' => '!=',
									),
								),
							)
						);
						$vehicle_count = $vehicle_count_query->found_posts;

						// Aggregate rating, read directly from the reviews table.
						$rating_row = $wpdb->get_row(
							$wpdb->prepare(
								"SELECT AVG(rating) as avg_rating, COUNT(*) as review_count FROM $reviews_table WHERE dealer_id = %d",
								$dealer_id
							)
						);
						$avg_rating   = $rating_row && $rating_row->avg_rating ? round( floatval( $rating_row->avg_rating ), 1 ) : 0;
						$review_count = $rating_row ? intval( $rating_row->review_count ) : 0;

						$profile_url = add_query_arg( 'dealer_id', $dealer_id, $profile_base_url );
						?>
						<a href="<?php echo esc_url( $profile_url ); ?>" class="carzuri-dealer-card" style="display: block; background: var(--carzuri-navy-dark, #0b192c); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 24px; text-decoration: none; transition: border-color 0.2s ease, transform 0.2s ease;">
							<h3 style="font-size: 17px; font-weight: 700; color: var(--carzuri-white, #ffffff); margin: 0 0 6px;">
								<?php echo esc_html( $biz_name ? $biz_name : $dealer->display_name ); ?>
							</h3>

							<?php if ( $loc ) : ?>
								<div style="font-size: 13px; color: var(--carzuri-gray-400, #94a3b8); margin-bottom: 14px; display: flex; align-items: center; gap: 5px;">
									<svg style="width: 14px; height: 14px; flex-shrink: 0;" fill="none" stroke="#d4af37" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
									<?php echo esc_html( $loc ); ?>
								</div>
							<?php endif; ?>

							<div style="display: flex; align-items: center; gap: 6px; margin-bottom: 14px;">
								<?php for ( $i = 1; $i <= 5; $i++ ) : ?>
									<span style="color: <?php echo ( $i <= round( $avg_rating ) ) ? '#d4af37' : 'rgba(255,255,255,0.2)'; ?>; font-size: 15px; line-height: 1;">★</span>
								<?php endfor; ?>
								<span style="font-size: 12.5px; color: var(--carzuri-gray-400, #94a3b8); margin-left: 2px;">
									<?php
									if ( $review_count > 0 ) {
										echo esc_html( $avg_rating ) . ' (' . esc_html( $review_count ) . ')';
									} else {
										esc_html_e( 'No reviews yet', 'carzuri-dealer-marketplace' );
									}
									?>
								</span>
							</div>

							<div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid rgba(255,255,255,0.08); padding-top: 14px;">
								<span style="font-size: 12.5px; color: var(--carzuri-gray-400, #94a3b8);">
									<?php
									/* translators: %d: number of vehicles */
									echo esc_html( sprintf( _n( '%d vehicle', '%d vehicles', $vehicle_count, 'carzuri-dealer-marketplace' ), $vehicle_count ) );
									?>
								</span>
								<span style="font-size: 12.5px; font-weight: 600; color: #d4af37;">
									<?php esc_html_e( 'View Profile →', 'carzuri-dealer-marketplace' ); ?>
								</span>
							</div>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

		</div>
		<style>
			.carzuri-dealer-card:hover {
				border-color: rgba(212, 175, 55, 0.4) !important;
				transform: translateY(-2px);
			}
		</style>
		<?php
		$output = ob_get_clean();
		// CRITICAL LESSON: Strip line breaks to prevent wpautop corruption of JS/HTML.
		return str_replace( array( "\r\n", "\n", "\r" ), '', $output );
	}
}

