/**
 * Carzuri Dealer Leads JavaScript Handler
 */
jQuery(document).ready(function($) {
    // Listen to changes on lead status dropdowns
    $('.carzuri-lead-status-select').on('change', function() {
        var $select = $(this);
        var inquiryId = $select.data('id');
        var newStatus = $select.val();

        // Save original styling
        var originalColor = $select.css('border-color');
        $select.css('border-color', '#3b82f6'); // Blue highlight during save
        $select.prop('disabled', true);

        $.ajax({
            url: carzuriDealerData.root_url + 'carzuri/v1/inquiries/' + inquiryId,
            method: 'PATCH',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', carzuriDealerData.nonce);
            },
            data: {
                status: newStatus
            },
            success: function(response) {
                $select.prop('disabled', false);
                if (response.success) {
                    $select.css('border-color', '#10b981'); // Green success flash
                    
                    // Update classes on status badge cell
                    var $badge = $('#carzuri-lead-badge-' + inquiryId);
                    $badge.removeClass('new contacted converted closed')
                          .addClass(newStatus)
                          .text(newStatus.charAt(0).toUpperCase() + newStatus.slice(1));

                    setTimeout(function() {
                        $select.css('border-color', '');
                    }, 1500);
                } else {
                    $select.css('border-color', '#ef4444'); // Red failure flash
                    alert(response.message || 'Could not update lead status.');
                    setTimeout(function() {
                        $select.css('border-color', '');
                    }, 1500);
                }
            },
            error: function(xhr) {
                $select.prop('disabled', false);
                $select.css('border-color', '#ef4444');
                var error = 'An error occurred while updating the status.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    error = xhr.responseJSON.message;
                }
                alert(error);
                setTimeout(function() {
                    $select.css('border-color', '');
                }, 1500);
            }
        });
    });
});
