/**
 * Carzuri Dealer Inventory JavaScript Handler
 */
jQuery(document).ready(function($) {
    // Tab switching logic
    $('.carzuri-dealer-tab-trigger').on('click', function() {
        var targetTab = $(this).data('tab');
        
        // Toggle tabs
        $('.carzuri-dealer-tab-trigger').removeClass('active');
        $(this).addClass('active');

        // Toggle contents
        $('.carzuri-dealer-tab-content').removeClass('active');
        $('#carzuri-tab-' + targetTab).addClass('active');
    });

    // Add Vehicle Modal Toggling
    $('#carzuri-add-vehicle-btn').on('click', function() {
        $('#carzuri-vehicle-modal-title').text('Add New Vehicle');
        $('#carzuri-vehicle-form')[0].reset();
        $('#vehicle_id').val('');
        $('#vehicle_description').val('');
        $('#vehicle_featured_image').prop('required', true);
        $('#featured-image-preview').hide().find('img').attr('src', '');
        $('#gallery-images-preview').empty();
        $('#carzuri-vehicle-modal').fadeIn();
    });

    $('.carzuri-close-modal').on('click', function() {
        $('#carzuri-vehicle-modal').fadeOut();
    });

    // Edit Vehicle Button
    $('.carzuri-edit-vehicle-btn').on('click', function() {
        var $btn = $(this);
        var vehicleId = $btn.data('id');
        
        // Set values in form from button attributes
        $('#vehicle_id').val(vehicleId);
        $('#vehicle_title').val($btn.data('title'));
        $('#vehicle_description').val($btn.data('description'));
        $('#vehicle_price').val($btn.data('price'));
        $('#vehicle_year').val($btn.data('year'));
        $('#vehicle_mileage').val($btn.data('mileage'));
        $('#vehicle_condition').val($btn.data('condition'));
        $('#vehicle_transmission').val($btn.data('transmission'));
        $('#vehicle_fuel_type').val($btn.data('fuel_type'));
        $('#vehicle_engine_size').val($btn.data('engine_size'));
        $('#vehicle_vin').val($btn.data('vin'));
        $('#vehicle_reg_number').val($btn.data('registration_number'));
        
        // Taxonomy dropdowns
        // NOTE: #vehicle_location_meta no longer exists — the free-text
        // location field was removed as part of the Location field
        // consolidation. #vehicle_location_tax (the real taxonomy value)
        // is now the only location field in this form.
        $('#vehicle_make').val($btn.data('make_name') || $btn.data('make_slug') || '');
        $('#vehicle_body_type').val($btn.data('body_type_name') || $btn.data('body_type_slug') || '');
        $('#vehicle_location_tax').val($btn.data('location_name') || $btn.data('location_slug') || '');

        // Reset file uploads during edit
        $('#vehicle_featured_image').val('').prop('required', false);
        $('#featured-image-preview').hide().find('img').attr('src', '');
        $('#vehicle_gallery_images').val('');
        $('#gallery-images-preview').empty();

        $('#carzuri-vehicle-modal-title').text('Edit Vehicle Details');
        $('#carzuri-vehicle-modal').fadeIn();
    });

    // Client-side image validation & preview for Featured Image
    $('#vehicle_featured_image').on('change', function() {
        var file = this.files[0];
        var $preview = $('#featured-image-preview');
        var $img = $('#featured-preview-img');
        
        if (!file) {
            $preview.hide();
            $img.attr('src', '');
            return;
        }

        // Validate type
        var validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        if (validTypes.indexOf(file.type) === -1) {
            alert('Error: Please select a valid image file (JPG, PNG, or WEBP).');
            $(this).val('');
            $preview.hide();
            $img.attr('src', '');
            return;
        }

        // Validate size (5MB = 5 * 1024 * 1024 bytes)
        if (file.size > 5 * 1024 * 1024) {
            alert('Error: The featured image exceeds the maximum size limit of 5MB.');
            $(this).val('');
            $preview.hide();
            $img.attr('src', '');
            return;
        }

        // Show preview
        var reader = new FileReader();
        reader.onload = function(e) {
            $img.attr('src', e.target.result);
            $preview.show();
        };
        reader.readAsDataURL(file);
    });

    // Client-side image validation & preview for Gallery Images
    $('#vehicle_gallery_images').on('change', function() {
        var files = this.files;
        var $previewContainer = $('#gallery-images-preview');
        $previewContainer.empty();

        if (!files || files.length === 0) {
            return;
        }

        var validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        var hasError = false;

        for (var i = 0; i < files.length; i++) {
            var file = files[i];

            // Validate type
            if (validTypes.indexOf(file.type) === -1) {
                alert('Error: "' + file.name + '" is not a valid image. Please select only JPG, PNG, or WEBP images.');
                hasError = true;
                break;
            }

            // Validate size
            if (file.size > 5 * 1024 * 1024) {
                alert('Error: "' + file.name + '" exceeds the 5MB size limit.');
                hasError = true;
                break;
            }

            // Generate preview
            (function(f) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    var $thumbnail = $('<div style="position: relative; width: 80px; height: 80px; border: 1px solid #ddd; border-radius: 4px; overflow: hidden;">' +
                        '<img src="' + e.target.result + '" style="width: 100%; height: 100%; object-fit: cover;">' +
                        '</div>');
                    $previewContainer.append($thumbnail);
                };
                reader.readAsDataURL(f);
            })(file);
        }

        if (hasError) {
            $(this).val('');
            $previewContainer.empty();
        }
    });

    // Form Submission
    $('#carzuri-vehicle-form').on('submit', function(e) {
        e.preventDefault();

        var $form = $(this);
        var $submitBtn = $form.find('button[type="submit"]');
        var originalText = $submitBtn.text();
        $submitBtn.prop('disabled', true).text('Saving...');

        // Build FormData
        var formData = new FormData();
        formData.append('vehicle_id', $('#vehicle_id').val());
        formData.append('title', $('#vehicle_title').val());
        formData.append('description', $('#vehicle_description').val());
        formData.append('price', $('#vehicle_price').val());
        formData.append('year', $('#vehicle_year').val());
        formData.append('mileage', $('#vehicle_mileage').val());
        formData.append('condition', $('#vehicle_condition').val());
        formData.append('transmission', $('#vehicle_transmission').val());
        formData.append('fuel_type', $('#vehicle_fuel_type').val());
        formData.append('engine_size', $('#vehicle_engine_size').val());
        formData.append('vin', $('#vehicle_vin').val());
        formData.append('registration_number', $('#vehicle_reg_number').val());
        // NOTE: the free-text 'location' field/param was removed as part of
        // the Location field consolidation — vehicle_location (the real
        // taxonomy, appended below) is now the only location value sent.
        
        // Taxonomies
        formData.append('vehicle_make', $('#vehicle_make').val());
        formData.append('vehicle_body_type', $('#vehicle_body_type').val());
        formData.append('vehicle_location', $('#vehicle_location_tax').val());

        // Featured image
        var featuredFile = $('#vehicle_featured_image')[0].files[0];
        if (featuredFile) {
            formData.append('featured_image', featuredFile);
        }

        // Gallery images
        var galleryFiles = $('#vehicle_gallery_images')[0].files;
        if (galleryFiles && galleryFiles.length > 0) {
            for (var i = 0; i < galleryFiles.length; i++) {
                formData.append('gallery_images[]', galleryFiles[i]);
            }
        }

        $.ajax({
            url: carzuriDealerData.root_url + 'carzuri/v1/dealer-vehicles',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', carzuriDealerData.nonce);
            },
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    alert(response.message);
                    window.location.reload();
                } else {
                    alert(response.message || 'Error saving vehicle.');
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            },
            error: function(xhr) {
                var error = 'An error occurred while saving.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    error = xhr.responseJSON.message;
                }
                alert(error);
                $submitBtn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Mark Vehicle as Sold
    $('.carzuri-sold-vehicle-btn').on('click', function() {
        var $btn = $(this);
        var vehicleId = $btn.data('id');

        if (!confirm('Are you sure you want to mark this vehicle as Sold?')) {
            return;
        }

        $btn.prop('disabled', true).text('Updating...');

        $.ajax({
            url: carzuriDealerData.root_url + 'carzuri/v1/dealer-vehicles',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', carzuriDealerData.nonce);
            },
            data: {
                vehicle_id: vehicleId,
                status: 'sold'
            },
            success: function(response) {
                if (response.success) {
                    alert('Vehicle marked as Sold.');
                    window.location.reload();
                } else {
                    alert(response.message || 'Error marking vehicle as sold.');
                    $btn.prop('disabled', false).text('Mark Sold');
                }
            },
            error: function(xhr) {
                alert('Could not update vehicle status. Please try again.');
                $btn.prop('disabled', false).text('Mark Sold');
            }
        });
    });
});
