/**
 * Carzuri Dealer Login Form JavaScript Handler
 */
jQuery(document).ready(function($) {
    var $form = $('#carzuri-dealer-login-form');
    if ($form.length === 0) {
        return;
    }

    var $messageBox = $('#carzuri-login-message');
    var restRoot = (typeof carzuriDealerLogin !== 'undefined' && carzuriDealerLogin.root_url) ? carzuriDealerLogin.root_url : '/wp-json/';
    var restNonce = (typeof carzuriDealerLogin !== 'undefined' && carzuriDealerLogin.nonce) ? carzuriDealerLogin.nonce : '';

    function showAlert($box, message, type) {
        var bg = type === 'error' ? '#fdf2f2' : (type === 'success' ? '#ecfdf5' : '#eff6ff');
        var color = type === 'error' ? '#9b1c1c' : (type === 'success' ? '#065f46' : '#1e40af');
        var border = type === 'error' ? '#f8b4b4' : (type === 'success' ? '#a7f3d0' : '#bfdbfe');
        $box.css({
            'display': 'block',
            'background': bg,
            'color': color,
            'border': '1px solid ' + border
        }).text(message);
    }

    /**
     * New Device Verification: builds and shows a one-time-code entry step
     * in place of the login form, calling Carzuri Core's shared
     * /carzuri/v1/verify-device endpoint. Built dynamically here rather
     * than as a template addition, since the markup only ever needs to
     * appear for this one flow.
     */
    function showDeviceVerificationStep(userId, remember, redirectUrl) {
        $form.hide();

        var $verifyBlock = $(
            '<div id="carzuri-device-verify-block" style="margin-top: 4px;">' +
                '<div id="carzuri-verify-message" class="carzuri-alert" style="display:none; padding: 12px 16px; border-radius: 6px; margin-bottom: 20px; font-size: 14px;"></div>' +
                '<div class="carzuri-form-group" style="margin-bottom: 18px;">' +
                    '<label for="carzuri_device_code" style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 6px;">Verification Code</label>' +
                    '<input type="text" id="carzuri_device_code" inputmode="numeric" maxlength="6" placeholder="6-digit code" class="carzuri-form-control" style="width: 100%; border: 1px solid #d1d5db; border-radius: 6px; padding: 10px 14px; font-size: 14px; letter-spacing: 2px;">' +
                '</div>' +
                '<button type="button" id="carzuri-verify-code-btn" class="carzuri-btn carzuri-btn-primary" style="width: 100%; font-size: 15px; font-weight: 600; padding: 12px; border-radius: 6px; border: none; cursor: pointer;">Verify & Continue</button>' +
                '<div style="text-align:center; margin-top: 16px;">' +
                    '<span style="font-size: 13px; color: #6b7280;">Didn\'t get a code?</span> ' +
                    '<button type="button" id="carzuri-resend-code-btn" style="background:none; border:none; padding:0; font-size: 13px; font-weight: 600; color: #3b82f6; cursor: pointer;">Resend it</button>' +
                '</div>' +
            '</div>'
        );

        $form.after($verifyBlock);

        var $verifyMsg = $('#carzuri-verify-message');

        $('#carzuri-verify-code-btn').on('click', function() {
            var code = $('#carzuri_device_code').val().trim();
            if (!code) {
                showAlert($verifyMsg, 'Please enter the code we emailed you.', 'error');
                return;
            }

            var $btn = $(this);
            $btn.prop('disabled', true).text('Verifying...');

            $.ajax({
                url: restRoot + 'carzuri/v1/verify-device',
                method: 'POST',
                beforeSend: function(xhr) {
                    if (restNonce) {
                        xhr.setRequestHeader('X-WP-Nonce', restNonce);
                    }
                },
                data: JSON.stringify({ user_id: userId, code: code, remember: remember }),
                contentType: 'application/json',
                success: function(response) {
                    if (response.success) {
                        showAlert($verifyMsg, response.message || 'Verified! Redirecting...', 'success');
                        setTimeout(function() {
                            window.location.href = redirectUrl;
                        }, 800);
                    } else {
                        $btn.prop('disabled', false).text('Verify & Continue');
                        showAlert($verifyMsg, response.message || 'Incorrect code. Please try again.', 'error');
                    }
                },
                error: function(xhr) {
                    $btn.prop('disabled', false).text('Verify & Continue');
                    var error = 'Could not verify the code. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        error = xhr.responseJSON.message;
                    }
                    showAlert($verifyMsg, error, 'error');
                }
            });
        });

        $('#carzuri-resend-code-btn').on('click', function() {
            var $btn = $(this);
            $btn.prop('disabled', true).text('Sending...');

            $.ajax({
                url: restRoot + 'carzuri/v1/verify-device/resend',
                method: 'POST',
                beforeSend: function(xhr) {
                    if (restNonce) {
                        xhr.setRequestHeader('X-WP-Nonce', restNonce);
                    }
                },
                data: JSON.stringify({ user_id: userId }),
                contentType: 'application/json',
                success: function(response) {
                    $btn.prop('disabled', false).text('Resend it');
                    showAlert($verifyMsg, response.message || 'A new code has been sent.', response.success ? 'success' : 'error');
                },
                error: function() {
                    $btn.prop('disabled', false).text('Resend it');
                    showAlert($verifyMsg, 'Could not resend the code. Please try again.', 'error');
                }
            });
        });
    }

    // Handle form submission
    $form.on('submit', function(e) {
        e.preventDefault();

        var $btn = $form.find('button[type="submit"]');
        var originalText = $btn.text();

        // Basic validation
        var username = $('#dealer_username').val().trim();
        var password = $('#dealer_password').val();

        if (!username || !password) {
            showAlert($messageBox, 'Please enter both username/email and password.', 'error');
            return;
        }

        $btn.prop('disabled', true).text('Logging in...');
        $messageBox.hide().text('');

        $.ajax({
            url: carzuriDealerLogin.root_url + 'carzuri/v1/dealer-login',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', carzuriDealerLogin.nonce);
            },
            data: {
                username: username,
                password: password,
                remember: $('#dealer_remember').is(':checked') ? 1 : 0
            },
            success: function(response) {
                if (response.success && response.requires_device_verification) {
                    showAlert($messageBox, response.message || 'Please verify your device to continue.', 'info');
                    showDeviceVerificationStep(response.user_id, response.remember, response.redirect_url || '/dealer-dashboard/');
                    return;
                }

                if (response.success) {
                    showAlert($messageBox, response.message || 'Login successful! Redirecting...', 'success');
                    setTimeout(function() {
                        window.location.href = response.redirect_url;
                    }, 1000);
                } else {
                    showAlert($messageBox, response.message || 'Incorrect email or password.', 'error');
                    $btn.prop('disabled', false).text(originalText);
                }
            },
            error: function(xhr) {
                var errorMsg = 'An error occurred during login. Please try again.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMsg = xhr.responseJSON.message;
                }
                showAlert($messageBox, errorMsg, 'error');
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Handle password toggle
    $('.carzuri-toggle-password').on('click', function() {
        var $btn = $(this);
        var $input = $btn.siblings('input');
        var $eyeIcon = $btn.find('.eye-icon');
        var $eyeOffIcon = $btn.find('.eye-off-icon');

        if ($input.attr('type') === 'password') {
            $input.attr('type', 'text');
            $eyeIcon.hide();
            $eyeOffIcon.show();
        } else {
            $input.attr('type', 'password');
            $eyeIcon.show();
            $eyeOffIcon.hide();
        }
    });
});
