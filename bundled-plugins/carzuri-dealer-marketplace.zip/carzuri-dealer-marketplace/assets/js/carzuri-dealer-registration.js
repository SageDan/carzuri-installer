/**
 * Carzuri Dealer Registration Form JavaScript Handler
 */
jQuery(document).ready(function($) {
    var $form = $('#carzuri-dealer-registration-form');
    if ($form.length === 0) {
        return;
    }

    var $messageBox = $('#carzuri-registration-message');

    $form.on('submit', function(e) {
        e.preventDefault();

        // Clear messages
        $messageBox.hide().removeClass('success error info').html('');

        // Basic validations
        var email = $('#dealer_email').val();
        var businessName = $('#dealer_business_name').val();
        var contactName = $('#dealer_contact_name').val();
        var phone = $('#dealer_phone').val();
        var location = $('#dealer_location').val();

        if (!email || !businessName || !contactName || !phone || !location) {
            $messageBox.addClass('error').html('Please fill in all required fields.').fadeIn();
            return;
        }

        // Disable submit button
        var $submitBtn = $form.find('button[type="submit"]');
        var originalBtnText = $submitBtn.text();
        $submitBtn.prop('disabled', true).text('Submitting...');

        var formData = {
            email: email,
            business_name: businessName,
            contact_name: contactName,
            phone: phone,
            whatsapp: $('#dealer_whatsapp').val(),
            location: location,
            reg_number: $('#dealer_reg_number').val(),
            description: $('#dealer_description').val()
        };

        $.ajax({
            url: carzuriDealerData.root_url + 'carzuri/v1/dealer-registration',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', carzuriDealerData.nonce);
            },
            data: formData,
            success: function(response) {
                if (response.success) {
                    $form.slideUp();
                    $messageBox.addClass('success')
                        .html('<h3 style="margin-top:0;">Application Submitted!</h3><p>' + response.message + '</p>')
                        .fadeIn();
                } else {
                    $messageBox.addClass('error').html(response.message || 'An error occurred during registration.').fadeIn();
                    $submitBtn.prop('disabled', false).text(originalBtnText);
                }
            },
            error: function(xhr) {
                var errorMessage = 'An error occurred. Please try again later.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }
                $messageBox.addClass('error').html(errorMessage).fadeIn();
                $submitBtn.prop('disabled', false).text(originalBtnText);
            }
        });
    });
});
